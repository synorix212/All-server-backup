//index.js

// pm2 start index.js --exp-backoff-restart-delay=100
// pm2 stop index.js

var app = require('express')();
var http = require('http').createServer(app);
var cors = require('cors');
app.use(cors());

const port = 3032;

const cheerio = require('cheerio');
const axios = require('axios');
const jsdom = require("jsdom");
const { JSDOM } = jsdom;

app.get('/profiles', function (req, res) {

    // Use the `get` method of axios with the URL of the ButterCMS documentation page as an argument
    axios.get('https://m.cricbuzz.com/profiles').then((response) => {
  
        let data = response.data;
        const dom = new JSDOM(response.data);

        let playerList = [];

        dom.window.document.querySelectorAll('a.cb-list-item').forEach(link => {
            playerList.push({ playerName: link.text, link: link.href });
        });
        res.send(playerList);
    })

});

app.get('/cricket-stats/player/:id/:name', function (req, res) {

    // Use the `get` method of axios with the URL of the ButterCMS documentation page as an argument
    axios.get('https://m.cricbuzz.com/cricket-stats/player/'+req.params.id+'/'+req.params.name).then((response) => {

        let data = response.data;
        const dom = new JSDOM(response.data);

        let profileData = {
            profileImage: "",
            profileInfo: {
                // name: "",
                // born: "",
                // age: "",
                // teams: "",
                // nickname: "",
                // batStyle: "",
                // bowlStyle: ""
            },
            BattingStatistics: {
                batList: [],
                name: ""
            },
            BowlingStatistics: {
                bowlList: [],
                name: ""
            }
        }

        dom.window.document.querySelectorAll('.cb-list-item').forEach((item, index) => {

            if (index == 2) {
                profileData.profileImage = item.querySelectorAll('.thumbnail img')[0].src;
            }
            if (index == 3) {
                item.querySelectorAll('table tbody tr').forEach((item2, index2) => {

                    let key = null;
                    if (item2.firstElementChild.textContent) {
                        key = item2.firstElementChild.textContent.replace(/\s/g, '');
                    }
                    let value = item2.firstElementChild.nextElementSibling.textContent;

                    if (!key) {
                        key = 'BornDetails';
                    }
                    profileData.profileInfo[key] = value;
                })

            }

            if (index == 4) {

                let key = item.textContent.replace(/\s/g, '');;
                let value = item.textContent;

                profileData.BattingStatistics.name = value;
            }

            if (index == 5) {



                item.querySelectorAll('table tbody tr').forEach((item2, index2) => {

                    let batData = {
                        name: "",
                        test: "",
                        odi: "",
                        t20i: "",
                        ipl: "",

                    }
                    batData.name = item2.firstElementChild.textContent;
                    batData.test = item2.firstElementChild.nextElementSibling.textContent;
                    batData.odi = item2.firstElementChild.nextElementSibling.nextElementSibling.textContent;
                    batData.t20i = item2.firstElementChild.nextElementSibling.nextElementSibling.nextElementSibling.textContent;
                    batData.ipl = item2.firstElementChild.nextElementSibling.nextElementSibling.nextElementSibling.nextElementSibling.textContent;

                    profileData.BattingStatistics.batList.push(batData);

                })

            }

            if (index == 6) {

                let key = item.textContent.replace(/\s/g, '');;
                let value = item.textContent;

                profileData.BowlingStatistics.name = value;
            }

            if (index == 7) {

                item.querySelectorAll('table tbody tr').forEach((item2, index2) => {

                    let bowlData = {
                        name: "",
                        test: "",
                        odi: "",
                        t20i: "",
                        ipl: "",

                    }
                    bowlData.name = item2.firstElementChild.textContent;
                    bowlData.test = item2.firstElementChild.nextElementSibling.textContent;
                    bowlData.odi = item2.firstElementChild.nextElementSibling.nextElementSibling.textContent;
                    bowlData.t20i = item2.firstElementChild.nextElementSibling.nextElementSibling.nextElementSibling.textContent;
                    bowlData.ipl = item2.firstElementChild.nextElementSibling.nextElementSibling.nextElementSibling.nextElementSibling.textContent;

                    profileData.BowlingStatistics.bowlList.push(bowlData);

                })

            }

        });

        res.send(profileData);

    })

});





http.listen(port, function () {
    console.log('listening on *:' + port);
});