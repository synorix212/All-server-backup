
var app = require('express')();
var http = require('http').createServer(app);
var cors = require('cors');
app.use(cors());
var axios = require('axios');
const { json } = require('express');
const { off } = require('process');
const moment = require('moment');

const port = 3036;

app.get('/', (req, res) => {
  res.send('odds Api')
})


let eventDatas = {};
let TimerInteval = 0;
function getAllData() {

  eventList(1);
  eventList(4);
  eventList(2);

}

function startInteval() {
  if (TimerInteval) {
    clearInterval(TimerInteval);
  }

  getAllData();

  TimerInteval = setInterval(() => {
    getAllData();
  }, 60000);
}
startInteval();

function eventList(eventTypeId) {
  var config = {
    method: 'get',
    url: "http://23.106.234.25:8082/sessionApi/eventList/" + eventTypeId
  };

  axios(config)
    .then(function (response) {
      if (response.data.status == 1) {
        response.data.data.forEach(data => {
          data.event.forEach(event => {
            virtualEventOdds(event.eventId);
          });
        });
      }
    })
    .catch(function (error) {
      // console.log(error);

    });
}


function virtualEventOdds(eventId) {
  var config = {
    method: 'get',
    url: "http://23.106.234.25:8081/sessionApi/virtualEventOdds/" + eventId
  };

  axios(config)
    .then(function (response) {
      if (response.data.status == 1) {
        eventDatas[eventId] = response.data;
      }
    })
    .catch(function (error) {
      // console.log(error);

    });
}

function convertMarketsList(data, markets) {
  // console.log(markets)

  let listMarketsFormat = [];
  if (data.data) {
    if (data.data.items) {
      data.data.items.forEach((market) => {
        markets.forEach((market1) => {
          if (market.market_id == market1.marketId) {
            if (market1.slug == "football") {
              market1.slug = "soccer";
            }
            market['marketName'] = market1.marketName;
            market['sportId'] = market1.sportId;
            market['sportName'] = market1.slug;
            market['event_id'] = market1.event_id;

            market.odds.forEach((runner) => {
              market1.runners.forEach((runner1) => {
                if (runner.selectionId == runner1.secId) {
                  runner['runnerName'] = runner1.runnerName;
                }
              });
            });
          }
        });
      });
      data.data.items.forEach((market, index) => {
        if (market) {
          // console.log(market.marketId)

          let marketData = {
            "updatetime": market.lastUpdatedTime,
            "update": "ok",
            "sport": market.sportName,
            "eventId": market.event_id,
            "MarketId": market.market_id,
            "marketName": market.marketName,
            "source": 3,
            "IsMarketDataDelayed": false,
            "Status": market.status,
            "IsInplay": market.inplay,
            "inplay": market.inplay,
            "NumberOfRunners": market.odds.length,
            "NumberOfActiveRunners": market.odds.length,
            "TotalMatched": '10760.00',
            "Runners": [
            ]
          }
          if (market.odds) {
            market.odds.forEach((runner, index) => {

              let availableToBack = [];
              let availableToLay = [];

              if (runner.backPrice1 != '-') {
                availableToBack.push({ price: runner.backPrice1, size: runner.backSize1 })
              }
              if (runner.backPrice2 != '-') {
                availableToBack.push({ price: runner.backPrice2, size: runner.backSize2 })
              }
              if (runner.backPrice3 != '-') {
                availableToBack.push({ price: runner.backPrice3, size: runner.backSize3 })
              }
              if (runner.layPrice1 != '-') {
                availableToLay.push({ price: runner.layPrice1, size: runner.laySize1 })
              }
              if (runner.layPrice2 != '-') {
                availableToLay.push({ price: runner.layPrice2, size: runner.laySize2 })
              }
              if (runner.layPrice3 != '-') {
                availableToLay.push({ price: runner.layPrice3, size: runner.laySize3 })
              }


              let runnerData = {
                "SelectionId": runner.selectionId,
                "runnerName": runner.runnerName,
                "Status": "ACTIVE",
                "LastPriceTraded": '0.00',
                "TotalMatched": 54536,
                "ExchangePrices": {
                  "AvailableToBack": availableToBack,
                  "AvailableToLay": availableToLay
                }
              }

              marketData.Runners.push(runnerData);
            })
          }


          listMarketsFormat.push(marketData)
        }

      });
    }
  }

  return listMarketsFormat;
}

function get_markets_list(handleData, marketIds, markets) {


  var config = {
    method: 'get',
    url: "http://23.106.234.25:8081/apiOdds/rsOddsApi2/" + marketIds
  };

  axios(config)
    .then(function (response) {
      if (response.data.status == 1) {
        handleData(convertMarketsList(response.data, markets));
      }
    })
    .catch(function (error) {
      // console.log(error);
      // handleData(error.message)
      handleData([]);

    });

}

app.get('/api/oddsInplayByEventId/:eventId', function (req, res) {

  let eventId = req.params.eventId;

  // console.log(eventDatas[eventId])
  let marketIds = [];
  let markets = [];
  if (eventDatas[eventId]) {
    if (eventDatas[eventId].data) {
      if (eventDatas[eventId].data.otherMarket) {
        eventDatas[eventId].data.otherMarket.forEach(market => {
          markets.push(market);
          marketIds.push(market.marketId)
        });
      }
      if (eventDatas[eventId].data.sportId == 1) {
        if (eventDatas[eventId].data.goalsMaker) {
          eventDatas[eventId].data.goalsMaker.forEach(market => {
            market['marketId'] = market.market_id;
            markets.push(market);
            marketIds.push(market.marketId)
          });
        }
      }
    }
  }

  // console.log(markets)
  get_markets_list(function (data) {
    res.send(data);
  }, marketIds, markets)

});


http.listen(port, function () {
  console.log('listening on *:' + port);
});