var crypto = require('crypto')

// Merchant Code= SKU20230217023140
// API Key= fB8nPEBXHodH2wMRe2s3Fw%3D%3D
// Secret Key= cTtuOWHyZI4lAl1xQ%2B7aPANJHxPsbr6Akd6nEx5kHbI%3D

const apikey = "fB8nPEBXHodH2wMRe2s3Fw%3D%3D"
const secretkey = "cTtuOWHyZI4lAl1xQ%2B7aPANJHxPsbr6Akd6nEx5kHbI%3D"


const encrypt_decrypt = (action, data) => {
    const encryptionMethod = "AES-256-CBC"

    const key = crypto.createHash('sha256').update(apikey).digest()
    const iv = crypto.createHash('sha256').update(secretkey, 'utf8').digest('hex').substring(0, 16)

    if (action == "encrypt") {
        const cipher = crypto.createCipheriv(encryptionMethod, key, iv)
        const res = encodeURIComponent(Buffer.from(
            cipher.update(data, 'utf8', 'base64') + cipher.final('base64')
        ).toString())
        // console.log(res)
        return res
    } else if (action == "decrypt") {
        const buff = decodeURIComponent(Buffer.from(data))
        const decipher = crypto.createDecipheriv(encryptionMethod, key, iv)
        const res = (
            decipher.update(buff.toString('utf8'), 'base64', 'utf8') +
            decipher.final('utf8')
        )
        // console.log(res)
        return res
    }

}
// https://staging.s88pay.net/SKU20230217023140/v2/dopayment?key=

let pay_req = "currency_code=INR&merchant_code=SKU20230217023140&merchant_api_key=fB8nPEBXHodH2wMRe2s3Fw%3D%3D&transaction_code=TEST-DP-1677663152&transaction_timestamp=1677835278&payment_code=P006&transaction_amount=1000&user_id=test01"
// example to encrypt data
let encryptData = encrypt_decrypt("encrypt", pay_req);
console.log("After pay_req Encryprtion");
console.log(encryptData);;

let tran_status = "merchant_api_key=fB8nPEBXHodH2wMRe2s3Fw%3D%3D&transaction_code=TEST-DP-1677663152";
encryptData = encrypt_decrypt("encrypt", tran_status);
console.log("After tran_status Encryprtion");
console.log(encryptData);

let merchant_code = "SKU20230217023140";
encryptData = encrypt_decrypt("encrypt", merchant_code);
console.log("After merchant_code Encryprtion");
console.log(encryptData);

let payout_req = '{ "merchant_code": "SKU20230217023140", "transaction_code": "TEST-DP-6355353", "transaction_timestamp": "1677584223", "payout_code": "WI04", "transaction_amount": "1000", "user_id": "1", "currency_code": "INR", "address": "gdgrgrgrewgewgewgrewg", "account_name": "test01" }';
encryptData = encrypt_decrypt("encrypt", payout_req);
console.log("After payout_req Encryprtion");
console.log(encryptData);

encryptData = "Fi5U%2BTxM99uQSikCgMbCEfTia4uW92%2FklnicXAWC202qECBcVU%2Fujx0%2FE0w7oZIrkL9OiRAbS11GtfxSlsUWDd7kUgJMeGervGRlD94lNIVjA%2BB%2FXIqKLRT0G12uRhaV1zrU19agjmvwnDixXTnFLzCXoerCxrRdq4sMnPo2Ddv00mCGzsZP0tBA1mADTal8KwVhs0r4dXt7H4Uc5XgTcaQmj8VTePvzzES7Z3h9kIPAw9lwdWThxfB8uQa%2B6vIryMTczjLVmQK0m9Go3TZmQg%3D%3D"

let get_pay_req = encrypt_decrypt("decrypt", encryptData);
console.log(get_pay_req)