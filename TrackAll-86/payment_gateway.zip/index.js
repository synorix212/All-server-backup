
// https://stackabuse.com/building-a-rest-api-with-node-and-express/

const express = require('express')();
var https = require('https');
var fs = require('fs');

const bodyParser = require('body-parser');
const cors = require('cors');

// let app = express();

const port = 58700;
var crypto = require('crypto');
// const sql = require('mssql')
var axios = require('axios');

express.use(cors());
express.use(bodyParser.urlencoded({ extended: false }));
express.use(bodyParser.json());

var options = {
    key: fs.readFileSync('../ssl_api_server/ssl/streamingtv.fun/streamingtv.fun-key.pem'),
    cert: fs.readFileSync('../ssl_api_server/ssl/streamingtv.fun/streamingtv.fun-crt.pem'),
    ca: fs.readFileSync('../ssl_api_server/ssl/streamingtv.fun/streamingtv.fun-chain.pem'),
}

app = https.createServer(options, express);



// const apikey = "fB8nPEBXHodH2wMRe2s3Fw%3D%3D";
// const secretkey = "cTtuOWHyZI4lAl1xQ%2B7aPANJHxPsbr6Akd6nEx5kHbI%3D";
// const authorization = "808B2F12A7A097D295CEE38F244D03DC";


// let currency_code = "INR";
// let merchant_code = " SKU20230217023140";
// let payment_code = "P006";
// let payout_code = "WI04";


const apikey = "SsKhk0gwH%2BIsYfnnPGN3FQ%3D%3D";
const secretkey = "A7nDRww1Ur1MRG7Jsi5QqQEs2pTpGySptXn%2FTjRBIo8%3D";
const authorization = " E260B461211A0EFE7CA5EA07B4163411";

let currency_code = "BDT";
let merchant_code = "SKU20230217023228";
let payment_code = "EPAY01D";
let payout_code = "EPAY01W";

let payamentUrl = "https://staging.s88pay.net/" + merchant_code + "/v2/dopayment?key=";


const encrypt_decrypt = (action, data) => {
    const encryptionMethod = "AES-256-CBC";

    const key = crypto.createHash('sha256').update(apikey).digest()
    const iv = crypto.createHash('sha256').update(secretkey, 'utf8').digest('hex').substring(0, 16)

    if (action == "encrypt") {
        const cipher = crypto.createCipheriv(encryptionMethod, key, iv)
        const res = encodeURIComponent(Buffer.from(
            cipher.update(data, 'utf8', 'base64') + cipher.final('base64')
        ).toString())
        // console.log(res)
        return res
    } else if (action == "decrypt") {
        const buff = decodeURIComponent(Buffer.from(data))
        const decipher = crypto.createDecipheriv(encryptionMethod, key, iv)
        const res = (
            decipher.update(buff.toString('utf8'), 'base64', 'utf8') +
            decipher.final('utf8')
        )
        // console.log(res)
        return res
    }

}


express.get('/', (req, res) => {
    res.send('Hello World, from express');
});





express.post('/api/Payment/PaymentGatwayLogin', (req, res) => {
    // console.log(req.body);

    // console.log(isNumber(req.body.amount))
    // if(!isNumber(req.body.amount)){
    //     res.send({ "Url":null, "status": { "message": "amount is Required", "code": 1 } })
    // }

    if (!req.body.userName) {
        res.send({ "Url": null, "status": { "message": "userName is Required", "code": 1 } })
    }
    if (!req.body.userId) {
        res.send({ "Url": null, "status": { "message": "userId is Required", "code": 1 } })
    }
    if (!req.body.parentId) {
        res.send({ "Url": null, "status": { "message": "parentId is Required", "code": 1 } })
    }

    if (!req.body.amount) {
        res.send({ "Url": null, "status": { "message": "amount is Required", "code": 1 } })
    }

    if (!req.body.currencyCode) {
        res.send({ "Url": null, "status": { "message": "currencyCode is Required", "code": 1 } })
    }
    if (parseInt(req.body.amount) < 0) {
        res.send({ "Url": null, "status": { "message": "Deposit amount must be greater than 0", "code": 1 } })
    }
    if (parseInt(req.body.amount) < 1000) {
        res.send({ "Url": null, "status": { "message": "Your deposit amount should be a minimum of 1000", "code": 1 } })
    }
    if (parseInt(req.body.amount) >= 5000000) {
        res.send({ "Url": null, "status": { "message": "Your deposit amount should be a maximum of 5000000", "code": 1 } })
    }



    let transaction_timestamp = (new Date().getTime() / 1000).toFixed(0);
    // console.log(transaction_timestamp)
    let userName = req.body.userName;
    let user_id = req.body.userId;
    let parent_id = req.body.parentId;
    let transaction_amount = req.body.amount;
    let currency_code = req.body.currencyCode;

    let transaction_code = userName + "-DP-" + user_id + "-" + transaction_timestamp;

    let pay_req = "currency_code=" + currency_code + "&merchant_code=" + merchant_code + "&merchant_api_key=" + apikey + "&transaction_code=" + transaction_code + "&transaction_timestamp=" + transaction_timestamp + "&payment_code=" + payment_code + "&transaction_amount=" + transaction_amount + "&user_id=" + parent_id;
    let encryptData = encrypt_decrypt("encrypt", pay_req);

    res.send({ "Url": payamentUrl + encryptData, "status": { "message": "", "code": 0 } })
});

express.post('/api/payment/callback_deposit', (req, res) => {
    // console.log(req.body);
    let encryptData = req.body.key;

    let decryptData = encrypt_decrypt("decrypt", encryptData);
    console.log(decryptData);
    let grab_url = 'https://example.com/?' + decryptData
    // const queryString = window.location.search;
    const urlParams = new URLSearchParams(grab_url);
    // console.log(urlParams.get('transaction_code'));


    // console.log(splitData)
    let currency_code = urlParams.get('currency_code');
    let transaction_code = urlParams.get('transaction_code');
    let transaction_status = urlParams.get('transaction_status');
    let transaction_amount = urlParams.get('transaction_amount');
    let transaction_actual_amount = urlParams.get('transaction_actual_amount');
    let transaction_fee = urlParams.get('transaction_fee');
    let transaction_no = urlParams.get('transaction_no');
    let parent_id = urlParams.get('user_id');

    let splitData = transaction_code.split('-');
    let user_id = splitData[2];
    let username = splitData[0];

    let depositLog = { // store ruth deposit logs
        "status": "2", //Pass 1 if payment success from payment gateway and 2 if payment failed from payment gateway(int)
        "trn_type": "1", //1 for Deposit(int)
        "username": username,
        "coins": transaction_amount,
        "uid": user_id,
        "parentId": parent_id,
        "trn_no": transaction_no,
        "trn_code": transaction_code
    }

    checkTransactionNo(function (respTranNo) {
        console.log("deposit tran no resp= ")
        console.log(respTranNo)

        if (respTranNo.status == "Success") {
            if (respTranNo.alreadyExist == 'false') {
                if (transaction_status == 1) { // Transaction is pending

                }
                if (transaction_status == 2) { // Transaction is completed

                    depositLog.status = 1;

                    let depositReq = {
                        "password": "INRvag@321",
                        "txntype": 1,
                        "mainUserId": parent_id,
                        "users": [
                            {
                                "userId": user_id,
                                "txnType": 1,
                                "amount": transaction_amount,
                                // "amount": 1,

                                "remark": "Fund Auto Transfer",
                                "key": 0,
                                "mainUserId": parent_id
                            }
                        ]
                    }
                    depositAmount(function (resp) {
                        console.log("deposit success coder resp= ")
                        console.log(resp)
                        if (resp.errorCode == 0) {
                            console.log(resp.result[0].result)
                            if (resp.result[0].result == "SUCCESS") {
                                depositToLogs(function (respLog) {
                                    console.log("deposit logs success ruth resp= ")
                                    console.log(respLog)
                                    // res.send(data);
                                    if (respLog.status == "Success") {
                                        res.send({ "status": { "message": "Transaction is completed", "code": 0 } })
                                    } else {
                                        res.send(respLog);
                                    }

                                }, depositLog);
                            } else {
                                res.send(resp);
                            }
                        } else {
                            res.send(resp);
                        }
                    }, depositReq);

                }
                if (transaction_status == 3) { // Transaction is Failed
                    depositLog.status = 2;
                    depositToLogs(function (respLog) {
                        console.log("deposit tranaction failed ruth resp= ")
                        console.log(respLog)
                        if (respLog.status == "Success") {
                            res.send({ "status": { "message": "Transaction is Failed", "code": 1 } })
                        } else {
                            res.send(respLog);
                        }
                    }, depositLog);

                }
            } else {
                res.send({ "status": { "message": "Transaction already completed", "code": 0 } })
            }
        } else {
            res.send(respTranNo);
        }
    }, transaction_no);




});

function depositAmount(handleData, data) {

    var data = JSON.stringify(data);

    var config = {
        method: 'post',
        url: 'https://101010.space/pad=81/transfert',
        headers: {
            'authorization': authorization,
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            handleData(response.data);
            // console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
            // console.log(error);
            handleData(error.message)
        });

}


function depositToLogs(handleDataLogs, data) {
    var data = JSON.stringify(data);

    var config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'https://social.cricbuzzer.io:15552/api/autoDeposit',
        headers: {
            'Content-Type': 'application/json',
            'Origin': 'https://cricbuzzer.io',
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            handleDataLogs(response.data)
            //   console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
            if (error.response.status == 500 || error.response.status == 201) {
                handleDataLogs(error.response.data)
            }
            // console.log(error);

        });


}


function checkTransactionNo(handleTranNo, trn_no) {


    var config = {
        method: 'get',
        maxBodyLength: Infinity,
        url: 'https://social.cricbuzzer.io:15552/api/checkTransactionNo?trn_no=' + trn_no,
        headers: {
            'Origin': 'https://cricbuzzer.io'
        }
    };

    axios(config)
        .then(function (response) {
            handleTranNo(response.data)
            // console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
            // console.log(error);
            handleTranNo(error)
        });



}

express.post('/api/payment/payout_withdraw', (req, res) => {

    // console.log(req.body);

    if (!req.body.userName) {
        res.send({ "Url": null, "status": { "message": "userName is Required", "code": 1 } })
    }
    if (!req.body.userId) {
        res.send({ "Url": null, "status": { "message": "userId is Required", "code": 1 } })
    }
    if (!req.body.parentId) {
        res.send({ "Url": null, "status": { "message": "parentId is Required", "code": 1 } })
    }

    if (!req.body.amount) {
        res.send({ "Url": null, "status": { "message": "amount is Required", "code": 1 } })
    }
    if (!req.body.bank_account_number) {
        res.send({ "Url": null, "status": { "message": "bank_account_number is Required", "code": 1 } })
    }
    if (!req.body.ifsc_code) {
        res.send({ "Url": null, "status": { "message": "ifsc_code is Required", "code": 1 } })
    }
    if (!req.body.bank_name) {
        res.send({ "Url": null, "status": { "message": "bank_name is Required", "code": 1 } })
    }
    if (!req.body.account_name) {
        res.send({ "Url": null, "status": { "message": "account_name is Required", "code": 1 } })
    }

    if (!req.body.currencyCode) {
        res.send({ "Url": null, "status": { "message": "currencyCode is Required", "code": 1 } })
    }
    if (parseInt(req.body.amount) < 0) {
        res.send({ "Url": null, "status": { "message": "Deposit amount must be greater than 0", "code": 1 } })
    }
    if (parseInt(req.body.amount) < 1000) {
        res.send({ "Url": null, "status": { "message": "Your deposit amount should be a minimum of 1000", "code": 1 } })
    }
    if (parseInt(req.body.amount) >= 5000000) {
        res.send({ "Url": null, "status": { "message": "Your deposit amount should be a maximum of 5000000", "code": 1 } })
    }

    let transaction_timestamp = (new Date().getTime() / 1000).toFixed(0);
    let userName = req.body.userName;
    let user_id = req.body.userId;
    let parent_id = req.body.parentId;
    let transaction_amount = req.body.amount;
    let bank_account_number = req.body.bank_account_number;
    let ifsc_code = req.body.ifsc_code;
    let bank_name = req.body.bank_name;
    let account_name = req.body.account_name;
    let currency_code = req.body.currencyCode;

    let transaction_code = userName + "-WD-" + user_id + "-" + transaction_timestamp;



    let pay_req = {
        "merchant_code": merchant_code,
        "transaction_code": transaction_code,
        // "transaction_code": "jammycame05@gmail.com-WD-496400-1678450784",

        "transaction_timestamp": transaction_timestamp,
        "payout_code": payout_code,
        "transaction_amount": transaction_amount,
        "user_id": parent_id,
        "currency_code": currency_code,
        // "address":"gdgrgrgrewgewgewgrewg",
        "bank_account_number": bank_account_number,
        "ifsc_code": ifsc_code,
        "bank_code": "SBIN",
        "bank_name": bank_name,
        "account_name": account_name
    };
    // var data = JSON.stringify(pay_req);

    // let encryptData = encrypt_decrypt("encrypt", data);
    // console.log(encryptData)

    withdrawRequest(function (resp) {
        if (resp.success) {
            res.send({ "status": { "message": resp.message, "code": 0 } })
        } else {
            res.send({ "status": { "message": resp.message, "code": 1 } })
        }
    }, pay_req)

});


function withdrawRequest(handleData, data) {
    var data = JSON.stringify(data);

    let encryptData = encrypt_decrypt("encrypt", data);
    console.log(encryptData)


    var data = JSON.stringify({
        "key": encryptData
    });

    var config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'https://staging.s88pay.net/api/v1/payout/' + merchant_code,
        headers: {
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            console.log(JSON.stringify(response.data));

            handleData(response.data)
        })
        .catch(function (error) {
            console.log(error.response.data);

            handleData(error.response.data)
        });


}

express.post('/api/payment/callback_withdraw', (req, res) => {
    // console.log(req.body);
    let encryptData = req.body.key;

    let decryptData = encrypt_decrypt("decrypt", encryptData);
    console.log(decryptData);

    // if(decryptData){
    //     return;
    // }
    decryptData = JSON.parse(decryptData);
    let currency_code = decryptData.currency_code;
    let transaction_code = decryptData.transaction_code;
    let transaction_status = decryptData.transaction_status;
    let transaction_amount = parseFloat(decryptData.transaction_amount).toFixed(2);
    let transaction_fee = decryptData.transaction_fee;
    let transaction_no = decryptData.transaction_no;
    let parent_id = decryptData.user_id;

    let bank_code = decryptData.bank_code;
    let bank_name = decryptData.bank_name;
    let ifsc_code = decryptData.ifsc_code;
    let bank_account = decryptData.bank_account;
    let bank_account_name = decryptData.bank_account_name;



    let splitData = transaction_code.split('-');
    let user_id = splitData[2];
    let username = splitData[0];

    let withdrawLog = { // store ruth withdraw logs
        "status": "2", //Pass 1 if withdraw success from payment gateway and 2 if withdraw failed from payment gateway(int)
        "trn_type": "2", //1 for withdraw(int)
        "username": username,
        "coins": transaction_amount,
        "uid": user_id,
        "parentId": parent_id,
        "paid_to": bank_account,
        "trn_no": transaction_no,
        "trn_code": transaction_code
    }

    console.log(JSON.stringify(withdrawLog))

    checkTransactionNo(function (respTranNo) {
        console.log("withdraw tran no resp= ")
        console.log(respTranNo)

        if (respTranNo.status == "Success") {
            if (respTranNo.alreadyExist == 'false') {
                if (transaction_status == 1) { // Transaction is pending

                }
                if (transaction_status == 2) { // Transaction is completed

                    withdrawLog.status = 1;

                    withdrawToLogs(function (respLog) {
                        console.log("withdraw logs success ruth resp= ")
                        console.log(respLog)
                        // res.send(data);
                        if (respLog.status == "Success") {
                            res.send({ "status": { "message": "Transaction is completed", "code": 0 } })
                        } else {
                            res.send(respLog);
                        }

                    }, withdrawLog);

                    // let withdrawReq = {
                    //     "password": "INRvag@321",
                    //     "txntype": 2,
                    //     "users": [
                    //         {
                    //             "userId": user_id,
                    //             "txnType": 2,
                    //             "amount": transaction_amount,
                    //             // "amount": 1,

                    //             "remark": "Fund Auto Transfer",
                    //             "key": 0,
                    //             "mainUserId": parent_id
                    //         }
                    //     ]
                    // }
                    // withdrawAmount(function (resp) {
                    //     console.log("withdraw success coder resp= ")
                    //     console.log(resp)
                    //     if (resp.errorCode == 0) {
                    //         console.log(resp.result[0].result)
                    //         if (resp.result[0].result == "SUCCESS") {
                    // withdrawToLogs(function (respLog) {
                    //     console.log("withdraw logs success ruth resp= ")
                    //     console.log(respLog)
                    //     // res.send(data);
                    //     if (respLog.status == "Success") {
                    //         res.send({ "status": { "message": "Transaction is completed", "code": 0 } })
                    //     } else {
                    //         res.send(respLog);
                    //     }

                    // }, withdrawLog);
                    //         } else {
                    //             res.send(resp);
                    //         }
                    //     } else {
                    //         res.send(resp);
                    //     }
                    // }, withdrawReq);

                }
                if (transaction_status == 3) { // Transaction is Failed
                    withdrawLog.status = 2;
                    withdrawToLogs(function (respLog) {
                        console.log(" withdraw tranaction failed ruth resp= ")
                        console.log(respLog)
                        if (respLog.status == "Success") {
                            res.send({ "status": { "message": "Transaction is Failed", "code": 1 } })
                        } else {
                            res.send(respLog);
                        }
                    }, withdrawLog);

                }
            } else {
                res.send({ "status": { "message": "Transaction already completed", "code": 0 } })
            }
        } else {
            res.send(respTranNo);
        }
    }, transaction_no);




});

function withdrawAmount(handleData, data) {
    var data = JSON.stringify(data);

    var config = {
        method: 'post',
        url: 'https://101010.space/pad=81/transfert',
        headers: {
            'authorization': authorization,
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            handleData(response.data);
            // console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
            // console.log(error);
            handleData(error.message)
        });

}


function withdrawToLogs(handleDataLogs, data) {
    var data = JSON.stringify(data);

    var config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'https://social.cricbuzzer.io:15552/api/autoWithdraw',
        headers: {
            'Content-Type': 'application/json',
            'Origin': 'https://cricbuzzer.io',
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            handleDataLogs(response.data)
            //   console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
            console.log(error.response.data)
            if (error.response.status == 500 || error.response.status == 201) {
                handleDataLogs(error.response.data)
            }
            // console.log(error);

        });


}


app.listen(port, () => console.log(`Hello world app listening on port ${port}!`))