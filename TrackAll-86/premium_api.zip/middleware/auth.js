// middleware/auth.js
const jwt = require('jsonwebtoken');

// Use ENV secret if available, fallback to default
const JWT_SECRET = process.env.JWT_SECRET || 'Hello_Jammy';

// Middleware to verify JWT token
module.exports.verifyToken = (req, res, next) => {
    try {
        const authHeader = req.headers['authorization'];

        // Check if the authorization header exists
        if (!authHeader) {
            return res.status(401).json({
                status: "Failed",
                message: "Authorization header missing"
            });
        }

        // Expect header in format "Bearer <token>"
        const [scheme, token] = authHeader.split(' ');

        if (!scheme || scheme.toLowerCase() !== 'bearer' || !token) {
            return res.status(401).json({
                status: "Failed",
                message: "Invalid token format. Use: Bearer <token>"
            });
        }

        // Verify token
        const decoded = jwt.verify(token, JWT_SECRET);

        // Attach user data from token payload to request object
        req.user = decoded;

        next(); // Continue to the next middleware or route handler

    } catch (err) {
        console.error("JWT Error:", err.message);

        if (err.name === "TokenExpiredError") {
            return res.status(401).json({
                status: "Failed",
                message: "Token expired. Please login again."
            });
        }

        return res.status(401).json({
            status: "Failed",
            message: "Invalid token"
        });
    }
};

// Middleware to authorize user based on allowed user types
module.exports.authorize = (allowedUsertypes) => {
    return (req, res, next) => {
        if (!req.user || !allowedUsertypes.includes(req.user.usertype)) {
            return res.status(403).json({
                status: "Failed",
                message: "Access denied"
            });
        }
        next();
    };
};
