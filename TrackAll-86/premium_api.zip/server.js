const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const protectedRoutes = require('./routes/protected');
const spbookRoutes = require("./routes/spbook");
const spbook_jdRoutes = require("./routes/spbook_jd");
const fancyRoutes = require("./routes/fancy");
const bmRoutes = require("./routes/bm");
const coderRoutes = require("./coder_api/index");
const whitelistRouter = require('./routes/whitelist');
const bonusRouter = require('./routes/bonus');




const app = express();

// 🔥 MUST BE BEFORE ROUTES
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

app.use(cors());
app.use(express.json());

app.use('/api', authRoutes);
app.use('/api', protectedRoutes);
app.use("/api", spbookRoutes);
app.use("/api2", fancyRoutes);
app.use("/api", bmRoutes);
app.use("/api3", coderRoutes);
app.use('/api', whitelistRouter);
app.use('/api', bonusRouter);

app.use("/api_jd", spbook_jdRoutes);


app.listen(3033, () => {
    console.log('Server running at http://localhost:3033');
});





// const sql = require("mssql");

// // SQL Server config
// const config = {
//     user: "jammy",
//     password: "Asdf1234",
//     server: "13.235.46.122",     // e.g. localhost or LAPTOP-123\\SQLEXPRESS
//     database: "premium_Fancy2",
//     port: 1433,
//     options: {
//         encrypt: false,              // Windows systems mostly false
//         trustServerCertificate: true
//     }
// };

// // Test connection
// async function testConnection() {
//     try {
//         let pool = await sql.connect(config);
//         console.log("✅ SQL Server Connected Successfully!");
//         let result = await pool.request().query("SELECT 1 AS sessionusers");
//         console.log("Query Result:", result.recordset);
//     } catch (err) {
//         console.error("❌ Connection Failed:", err);
//     }
// }

// testConnection();