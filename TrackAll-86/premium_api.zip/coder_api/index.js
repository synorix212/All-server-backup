const express = require("express");
const moment = require("moment-timezone");
const router = express.Router();
const { verifyToken, authorize } = require("../middleware/auth");

const db1 = require("./db1");  // direct import
const db2 = require("./db2");  // direct import


// Promise wrapper for MySQL query
function q(conn, sql, params = []) {
  return new Promise((resolve, reject) => {
    conn.query(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}


router.get('/premiumBetMarketlist', async function (req, res) {
  try {

    const premiumQuery = `
      SELECT 
        bet.gameId,
        game.sportsName,
        bet.marketName,
        bet.eventId,
        game.eventName,
        game.parentTypeId,
        bet.marketId,
        bet.betTime,
        game.startTime
      FROM vrnlapp.liveBets AS bet
      JOIN vrnlapp.vrnlGames AS game 
        ON bet.gameId = game.gameId
      WHERE bet.consolidateId LIKE 'P-%'
      GROUP BY bet.marketId, bet.eventId
    `;

    // Fetch premium from both DBs
    const [premium1, premium2] = await Promise.all([
      q(db1, premiumQuery).catch(err => { console.error("DB1 premium error:", err); return []; }),
      q(db2, premiumQuery).catch(err => { console.error("DB2 premium error:", err); return []; }),
    ]);

    const premiumCombined = [...premium1, ...premium2];

    if (premiumCombined.length === 0) {
      return res.status(404).json({ message: "No premium data found." });
    }

    premiumCombined.forEach(market => {
      market.betIstTime = moment(market.betTime).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      market.eventDate = market.startTime
        ? moment(market.startTime).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss")
        : null;
    });

    const gameIds1 = [...new Set(premium1.map(b => b.gameId))];
    const gameIds2 = [...new Set(premium2.map(b => b.gameId))];


    const selectionQuery = `
      SELECT gameId, sourceSelId, marketId, selName 
      FROM gameSelction 
      WHERE gameId IN (?)
    `;

    const [sels1, sels2] = await Promise.all([
      q(db1, selectionQuery, [gameIds1]).catch(err => { console.error("DB1 selection error:", err); return []; }),
      q(db2, selectionQuery, [gameIds2]).catch(err => { console.error("DB2 selection error:", err); return []; }),
    ]);

    const allSelections = [...sels1, ...sels2];

    const selKey = s => `${s.gameId}||${s.sourceSelId}||${s.marketId}`;
    const seen = new Set();
    const dedupedSelections = [];

    for (const s of allSelections) {
      const k = selKey(s);
      if (!seen.has(k)) {
        seen.add(k);
        dedupedSelections.push(s);
      }
    }

    // this is combined VRNL and BESTWIZ
    const mergedData = premiumCombined.map(market => {
      const selections = dedupedSelections.filter(sel => sel.gameId == market.gameId && sel.marketId == market.marketId);
      return { ...market, selections };
    });

    //remove duplicate by marketId
    // Deduplicate mergedData by marketId
    const seenMarketIds = new Set();
    const dedupedMergedData = [];

    mergedData.forEach(market => {
      if (!seenMarketIds.has(market.marketId)) {
        seenMarketIds.add(market.marketId);
        dedupedMergedData.push(market);
      }
    });


    res.json({
      totalGames: dedupedMergedData.length,
      data: dedupedMergedData
    });

  } catch (err) {
    console.error("Unexpected Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get('/parlayBetMarketlist', async function (req, res) {
  try {
    // 1️⃣ Fetch parlay bets from DB1
    const queryString = "SELECT consolidateId, betTime, details FROM vrnlapp.liveBets WHERE sportName='parlay';";
    const parlayListRaw = await q(db1, queryString);

    if (!parlayListRaw || parlayListRaw.length === 0) {
      return res.status(404).json({ message: "No parlay bets found." });
    }

    // 2️⃣ Parse all details and flatten
    let parlay_list = parlayListRaw.flatMap(x => JSON.parse(x.details));

    // 3️⃣ Filter out bets with result already set
    parlay_list = parlay_list.filter(bet => !bet.result);

    // 4️⃣ Remove duplicate gameIds
    parlay_list = parlay_list.filter(
      (item, index, self) => index === self.findIndex(t => t.gameId === item.gameId)
    );

    const gameIds = [...new Set(parlay_list.map(b => b.gameId))];

    if (gameIds.length === 0) {
      return res.status(404).json({ message: "No gameIds found." });
    }

    // 5️⃣ Fetch selections for these gameIds
    const selectionQuery = `SELECT gameId, sourceSelId, marketId, selName FROM gameSelction WHERE gameId IN (?)`;
    const selectionsResults = await q(db1, selectionQuery, [gameIds]);

    // 6️⃣ Merge selections into parlay_list by gameId
    const mergedData = parlay_list.map(market => {
      const selections = selectionsResults.filter(sel => sel.gameId == market.gameId);
      return { ...market, selections };
    });

    // 7️⃣ Send JSON response
    res.json({
      totalGames: mergedData.length,
      data: mergedData
    });

  } catch (err) {
    console.error("❌ Error in /api/parlay_bets_games:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get('/fancyBetMarketlist', async function (req, res) {
  try {
    const fancyQuery = `
      SELECT 
        bet.gameId,
        game.sportsName,
        bet.marketName,
        bet.eventId,
        game.oddSource,
        game.eventName,
        bet.marketId,
        bet.betTime,
        game.startTime,
        game.competitionName,
        game.parentMarketId
      FROM vrnlapp.liveBets AS bet
      JOIN vrnlapp.vrnlGames AS game 
        ON bet.gameId = game.gameId
      WHERE bet.isFancy = 1
      GROUP BY bet.marketName, bet.eventId
    `;

    // 1️⃣ Fetch from both DBs
    const [fancy1, fancy2] = await Promise.all([
      q(db1, fancyQuery).catch(err => { console.error("DB1 fancy error:", err); return []; }),
      q(db2, fancyQuery).catch(err => { console.error("DB2 fancy error:", err); return []; }),
    ]);

    // 2️⃣ Combine results
    const fancyCombined = [...fancy1, ...fancy2];

    if (fancyCombined.length === 0) {
      return res.status(404).json({ message: "No fancy markets found." });
    }

    // 3️⃣ Format times and extract sid
    fancyCombined.forEach(market => {
      const str = market.marketId; //"df_1.249300702_43688511_1st"
      const parts = str.split("_");
      const sid = parts[2]; // "43688511"
      market.sid = sid;

      market.betIstTime = moment(market.betTime).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      market.eventDate = market.startTime
        ? moment(market.startTime).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss")
        : null;
    });

    // 4️⃣ Remove duplicate marketId
    const seenMarketIds = new Set();
    const dedupedFancy = fancyCombined.filter(market => {
      if (!seenMarketIds.has(market.marketId)) {
        seenMarketIds.add(market.marketId);
        return true;
      }
      return false;
    });

    // 5️⃣ Send response
    res.json({
      totalGames: dedupedFancy.length,
      data: dedupedFancy
    });

  } catch (err) {
    console.error("Unexpected error in /api/get_fancy_list:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.get('/pendingPremiumEvents', verifyToken, authorize([1, 2, 4]), async function (req, res) {
  const { sportsName } = req.query; // e.g., ?sportsName=cricket or ALL
  try {

    let premiumQuery = `
      SELECT 
        bet.gameId,
        game.sportsName,
        bet.marketName,
        bet.eventId,
        game.eventName,
        bet.marketId,
        bet.betTime,
        game.startTime
      FROM vrnlapp.liveBets AS bet
      JOIN vrnlapp.vrnlGames AS game 
        ON bet.gameId = game.gameId
      WHERE bet.consolidateId LIKE 'P-%'
    `;

    // Add sportsName filter only if provided and not ALL
    if (sportsName && sportsName.toUpperCase() !== 'ALL') {
      premiumQuery += ` AND game.sportsName = '${sportsName}'`;
    }
    // Complete GROUP BY (eventId selected columns)
    premiumQuery += `
     GROUP BY bet.eventId,game.sportsName
   `;

    // Add sportsName filter only if provided and not ALL
    if (sportsName && sportsName.toUpperCase() !== 'ALL') {
      premiumQuery += ` AND game.sportsName = '${sportsName}'`;
    }

    // Fetch premium from both DBs
    const [premium1, premium2] = await Promise.all([
      q(db1, premiumQuery).catch(err => { console.error("DB1 premium error:", err); return []; }),
      q(db2, premiumQuery).catch(err => { console.error("DB2 premium error:", err); return []; }),
    ]);

    const premiumCombined = [...premium1.map(r => ({ ...r, source: 'MainV' })), ...premium2.map(r => ({ ...r, source: 'Bwiz' }))];

    if (premiumCombined.length === 0) {
      return res.status(404).json({ message: "No premium Events data found." });
    }
    const sportMap = {
      cricket: 4,
      soccer: 1,
      tennis: 2
    };
    // Convert times to IST
    premiumCombined.forEach(market => {
      market.sportId = sportMap[market.sportsName] || null;
      market.betIstTime = moment(market.betTime).add(5.5, 'hours');
      market.eventDate = market.startTime
        ? moment(market.startTime).add(5.5, 'hours')
        : null;
      // market.eventDate = market.startTime
      //   ? moment(market.startTime).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss")
      //   : null;
    });

    // Deduplicate by eventId
    const seenEventIds = new Set();
    const dedupedMergedData = [];

    premiumCombined.forEach(event => {
      if (!seenEventIds.has(event.eventId)) {
        seenEventIds.add(event.eventId);
        dedupedMergedData.push(event);
      }
    });

    // Sort by eventDate ascending (earliest first)
    dedupedMergedData.sort((a, b) => {
      if (!a.eventDate) return 1;  // null goes to end
      if (!b.eventDate) return -1;
      return moment(a.eventDate, "YYYY-MM-DD HH:mm:ss").valueOf() -
        moment(b.eventDate, "YYYY-MM-DD HH:mm:ss").valueOf();
    });

    res.json({
      totalGames: dedupedMergedData.length,
      data: dedupedMergedData
    });

  } catch (err) {
    console.error("Unexpected Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get('/pendingParlayEvents', verifyToken, authorize([1, 2, 4]), async function (req, res) {
  try {
    const { sportsName } = req.query; // read sportsName from query params
    // 1️⃣ Fetch parlay bets from DB1
    const queryString = `
      SELECT consolidateId, betTime, details 
      FROM vrnlapp.liveBets 
      WHERE sportName='parlay';
    `;
    const parlayListRaw = await q(db1, queryString);

    if (!parlayListRaw || parlayListRaw.length === 0) {
      return res.status(404).json({ message: "No parlay bets found." });
    }

    // 2️⃣ Parse all details and flatten
    let parlay_list = parlayListRaw.flatMap(x => JSON.parse(x.details));

    // 3️⃣ Filter out bets already settled
    parlay_list = parlay_list.filter(x => !x.result);

    // 4️⃣ Remove duplicate gameIds
    parlay_list = parlay_list.filter(
      (item, index, self) =>
        index === self.findIndex(t => t.gameId === item.gameId)
    );

    // 4️⃣ Remove duplicate eventId
    parlay_list = parlay_list.filter(
      (item, index, self) =>
        index === self.findIndex(t => t.eventId === item.eventId)
    );

    parlay_list.forEach(bet => {
      bet.startTime = moment(bet.startTime).add(5.5, 'hours');
    });

    // 5️⃣ Extract unique eventIds
    let eventIds = parlay_list
      .map(x => x.eventId)
      .filter(x => x !== undefined && x !== null);

    eventIds = [...new Set(eventIds)];

    if (eventIds.length === 0) {
      return res.status(404).json({ message: "No eventIds found." });
    }

    // 6️⃣ Fetch event details from vrnlGames using db1
    const selectionQuery = `
      SELECT gameId, sportsName, eventName, eventId, marketName, marketId, winnerSelId, startTime
      FROM vrnlapp.vrnlGames 
      WHERE eventId IN (?) 
        AND marketName = 'Match Odds'
        AND winnerSelId != 0
    `;

    const eventList = await q(db1, selectionQuery, [eventIds]);

    const eventMap = new Map(eventList.map(e => [String(e.eventId), e]));
    console.log(eventMap);

    parlay_list = parlay_list.map(p => {
      const key = String(p.eventId);            // ensure same type
      const winnerExists = eventMap.has(key);   // correct way to check

      return {
        ...p,
        hasResult: winnerExists
      };
    });


    // 6️⃣ Filter by sportsName if provided
    if (sportsName && sportsName.toUpperCase() !== "ALL") {
      parlay_list = parlay_list.filter(
        x => x.sport && x.sport.toUpperCase() === sportsName.toUpperCase()
      );
    }

    // 7️⃣ Final response
    return res.json({
      totalBets: parlay_list.length,
      data: parlay_list,
      eventList: eventList
    });

  } catch (err) {
    console.error("❌ Error in /pendingParlayEvents:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.get('/pendingFancyEvents', verifyToken, authorize([1, 2, 3]), async function (req, res) {
  try {
    const fancyQuery = `
      SELECT 
        bet.gameId,
        game.sportsName,
        bet.eventId,
        game.marketName,
        game.oddSource,
        game.eventName,
        game.startTime,
        game.competitionName,
        game.parentMarketId
      FROM vrnlapp.liveBets AS bet
      JOIN vrnlapp.vrnlGames AS game 
        ON bet.gameId = game.gameId
      WHERE bet.isFancy = 1
      GROUP BY bet.eventId
    `;
    const fancyIframeQuery = `
    SELECT 
      bet.gameId,
      game.sportsName,
      bet.eventId,
      game.marketName,
      game.oddSource,
      game.eventName,
      game.startTime,
      game.competitionName,
      game.parentMarketId
    FROM vrnlapp.userBetsSky AS bet 
    JOIN vrnlapp.vrnlGames AS game 
      ON bet.gameId = game.gameId 
    WHERE bet.isFancy = 1 and bet.status = 0 
    GROUP BY bet.eventId;
  `;

    // 1️⃣ Fetch from both DBs
    const [fancy1, fancy2, fancy3] = await Promise.all([
      q(db1, fancyQuery).catch(err => { console.error("DB1 fancy error:", err); return []; }),
      q(db2, fancyQuery).catch(err => { console.error("DB2 fancy error:", err); return []; }),
      q(db1, fancyIframeQuery).catch(err => { console.error("DB1 Iframe fancy error:", err); return []; }),

    ]);

    // 2️⃣ Combine results
    const fancyCombined = [...fancy1.map(r => ({ ...r, source: 'MainV' })), ...fancy2.map(r => ({ ...r, source: 'Bwiz' })), ...fancy3.map(r => ({ ...r, source: 'Iframe' }))];

    if (fancyCombined.length === 0) {
      return res.status(404).json({ message: "No fancy Events found." });
    }

    // 3️⃣ Format times and extract sid
    fancyCombined.forEach(market => {
      market.eventDate = market.startTime
        ? moment(market.startTime).add(5.5, 'hours')
        : null;
      // market.eventDate = market.startTime
      //   ? moment(market.startTime).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss")
      //   : null;
    });

    // 4️⃣ Remove duplicate eventId
    const seenEventIds = new Set();
    const dedupedFancyEvent = fancyCombined.filter(event => {
      if (!seenEventIds.has(event.eventId)) {
        seenEventIds.add(event.eventId);
        return true;
      }
      return false;
    });

    // 5️⃣ Send response
    res.json({
      totalGames: dedupedFancyEvent.length,
      data: dedupedFancyEvent
    });

  } catch (err) {
    console.error("Unexpected error in /api/pendingFancyEvents:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.get('/pendingBookmakerEvents', verifyToken, authorize([1, 2]), async function (req, res, next) {
  try {
    const bookmakerQuery = `
      SELECT 
        bet.gameId,
        game.sportsName,
        bet.marketName,
        bet.eventId,
        game.eventName,
        bet.marketId,
        bet.betTime,
        game.startTime
      FROM vrnlapp.liveBets AS bet
      JOIN vrnlapp.vrnlGames AS game 
        ON bet.gameId = game.gameId
      WHERE bet.marketName = 'Bookmaker'
      GROUP BY bet.marketName, bet.eventId
    `;

    // 1️⃣ Fetch markets from both DBs
    const [db1Markets, db2Markets] = await Promise.all([
      q(db1, bookmakerQuery).catch(err => { console.error("DB1 error:", err); return []; }),
      q(db2, bookmakerQuery).catch(err => { console.error("DB2 error:", err); return []; }),
    ]);

    const processMarketTimes = (markets) => {
      markets.forEach(market => {
        market.betIstTime = moment(market.betTime).add(5.5, 'hours');
        market.startTime = market.startTime
          ? moment(market.startTime).add(5.5, 'hours')
          : null;
        market.eventDate = market.startTime;
        // market.betIstTime = moment(market.betTime).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
        // market.eventDate = market.startTime
        //   ? moment(market.startTime).tz("Asia/Kolkata").add(5.5, 'hours').format("YYYY-MM-DD HH:mm:ss")
        //   : null;
      });
      return markets;
    };

    const db1MarketsProcessed = processMarketTimes(db1Markets);
    const db2MarketsProcessed = processMarketTimes(db2Markets);

    // 2️⃣ Fetch selections separately for DB1 and DB2 using q()
    const fetchSelections = async (db, markets) => {
      const gameIds = [...new Set(markets.map(m => m.gameId))];
      if (!gameIds.length) return markets.map(m => ({ ...m, selections: [] }));

      const selectionQuery = `SELECT gameId, sourceSelId, marketId, selName FROM gameSelction WHERE gameId IN (?)`;
      const selectionsResults = await q(db, selectionQuery, [gameIds]).catch(err => {
        console.error("Error fetching selections:", err);
        return [];
      });

      return markets.map(market => {
        const sel = selectionsResults.filter(s => s.gameId == market.gameId);
        return { ...market, selections: sel };
      });
    };

    const [db1Merged, db2Merged] = await Promise.all([
      fetchSelections(db1, db1MarketsProcessed),
      fetchSelections(db2, db2MarketsProcessed),
    ]);

    // 3️⃣ Combine both DBs
    const combinedData = [...db1Merged, ...db2Merged];

    // 4️⃣ Remove duplicate eventId
    const seenEventIds = new Set();
    const dedupedBMEvent = combinedData.filter(event => {
      if (!seenEventIds.has(event.eventId)) {
        seenEventIds.add(event.eventId);
        return true;
      }
      return false;
    });

    // 5️⃣ Send response
    res.json({
      totalGames: dedupedBMEvent.length,
      data: dedupedBMEvent
    });


  } catch (err) {
    console.error("Error in /pendingBookmakerEvents:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.get("/getAwcOperatorsAgents", verifyToken, async (req, res) => {
  try {
    const query = `
          SELECT id,agentId,apiUrl,secretKey,awcCurrency,betLimit
          FROM vrnlapp.awcOperators WHERE awcCurrency IS NOT NULL group by agentid,awcCurrency ORDER BY awcCurrency ASC;
      `;

    const result = await q(db1, query);

    if (!result || result.length === 0) {
      return res.status(404).json({
        status: "Error",
        message: "No Agents Found",
        data: null
      });
    }

    // 🔹 Update/Map before sending response
    const jeffAgents = [
      'vrnlag1', 'vrnlag2', 'vrnlag4', 'vrnlag5', 'vrnlag6', 'vrnlag7', 'vrnlag8', 'vrnlagbdt', 'vrnlagpkr', 'vrnlaginr', 'vrnlagusd'
    ];

    const tuhinAgents = [
      'plyfxag01', 'plyfxag02', 'plyfxag03', 'plyfxag04', 'playfxusd01', 'playfxagbdt'
    ];
    const stageAgents = [
      'stageagt','vrml'
    ];

    const finalData = result.map(item => ({
      ...item,
      agentName: jeffAgents.includes(item.agentId) ? 'JEFF'
        : tuhinAgents.includes(item.agentId) ? 'TUHIN'
          : stageAgents.includes(item.agentId) ? 'STAGING'
            : 'Unknown'
    }));

    res.json({
      status: "Success",
      data: finalData
    });

  } catch (err) {
    console.error("Error in getAwcOperatorsByAgent:", err);
    res.status(500).json({
      status: "Error",
      message: "Internal server error",
      data: null
    });
  }
});

router.get("/balance/:userId", async (req, res) => {
  const { userId } = req.params;

  // ✅ userId validation
  if (isNaN(userId)) {
    return res.status(400).json({
      status: "Error",
      message: "Invalid userId",
    });
  }

  try {
    const query = `
      SELECT balance
      FROM vrnlUsers
      WHERE userId = ?;
    `;

    const result = await q(db1, query, [userId]);

    if (!result || result.length === 0) {
      return res.status(404).json({
        status: "Error",
        message: "User not found",
      });
    }

    return res.json({
      status: "Success",
      balance: result[0].balance
    });

  } catch (err) {
    console.error("Error in balance by userId:", err);
    return res.status(500).json({
      status: "Error",
      message: "Internal server error",
    });
  }
});

router.get("/mapDomains", async (req, res) => {
  try {
    const query = `
    SELECT * FROM vrnlapp.domainsMap;;
      `;

    const result = await q(db1, query);

    if (!result || result.length === 0) {
      return res.status(404).json({
        status: "Error",
        message: "No Domains Found",
        data: null
      });
    }

    res.json({
      status: "Success",
      data: result
    });

  } catch (err) {
    console.error("Error in getAwcOperatorsByAgent:", err);
    res.status(500).json({
      status: "Error",
      message: "Internal server error",
      data: null
    });
  }
});


module.exports = router;
