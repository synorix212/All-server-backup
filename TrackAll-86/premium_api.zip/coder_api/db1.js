// db/db1.js
const mysql = require("mysql");

const db1_config = {
  // host: process.env.DB1_HOST || "vrnl-db-new-readonly.czc8oc2ceggy.ap-south-1.rds.amazonaws.com",
  host: process.env.DB1_HOST || "vrnl-db-new.czc8oc2ceggy.ap-south-1.rds.amazonaws.com",
  user: process.env.DB1_USER || "vrnlappusr",
  password: process.env.DB1_PASS || "okDU6i8csmqdb121!",
  database: process.env.DB1_NAME || "vrnlapp",
  port: 3306,
};

let db1;
let isReconnectingDB1 = false;  // to avoid duplicate reconnect loops

function handleDisconnectDB1() {

  if (isReconnectingDB1) return;
  isReconnectingDB1 = true;

  db1 = mysql.createConnection(db1_config);

  db1.connect((err) => {
    if (err) {
      console.log("❌ DB1 connection error:", err.code || err);
      return setTimeout(() => {
        isReconnectingDB1 = false;
        handleDisconnectDB1();
      }, 2000);
    }

    console.log("✅ DB1 connected successfully!");
    isReconnectingDB1 = false;
  });

  db1.on("error", (err) => {
    console.log("🔥 DB1 ERROR:", err);

    // All fatal errors that require full reconnect
    if (
      err.code === "PROTOCOL_CONNECTION_LOST" ||
      err.code === "ECONNRESET" ||
      err.code === "ETIMEDOUT" ||
      err.code === "EHOSTUNREACH" ||
      err.code === "ECONNREFUSED" ||
      err.code === "PROTOCOL_ENQUEUE_AFTER_FATAL_ERROR" ||
      err.code === "PROTOCOL_PACKETS_OUT_OF_ORDER" ||
      err.fatal
    ) {
      console.log("🛑 DB1 connection lost — reconnecting...");
      isReconnectingDB1 = false;
      return handleDisconnectDB1();
    }

    console.log("⚠ Non-fatal DB1 error:", err);
  });
}

handleDisconnectDB1();

module.exports = db1;

