// db/db2.js
const mysql = require("mysql");

const db2_config = {
    host: process.env.DB1_HOST || "betswiz-db.cp686q8uif6s.ap-south-1.rds.amazonaws.com",
    user: process.env.DB1_USER || "vrnlappusr",
    password: process.env.DB1_PASS || "okDU6i8csmqdb121!",
    database: process.env.DB1_NAME || "vrnlapp",
  port: 3306,
};

let db2;

let isReconnectingDB2 = false;  // prevent multiple reconnect loops

function handleDisconnectDB2() {
  if (isReconnectingDB2) return; // avoid duplicate reconnect attempts
  isReconnectingDB2 = true;

  db2 = mysql.createConnection(db2_config); // same as your original

  db2.connect((err) => {
    if (err) {
      console.log("❌ DB2 connection error:", err.code || err);
      return setTimeout(() => {
        isReconnectingDB2 = false;
        handleDisconnectDB2();
      }, 2000);
    }

    console.log("✅ DB2 connected successfully!");
    isReconnectingDB2 = false;
  });

  db2.on("error", (err) => {
    console.log("🔥 DB2 ERROR:", err);

    // these errors require reconnect
    if (
      err.code === "PROTOCOL_CONNECTION_LOST" ||
      err.code === "ECONNRESET" ||
      err.code === "PROTOCOL_ENQUEUE_AFTER_FATAL_ERROR" ||
      err.code === "PROTOCOL_PACKETS_OUT_OF_ORDER" ||
      err.code === "ETIMEDOUT" ||
      err.code === "EHOSTUNREACH" ||
      err.code === "ECONNREFUSED" ||
      err.fatal
    ) {
      console.log("🛑 DB2 connection lost — reconnecting...");
      isReconnectingDB2 = false;
      return handleDisconnectDB2();
    }

    console.log("⚠ Non-fatal DB2 error:", err);
  });
}

handleDisconnectDB2();

module.exports = db2;
