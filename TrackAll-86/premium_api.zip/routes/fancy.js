const express = require("express");
const fs = require("fs");
const axios = require("axios");
const router = express.Router();
const { sql, poolPromise2 } = require('../db');
const { verifyToken, authorize } = require("../middleware/auth");

// POST /api/AddTKEvent
router.post('/AddTKEvent', async (req, res) => {
    const { eventname, eventid, eventdate, eventtypeid, eventtypename, eventgameid, BfMarketId } = req.body;

    if (!eventname || !eventid || !eventdate) {
        return res.status(400).json({ status: "Error", message: "Missing required fields" });
    }

    try {
        const pool = await poolPromise2;

        // Check if event already exists
        const checkQuery = `
            SELECT * FROM dbo.TKeventlist
            WHERE eventid = @eventid
        `;
        const checkResult = await pool.request()
            .input('eventid', sql.Int, eventid)
            .query(checkQuery);

        if (checkResult.recordset.length > 0) {
            return res.json({ status: "Success", message: "Event Already Exist..." });
        }

        // Insert new event
        const insertQuery = `
            INSERT INTO dbo.TKeventlist (eventname, eventid, eventdate,eventtypeid, eventtypename, eventgameid, BfMarketId)
            VALUES (@eventname, @eventid, @eventdate,@eventtypeid, @eventtypename, @eventgameid, @BfMarketId)
        `;
        await pool.request()
            .input('eventname', sql.VarChar(100), eventname)
            .input('eventid', sql.Int, eventid)
            .input('eventdate', sql.DateTime, new Date(eventdate))
            .input('eventtypeid', sql.Int, eventtypeid || null)
            .input('eventtypename', sql.VarChar(50), eventtypename || null)
            .input('eventgameid', sql.VarChar(50), eventgameid || null)
            .input('BfMarketId', sql.VarChar(50), BfMarketId || null)
            .query(insertQuery);

        return res.json({ status: "Success", message: "Event Added Successfully" });

    } catch (err) {
        console.error('SQL Error:', err);
        return res.status(500).json({ status: "Error", message: "Internal Server Error", error: err.message });
    }
});

// GET /api/GetTKAllevents
router.get('/GetTKAllevents', verifyToken, authorize([1, 2, 3]), async (req, res) => {
    try {
        const pool = await poolPromise2;

        const query = `
            SELECT eventname, eventid, eventdate,eventtypeid, eventtypename,eventgameid, BfMarketId
            FROM dbo.TKeventlist 
            WHERE eventdate >= DATEADD(DAY, -10, GETUTCDATE())
            ORDER BY eventdate DESC
        `;

        const result = await pool.request().query(query);

        return res.json({
            status: "Success",
            data: result.recordset || []
        });

    } catch (err) {
        console.error('SQL Error:', err);
        return res.status(500).json({
            status: "Error",
            message: "Internal Server Error",
            error: err.message
        });
    }
});

// POST /api/AddTKFancy
router.post('/AddTKFancy', async (req, res) => {
    const {
        Fancy,
        Status,
        EventDate,
        Eventname,
        Eventid,
        Result,
        CompititionName,
        type,
        sid,
        gameId,
        BfMarketId
    } = req.body;

    if (!Fancy || Status === undefined || !EventDate || !Eventname || !Eventid || !sid) {
        return res.status(400).json({ status: "Error", message: "Missing required fields" });
    }

    try {
        const pool = await poolPromise2;

        // Check if record already exists for the same Eventid and sid
        const checkQuery = `
            SELECT * FROM dbo.TKsessionlist
            WHERE Eventid = @Eventid AND sid = @sid
        `;
        const checkResult = await pool.request()
            .input('Eventid', sql.Int, Eventid)
            .input('sid', sql.Int, sid)
            .query(checkQuery);

        if (checkResult.recordset.length > 0) {
            return res.json({ status: "Success", message: "Fancy Already Exist..." });
        }

        // Insert new Fancy
        const insertQuery = `
            INSERT INTO dbo.TKsessionlist
            (Fancy, Status, Date, Eventname, Eventid, Result, CompitionName, type, sid, gameId, BfMarketId)
            VALUES
            (@Fancy, @Status, @Date, @Eventname, @Eventid, @Result, @CompititionName, @type, @sid, @gameId, @BfMarketId)
        `;

        await pool.request()
            .input('Fancy', sql.VarChar(50), Fancy)
            .input('Status', sql.Int, Status)
            .input('Date', sql.SmallDateTime, new Date(EventDate))
            .input('Eventname', sql.VarChar(100), Eventname)
            .input('Eventid', sql.Int, Eventid)
            .input('Result', sql.Int, Result || null)
            .input('CompititionName', sql.VarChar(50), CompititionName || null)
            .input('type', sql.TinyInt, type || null)
            .input('sid', sql.Int, sid)
            .input('gameId', sql.VarChar(25), gameId || null)
            .input('BfMarketId', sql.VarChar(50), BfMarketId || null)
            .query(insertQuery);

        return res.json({ status: "Success", message: "Fancy Added Successfully" });

    } catch (err) {
        console.error('SQL Error:', err);
        return res.status(500).json({ status: "Error", message: "Internal Server Error", error: err.message });
    }
});

// GET /api/GetAmanfancyList
// Example: /GetAmanfancyList?status=0&eventid=34987920&source=2
router.get('/GetAmanfancyList', verifyToken, authorize([1, 2, 3]), async (req, res) => {
    try {
        const { status, eventid, source } = req.query;

        const pool = await poolPromise2;

        // Base query
        let query = `SELECT *
                     FROM dbo.TKsessionlist
                     WHERE isBet=1 AND 1=1`; // allows dynamic filters

        const request = pool.request();

        // Apply filters if provided
        if (status !== undefined) {
            query += " AND Status = @status";
            request.input('status', sql.Int, parseInt(status));
        }

        if (eventid) {
            query += " AND Eventid = @eventid";
            request.input('eventid', sql.Int, parseInt(eventid));
        }

        if (source) {
            query += " AND type = @type";
            request.input('type', sql.TinyInt, parseInt(source));
        }

        // Execute query
        const result = await request.query(query);

        return res.json({
            status: "Success",
            data: result.recordset || []
        });

    } catch (err) {
        console.error('SQL Error:', err);
        return res.status(500).json({
            status: "Error",
            message: "Internal Server Error",
            error: err.message
        });
    }
});

// POST /api/updateTKFancyResult
router.post('/updateTKFancyResult', verifyToken, authorize([1, 2, 3]), async (req, res) => {
    const { Id, Status, Result, Settledby, Reversed, Eventid } = req.body;

    if (!Id || Status === undefined || Result === undefined || !Settledby) {
        return res.status(400).json({ status: "Error", message: "Missing required fields" });
    }

    try {
        const pool = await poolPromise2;

        // Check if record exists
        const checkQuery = `
            SELECT * FROM dbo.TKsessionlist
            WHERE Id = @Id
        `;
        const checkResult = await pool.request()
            .input('Id', sql.Int, Id)
            .query(checkQuery);

        if (checkResult.recordset.length === 0) {
            return res.status(404).json({ status: "Error", message: "Fancy Not Found" });
        }

        // Update record
        const updateQuery = `
            UPDATE dbo.TKsessionlist
            SET Status = @Status,
                Result = @Result,
                Settledby = @Settledby,
                Reversed = @Reversed,
                settledTime = GETDATE()
            WHERE Id = @Id
        `;

        const updateResult = await pool.request()
            .input('Id', sql.Int, Id)
            .input('Status', sql.Int, Status)
            .input('Result', sql.Int, Result)
            .input('Settledby', sql.VarChar(25), Settledby)
            .input('Reversed', sql.VarChar(25), Reversed || null)
            .query(updateQuery);

        // Check if any row was actually updated
        if (updateResult.rowsAffected[0] === 0) {
            return res.status(404).json({ status: "Error", message: "No Fancy record found with Id = " + sbid });
        }

        // Determine response message
        let responseMessage;

        if (Status === 2) {
            responseMessage = "Fancy Cancelled Successfully";
        } else if (Reversed && Status === 0) {
            responseMessage = "Fancy Reversed Successfully";
        } else {
            responseMessage = "Fancy Settled Successfully";
        }

        // console.log(checkResult.recordset)

        // 🔥 CALL store_fancy_result API (non-blocking)
        if (checkResult.recordset[0].Eventid && checkResult.recordset[0].Fancy) {
            axios.post("https://sp.vrnlapi.live/api2/store_fancy_result", {
                matchBfId: checkResult.recordset[0].Eventid,
                fancyName: checkResult.recordset[0].Fancy,
                result: Result,
                fsource: checkResult.recordset[0].type,
            })
                .then(() => console.log("store_fancy_result called"))
                .catch(err => console.error("store_fancy_result failed:", err.message));
        }

        return res.json({ status: "Success", result: responseMessage });

    } catch (err) {
        console.error('SQL Error:', err);
        return res.status(500).json({ status: "Error", message: "Internal Server Error", error: err.message });
    }
});

router.post("/updateMarketIsBet", async (req, res) => {
    const { data } = req.body; // [{ Eventid, sid }, ... ]

    if (!data || !Array.isArray(data) || data.length === 0) {
        return res.status(400).json({
            status: "Failed",
            message: "data must be a non-empty array of {Eventid, sid}"
        });
    }

    try {
        const pool = await poolPromise2;

        const updated = [];
        const alreadyUpdated = [];
        const notFound = [];

        // 🔍 Step 1: Build dynamic WHERE clause
        const whereClauses = data.map((d, i) => `(Eventid = ${d.Eventid} AND sid = ${d.sid})`).join(' OR ');

        const result = await pool.request().query(`
            SELECT Eventid, sid, isBet
            FROM TKsessionlist
            WHERE ${whereClauses}
        `);

        const records = result.recordset.map(r => ({
            Eventid: r.Eventid,
            sid: r.sid,
            isBet: r.isBet
        }));

        // 🔎 Step 2: Check status for each combination
        data.forEach(d => {
            const record = records.find(r => r.Eventid == d.Eventid && r.sid == d.sid);

            if (!record) {
                notFound.push(d); // ❌ Combination not found
            } else if (record.isBet === 1) {
                alreadyUpdated.push(d); // ⚠ Already isBet = 1
            }
        });
        // console.log(records)

        // 🔥 Step 3: Update those with isBet IS NULL
        const toUpdate = records.filter(r => r.isBet === null).map(r => `(${r.Eventid}, ${r.sid})`);

        if (toUpdate.length > 0) {
            const updateQuery = `
                UPDATE TKsessionlist
                SET isBet = 1
                WHERE ${toUpdate.map(t => `(Eventid = ${t.split(',')[0].replace('(', '')} AND sid = ${t.split(',')[1].replace(')', '')})`).join(' OR ')}
            `;
            await pool.request().query(updateQuery);
            updated.push(...toUpdate.map(t => ({ Eventid: parseInt(t.split(',')[0].replace('(', '').trim()), sid: parseInt(t.split(',')[1].replace(')', '').trim()) })));
        }

        return res.json({
            status: "Success",
            message: "Fancy isBet update process completed",
            updated,
            alreadyUpdated,
            notFound
        });

    } catch (err) {
        console.error("updateMarketIsBet Error:", err);
        return res.status(500).json({
            status: "Failed",
            message: err.message
        });
    }
});

router.post("/store_fancy_result", express.json(), async (req, res) => {
    try {
        const { matchBfId, fancyName, result, fsource } = req.body;

        // ✅ validations
        if (!matchBfId) {
            return res.send({ result: "MatchBfId is required" });
        }

        if (!fancyName) {
            return res.send({ result: "FancyName is required" });
        }

        // ✅ match id remapping
        let newMatchId = matchBfId;

        const matchMap = {
            "220825080857": "1708260100",
            "220822054223": "1708230017",
        };

        if (matchMap[newMatchId]) {
            newMatchId = matchMap[newMatchId];
        }

        // ✅ clean fancy name
        const cleanFancyName = fancyName
            .replace(/\t/g, " ")
            .replace(/\//g, "_")
            .trim();

        const content = JSON.stringify(result);

        const basePath = "../../store_fancy_result_jammy/";

        // helper function to write file
        const saveFile = (filename) =>
            fs.promises.writeFile(basePath + filename, content);

        const filesToWrite = [];

        // main files
        filesToWrite.push(`${newMatchId}_${cleanFancyName}.json`);
        filesToWrite.push(`${matchBfId}_${cleanFancyName}.json`);

        // with fsource
        if (fsource !== undefined) {
            filesToWrite.push(`${newMatchId}_${fsource}_${cleanFancyName}.json`);
            filesToWrite.push(`${matchBfId}_${fsource}_${cleanFancyName}.json`);
        }

        // special diamond settlement case
        const diamondMatches = ["28102621", "1803131619", "1803152111"];
        if (diamondMatches.includes(newMatchId)) {
            filesToWrite.push(`${newMatchId}_1_${cleanFancyName}.json`);
        }

        // ✅ write all files
        await Promise.all(filesToWrite.map(saveFile));

        res.send({ result: "Result saved!" });

    } catch (err) {
        console.error("File save error:", err);
        res.send({ result: "failed" });
    }
});

// POST /api/updateTKFancyResultAuto
router.post('/updateTKFancyResultAuto', async (req, res) => {
    const { sid, Status, Result, Settledby, Reversed, Eventid } = req.body;

    if (!sid || Status === undefined || Result === undefined || !Settledby) {
        return res.status(400).json({ status: "Error", message: "Missing required fields" });
    }

    try {
        const pool = await poolPromise2;

        // Check if record exists
        const checkQuery = `
            SELECT * FROM dbo.TKsessionlist
            WHERE sid = @sid
        `;
        const checkResult = await pool.request()
            .input('sid', sql.Int, sid)
            .query(checkQuery);

        if (checkResult.recordset.length === 0) {
            return res.status(404).json({ status: "Error", message: "Fancy Not Found" });
        }

        // Update record
        const updateQuery = `
            UPDATE dbo.TKsessionlist
            SET Status = @Status,
                Result = @Result,
                Settledby = @Settledby,
                Reversed = @Reversed,
                settledTime = GETDATE()
            WHERE sid = @sid
        `;

        const updateResult = await pool.request()
            .input('sid', sql.Int, sid)
            .input('Status', sql.Int, Status)
            .input('Result', sql.Int, Result)
            .input('Settledby', sql.VarChar(25), Settledby)
            .input('Reversed', sql.VarChar(25), Reversed || null)
            .query(updateQuery);

        // Check if any row was actually updated
        if (updateResult.rowsAffected[0] === 0) {
            return res.status(404).json({ status: "Error", message: "No Fancy record found with sid = " + sid });
        }

        // Determine response message
        let responseMessage;

        if (Status === 2) {
            responseMessage = "Auto Fancy Cancelled Successfully";
        } else if (Reversed && Status === 0) {
            responseMessage = "Auto Fancy Reversed Successfully";
        } else {
            responseMessage = "Auto Fancy Settled Successfully";
        }

        // console.log(checkResult.recordset)

        // 🔥 CALL store_fancy_result API (non-blocking)
        if (checkResult.recordset[0].Eventid && checkResult.recordset[0].Fancy) {
            axios.post("https://sp.vrnlapi.live/api2/store_fancy_result", {
                matchBfId: checkResult.recordset[0].Eventid,
                fancyName: checkResult.recordset[0].Fancy,
                result: Result,
                fsource: checkResult.recordset[0].type,
            })
                .then(() => console.log("store_fancy_result called"))
                .catch(err => console.error("store_fancy_result failed:", err.message));
        }

        return res.json({ status: "Success", result: responseMessage });

    } catch (err) {
        console.error('SQL Error:', err);
        return res.status(500).json({ status: "Error", message: "Internal Server Error", error: err.message });
    }
});

module.exports = router;
