const express = require("express");
const router = express.Router();
const { sql, poolPromise2 } = require('../db');
const { verifyToken, authorize } = require("../middleware/auth");

// ======= List BM Results =======
router.get("/listBmResults", verifyToken, authorize([1, 2]), async (req, res) => {
    try {
        const pool = await poolPromise2;

        const results = await pool.request()
            .query("SELECT * FROM BMResults WHERE eventDate >= DATEADD(DAY, -15, GETDATE()) ORDER BY eventDate DESC");

        res.json({ status: "Success", data: results.recordset });
    } catch (err) {
        console.error("Error in listBmResults:", err);
        res.status(500).json({ status: "Error", message: "Internal server error" });
    }
});

router.post("/settleBmResult", verifyToken, authorize([1, 2]), async (req, res) => {
    const { eventName, marketId, eventId, result, gameId, runners, settledBy, eventDate } = req.body;

    if (!marketId || result === undefined || !eventName || !gameId || !runners || !settledBy) {
        return res.status(400).json({ status: "Error", message: "Required fields missing" });
    }

    try {
        const pool = await poolPromise2;

        // Check if BM result already exists
        const existing = await pool.request()
            .input("marketId", marketId)
            .query("SELECT * FROM BMResults WHERE marketId = @marketId");

        if (existing.recordset.length > 0) {
            // Already settled, skip
            return res.json({ status: "Skipped", message: "BM Result already settled" });
        }

        // Insert first-time BM result
        await pool.request()
            .input("eventName", eventName)
            .input("marketId", marketId)
            .input("eventId", eventId)
            .input("result", result)
            .input("gameId", gameId)
            .input("runner", runners)
            .input("settledBy", settledBy)
            .input("eventDate", eventDate)          // from payload
            .input("settledTime", new Date())      // server-generated timestamp
            .query(`
                INSERT INTO BMResults 
                (eventName, marketId, eventId, result, gameId, runner,settledBy, eventDate, settledTime) 
                VALUES 
                (@eventName, @marketId, @eventId, @result, @gameId, @runner,@settledBy, @eventDate, @settledTime)
            `);

        // Determine response message
        let responseMessage;
        if (result === -1) {
            responseMessage = "BM Result cancelled successfully";
        } else {
            responseMessage = "BM Result settled successfully";
        }

        res.json({ status: "Success", message: responseMessage });

    } catch (err) {
        console.error("Error in settleBmResult:", err);
        res.status(500).json({ status: "Error", message: "Internal server error" });
    }
});

// ======= Reverse BM Result by result & gameId =======
router.post("/reverseBmResult", verifyToken, authorize([1, 2]), async (req, res) => {
    const { result, gameId, reversedBy } = req.body;

    if (!gameId || !reversedBy) {
        return res.status(400).json({ status: "Error", message: "result, gameId, and reversedBy are required" });
    }

    try {
        const pool = await poolPromise2;

        // Check if BM result exists
        const existing = await pool.request()
            .input("gameId", gameId)
            .query("SELECT * FROM bmResults WHERE gameId = @gameId");

        if (existing.recordset.length === 0) {
            return res.status(404).json({ status: "Error", message: "BM market not found" });
        }

        // Mark as reversed by setting reversedBy and reversedTime
        await pool.request()
            .input("result", result)
            .input("gameId", gameId)
            .input("reversedBy", reversedBy)
            .query(`
                UPDATE bmResults
                SET result=@result,
                    reversedBy = @reversedBy,
                    settledTime = GETDATE()
                WHERE gameId = @gameId
            `);

        // // Determine response message
        // let responseMessage;
        // if (result === -1) {
        //     responseMessage = "BM Result cancelled successfully";
        // } else {
        //     responseMessage = "BM Result settled successfully";
        // }

        // res.json({ status: "Success", message: responseMessage });

        res.json({ status: "Success", message: "Result Reversed Successfully..." });

    } catch (err) {
        console.error("Error in reverseBmResult:", err);
        res.status(500).json({ status: "Error", message: "Internal server error" });
    }
});

router.get("/getBmResults/:gameId", async (req, res) => {
    const { gameId } = req.params;

    try {
        const pool = await poolPromise2;

        const result = await pool.request()
            .input("gameId", gameId)
            .query("SELECT eventId,eventName,marketId,result,gameId,settledTime FROM BMResults WHERE gameId = @gameId AND result IS NOT NULL");

        // ❌ Agar data nahi mila
        if (!result.recordset || result.recordset.length === 0) {
            return res.status(404).json({
                status: "Error",
                message: "No Game Found",
                data: null
            });
        }

        // ✅ Data mil gaya
        return res.json({
            status: "Success",
            data: result.recordset
        });

    } catch (err) {
        console.error("Error in getBmResults:", err);
        return res.status(500).json({
            status: "Error",
            message: "Internal server error",
            data: null
        });
    }
});


module.exports = router;
