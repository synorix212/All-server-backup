const express = require('express');
const router = express.Router();
const { sql, poolPromise1 } = require('../db');
const jwt = require('jsonwebtoken');
const { verifyToken } = require("../middleware/auth");

const JWT_SECRET = process.env.JWT_SECRET || "Hello_Jammy";

// Login API
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const pool = await poolPromise1;

        // Get user by username
        const result = await pool.request()
            .input('username', sql.VarChar, username)
            .query('SELECT * FROM sessionusers WHERE username = @username');

        if (result.recordset.length === 0) {
            return res.status(401).json({ status: "Failed", message: "Invalid username or password" });
        }

        const user = result.recordset[0];

        // Direct password check (plain text check)
        if (password !== user.password) {
            return res.status(401).json({ status: "Failed", message: "Invalid username or password" });
        }

        // Generate JWT with usertype and userrole
        const token = jwt.sign(
            {
                uid: user.uid,
                username: user.username,
                usertype: user.usertype, // ✅ Add usertype
                userrole: user.userrole  // ✅ Add userrole
            },
            JWT_SECRET,
            { expiresIn: '1d' } // 1 day expiry
        );

        // Store token in DB
        await pool.request()
            .input("token", sql.NVarChar, token)
            .input("uid", sql.Int, user.uid)
            .query(`
                UPDATE sessionusers 
                SET token = @token 
                WHERE uid = @uid
            `);

        // Response
        res.json({
            status: "Success",
            message: "Login Successfully",
            token,
            uid: user.uid,
            username: user.username,
            usertype: user.usertype || null,
            userrole: user.userrole || null
        });

    } catch (err) {
        console.error("💥 Login API Error:", err);
        res.status(500).json({ status: "Failed", message: "Server error" });
    }
});

// Logout API
router.post('/logout', verifyToken, (req, res) => {
    // Token invalidation: client-side remove, server-side optional blacklist
    return res.json({ status: '200', message: 'Logout successful. Token expired.' });
});

module.exports = router;
