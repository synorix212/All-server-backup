const express = require("express");
const router = express.Router();
const { sql, poolPromise3 } = require('../db');
const { verifyToken, authorize } = require("../middleware/auth");



router.post("/AddTKEvent", async (req, res) => {
    const { eventname, eventid, eventdate, eventtypeid, eventtypename } = req.body;

    if (!eventname || !eventid || !eventdate || !eventtypeid || !eventtypename) {
        return res.status(400).json({ status: "Failed", message: "All fields are required" });
    }

    try {
        const pool = await poolPromise3;

        // Check if event already exists
        const check = await pool.request()
            .input("eventid", sql.Int, eventid)
            .query("SELECT * FROM TKEventList WHERE eventid = @eventid");

        if (check.recordset.length > 0) {
            return res.json({ status: "Failed", message: "Event already exists" });
        }

        // Insert new event
        await pool.request()
            .input("eventname", sql.VarChar(100), eventname)
            .input("eventid", sql.Int, eventid)
            .input("eventdate", sql.DateTime, eventdate)
            .input("eventtypeid", sql.Int, eventtypeid)
            .input("eventtypename", sql.VarChar(50), eventtypename)
            .query(`
                INSERT INTO TKEventList (eventname, eventid, eventdate, eventtypeid, eventtypename)
                VALUES (@eventname, @eventid, @eventdate, @eventtypeid, @eventtypename)
            `);

        res.json({ status: "Success", message: "Event added successfully" });

    } catch (err) {
        console.error("AddTKEvent Error:", err);
        res.status(500).json({ status: "Failed", message: err.message });
    }
});

router.get("/geteventsbySports/:eventtypeid", verifyToken, authorize([1, 2, 4]), async (req, res) => {
    const { eventtypeid } = req.params;

    if (!eventtypeid) {
        return res.status(400).json({ status: "Failed", message: "EventTypeId is required" });
    }

    try {
        const pool = await poolPromise3;

        const result = await pool.request()
            .input("eventtypeid", sql.Int, eventtypeid)
            .query("SELECT * FROM TKEventList WHERE eventtypeid = @eventtypeid AND eventdate >= DATEADD(DAY, -10, GETUTCDATE()) ORDER BY eventdate DESC");

        res.json({
            status: "Success",
            events: result.recordset
        });

    } catch (err) {
        console.error("geteventsbySports Error:", err);
        res.status(500).json({ status: "Failed", message: err.message });
    }
});

// ek baar me ek market save karega but time lagega jab match bahot jyada hoga hai
router.post("/addSpBook", async (req, res) => {
    const {
        eventName,
        eventDate,
        eventId,
        sbmarketname,
        sbrunners,
        sbmarketid,
        sportType,
        isSrl
    } = req.body;

    try {
        // Use the pool from db.js
        const pool = await poolPromise3;

        // check exist
        const check = await pool.request()
            .input("eventId", sql.Int, eventId)
            .input("sbmarketid", sql.BigInt, sbmarketid)
            .query(`
                SELECT sbmarketid FROM sportsbook 
                WHERE eventId=@eventId AND sbmarketid=@sbmarketid
            `);

        if (check.recordset.length > 0) {
            return res.json({
                status: "Success",
                message: "SB Market is Already Exist..."
            });
        }

        // insert new market
        await pool.request()
            .input("eventName", sql.NVarChar, eventName)
            .input("eventDate", sql.SmallDateTime, eventDate)
            .input("eventId", sql.Int, eventId)
            .input("sbmarketname", sql.NVarChar, sbmarketname)
            .input("sbrunners", sql.NVarChar, sbrunners)
            .input("sbmarketid", sql.BigInt, sbmarketid)
            .input("sportType", sql.SmallInt, sportType)
            .input("isSrl", sql.TinyInt, isSrl)
            .input("status", sql.SmallInt, 0)
            .query(`
                INSERT INTO sportsbook
                (eventName, eventDate, eventId, sbmarketname, sbrunners, sbmarketid, sportType, isSrl,status, addTime)
                VALUES (@eventName, @eventDate, @eventId, @sbmarketname, @sbrunners, @sbmarketid, @sportType, @isSrl,@status, GETDATE())
            `);

        return res.json({
            status: "Success",
            message: "SB Market Saved Successfully"
        });

    } catch (err) {
        console.log(err);
        res.status(500).json({ status: "Error", message: err.message });
    }
});

// ek sath me multiple market save karega but slow hai
router.post("/addSpBooks", async (req, res) => {
    let { markets } = req.body;

    if (!markets || !Array.isArray(markets)) {
        return res.status(400).json({
            status: "Error",
            message: "Markets array required"
        });
    }

    try {
        const pool = await poolPromise3;

        let results = [];

        for (let m of markets) {
            const {
                eventName,
                eventDate,
                eventId,
                sbmarketname,
                sbrunners,
                sbmarketid,
                sportType,
                isSrl
            } = m;

            // Check if exists
            const check = await pool.request()
                .input("eventId", sql.Int, eventId)
                .input("sbmarketid", sql.BigInt, sbmarketid)
                .query(`
                    SELECT sbmarketid FROM sportsbook 
                    WHERE eventId=@eventId AND sbmarketid=@sbmarketid
                `);

            if (check.recordset.length > 0) {
                results.push({
                    sbmarketid,
                    sbmarketname,
                    eventId,
                    eventName,
                    sportType,
                    status: "Success",
                    message: "SB Market is Already Exist.."
                });
                continue; // skip insertion
            }

            // Insert if not exist
            await pool.request()
                .input("eventName", sql.NVarChar, eventName)
                .input("eventDate", sql.SmallDateTime, eventDate)
                .input("eventId", sql.Int, eventId)
                .input("sbmarketname", sql.NVarChar, sbmarketname)
                .input("sbrunners", sql.NVarChar, sbrunners)
                .input("sbmarketid", sql.BigInt, sbmarketid)
                .input("sportType", sql.SmallInt, sportType)
                .input("isSrl", sql.TinyInt, isSrl)
                .input("status", sql.SmallInt, 0)
                .query(`
                    INSERT INTO sportsbook
                    (eventName, eventDate, eventId, sbmarketname, sbrunners, sbmarketid, sportType, isSrl, status, addTime)
                    VALUES (@eventName, @eventDate, @eventId, @sbmarketname, @sbrunners, @sbmarketid, @sportType, @isSrl, @status, GETDATE())
                `);

            results.push({
                sbmarketid,
                sbmarketname,
                eventId,
                eventName,
                sportType,
                status: "Success",
                message: "SB Market Saved Successfully"
            });
        }

        return res.json({
            status: "Success",
            results
        });

    } catch (err) {
        console.log(err);
        return res.status(500).json({
            status: "Error",
            message: err.message
        });
    }
});

// ek sath me multiple market save karega and fast hai bahot
router.post("/addSpBooks_new", async (req, res) => {
    const { markets } = req.body;

    if (!Array.isArray(markets) || !markets.length) {
        return res.status(400).json({
            status: "Error",
            message: "Markets array required"
        });
    }

    try {
        const pool = await poolPromise3;

        const CHUNK_SIZE = 10;
        let inserted = 0;

        for (let i = 0; i < markets.length; i += CHUNK_SIZE) {
            const chunk = markets.slice(i, i + CHUNK_SIZE);

            const values = chunk.map((m, idx) => `
                (
                  @eventName${idx},
                  @eventDate${idx},
                  @eventId${idx},
                  @sbmarketname${idx},
                  @sbrunners${idx},
                  @sbmarketid${idx},
                  @sportType${idx},
                  @isSrl${idx},
                  0,
                  GETDATE()
                )
            `).join(",");

            const request = pool.request();

            chunk.forEach((m, idx) => {
                request
                    .input(`eventName${idx}`, sql.NVarChar(150), m.eventName)
                    .input(`eventDate${idx}`, sql.SmallDateTime, m.eventDate)
                    .input(`eventId${idx}`, sql.Int, m.eventId)
                    .input(`sbmarketname${idx}`, sql.NVarChar(250), m.sbmarketname)
                    .input(`sbrunners${idx}`, sql.NVarChar(sql.MAX), m.sbrunners)
                    .input(`sbmarketid${idx}`, sql.BigInt, m.sbmarketid)
                    .input(`sportType${idx}`, sql.SmallInt, m.sportType)
                    .input(`isSrl${idx}`, sql.TinyInt, m.isSrl);
            });

            const query = `
                INSERT INTO sportsbook
                (eventName, eventDate, eventId, sbmarketname, sbrunners, sbmarketid, sportType, isSrl, status, addTime)
                SELECT *
                FROM (VALUES ${values}) AS v
                (
                  eventName, eventDate, eventId, sbmarketname,
                  sbrunners, sbmarketid, sportType, isSrl, status, addTime
                )
                WHERE NOT EXISTS (
                    SELECT 1 FROM sportsbook s
                    WHERE s.eventId = v.eventId
                      AND s.sbmarketid = v.sbmarketid
                );
            `;

            const result = await request.query(query);
            inserted += result.rowsAffected[0];
        }

        return res.json({
            status: "Success",
            message: "SB Markets processed",
            inserted
        });

    } catch (err) {
        console.error("addSpBooks error:", err);
        return res.status(500).json({
            status: "Error",
            message: err.message
        });
    }
});


router.get("/getSportbookmarket/:sportType/:status/:eventId", verifyToken, authorize([1, 2, 4]), async (req, res) => {
    const { sportType, status, eventId } = req.params;

    try {
        const pool = await poolPromise3;

        // const result = await pool.request()
        //     .input("sportType", sql.SmallInt, sportType) // SmallInt for sportType
        //     .input("status", sql.TinyInt, status)         // assuming status is stored as TinyInt
        //     .input("eventId", sql.Int, eventId)
        //     .query(`
        //         SELECT *
        //         FROM sportsbook
        //         WHERE status=@status AND sportType=@sportType AND eventId=@eventId
        //     `);

        const result = await pool.request()
            .input("sportType", sql.SmallInt, sportType) // SmallInt for sportType
            .input("status", sql.TinyInt, status)         // assuming status is stored as TinyInt
            .input("eventId", sql.Int, eventId)
            .query(`
                SELECT *
                FROM sportsbook
                WHERE isBet=1 AND status=@status AND eventId=@eventId
            `);

        if (result.recordset.length === 0) {
            return res.json({ status: "Success", message: "No market found", data: [] });
        }

        res.json({ status: "Success", data: result.recordset });

    } catch (err) {
        console.error(err);
        res.status(500).json({ status: "Error", message: err.message });
    }
});

router.post("/settleSportBook", verifyToken, authorize([1, 2, 4]), async (req, res) => {
    const { sbid, status, result, settledby, reversed, selectionId } = req.body;

    if (!sbid || status === undefined || !settledby) {
        return res.status(400).json({ status: "Error", message: "sbid, status, and settledby are required" });
    }

    try {
        const pool = await poolPromise3;

        // Update the sportsbook record

        const updateResult = await pool.request()
            .input("sbid", sql.BigInt, sbid)
            .input("status", sql.TinyInt, status)
            .input("result", sql.NVarChar, result || null)
            .input("settledby", sql.NVarChar, settledby)
            .input("reversed", sql.NVarChar, reversed || null)
            .input("selectionId", sql.NVarChar, selectionId || null)
            .query(`
            UPDATE sportsbook
            SET
                status = @status,
                result = @result,
                settledby = @settledby,
                reversed = @reversed,
                selectionId = @selectionId,
                settledTime = GETDATE()
            WHERE sbid = @sbid
        `);

        // Check if any row was actually updated
        if (updateResult.rowsAffected[0] === 0) {
            return res.status(404).json({ status: "Error", message: "No sportsbook record found with sbid = " + sbid });
        }

        const message = status === 2
            ? "Market Cancelled Successfully..."
            : status === 1
                ? "Market Settled Successfully..."
                : "Market Reversed Successfully...";

        res.json({ status: "Success", message });

    } catch (err) {
        console.error(err);
        res.status(500).json({ status: "Error", message: err.message });
    }
});

router.post("/updateMarketIsBet", async (req, res) => {
    const { marketIds } = req.body;

    if (!marketIds || !Array.isArray(marketIds) || marketIds.length === 0) {
        return res.status(400).json({ status: "Failed", message: "marketIds must be a non-empty array" });
    }


    // console.log("/n" + JSON.stringify(marketIds))

    try {
        const pool = await poolPromise3;

        const updated = [];
        const alreadyUpdated = [];
        const notFound = [];

        // 🔥 Step 1: Fetch all sbmarketid from DB (exists or not)
        const result = await pool.request().query(`
            SELECT sbmarketid, isBet
            FROM sportsbook
            WHERE sbmarketid IN (${marketIds.join(',')})
        `);

        const records = result.recordset.map(r => ({
            id: r.sbmarketid,
            isBet: r.isBet
        }));

        // 🔥 Step 2: Identify each sbmarketid status
        marketIds.forEach(id => {
            const record = records.find(r => r.id === id);

            if (!record) {
                notFound.push(id); // ❌ Does NOT exist in DB
            } else if (record.isBet === 1) {
                alreadyUpdated.push(id); // ⚠ Already updated
            }
        });

        // 🔥 Step 3: Update only isBet = 0 markets
        const toUpdate = records.filter(r => r.isBet === 0).map(r => r.id);

        if (toUpdate.length > 0) {
            await pool.request().query(`
                UPDATE sportsbook
                SET isBet = 1
                WHERE sbmarketid IN (${toUpdate.join(',')})
            `);
            updated.push(...toUpdate);
        }

        return res.json({
            status: "Success",
            message: "Market isBet update processed",
            updated,         // Actually updated now
            alreadyUpdated,  // Found but isBet already 1
            notFound         // sbmarketid not in table
        });

    } catch (err) {
        console.error("updateMarketIsBet Error:", err);
        return res.status(500).json({ status: "Failed", message: err.message });
    }
});


router.get("/getpremiumResult/:eventId/:sbmarketid", async (req, res) => {
    const { eventId, sbmarketid } = req.params;

    if (!eventId || !sbmarketid) {
        return res.status(400).json({
            status: "Failed",
            message: "eventId and sbmarketid are required"
        });
    }

    try {
        const pool = await poolPromise3;

        // Fetch single row from DB
        const result = await pool.request()
            .input("eventId", sql.BigInt, eventId)
            .input("sbmarketid", sql.BigInt, sbmarketid)
            .query(`
                SELECT TOP 1
                    sbmarketid AS marketId,
                    result,
                    sbmarketName,
                    selectionId
                FROM sportsbook
                WHERE eventid = @eventId
                  AND sbmarketid = @sbmarketid
            `);

        if (result.recordset.length === 0) {
            return res.json({
                status: "Error",
                result: null,
                sbmarketName: null,
                selectionId: null
            });
        }

        const row = result.recordset[0];

        return res.json({
            status: "Success",
            result: row.result,
            sbmarketName: row.sbmarketName,
            selectionId: row.selectionId
        });

    } catch (err) {
        console.error("getpremiumResult Error:", err);
        return res.status(500).json({
            status: "Failed",
            message: err.message
        });
    }
});

module.exports = router;
