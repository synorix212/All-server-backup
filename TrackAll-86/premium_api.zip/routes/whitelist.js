const express = require('express');
const axios = require('axios');
const https = require('https');
const router = express.Router();
const { verifyToken, authorize } = require("../middleware/auth");

const httpsAgent = new https.Agent({
  rejectUnauthorized: false,
});


const BASE_URL = 'https://api.111111.info/pad=99/';

const AURA_BASE_URL = 'https://222222.digital/pad=81';

// 👉 yahan apna token daal do (ya ENV se lo)
const AUTH_TOKEN = process.env.AURA_AUTH_TOKEN || 'D7E14BF0589A553BDF08ED507EA71B86';

// common axios config
const axiosConfig = {
  headers: {
    'authorization': `${AUTH_TOKEN}`,
    'Content-Type': 'application/json'
  },
  timeout: 10000
};


/* 🔁 COMMON FUNCTION */

async function hitApi(rawQuery) {
  try {
    const response = await axios.get(BASE_URL, {
      params: rawQuery,
      // IMPORTANT: query ko same rakhne ke liye
      paramsSerializer: params => new URLSearchParams(params).toString()
    });
    return response.data;
  } catch (err) {
    return {
      error: true,
      message: err.response?.data || err.message
    };
  }
}

/* ================= Coder Api list/whitelist/delete ================= */

router.get('/coderApi', verifyToken, authorize([1]), async (req, res) => {
  res.json(await hitApi(req.query));
});



/* ================= AWC LIST ================= */
/**
 * GET /awclist
 */
router.get('/awclist', verifyToken, authorize([1]), async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/awclist`);

    // 🔹 Update/Map before sending response
    const jeffAgents = [
      'vrnlag1', 'vrnlag2', 'vrnlag4', 'vrnlag5', 'vrnlag6', 'vrnlag7', 'vrnlag8', 'vrnlagbdt', 'vrnlagpkr', 'vrnlaginr', 'vrnlagusd'
    ];

    const tuhinAgents = [
      'plyfxag01', 'plyfxag02', 'plyfxag03', 'plyfxag04', 'playfxusd01', 'playfxagbdt'
    ];
    const stageAgents = [
      'stageagt','vrml'
    ];

    response.data = response.data.map(item => ({
      ...item,
      clientName: jeffAgents.includes(item.agentId) ? 'JEFF'
        : tuhinAgents.includes(item.agentId) ? 'TUHIN'
          : stageAgents.includes(item.agentId) ? 'STAGING'
            : 'Unknown'
    }));

    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});

/* ================= AWC DELETE ================= */
/**
 * GET /awcdelete?domain=
 */
router.get('/awcdelete', verifyToken, authorize([1]), async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/awcdelete`, {
      params: {
        domain: req.query.domain
      }
    });
    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});

/* ================= AWC ACTIVATE ================= */
/**
 * GET /awcactivate
 * RAW query forward (betlimit jaisa big JSON bhi)
 */
router.get('/awcactivate', verifyToken, authorize([1]), async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/awcactivate`, {
      params: req.query,
      paramsSerializer: params =>
        new URLSearchParams(params).toString()
    });

    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});

/* ================= GET AURA OPERATORS ================= */
router.get('/aura/get', verifyToken, authorize([1]), async (req, res) => {
  try {
    const response = await axios.get(
      `${AURA_BASE_URL}/getAuraOperators`,
      axiosConfig
    );
    // console.log(response.data)
    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});

/* ================= SET AURA OPERATORS ================= */
router.post('/aura/set', verifyToken, authorize([1]), async (req, res) => {
  try {
    const response = await axios.post(
      `${AURA_BASE_URL}/setAuraOperators`,
      req.body,
      axiosConfig
    );
    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});


router.get('/scoreid/getall', verifyToken, authorize([1, 2, 3, 4]), async (req, res) => {
  try {
    const response = await axios({
      method: 'get',
      url: 'https://sportbet.id/VRN/v1/api/scoreid/getall'
    });

    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});

router.get('/highlights/:id', verifyToken, authorize([1, 2, 3, 4]), async (req, res) => {
  try {
    const { id } = req.params;

    const response = await axios({
      method: 'get',
      url: `https://tvlivestreaming.online:3447/api/highlights/${id}`,
      httpsAgent
    });

    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});

router.post('/scoreid/post', verifyToken, authorize([1, 2, 3, 4]), async (req, res) => {
  try {
    const response = await axios({
      method: 'post',
      url: 'https://sportbet.id/VRN/v1/api/scoreid/post',
      headers: {
        'Content-Type': 'application/json'
      },
      data: req.body
    });

    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});

router.get('/scoreid/delete', verifyToken, authorize([1, 2, 3, 4]), async (req, res) => {
  try {
    const response = await axios({
      method: 'DELETE',
      url: 'https://sportbet.id/VRN/v1/api/scoreid/delete',
      params: {
        eventid: req.query.eventid
      }
    });

    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});

router.post('/store-match-data', verifyToken, authorize([1, 2, 3, 4]), async (req, res) => {
  try {
    const response = await axios({
      method: 'post',
      url: 'https://tvlivestreaming.online:15692/api/store_match_data',
      httpsAgent,
      headers: {
        'Content-Type': 'application/json'
      },
      data: req.body
    });

    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});

router.get('/getTicker', verifyToken, authorize([1, 2]), async (req, res) => {
  try {
    const response = await axios({
      method: 'get',
      url: 'https://tvlivestreaming.online:15692/api/get_ticker',
      httpsAgent
    });

    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});

router.post('/setTicker', verifyToken, authorize([1, 2]), async (req, res) => {
  try {
    const response = await axios({
      method: 'post',
      url: 'https://tvlivestreaming.online:15692/api/store_ticker',
      httpsAgent,
      headers: {
        'Content-Type': 'application/json'
      },
      data: req.body
    });

    res.json(response.data);
  } catch (err) {
    res.status(500).json({
      error: true,
      message: err.response?.data || err.message
    });
  }
});


module.exports = router;
