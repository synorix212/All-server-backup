const express = require('express');
const axios = require('axios');
const router = express.Router();



const BASE_URL = 'https://111111.info/pad=81';

const AUTH_TOKEN = 'A0A092909B90FC122F5DE008DB14D2DC';


// 🔹 Common axios config
const axiosInstance = axios.create({
    timeout: 10000,
    headers: {
        authorization: AUTH_TOKEN
    }
});

// 🔹 Function to call GET API
async function callApi(url) {
    const response = await axiosInstance.get(url);
    return response.data;
}

// 🔹 Response ko same format me convert karna
function formatResponse(apiName, data) {
    return {
        apiName: apiName,
        status: 'SUCCESS',
        fetchedAt: new Date().toISOString(),
        data: data
    };
}




// 🔹 Calculate total stake, PL & turnover for each API
function calculateTotals(apiResponses) {
    return apiResponses.map(api => {
        let totalStake = 0;
        let totalPL = 0;
        let totalTurnover = 0;

        function processValues(stake, pl) {
            if (stake != null && pl != null) {
                const absPL = Math.abs(pl); // negative ko positive
                totalStake += stake;
                totalPL += pl;

                // choti value turnover me add
                totalTurnover += Math.min(stake, absPL);
            }
        }
        // // ✅ SAFE CHECK
        // if (!api?.data?.result || !Array.isArray(api.data.result)) {
        //     return {
        //         apiName: api.apiName,
        //         totalStake: 0,
        //         totalPL: 0,
        //         totalTurnover: 0
        //     };
        // }

        // console.log(api.data.result,api.apiName)
        api.data.result.forEach(item => {

            processValues(item.stake, item.PL ?? item.pl);

            if (item.bets && Array.isArray(item.bets)) {
                item.bets.forEach(b => {
                    processValues(
                        b.stake,
                        b.roundPl ?? b.PL ?? b.pl
                    );
                });
            }

            if (item.listBets && Array.isArray(item.listBets)) {
                item.listBets.forEach(lb => {
                    processValues(lb.stake, lb.PL ?? lb.pl);
                });
            }

        });

        return {
            apiName: api.apiName,
            totalStake,
            totalPL,
            totalTurnover
        };
    });
}

// 🔹 Router endpoint
router.get('/fetchUserData', async (req, res) => {
    const { userId, from, to } = req.query;

    const fromUTC = convertISTtoUTC(from);
    const toUTC = convertISTtoUTC(to);

    if (!userId || !from || !to) {
        return res.status(400).json({ error: 'Missing required query parameters: userId, from, to' });
    }

    try {
        const finalResult = [];

        // 1️⃣ API 1
        const api1Data = await callApi(`${BASE_URL}/betsHistory?from=${fromUTC}&to=${toUTC}&userId=${userId}&status=1`);
        finalResult.push(formatResponse('EXCH', api1Data));

        console.log(`${BASE_URL}/betsHistory?from=${from}&to=${to}&userId=${userId}&status=1`)

        console.log(`${BASE_URL}/betsHistory?from=${fromUTC}&to=${toUTC}&userId=${userId}&status=1`)

        // 2️⃣ API 2
        const api2Data = await callApi(`${BASE_URL}/casinoAWCProfitLoss?from=${fromUTC}&to=${toUTC}&userId=${userId}`);
        finalResult.push(formatResponse('AWC', api2Data));

        // 3️⃣ API 3
        const api3Data = await callApi(`${BASE_URL}/casinoBOGProfitLoss?from=${fromUTC}&to=${toUTC}&userId=${userId}`);
        finalResult.push(formatResponse('BOG', api3Data));

        // 4️⃣ API 4
        const api4Data = await callApi(`${BASE_URL}/parlayBetsHistory?from=${fromUTC}&to=${toUTC}&userId=${userId}`);
        finalResult.push(formatResponse('PARLAY', api4Data));

        // 🔹 Calculate totals
        const totals = calculateTotals(finalResult);

        // res.json({ finalResult, totals });
        res.json({ totals });


    } catch (error) {
        console.error('❌ API Error:', error.message);
        res.status(500).json({ error: error.message });
    }
});

// 🔹 Calculate total stake, PL & turnover for each API and compitions wise
// function calculateTotalsCompWise(apiResponses) {
//     return apiResponses.map(api => {
//         let totalStake = 0;
//         let totalPL = 0;
//         let totalTurnover = 0;

//         let competitionTotals = {}; // 🔹 NEW (only for EXCH)

//         function processValues(stake, pl, competitionName) {
//             if (stake != null && pl != null) {
//                 const absPL = Math.abs(pl);

//                 totalStake += stake;
//                 totalPL += pl;
//                 totalTurnover += Math.min(stake, absPL);

//                 // 🔹 Only for EXCH → competition wise
//                 if (api.apiName === "EXCH") {
//                     if (!competitionTotals[competitionName]) {
//                         competitionTotals[competitionName] = {
//                             competitionName,
//                             totalStake: 0,
//                             totalPL: 0,
//                             totalTurnover: 0
//                         };
//                     }

//                     competitionTotals[competitionName].totalStake += stake;
//                     competitionTotals[competitionName].totalPL += pl;
//                     competitionTotals[competitionName].totalTurnover += Math.min(stake, absPL);
//                 }
//             }
//         }

//         api.data.result.forEach(item => {
//             const comp = item.competitionName || "Unknown";

//             processValues(item.stake, item.PL ?? item.pl, comp);

//             if (item.bets && Array.isArray(item.bets)) {
//                 item.bets.forEach(b => {
//                     processValues(
//                         b.stake,
//                         b.roundPl ?? b.PL ?? b.pl,
//                         comp
//                     );
//                 });
//             }

//             if (item.listBets && Array.isArray(item.listBets)) {
//                 item.listBets.forEach(lb => {
//                     processValues(
//                         lb.stake,
//                         lb.PL ?? lb.pl,
//                         comp
//                     );
//                 });
//             }
//         });

//         return {
//             apiName: api.apiName,
//             totalStake,
//             totalPL,
//             totalTurnover,

//             // 🔹 Only add when EXCH
//             ...(api.apiName === "EXCH" && {
//                 competitionWise: Object.values(competitionTotals)
//             })
//         };
//     });
// }


function calculateTotalsCompWise(apiResponses) {
    return apiResponses.map(api => {
        let totalStake = 0;
        let totalPL = 0;
        let totalTurnover = 0;

        let competitionTotals = {};
        let sportTotals = {};
        let gameTypeTotals = {};

        function processValues(stake, pl, competitionName, sportName, gameType) {
            if (stake != null && pl != null) {
                const absPL = Math.abs(pl);

                totalStake += stake;
                totalPL += pl;
                totalTurnover += Math.min(stake, absPL);

                if (api.apiName === "EXCH") {

                    if (!competitionTotals[competitionName]) {
                        competitionTotals[competitionName] = {
                            competitionName,
                            totalStake: 0,
                            totalPL: 0,
                            totalTurnover: 0
                        };
                    }

                    competitionTotals[competitionName].totalStake += stake;
                    competitionTotals[competitionName].totalPL += pl;
                    competitionTotals[competitionName].totalTurnover += Math.min(stake, absPL);

                    if (!sportTotals[sportName]) {
                        sportTotals[sportName] = {
                            sportName,
                            totalStake: 0,
                            totalPL: 0,
                            totalTurnover: 0
                        };
                    }

                    sportTotals[sportName].totalStake += stake;
                    sportTotals[sportName].totalPL += pl;
                    sportTotals[sportName].totalTurnover += Math.min(stake, absPL);
                }

                if (api.apiName === "AWC" || api.apiName === "BOG") {

                    if (!gameTypeTotals[gameType]) {
                        gameTypeTotals[gameType] = {
                            gameType,
                            totalStake: 0,
                            totalPL: 0,
                            totalTurnover: 0
                        };
                    }

                    gameTypeTotals[gameType].totalStake += stake;
                    gameTypeTotals[gameType].totalPL += pl;
                    gameTypeTotals[gameType].totalTurnover += Math.min(stake, absPL);
                }
            }
        }

        api.data.result.forEach(item => {

            const comp = item.competitionName || "Unknown";
            const sport = item.sportName || item.sport || "Unknown";
            const gameType = item.gameType || "Unknown";

            processValues(
                item.stake,
                item.PL ?? item.pl,
                comp,
                sport,
                gameType
            );

            if (item.bets && Array.isArray(item.bets)) {
                item.bets.forEach(b => {
                    processValues(
                        b.stake,
                        b.roundPl ?? b.PL ?? b.pl,
                        comp,
                        sport,
                        gameType
                    );
                });
            }

            if (item.listBets && Array.isArray(item.listBets)) {
                item.listBets.forEach(lb => {
                    processValues(
                        lb.stake,
                        lb.PL ?? lb.pl,
                        comp,
                        sport,
                        gameType
                    );
                });
            }
        });

        return {
            apiName: api.apiName,
            totalStake,
            totalPL,
            totalTurnover,

            ...(api.apiName === "EXCH" && {
                competitionWise: Object.values(competitionTotals),
                sportWise: Object.values(sportTotals)
            }),

            ...((api.apiName === "AWC" || api.apiName === "BOG") && {
                gameTypeWise: Object.values(gameTypeTotals)
            })
        };
    });
}

// 🔹 Router endpoint

router.get('/fetchUserDataCompWise', async (req, res) => {
    const { userId, from, to } = req.query;

    const fromUTC = convertISTtoUTC(from);
    const toUTC = convertISTtoUTC(to);

    if (!userId || !from || !to) {
        return res.status(400).json({ error: 'Missing required query parameters: userId, from, to' });
    }

    try {
        const finalResult = [];

        // 1️⃣ API 1
        const api1Data = await callApi(`${BASE_URL}/betsHistory?from=${fromUTC}&to=${toUTC}&userId=${userId}&status=1`);
        finalResult.push(formatResponse('EXCH', api1Data));

        console.log(`${BASE_URL}/betsHistory?from=${from}&to=${to}&userId=${userId}&status=1`)

        console.log(`${BASE_URL}/betsHistory?from=${fromUTC}&to=${toUTC}&userId=${userId}&status=1`)

        // 2️⃣ API 2
        const api2Data = await callApi(`${BASE_URL}/casinoAWCProfitLoss?from=${fromUTC}&to=${toUTC}&userId=${userId}`);
        finalResult.push(formatResponse('AWC', api2Data));

        // 3️⃣ API 3
        const api3Data = await callApi(`${BASE_URL}/casinoBOGProfitLoss?from=${fromUTC}&to=${toUTC}&userId=${userId}`);
        finalResult.push(formatResponse('BOG', api3Data));

        // 4️⃣ API 4
        const api4Data = await callApi(`${BASE_URL}/parlayBetsHistory?from=${fromUTC}&to=${toUTC}&userId=${userId}`);
        finalResult.push(formatResponse('PARLAY', api4Data));

        // 🔹 Calculate totals
        const totals = calculateTotalsCompWise(finalResult);

        // res.json({ finalResult, totals });
        res.json({ totals });


    } catch (error) {
        console.error('❌ API Error:', error.message);
        res.status(500).json({ error: error.message });
    }
});


function convertISTtoUTC(dateStr) {
    // decode if encoded
    dateStr = decodeURIComponent(dateStr);

    const [datePart, timePart] = dateStr.trim().split(' ');
    const [year, month, day] = datePart.split('-').map(Number);
    const [hour, minute, second] = timePart.split(':');
    const [sec, ms] = second.split('.');

    const date = new Date(Date.UTC(year, month - 1, day, hour, minute, sec, ms));

    date.setMinutes(date.getMinutes() - 330); // IST -> UTC

    return date.toISOString().replace('T', ' ').replace('Z', '');
}
// function convertISTtoUTC(dateStr) {
//     const date = new Date(dateStr);
//     date.setMinutes(date.getMinutes() - 330); // 5h 30m = 330 minutes
//     return date.toISOString().replace('T', ' ').replace('Z', '');
// }

module.exports = router;
