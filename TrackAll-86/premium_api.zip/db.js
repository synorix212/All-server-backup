// db.js
const sql = require('mssql');

const config1 = {
    user: 'jammy',                // SQL Server username
    password: 'Asdf1234',  // SQL Server password
    database: 'premium_Fancy2',    // Database name
    server: '3.6.24.1',       // Server name or IP
    port: 1433,
    options: {
        encrypt: false,
        trustServerCertificate: true
    },
    pool: {
        max: 20,
        min: 0,
        idleTimeoutMillis: 120000
    },
    connectionTimeout: 60000,  // 60 seconds
    requestTimeout: 120000 // 60 seconds instead of 15
};

const config2 = {
    user: 'jammy',                // SQL Server username
    password: 'Asdf1234',  // SQL Server password
    database: 'fancydata',    // Database name
    server: '3.6.24.1',       // Server name or IP
    port: 1433,
    options: {
        encrypt: false,
        trustServerCertificate: true
    },
    pool: {
        max: 20,
        min: 0,
        idleTimeoutMillis: 120000
    },
    connectionTimeout: 60000,  // 60 seconds
    requestTimeout: 120000 // 60 seconds instead of 15
};

const config3 = {
    user: 'preJam',                // SQL Server username
    password: 'Asdf1234',  // SQL Server password
    database: 'premium_Fancy2',    // Database name
    server: '3.6.200.201',       // Server name or IP
    port: 1433,
    options: {
        encrypt: false,
        trustServerCertificate: true
    },
    pool: {
        max: 20,
        min: 0,
        idleTimeoutMillis: 120000
    },
    connectionTimeout: 60000,  // 60 seconds
    requestTimeout: 120000 // 60 seconds instead of 15
};

// Generic function to create a pool with reconnect
async function createPool(config, poolNo) {
    let pool;
    while (!pool) {
        try {
            pool = await new sql.ConnectionPool(config).connect();
            console.log('✔ SQL Server ' + poolNo + ' Connected Successfully');
        } catch (err) {
            console.log('❌ SQL Server ' + poolNo + ' Connection Failed, retrying in 5 seconds:', err.message);
            await new Promise(res => setTimeout(res, 5000)); // wait 5 seconds before retry
        }
    }
    // Handle errors after connection
    pool.on('error', async err => {
        console.log('⚠ SQL ' + poolNo + ' Pool Error, reconnecting...', err.message);
        pool = await createPool(config); // Reconnect if pool error
    });

    return pool;
}

// Export pooled connections
const poolPromise1 = createPool(config1, 1);
const poolPromise2 = createPool(config2, 2);
const poolPromise3 = createPool(config3, 3);


sql.on('error', err => {
    console.error('🔥 Global SQL Error:', err);
});

// const poolPromise1 = new sql.ConnectionPool(config)
//     .connect()
//     .then(pool => {
//         console.log('✔ SQL Server1 Connected Successfully');
//         return pool;
//     })
//     .catch(err => {
//         console.log('❌ SQL Server1 Connection Failed:', err);
//     });

// const poolPromise2 = new sql.ConnectionPool(config2)
//     .connect()
//     .then(pool => {
//         console.log('✔ SQL Server2 Connected Successfully');
//         return pool;
//     })
//     .catch(err => {
//         console.log('❌ SQL Server2 Connection Failed:', err);
//     });

module.exports = {
    sql,
    poolPromise1,
    poolPromise2,
    poolPromise3
};
