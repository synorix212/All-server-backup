var http = require("https");
var mysql = require('mysql')
const got = require('got');
const axios = require('axios');
//var development = process.env.DEVELOPMENT
//var mysql_password = 'uNxLmNyxWVyD62EU'
//var mysql_username = 'root'
//var mysql_host = 'api.allexch.com'
//var mysql_db = 'db_betapp'

let runFancyResult = false; //jab bhi panel me kuch issue raha to yaha aake bas true karna hai and pm2 update all kar dena hai


const agent = new http.Agent({
    rejectUnauthorized: false, // ⚠️ disables SSL certificate verification
});

// const mysql_username = process.env.mysqlUsername || 'laserApi';
// const mysql_password = process.env.mysqlPassword || 'db9DU6i8coksmq6h';
// const mysql_host = process.env.mysqlHost || 'laserbookrdsrr.chei3penixmp.eu-west-2.rds.amazonaws.com';
// const mysql_db = process.env.mysqlDb || 'vrnlapp';

const mysql_username = process.env.mysqlUsername || 'vrnlappusr';
const mysql_password = process.env.mysqlPassword || 'okDU6i8csmqdb121!';
// const mysql_host = process.env.mysqlHost || 'vrnl-db-readonly.c2fyyveua9jg.eu-west-2.rds.amazonaws.com';
const mysql_host = process.env.mysqlHost || 'betswiz-db.cp686q8uif6s.ap-south-1.rds.amazonaws.com';
const mysql_db = process.env.mysqlDb || 'vrnlapp';

// const mysql_username = process.env.mysqlUsername || 'vrnlappusr';
// const mysql_password = process.env.mysqlPassword || 'okDU6i8csmqdb121!';
// const mysql_host = process.env.mysqlHost || 'vrnl-db.c2fyyveua9jg.eu-west-2.rds.amazonaws.com';
// const mysql_db = process.env.mysqlDb || 'vrnlapp';


var mysql_port = 3306

event_id_version = {}

var POLLING_INTERVAL = 30000
var pollingTimer
var connection, session

var db_config = {
    host: mysql_host,
    user: mysql_username,
    password: mysql_password,
    database: mysql_db,
    port: mysql_port,
};

let enableDiaMarkets = {};
let enableSkyMarkets = {};
let enableDiaBMarkets = {};
let enableSkyBMarkets = {};

let mainUrl = "https://api.sportbet.id:8444";
let backUpUrl = "https://bkp.sportbet.id:8444";

function handleDisconnect() {
    connection = mysql.createConnection(db_config);
    connection.connect(function (err) {
        if (err) {
            console.log('error when connecting to db:', err);
            setTimeout(handleDisconnect, 2000);
        }
    });
    connection.on('error', function (err) {
        console.log('db error', err);
        if (err.code === 'PROTOCOL_CONNECTION_LOST') {
            handleDisconnect();
        } else {
            console.log("gotcha !!! data base connection terminating the nodejs");
            throw err;
        }
    });
}
handleDisconnect();


async function addSession(game) {


    let data = JSON.stringify({
        "Fancy": game.marketName,
        "Eventname": game.eventName,
        "Eventid": game.eventId,
        "type": game.oddSource,
        "sid": game.sid
    });

    let config = {
        method: 'post',
        url: mainUrl + '/api/addSession',
        headers: {
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios.request(config)
        .then((response) => {
            // console.log(JSON.stringify(response.data));
        })
        .catch((error) => {
            if (error.response) {
                // The request was made and the server responded with a status code
                console.error('Request failed with status code:', error.response.status);
                console.error('URL:', error.config.url);
                console.error('Response data:', error.response.data);
            } else if (error.request) {
                // The request was made but no response was received
                console.error('No response received for request to:', error.config.url);
            } else {
                // Something happened in setting up the request
                console.error('Error in request setup:', error.message);
            }
        });

}

async function addSessionBackup(game) {

    let data = JSON.stringify({
        "Fancy": game.marketName,
        "Eventname": game.eventName,
        "Eventid": game.eventId,
        "type": game.oddSource,
        "sid": game.sid
    });

    let config = {
        method: 'post',
        url: backUpUrl + '/api/addSession',
        headers: {
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios.request(config)
        .then((response) => {
            // console.log(JSON.stringify(response.data));
        })
        .catch((error) => {
            if (error.response) {
                // The request was made and the server responded with a status code
                console.error('Request failed with status code:', error.response.status);
                console.error('URL:', error.config.url);
                console.error('Response data:', error.response.data);
            } else if (error.request) {
                // The request was made but no response was received
                console.error('No response received for request to:', error.config.url);
            } else {
                // Something happened in setting up the request
                console.error('Error in request setup:', error.message);
            }
        });

}

async function get_result(game) {
    const { eventId, marketName } = game;
    const url = mainUrl + '/api/fancyMarketWithBets/0/' + eventId + '/' + marketName;

    try {
        const apiResp = await got.post(url);
        if (apiResp.statusCode === 200) {
            enableDiaMarkets[marketName] = game;
        } else if (apiResp.statusCode === 201) {
            await addSession(game);
        } else if (apiResp.statusCode === 202) {
            // console.warn(
            //     `Request accepted (202) but not yet processed for EventId=${eventId}, Market=${marketName}, URL=${url}`
            // );
        } else if (apiResp.statusCode === 404) {
            console.error(`Resource not found: ${url}`);
        } else {
            console.error(
                `API error ${apiResp.statusCode} for EventId=${eventId}, Market=${marketName}, URL=${url}`
            );
        }
    } catch (err) {
        console.error(
            `Request failed for EventId=${eventId}, Market=${marketName}, URL=${url}, Error=${err.message}`
        );
    }
}

async function get_result_tk(game) {
    const { eventId, marketName } = game;
    const url = mainUrl + '/api/fancyMarketWithBets/1/' + eventId + '/' + marketName;

    try {
        const apiResp = await got.post(url);
        if (apiResp.statusCode === 200) {
            enableSkyMarkets[marketName] = game;
        } else if (apiResp.statusCode === 201) {
            await addSession(game);
        } else if (apiResp.statusCode === 202) {
            // console.warn(
            //     `Request accepted (202) but not yet processed for EventId=${eventId}, Market=${marketName}, URL=${url}`
            // );
        } else if (apiResp.statusCode === 404) {
            console.error(`Resource not found: ${url}`);
        } else {
            console.error(
                `API error ${apiResp.statusCode} for EventId=${eventId}, Market=${marketName}, URL=${url}`
            );
        }
    } catch (err) {
        console.error(
            `Request failed for EventId=${eventId}, Market=${marketName}, URL=${url}, Error=${err.message}`
        );
    }
}

async function get_result_backup(game) {
    const { eventId, marketName } = game;
    const url = backUpUrl + '/api/fancyMarketWithBets/0/' + eventId + '/' + marketName;

    try {
        const apiResp = await got.post(url);
        if (apiResp.statusCode === 200) {
            enableDiaBMarkets[marketName] = game;
        } else if (apiResp.statusCode === 201) {
            await addSessionBackup(game);
        } else if (apiResp.statusCode === 202) {
            // console.warn(
            //     `Request accepted (202) but not yet processed for EventId=${eventId}, Market=${marketName}, URL=${url}`
            // );
        } else if (apiResp.statusCode === 404) {
            console.error(`Resource not found: ${url}`);
        } else {
            console.error(
                `API error ${apiResp.statusCode} for EventId=${eventId}, Market=${marketName}, URL=${url}`
            );
        }
    } catch (err) {
        console.error(
            `Request failed for EventId=${eventId}, Market=${marketName}, URL=${url}, Error=${err.message}`
        );
    }
}

async function get_result_tk_backup(game) {
    const { eventId, marketName } = game;
    const url = backUpUrl + '/api/fancyMarketWithBets/1/' + eventId + '/' + marketName;

    try {
        const apiResp = await got.post(url);
        if (apiResp.statusCode === 200) {
            enableSkyBMarkets[marketName] = game;
        } else if (apiResp.statusCode === 201) {
            await addSessionBackup(game);
        } else if (apiResp.statusCode === 202) {
            // console.warn(
            //     `Request accepted (202) but not yet processed for EventId=${eventId}, Market=${marketName}, URL=${url}`
            // );
        } else if (apiResp.statusCode === 404) {
            console.error(`Resource not found: ${url}`);
        } else {
            console.error(
                `API error ${apiResp.statusCode} for EventId=${eventId}, Market=${marketName}, URL=${url}`
            );
        }
    } catch (err) {
        console.error(
            `Request failed for EventId=${eventId}, Market=${marketName}, URL=${url}, Error=${err.message}`
        );
    }
}

var pollingLoop = async function () {
    // connection = mysql.createConnection(db_config);

    // var queryString = "SELECT marketName,eventId, FROM vrnlapp.liveBets where isFancy=1 GROUP BY marketName,eventId";
    var queryString = "SELECT bet.marketName,bet.eventId,game.oddSource,game.eventName,bet.marketId FROM vrnlapp.liveBets as bet join vrnlapp.vrnlGames as game ON bet.gameId=game.gameId where bet.isFancy=1 GROUP BY bet.marketName,bet.eventId";
    connection.query(queryString, function (err, gameDetail, fields) {
        // connection.end();
        if (err) {
            console.log('error in db ' + err);
        } else {
            gameDetail.forEach(async game => {
                const str = game.marketId; //"df_1.249300702_43688511_1st"
                const parts = str.split("_");
                const sid = parts[2]; // "43688511"
                game.sid = sid;
            })
            // console.log(gameDetail)
            // console.log(gameDetail.length)

            gameDetail.forEach(async game => {
                if (game.oddSource == 0) {
                    // // if (!enableDiaMarkets[game.marketName]) {
                    // await get_result(game);
                    // // }
                }
            })
            gameDetail.forEach(async game => {
                if (game.oddSource == 1) {
                    // // if (!enableSkyMarkets[game.marketName]) {
                    // await get_result_tk(game);
                    // // }

                }
            })
            gameDetail.forEach(async game => {
                if (game.oddSource == 0) {
                    // if (!enableDiaBMarkets[game.marketName]) {
                    // await get_result_backup(game);
                    // }
                }
            })
            gameDetail.forEach(async game => {
                if (game.oddSource == 1) {
                    // console.log(game)
                    // if (!enableDiaBMarkets[game.marketName]) {
                    await get_result_tk_backup(game);
                    
                    if (runFancyResult) { // here need to check true by defualt is its false
                        await getRadheFancyResult(game);// call this api to get radhe result if runFancyResult =true
                    }

                    // }
                }
            })

        }
    });
    // connection1 = mysql.createConnection(db_config);
    var queryString1 = "SELECT marketName,eventId,eventName,marketId FROM vrnlapp.userBetsSky where isFancy=1 and status=0 GROUP BY marketName,eventId";
    connection.query(queryString1, function (err, gameDetail, fields) {
        // connection1.end();
        if (err) {
            console.log('error in db ' + err);
        } else {
            gameDetail.forEach(async game => {
                const str = game.marketId; //"df_1.249300702_43688511_1st"
                const parts = str.split("_");
                const sid = parts[2]; // "43688511"
                game.sid = sid;
            })
            // console.log(gameDetail.length)
            gameDetail.forEach(async game => {
                // game['oddSource'] = 0;
                // await get_result(game);

            })
            gameDetail.forEach(async game => {
                // game['oddSource'] = 0;
                // await get_result_backup(game);
            })

        }
    });
}
pollingLoop()
pollingTimer = setInterval(pollingLoop, POLLING_INTERVAL);



async function getRadheFancyResult(game) {
    const { eventId, marketName, sid, oddSource } = game;
    // const url = `http://18.171.69.133:6010/market/result/${sid}`;
    const url = `http://5.189.187.132:3490/market/result/${sid}`;


    try {
        const response = await axios.get(url);

        if (response.status !== 200) {
            console.error(
                `Radhe API returned status ${response.status} for EventId=${eventId}, Market=${marketName}, SID=${sid}`
            );
            return;
        }

        const data = response.data;

        if (!data?.isSuccess) {
            console.warn(`Radhe API response not successful for SID=${sid}`);
            return;
        }

        const item = data.items;

        if (item?.Status !== "DECLARED" && item?.Status !== "VOID") {
            console.log(`Market not declared yet for SID=${sid}`);
            return;
        }

        if (item.MarketId !== sid) {
            console.warn(`MarketId mismatch. Expected: ${sid}, Got: ${item.MarketId}`);
            return;
        }
        if (item.Status == "VOID") {
            item.WinnerId = -1;
        }

        game.Winner = item.WinnerId;

        console.log("✅ Radhe API Response:", item);
        console.log("✅ Game Object:", game);

        await addFancyResultToJammyApi(game);

    } catch (error) {
        console.error(
            `❌ Radhe Request failed for EventId=${eventId}, Market=${marketName}, SID=${sid}, URL=${url}`
        );
        console.error("Error:", error.message);
    }
}

async function addFancyResultToJammyApi(game) {
    const { eventId, marketName, Winner, oddSource } = game;

    const data = {
        matchBfId: eventId,
        fancyName: marketName,
        result: Winner,
        fsource: oddSource,
    };
    console.log(data)

    const config = {
        method: "post",
        url: "https://streamingtv.fun:15692/api/store_fancy_result",
        headers: { "Content-Type": "application/json" },
        data: JSON.stringify(data),
        // httpsAgent: agent,
    };

    try {
        const response = await axios.request(config);
        console.log("✅ Jammy API Response:", response.data);
    } catch (error) {
        console.log(error)
        if (error.response) {
            console.error("❌ Jammy API Error:");
            console.error("Status:", error.response.status);
            console.error("URL:", error.config.url);
            console.error("Response Data:", error.response.data);
        } else if (error.request) {
            console.error("❌ No response from Jammy API:", error.config.url);
        } else {
            console.error("❌ Error setting up Jammy API request:", error.message);
        }
    }
}