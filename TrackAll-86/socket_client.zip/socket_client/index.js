

var app = angular.module('sportApp', []);

var socket = io('http://localhost:3030');
var casinoType;

app.controller('homeController', function ($scope, $http, $rootScope, $timeout, $window, $location, $interval) {

    // var socket = io('http://45.76.140.29:3030');


    // var localSocket = io('http://35.177.98.253:3030');//TTLIVE LINE
    // var localSocket1 = io('http://18.170.129.193:3030');//VRNL FANY

    var localSocket1 = io('http://5.189.187.132:3030');
    // var localSocket2 = io('http://167.86.102.80:3030'); //odds
    var localSocket2 = io('http://173.212.229.110:3030'); //VRNL HOSTING 
    // var localSocket3 = io('http://18.134.247.58:3030'); //lc247 host server

    // var localSocket3 = io('http://35.179.70.8:3030'); //MAHADEV LIVE LINE
    // var localSocket4 = io('http://18.135.89.19:3030'); //MAHADEV FANCY
    // var localSocket5 = io('http://3.8.74.175:3030'); //Hosting laser FANCY
    // var localSocket6 = io('http://13.41.90.127:3030'); //Hosting laser FANCY



    setInterval(function () {
        console.clear();
    }, 10000)


    socket.on('send_betfair_match', function (data) {
        // console.log(data);
        // localSocket.emit("betfair_match", data);
        // localSocket1.emit("betfair_match", data);

    });

    socket.on('send_betfair_score', function (data) {
        // console.log(data);
        data = data.filter(item => {
            return item.eventTypeId != 4;
        })
        console.log(data)

        // data.forEach(element => {
        //     if(element.eventTypeId==4){
        //         element.score=null
        //     }
        // });

        // console.log(JSON.stringify(data));
        // localSocket.emit("betfair_score", data);
        localSocket1.emit("betfair_score", data);
        localSocket2.emit("betfair_score", data);
        // localSocket3.emit("betfair_score", data);
        // y.emit("betfair_score", data);
        // localSocket5.emit("betfair_score", data);
        // localSocket6.emit("betfair_score", data);

    })


    function getlistGamesVrnl(sportRadar) {
        $.ajax({
            // url: "http://51.195.220.62:82/listGames",
            // url: "https://betswiz8.com/pad=82/listGames",
            // url: "https://333333.fun/pad=82/listGames",
            url: 'https://555555.today/pad=82/listAllGames',
            method: 'GET',
            success: function (data) {
                data = JSON.parse(data);

                data.result.forEach(match => {

                    if (match.eventId.toString().length == 8) {
                        // if(match.eventTypeId==2){
                        if (match.isInPlay == 1) {
                            match.markets.forEach(market => {
                                addMarket(market.marketId)
                            });
                        }
                        // }

                    }

                });

            },
            error: function (err) {
                console.log(err)
            }
        });
    }

    // getlistGamesVrnl();

    setInterval(function () {
        // getlistGamesVrnl();


    }, 60000)

    // http://192.248.174.30:3035/api/add/1.201718189

    function addMarket(marketId) {
        $.ajax({
            url: "http://192.248.174.30:3035/api/add/" + marketId,

            method: 'GET',
            success: function (data) {

            },
            error: function (err) {
                console.log(err)
            }
        });
    }

    setInterval(function () {
        // getlistGamesVrnl();


    }, 60000)
});