
var app = require('express')();
var http = require('http').createServer(app);
var cors = require('cors');
app.use(cors());
var axios = require('axios');
var qs = require('qs');
const { json } = require('express');
const { off } = require('process');
// const moment = require('moment');

const port = 3037;

app.get('/', (req, res) => {
    res.send('odds Bf Api')
})

let TimerIntevalListGames = 0;
let TimerIntevalFancy = 0;

let BfDataStore = {};

let ListGamesData = [];

function startIntevalFancy() {
    if (TimerIntevalListGames) {
        clearInterval(TimerIntevalListGames);
    }
    if (TimerIntevalFancy) {
        clearInterval(TimerInteval);
    }
    listGames();
    TimerIntevalListGames = setInterval(() => {
        listGames();
    }, 30000);

    TimerIntevalFancy = setInterval(() => {

        if (ListGamesData.length > 0) {
            let ids = [];
            ListGamesData.forEach((match, index) => {
                let event_id = match.eventId.toString();

                match.markets = match.markets.filter(function (market) {
                    return market.marketName != "Over/Under 3.5 Goals";
                });
                match.markets = match.markets.filter(function (market) {
                    return market.marketName != "To Win the Toss";
                });
                // && match.eventId == 31903483
                // if (match.eventTypeId == 1 && event_id.length < 9) { //if cricket soccer and tenns
                //     if (match.markets[0]) {
                //         match.markets.forEach((market, index2) => {
                //             ids.push(market.marketId);
                //         });
                //     }
                // }

                if (match.eventTypeId < 5 && event_id.length < 9) { //if cricket soccer and tenns
                    if (match.markets[0]) {
                        match.markets.forEach((market, index2) => {
                            ids.push(market.marketId);
                        });
                    }
                }

                // if (parseInt(match.eventTypeId) > 4 && event_id.length < 9) {  //if Not cricket soccer and tenns
                //     if (match.markets[0]) {
                //         match.markets.forEach((market, index2) => {
                //             ids.push(market.marketId);
                //         });
                //     }
                // }
            });
            // var data = JSON.stringify(ids.toString());
            // console.log(data)
            console.log(ids.length)
            // ids.length = parseInt(ids.length/2);

            // console.log(ids.length);
            // ids = ids.splice(parseInt(ids.length / 2), ids.length);
            // console.log(ids);
            // ids = ids.splice(0, parseInt(ids.length / 2));
            // console.log(ids);

            marketsbook(ids);
        }
    }, 1000);


}
// startIntevalFancy();


function listGames() {

    var config = {
        method: 'get',
        url: 'https://555555.today/pad=82/listAllGames',
    };

    axios(config)
        .then(function (response) {
            ListGamesData = response.data.result;

        })
        .catch(function (error) {
            console.log(error);
        });
}

function createMarketIdList(ids) {
    let e = [];
    return ids.forEach(id => {
        e.push("market_ids[]=" + encodeURIComponent(id))
    }),
        e = [...new Set(e)],
        e.join("&")
}
function marketsbook(ids) {
    // console.log(createMarketIdList(ids))

    // var data = qs.stringify({
    //     'market_ids[]': '1.201744902',
    // });
    var config = {
        method: 'post',
        url: 'https://odds.laser247.com/ws/getMarketDataNew',
        headers: {
            'origin': 'https://laser247.com',
            'content-type': 'application/x-www-form-urlencoded',
            'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1'
        },
        data: createMarketIdList(ids)
    };

    axios(config)
        .then(function (response) {
            // console.log(pipe_string_to_JSON(response.data));
            // console.log(JSON.stringify(response.data));
            // console.log(IsBfFormatter(pipe_string_to_JSON(response.data)).length);
            pushDatatoServer(IsBfFormatter(pipe_string_to_JSON(response.data)));

            IsBfFormatter(pipe_string_to_JSON(response.data)).forEach(market => {
                BfDataStore[market.MarketId] = market;
            });

        })
        .catch(function (error) {
            console.log(error);
        });


}

function pipe_string_to_JSON(G) {
    return (G = (G = [...new Set(G)]).filter(ce => null != ce)).forEach((ce, U) => {
        G[U] = ce.split("|")
    }), G
}

function IsBfFormatter(markets) {
    let bfMarketData = [];
    markets.forEach((bfMarket, index1) => {
        ListGamesData.forEach((match, index) => {
            if (match.markets[0]) {
                match.markets.forEach((market, index2) => {
                    if (bfMarket[0] == market.marketId) {

                        let mktData = {
                            "updatetime": new Date(),
                            "update": "ok",
                            "sport": match.sportsName,
                            "eventId": match.eventId,
                            "MarketId": market.marketId,
                            "marketName": market.marketName,
                            "source": 5,
                            "IsMarketDataDelayed": false,
                            "Status": bfMarket[2],
                            "IsInplay": match.isInPlay == 1 ? true : false,
                            "inplay": match.isInPlay == 1 ? true : false,
                            "NumberOfRunners": market.runners.length,
                            "NumberOfActiveRunners": market.runners.length,
                            "TotalMatched": bfMarket[5],
                            "Runners": []
                        }

                        market.runners.forEach((runner, index3) => {
                            bfMarket.forEach((bfrunData, index4) => {

                                if (bfrunData == runner.selectionId && index4 > 7) {
                                    // console.log(index4, bfrunData)
                                    let runnerData = {
                                        "SelectionId": runner.selectionId,
                                        "runnerName": runner.selectionName,
                                        "Status": bfMarket[index4 + 1],
                                        "LastPriceTraded": bfMarket[index4 + 2],
                                        "TotalMatched": 0,
                                        "ExchangePrices": {
                                            "AvailableToBack": [{ price: bfMarket[index4 + 2], size: bfMarket[index4 + 3] }, { price: bfMarket[index4 + 4], size: bfMarket[index4 + 5] }, { price: bfMarket[index4 + 6], size: bfMarket[index4 + 7] }],
                                            "AvailableToLay": [{ price: bfMarket[index4 + 8], size: bfMarket[index4 + 9] }, { price: bfMarket[index4 + 10], size: bfMarket[index4 + 11] }, { price: bfMarket[index4 + 12], size: bfMarket[index4 + 13] }]
                                        }
                                    }
                                    mktData.Runners.push(runnerData);
                                }

                            });
                        });


                        bfMarketData.push(mktData);

                        // console.log(bfMarket)
                    }
                });
            }
        });
    });

    // console.log(JSON.stringify(bfMarketData))

    return bfMarketData
}

function pushDatatoServer(data) {

    var config = {
        method: 'post',
        url: 'http://18.134.247.58:3031/bfdata',
        headers: {
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            console.log(response.data);
            // console.log(response.headers);
        })
        .catch(function (error) {
            console.log(error);
        });
}





function doSomethingAsync(marketId) {
    return new Promise((resolve) => {

        if (BfDataStore[marketId]) {
            resolve(BfDataStore[marketId]);
        } else {
            resolve([]);
        }
    });
}

app.get('/api/markets/:marketIds', function (req, res) {

    let splitMarketIds = req.params.marketIds.split(',');

    const promises = [];

    for (let i = 0; i < splitMarketIds.length; i++) {
        promises.push(doSomethingAsync(splitMarketIds[i]));
    }

    Promise.all(promises)
        .then((results) => {
            res.send(results);
        })
        .catch((e) => {
            // Handle errors here
            res.send(e);
        });

});

http.listen(port, function () {
    console.log('listening on *:' + port);
});