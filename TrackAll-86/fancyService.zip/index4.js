
var app = require('express')();
var http = require('http').createServer(app);
var cors = require('cors');
app.use(cors());
var axios = require('axios');
const { json } = require('express');

const port = 3035;

const redis = require('redis');
const redisPort = 6379;
const client = redis.createClient(redisPort);


app.get('/api/bm_fancy/:gameId', function (req, res) {
    let content = JSON.stringify({
        "diamondEventId": "1703061008",
        "diamondMarketId": "1.170306100808",
        "skyEventId": "-10206504"
    });
    // client.set('store_map_bm_fancy_dia1703061008', content);

    let skyEventId = "";
    let DiaMktId = "";

    // client.get('store_map_bm_fancy_dia' + req.params.gameId, (err, response) => {
    //     // console.log(data)
    //     if (response) {
    //         try {
    //             response = JSON.parse(response);
    //             skyEventId = response.skyEventId;
    //             DiaMktId = response.diamondMarketId;
    //         } catch (err) {
    //             console.error(err)
    //         }
    //     } else {
    //     }
    // });

    console.log(skyEventId)

});

http.listen(port, function () {
    console.log('listening on *:' + port);
});