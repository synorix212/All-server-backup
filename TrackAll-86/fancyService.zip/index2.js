
var app = require('express')();
var http = require('http').createServer(app);
var cors = require('cors');
app.use(cors());
var axios = require('axios');
const { json } = require('express');
const { off } = require('process');
const moment = require('moment');

const port = 3036;

// const redis = require('redis');
// const redisPort = 6379;
// const client = redis.create  (redisPort);

// // Check if redis is running
// var redisIsReady = false;
// client.on('error', function (err) {
//     redisIsReady = false;
//     console.log('redis is not running');
//     console.log(err);
// });
// client.on('ready', function () {
//     redisIsReady = true;
//     console.log('redis is running');
// });

app.get('/', (req, res) => {
    res.send('fancy Api')
})

let TimerIntevalFancy = 0;
let storeMatches = {};

function startIntevalFancy() {
    if (TimerIntevalFancy) {
        clearInterval(TimerInteval);
    }
    // getFancyEventList(4);

    TimerIntevalFancy = setInterval(() => {
        // getFancyEventList(4);
    }, 60000);
}
// startIntevalFancy();

function getFancyEventList(eventTypeId) {



    var config = {
        method: 'get',
        url: 'http://192.248.174.30:3035/api/get_latest_event_list/' + eventTypeId,
    };

    axios(config)
        .then(function (response) {

            if (response.data) {
                response.data.forEach((element, index) => {
                    storeMatches[element.event.id] = element;
                });
            }
        })
        .catch(function (error) {
            // console.log(error);
        });

}

function getFancy() {
    let fancy = {
        "mid": "",
        "sid": "",
        "nat": "",
        "b1": "0.00",
        "bs1": "0.00",
        "l1": "0.00",
        "ls1": "0.00",
        "b2": "0.00",
        "bs2": "0.00",
        "l2": "0.00",
        "ls2": "0.00",
        "b3": "0.00",
        "bs3": "0.00",
        "l3": "0.00",
        "ls3": "0.00",
        "gtype": "Fancy",
        "utime": "0",
        "gvalid": "0",
        "gstatus": "",
        "remark": "",
        "min": "",
        "max": "",
        "srno": "",
        "s1": "0",
        "s2": "0",
        "ballsess": "1"
    };

    return fancy;
}

function convertToDiamondFancy(data) {
    let diamondFancyFormat = [];
    // data = JSON.parse(data);
    // console.log(data)

    if (data) {
        if (data.data) {
            let fancyIds = Object.keys(data.data);
            fancyIds.forEach((item, index) => {

                // console.log(item)
                // console.log(data.data[item])
                item = JSON.parse(data.data[item])

                let fancy = getFancy();
                // if ((item.status1 == "status1")) {
                if (item.status1 == "ACTIVE") {
                    fancy.gstatus = "";
                }
                if (item.status1 == "SUSPENDED") {
                    fancy.gstatus = "SUSPENDED";
                }
                if (item.status1 == "BALL_RUNNING") {
                    fancy.gstatus = "BALL RUNNING";
                }
                if (fancy.gstatus) {
                    fancy.gvalid = 1;
                } else {
                    fancy.gvalid = 0;
                }
                fancy['result'] = item.result;
                fancy.nat = item.name;
                if (data.event_id.length > 10) {
                    fancy.mid = '1.' + data.event_id;
                } else {
                    // fancy.mid = data.highlightMarketId;
                    fancy.mid = storeMatches[data.event_id]?.marketId;
                }
                // fancy.mid = data.highlightMarketId;
                fancy.sid = item.id;
                fancy.b1 = item.b1 ? item.b1 : 0;
                fancy.bs1 = item.bs1 ? item.bs1 : 0;
                fancy.l1 = item.l1 ? item.l1 : 0;
                fancy.ls1 = item.ls1 ? item.ls1 : 0;

                fancy.srno = item.sort;
                fancy.min = item.min_bet;
                fancy.max = item.max_bet;

                diamondFancyFormat.push(fancy);
                // }
            })
        }
    }


    return diamondFancyFormat;
}

function getsky_fancy(handleData, eventId) {


    var config = {
        method: 'get',
        url: 'http://45.76.33.57:3035/api/active_fancy/' + eventId,
    };

    axios(config)
        .then(function (response) {
            // console.log(JSON.stringify(response.data));

            handleData(convertToDiamondFancy(response.data));
        })
        .catch(function (error) {
            // console.log(error);
            handleData(error.message)

        });

}

function getbook() {
    let book = {
        "mid": "",
        "mname": "Bookmaker",
        "remark": "",
        "remark1": "",
        "min": "",
        "max": "",
        "sid": "",
        "nat": "",
        "b1": "0.00",
        "bs1": "0.00",
        "l1": "0.00",
        "ls1": "0.00",
        "s": "",
        "sr": "",
        "gtype": "Match1",
        "utime": "0",
        "b2": "0.00",
        "bs2": "0.00",
        "b3": "0.00",
        "bs3": "0.00",
        "l2": "0.00",
        "ls2": "0.00",
        "l3": "0.00",
        "ls3": "0.00",
        "b1s": "False",
        "b2s": "False",
        "b3s": "False",
        "l1s": "False",
        "l2s": "False",
        "l3s": "False"
    };

    return book;
}


function convertToDiamondBookMaking(data) {
    // data = JSON.parse(data);

    let diamondBookFormat = [];
    if (data) {
        if (data.data) {
            data.data.forEach((market, index) => {

                if (market.data.name != "BOOKMAKER") {
                    return;
                }
                let runners = [];
                market.data.runners = JSON.parse(market.data.runners);
                let bmIds = Object.keys(market.data.runners);
                bmIds.forEach((item, index) => {

                    item = market.data.runners[item];
                    // console.log(item)
                    let book = getbook();

                    if (item.status == "ACTIVE") {
                        book.s = "ACTIVE";
                    }
                    if (item.status == "SUSPENDED") {
                        book.s = "SUSPENDED";
                    }
                    if (item.status == "BALL_RUNNING") {
                        book.s = "BALL RUNNING";
                    }

                    book.nat = item.name;
                    book.mname = market.data.name;

                    // book.mid = data.bookMakerEvent.highlightMarketId;


                    // book.mid = storeMatches[market.data.event_id]?.marketId;
                    if (market.data.event_id.length > 10) {
                        // console.log(market.data.event_id)
                        book.mid = '1.' + market.data.event_id;
                    } else {
                        book.mid = storeMatches[market.data.event_id]?.marketId;
                    }

                    book.sid = item.selection_id;
                    book.b1 = item.back_price;
                    book.bs1 = parseInt(item.back_volume);
                    book.l1 = item.lay_price;
                    book.ls1 = parseInt(item.lay_volume);

                    book.sr = item.sort;
                    book.min = market.data.min_bet;
                    book.max = market.data.max_bet;

                    // if (data.bookMakerMarket.markets[0].marketId == item.marketId) {
                    runners.push(book);

                    // }

                })
                diamondBookFormat.push(runners)
            });
        }
    }

    // console.log(JSON.stringify(diamondBookFormat))

    return diamondBookFormat;

}

function getsky_book(handleData, eventId) {


    var config = {
        method: 'get',
        url: 'http://45.76.33.57:3035/api/active_bm/' + eventId,
    };

    axios(config)
        .then(function (response) {
            // console.log(JSON.stringify(response.data));

            handleData(convertToDiamondBookMaking(response.data));
        })
        .catch(function (error) {
            // console.log(error);
            handleData(error.message)

        });

}

app.get('/api/bm_fancy/:gameId', function (req, res) {


    let finalData = {
        "data": {
            "t1": [],
            "t2": [],
            "t3": [],
            "t4": []
        },
        "message": true,
        "status": 200
    }
    getsky_fancy(function (data) {
        // console.log(JSON.stringify(data));
        finalData.data.t3 = data;
        getsky_book(function (data1) {
            if (data1.length > 0) {
                finalData.data.t2.push({ bm1: [], bm2: [] });
                if (data1[0]) {
                    finalData.data.t2[0].bm2 = data1[0];
                }
                if (data1[1]) {
                    finalData.data.t2[0].bm1 = data1[1];
                } else {
                    finalData.data.t2[0].bm1 = data1[0];
                }
            }

            // console.log(JSON.stringify(data));

            res.send(finalData);
        }, req.params.gameId)
    }, req.params.gameId)

});

function getFancyList(handleData, eventId) {


    var config = {
        method: 'get',
        url: 'http://45.76.33.57:3035/api/fancy_list/' + eventId,
        // url: 'http://176.58.102.18:8880/api/active-fancy/' + eventId,

    };

    axios(config)
        .then(function (response) {
            // console.log(JSON.stringify(response.data));

            handleData(convertToDiamondFancy(response.data));
        })
        .catch(function (error) {
            // console.log(error);
            handleData(error.message)

        });

}

app.get('/api/bm_fancy/:gameId/:source', function (req, res) {


    let finalData = {
        "data": {
            "t1": [],
            "t2": [],
            "t3": [],
            "t4": []
        },
        "message": true,
        "status": 200
    }
    getFancyList(function (data) {
        // console.log(JSON.stringify(data));
        finalData.data.t3 = data;
        res.send(finalData);

    }, req.params.gameId)

});

//--------------------------------------------------------------------------------------------
function formatBmFancy(data) {
    let BM_FancyData = {
        "BMmarket": {},
        "Fancymarket": [],
    }


    if (!data.data) {
        return BM_FancyData;
    }
    if (data.data) {
        data = data.data;
    }



    if (data.t2) {
        BM_FancyData.BMmarket = data.t2[0];
    }
    if (data.t3) {
        BM_FancyData.Fancymarket = data.t3;

    }

    return BM_FancyData;

}

app.get('/api2/bm_fancy/:gameId', function (req, res) {


    var config = {
        method: 'get',
        url: 'https://fancy.dreaminplay.com:3443/api/bm_fancy/' + req.params.gameId,
    };

    axios(config)
        .then(function (response) {
            response.data = formatBmFancy(response.data)
            res.send(response.data);
        })
        .catch(function (error) {
            // console.log(error);
            res.send(null);

        });

});


// ---------------------------------------------------------------------------------------------


let TimerInteval;

let indexCount = 50;


let storeHighlights = {};
let storeEvents = {};
let storeMarkets = {};

function getAllData() {

    getLatestEventList(4);
    getLatestEventList(1);
    getLatestEventList(2);
    // setTimeout(()=>{

    // },30000)

}

function startInteval() {
    if (TimerInteval) {
        clearInterval(TimerInteval);
    }

    getAllData();

    TimerInteval = setInterval(() => {
        getAllData();
    }, 60000);
}
startInteval();


function getLatestEventList(eventTypeId) {



    var config = {
        method: 'get',
        url: 'http://192.248.174.30:3035/api/get_latest_event_list/' + eventTypeId,
    };

    axios(config)
        .then(function (response) {

            if (response.data) {
                response.data.forEach((element, index) => {
                    storeMarkets[element.marketId] = element;
                    if (eventTypeId != 2) {
                        if (!storeEvents[element.event.id]) {

                            // if (index < indexCount) {
                            // setTimeout(() => {
                            getExtraMarketList(element.event.id, eventTypeId);
                            // }, index + 100)
                            // } else {
                            //     // indexCount = indexCount + 50;
                            // }

                        }
                    }
                });
            }
            let content = JSON.stringify(response.data);
            // client.set('store_eventsBySport_data_' + eventTypeId, content);
            storeHighlights[eventTypeId] = response.data;
        })
        .catch(function (error) {
            // console.log(error);
        });

}


function getExtraMarketList(eventId, eventTypeId) {

    let url;
    if (eventTypeId == 4) {
        url = 'http://192.248.174.30:3035/api/cricket_extra_market_list/' + eventId;
    } else {
        url = 'http://192.248.174.30:3035/api/under_over_goal_market_list/' + eventId;
    }

    var config = {
        method: 'get',
        url: url
    };

    axios(config)
        .then(function (response) {
            response.data.forEach(element => {
                storeMarkets[element.marketId] = element;
            });
            let content = JSON.stringify(response.data);
            // client.set('store_eventsBySport_data_' + eventId, content);
            storeEvents[eventId] = response.data;

        })
        .catch(function (error) {
            // console.log(error);

        });

}


let listEventDatas = {};

function convertListEventsBySport(data, isInplay, competitionId) {

    let listEventsBySportFormat = [];
    if (data) {
        if (data) {
            data.forEach((event, index) => {
                listEventDatas[event?.event?.id] = event;
                let eventData = {
                    "sport": event?.eventType.name.toLowerCase(),
                    "competitionId": event?.competition?.id,
                    "competitionName": event?.competition?.name,
                    "Id": event?.event?.id,
                    "name": event?.event?.name,
                    "countryCode": event?.event?.countryCode,
                    "timezone": event?.event?.timezone,
                    "openDate": moment(event?.event?.openDate).utc().format('M/DD/YYYY h:mm:ss A')+' +00:00',
                    "inplay": event?.description?.turnInPlayEnabled,
                    "hasFancy": false,
                    "status": "OPEN"
                }

                if (competitionId) {
                    if (event?.competition?.id == competitionId) {
                        listEventsBySportFormat.push(eventData)
                    }
                } else {
                    if (isInplay) {
                        if (isInplay == event.description.turnInPlayEnabled)
                            listEventsBySportFormat.push(eventData);
                    } else {
                        listEventsBySportFormat.push(eventData);
                    }
                }
            });
        }
    }

    return listEventsBySportFormat;
}

function get_latest_event_list(handleData, eventTypeId, isInplay, competitionId) {

    if (storeHighlights[eventTypeId]) {
        handleData(convertListEventsBySport(storeHighlights[eventTypeId], isInplay, competitionId));
    } else {
        handleData([]);
    }


    // client.get('store_eventByMarket_data_' + eventTypeId, (err, data) => {
    //     // console.log(data)
    //     if (data) {
    //         try {
    //             data = JSON.parse(data);
    //         } catch (err) {
    //             console.error(err)
    //         }
    //         handleData(convertListEventsBySport(data, isInplay, competitionId));
    //     } else {
    //         handleData([]);
    //     }
    // });


    // var config = {
    //     method: 'get',
    //     url: 'http://192.248.174.30:3035/api/get_latest_event_list/' + eventTypeId,
    // };

    // axios(config)
    //     .then(function (response) {
    //         // console.log(JSON.stringify(response.data));

    //         handleData(convertListEventsBySport(response.data, isInplay, competitionId));
    //     })
    //     .catch(function (error) {
    //         // console.log(error);
    //         handleData(error.message)

    //     });

}

app.get('/api/listEventsBySport/:eventTypeId', function (req, res) {
    let isInplay = false;

    get_latest_event_list(function (data) {
        res.send(data);
    }, req.params.eventTypeId, isInplay);

});

app.get('/api/listEventsByCompetition/:eventTypeId/:competitionId', function (req, res) {
    let isInplay = false;

    get_latest_event_list(function (data) {
        res.send(data);
    }, req.params.eventTypeId, isInplay, req.params.competitionId)

});

app.get('/api/listInplayEvents/:eventTypeId', function (req, res) {

    let isInplay = true;

    get_latest_event_list(function (data) {
        res.send(data);
    }, req.params.eventTypeId, isInplay, req.params.competitionId)

});

function convertListMarketsByEvent(data) {

    let listMarketsByEventFormat = [];
    if (data) {
        if (data) {
            data.forEach((market, index) => {
                let marketData = {
                    "Updatetime": null,
                    "marketId": market.marketId,
                    "marketName": market.marketName,
                    "totalMatched": market.totalMatched,
                    "status": "OPEN",
                    "runners": [
                    ]
                }
                market.runners.forEach((runner, index) => {

                    let runnerData = {
                        "selectionId": runner.selectionId,
                        "runnerName": runner.runnerName
                    }
                    marketData.runners.push(runnerData);
                })

                listMarketsByEventFormat.push(marketData)

            });
        }
    }

    return listMarketsByEventFormat;
}

function get_extra_market_list(handleData, eventId, eventTypeId) {

    if (storeEvents[eventId]) {
        handleData(convertListMarketsByEvent(storeEvents[eventId]));
    } else {
        handleData([]);
    }

    // client.get('store_eventByMarket_data_' + eventId, (err, data) => {
    //     // console.log(data)
    //     if (data) {
    //         try {
    //             data = JSON.parse(data);
    //         } catch (err) {
    //             console.error(err)
    //         }
    //         handleData(convertListMarketsByEvent(data));
    //     } else {
    //         handleData([]);
    //     }
    // });

    // let url;
    // if (eventTypeId == 4) {
    //     url = 'http://192.248.174.30:3035/api/cricket_extra_market_list/' + eventId;
    // } else {
    //     url = 'http://192.248.174.30:3035/api/under_over_goal_market_list/' + eventId;
    // }

    // var config = {
    //     method: 'get',
    //     url: url
    // };

    // axios(config)
    //     .then(function (response) {
    //         // console.log(JSON.stringify(response.data));

    //         handleData(convertListMarketsByEvent(response.data));
    //     })
    //     .catch(function (error) {
    //         // console.log(error);
    //         handleData(error.message)

    //     });

}

app.get('/api/listMarkets/:eventId', function (req, res) {

    let eventTypeId;
    if (listEventDatas[req.params.eventId]) {
        eventTypeId = listEventDatas[req.params.eventId].eventType.id;
    }

    if (eventTypeId == 2) {
        let resp = [];
        resp.push(listEventDatas[req.params.eventId]);
        res.send(convertListMarketsByEvent(resp));
    } else {
        get_extra_market_list(function (data) {
            res.send(data);
        }, req.params.eventId, eventTypeId)
    }



});

function convertMarketsList(data) {

    let listMarketsFormat = [];
    if (data) {
        if (data) {
            data.forEach((market, index) => {
                if (market) {
                    // console.log(market.marketId)

                    let getStoreMarket;
                    if (storeMarkets[market.marketId]) {
                        getStoreMarket = storeMarkets[market.marketId]
                    }

                    let marketData = {
                        "updatetime": null,
                        "update": "ok",
                        "sport": "",
                        "eventId": market.eventId,
                        "MarketId": market.marketId,
                        "marketName": getStoreMarket?.marketName,
                        "source": 3,
                        "IsMarketDataDelayed": market.isMarketDataDelayed,
                        "Status": market.status,
                        "IsInplay": market.inplay,
                        "inplay": market.inplay,
                        "NumberOfRunners": market.numberOfRunners,
                        "NumberOfActiveRunners": market.numberOfActiveRunners,
                        "TotalMatched": getStoreMarket?.totalMatched,
                        "Runners": [
                        ]
                    }

                    market.runners.forEach((runner, index) => {

                        let runnerData = {
                            "SelectionId": runner.selectionId,
                            "runnerName": runner.runnerName,
                            "Status": runner.status,
                            "LastPriceTraded": runner.lastPriceTraded,
                            "TotalMatched": runner.totalMatched,
                            "ExchangePrices": {
                                "AvailableToBack": runner.ex.availableToBack,
                                "AvailableToLay": runner.ex.availableToLay
                            }
                        }
                        if (getStoreMarket?.runners.length > 0) {
                            getStoreMarket.runners.forEach((getRunner) => {
                                if (getRunner.selectionId == runner.selectionId) {
                                    runnerData.runnerName = getRunner.runnerName;
                                }
                            })
                        }
                        marketData.Runners.push(runnerData);
                    })

                    listMarketsFormat.push(marketData)
                }

            });
        }
    }

    return listMarketsFormat;
}

function get_markets_list(handleData, marketIds) {


    var config = {
        method: 'get',
        url: "http://192.248.174.30:3035/api/markets/" + marketIds
    };

    axios(config)
        .then(function (response) {
            // console.log(JSON.stringify(response.data));

            handleData(convertMarketsList(response.data));
        })
        .catch(function (error) {
            // console.log(error);
            handleData(error.message)

        });

}

app.get('/api/oddsInplay/:marketIds', function (req, res) {

    get_markets_list(function (data) {
        res.send(data);
    }, req.params.marketIds)

});


http.listen(port, function () {
    console.log('listening on *:' + port);
});