
// pm2 start index.js --exp-backoff-restart-delay=100
// pm2 stop index.js

var app = require('express')();
var http = require('http').createServer(app);
var cors = require('cors');
app.use(cors());

const port = 3030;

app.get('/', (req, res) => {
  res.send('fancy Api')
})

let https = require('https');

function formatBmFancy(data) {
  let BM_FancyData = {
    "BMmarket": {},
    "Fancymarket": [],
  }


  if (!data.data) {
    return BM_FancyData;
  }
  // console.log(data)
  data = data.data;



  if (data.t2) {
    BM_FancyData.BMmarket = data.t2[0];
  }
  if (data.t3) {
    BM_FancyData.Fancymarket.push(data.t3);
  }
  if (data.t4) {
    BM_FancyData.Fancymarket.push(data.t4);
  }

  return BM_FancyData;

}

app.get('/api/fancy/:id', function (req, res) {

  https.get('https://multiexch.com:3442/api/bm_fancy/' + req.params.id, (resp) => {

    // console.log(resp)
    let data = '';

    // // A chunk of data has been received.
    resp.on('data', (chunk) => {
      data += chunk;
    });

    // // The whole response has been received. Print out the result.
    resp.on('end', () => {
      data = JSON.parse(data)
      data = formatBmFancy(data);
      res.send(data);
    });



  }).on("error", (err) => {
    // console.log("Error: " + err.message);
    res.send(err);
  });
});

app.get('/api/new_fancy/:id', function (req, res) {

  https.get('https://betfairoddsapi.com:3443/api/new_bm_fancy/' + req.params.id, (resp) => {

    // console.log(resp)
    let data = '';

    // // A chunk of data has been received.
    resp.on('data', (chunk) => {
      data += chunk;
    });

    // // The whole response has been received. Print out the result.
    resp.on('end', () => {
      data = JSON.parse(data)
      data = formatBmFancy(data);
      res.send(data);
    });



  }).on("error", (err) => {
    // console.log("Error: " + err.message);
    res.send(err);
  });
});

app.get('/api/odds/:id', function (req, res) {

  https.get('https://multiexch.com:3442/api/sky_odds/' + req.params.id, (resp) => {

    // console.log(resp)
    let data = '';

    // // A chunk of data has been received.
    resp.on('data', (chunk) => {
      data += chunk;
    });

    // // The whole response has been received. Print out the result.
    resp.on('end', () => {
      data = JSON.parse(data)
      res.send(data);
    });



  }).on("error", (err) => {
    // console.log("Error: " + err.message);
    res.send(err);
  });
});

app.get('/api/bf_odds/:id', function (req, res) {

  https.get('https://multiexch.com:3442/api/bf_odds/' + req.params.id, (resp) => {

    // console.log(resp)
    let data = '';

    // // A chunk of data has been received.
    resp.on('data', (chunk) => {
      data += chunk;
    });

    // // The whole response has been received. Print out the result.
    resp.on('end', () => {
      data = JSON.parse(data)
      res.send(data);
    });



  }).on("error", (err) => {
    // console.log("Error: " + err.message);
    res.send(err);
  });
});

app.get('/api/highlights/:id', function (req, res) {

  https.get('https://multiexch.com:3442/api/highlights/' + req.params.id, (resp) => {

    // console.log(resp)
    let data = '';

    // // A chunk of data has been received.
    resp.on('data', (chunk) => {
      data += chunk;
    });

    // // The whole response has been received. Print out the result.
    resp.on('end', () => {
      data = JSON.parse(data)
      res.send(data);
    });



  }).on("error", (err) => {
    // console.log("Error: " + err.message);
    res.send(err);
  });
});

app.get('/api/inplay/:id', function (req, res) {

  https.get('https://multiexch.com:3442/api/inplay/' + req.params.id, (resp) => {

    // console.log(resp)
    let data = '';

    // // A chunk of data has been received.
    resp.on('data', (chunk) => {
      data += chunk;
    });

    // // The whole response has been received. Print out the result.
    resp.on('end', () => {
      data = JSON.parse(data)
      res.send(data);
    });



  }).on("error", (err) => {
    // console.log("Error: " + err.message);
    res.send(err);
  });
});

app.get('/api/game_details/:id', function (req, res) {

  https.get('https://multiexch.com:3442/api/game_details/' + req.params.id, (resp) => {

    // console.log(resp)
    let data = '';

    // // A chunk of data has been received.
    resp.on('data', (chunk) => {
      data += chunk;
    });

    // // The whole response has been received. Print out the result.
    resp.on('end', () => {
      data = JSON.parse(data)
      res.send(data);
    });



  }).on("error", (err) => {
    // console.log("Error: " + err.message);
    res.send(err);
  });
});


app.get('/api/markets_results/:ids', function (req, res) {

  https.get('https://betfairoddsapi.com:3443/api/markets_result/' + req.params.ids, (resp) => {

    // console.log(resp)
    let data = '';

    // // A chunk of data has been received.
    resp.on('data', (chunk) => {
      data += chunk;
    });

    // // The whole response has been received. Print out the result.
    resp.on('end', () => {
      data = JSON.parse(data)
      res.send(data);
    });



  }).on("error", (err) => {
    // console.log("Error: " + err.message);
    res.send(err);
  });
});

http.listen(port, function () {
  console.log('listening on *:' + port);
});