
var app = require('express')();
var http = require('http').createServer(app);
var cors = require('cors');
app.use(cors());
var axios = require('axios');
const { json } = require('express');
const { off } = require('process');
// const moment = require('moment');

const port = 3036;

app.get('/', (req, res) => {
    res.send('odds Bf Api')
})

let TimerIntevalListGames = 0;
let TimerIntevalFancy = 0;

let ListGamesData = [];

function startIntevalFancy() {
    if (TimerIntevalListGames) {
        clearInterval(TimerIntevalListGames);
    }
    if (TimerIntevalFancy) {
        clearInterval(TimerInteval);
    }
    listGames();
    TimerIntevalListGames = setInterval(() => {
        listGames();
    }, 30000);

    TimerIntevalFancy = setInterval(() => {

        if (ListGamesData.length > 0) {
            let ids = [];
            ListGamesData.forEach((match, index) => {
                let event_id = match.eventId.toString();
                // && match.eventId == 31903483
                // if (match.eventTypeId == 1 && event_id.length < 9) { //if cricket soccer and tenns
                //     if (match.markets[0]) {
                //         match.markets.forEach((market, index2) => {
                //             ids.push(market.marketId);
                //         });
                //     }
                // }

                if (match.eventTypeId < 5 && event_id.length < 9) { //if cricket soccer and tenns
                    if (match.markets[0]) {
                        match.markets.forEach((market, index2) => {
                            ids.push(market.marketId);
                        });
                    }
                }

                // if (parseInt(match.eventTypeId) > 4 && event_id.length < 9) {  //if Not cricket soccer and tenns
                //     if (match.markets[0]) {
                //         match.markets.forEach((market, index2) => {
                //             ids.push(market.marketId);
                //         });
                //     }
                // }
            });
            var data = JSON.stringify(ids.toString());
            // console.log(data)
            console.log(ids.length)
            // ids.length = parseInt(ids.length/2);

            // console.log(ids.length);
            // ids = ids.splice(parseInt(ids.length / 2), ids.length);
            // console.log(ids);
            // ids = ids.splice(0, parseInt(ids.length / 2));
            // console.log(ids);

            marketsbook(ids);
        }
    }, 500);


}

// startIntevalFancy(); //please uncomment to run ssexch grabber for betfair odds


function listGames() {

    var config = {
        method: 'get',
        // url: 'https://555555.today/pad=82/listAllGames',
        url: 'https://555555.today/pad=82/listGames?sport=&inplay=0'
    };

    axios(config)
        .then(function (response) {
            ListGamesData = response.data.result;

        })
        .catch(function (error) {
            console.log(error);
        });
}

function marketsbook(ids) {
    var data = JSON.stringify(ids.toString());


    var config = {
        method: 'post',
        // url: 'https://ssexch.io/exchangeapi/sports/marketsbook',
        url: 'https://ssplaywin.club/exchangeapi/sports/marketsbook',

        // url: 'https://kheloyar.net/exchangeapi/sports/marketsbook',

        headers: {
            'origin': 'https://ssexch.io',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            response.data.forEach((bfMarket, index) => {
                ListGamesData.forEach((match, index) => {
                    if (match.markets[0]) {
                        match.markets.forEach((market, index2) => {
                            if (bfMarket.marketId == market.marketId) {
                                bfMarket['eventId'] = match.eventId;
                                bfMarket['marketName'] = market.marketName;
                                bfMarket['sport'] = match.sportsName;

                                bfMarket.runners.forEach((bfRunner, index3) => {
                                    market.runners.forEach((runner, index4) => {

                                        if (bfRunner.selectionId == runner.selectionId) {
                                            bfRunner['runnerName'] = runner.selectionName;
                                        }
                                    })
                                });

                            }
                        });
                    }
                });
            });
            // console.log(JSON.stringify(IsBfFormatter(response.data)));
            pushDatatoServer(IsBfFormatter(response.data));

        })
        .catch(function (error) {
            console.log(error);
        });

}

function IsBfFormatter(markets) {
    let bfMarketData = [];
    markets.forEach((market, index1) => {
        let mktData = {
            "updatetime": new Date(),
            "update": "ok",
            "sport": market.sport,
            "eventId": market.eventId,
            "MarketId": market.marketId,
            "marketName": market.marketName,
            "source": 4,
            "IsMarketDataDelayed": market.isMarketDataDelayed,
            "Status": market.status,
            "IsInplay": market.inplay,
            "inplay": market.inplay,
            "NumberOfRunners": market.numberOfRunners,
            "NumberOfActiveRunners": market.numberOfActiveRunners,
            "TotalMatched": market.totalMatched,
            "Runners": []
        }

        market.runners.forEach((runner, index2) => {
            let runnerData = {
                "SelectionId": runner.selectionId,
                "runnerName": runner.runnerName,
                "Status": runner.status,
                "LastPriceTraded": runner.lastPriceTraded,
                "TotalMatched": runner.totalMatched,
                "ExchangePrices": {
                    "AvailableToBack": runner.ex?.availableToBack,
                    "AvailableToLay": runner.ex?.availableToLay
                },
            }
            mktData.Runners.push(runnerData);
        });
        bfMarketData.push(mktData);
    });

    return bfMarketData
}

function pushDatatoServer(data) {

    var config = {
        method: 'post',
        // url: 'http://13.126.202.236:3031/bfdata',
        // url: 'http://api3.streamingtv.fun:3031/bfdata',
        url: 'http://access.streamingtv.fun:3031/bfdata',//.236

        headers: {
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            console.log(response.data);
            // console.log(response.headers);
        })
        .catch(function (error) {
            console.log(error);
        });
}

http.listen(port, function () {
    console.log('listening on *:' + port);
});