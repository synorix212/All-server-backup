
var express = require('express')();
var https = require('https');
var axios = require('axios');
var fs = require('fs');

var ssl_domain = require("./ssl/ssl_domain");

const { json } = require('express');

const redis = require('redis');
const redisPort = 6379;
const client = redis.createClient(redisPort);


var app = https.createServer(ssl_domain.options, express);

app.addContext('api1.streamingtv.fun', ssl_domain.options1);
app.addContext('api2.streamingtv.fun', ssl_domain.options2);
app.addContext('api3.streamingtv.fun', ssl_domain.options3);
app.addContext('access.vrnl.net', ssl_domain.options4);
app.addContext('access.streamtv247.fun', ssl_domain.options5);
app.addContext('api3.streamtv247.fun', ssl_domain.options6);
app.addContext('api.bfoddsapi.in', ssl_domain.options7);
app.addContext('access.vrnlapi.live', ssl_domain.options8);
app.addContext('api3.vrnlapi.live', ssl_domain.options9);

var _ = require('lodash');

var cors = require('cors')

express.use(cors());
express.get('/', function (req, res) {
    res.send('Hello world');
});

let TimerIntevalFancy = 0;
let TimerIntevalListGames = 0;
let storeMatches = [];
let eventTypeId = 1;
function startIntevalFancy() {
    if (TimerIntevalFancy) {
        clearInterval(TimerInteval);
    }
    if (TimerIntevalListGames) {
        clearInterval(TimerIntevalListGames);
    }
    getFancyEventList(eventTypeId);

    TimerIntevalFancy = setInterval(() => {

        // for all matches
        let eventIdss = [];
        storeMatches.forEach(element => {
            eventIdss.push(element.gameId);
        });
        eventIdss = eventIdss.join(',');
        if (eventIdss) {
            getFancyDataAll(eventIdss, eventTypeId);
        }
        // for all matches

        // storeMatches.forEach(element => {
        //     getFancyData(element.gameId, eventTypeId);
        // });
    }, 1000);

    TimerIntevalListGames = setInterval(() => {
        getFancyEventList(eventTypeId);
    }, 2000);
}
startIntevalFancy();

function getFancyEventList(eventTypeId) {

    let config = {
        method: 'get',
        maxBodyLength: Infinity,
        url: 'https://streamingtv.fun:3447/api/highlights/' + eventTypeId,
        headers: {}
    };

    axios.request(config)
        .then((response) => {
            if (response.data) {
                storeMatches = response.data.data;

                // for all matches
                let eventIdss = [];
                if (storeMatches[0]) {
                    storeMatches.forEach(element => {
                        eventIdss.push(element.gameId);
                    });
                }

                eventIdss = eventIdss.join(',');
                getFancyDataAll(eventIdss, eventTypeId);
                // for all matches

                // storeMatches.forEach(element => {
                //     getFancyData(element.gameId, eventTypeId);
                // });
            }
            // console.log(JSON.stringify(response.data));
        })
        .catch((error) => {
            console.log(error);
        });

}


function getFancyData(eventId, eventTypeId) {

    let config = {
        method: 'get',
        maxBodyLength: Infinity,
        url: 'https://api3.streamingtv.fun:3471/api/bm_fancy/' + eventId,
        headers: {}
    };

    axios.request(config)
        .then((response) => {
            if (response.data) {
                content = JSON.stringify(response.data);
                client.set('store_sky_markets' + eventId, content);
                if (eventTypeId == 1) {
                    client.set('store_markets' + eventId, content);
                }
            }
            // console.log(JSON.stringify(response.data));
        })
        .catch((error) => {
            console.log(error);
        });

}

function getFancyDataAll(eventIds, eventTypeId) {
    if (!eventIds) {
        return;
    }

    let config = {
        method: 'get',
        url: 'https://api3.streamingtv.fun:3471/api/bm_fancy_multi/' + eventIds,
        headers: {}
    };

    axios.request(config)
        .then((response) => {
            if (response.data) {
                response.data.forEach(element => {
                    content = JSON.stringify(element);
                    client.set('store_sky_markets' + element.gameId, content);
                    if (eventTypeId == 1) {
                        client.set('store_markets' + element.gameId, content);
                    }

                });

            }
            // console.log(JSON.stringify(response.data));
        })
        .catch((error) => {
            console.log(error)
            if (error.code === 'ECONNABORTED') {
                console.log('Request timed out');
            } else {
                console.log(error.message);
            }
        });

}

function getCallerIP(request) {
    var ip = request.headers['x-forwarded-for'] ||
        request.connection.remoteAddress ||
        request.socket.remoteAddress ||
        request.connection.socket.remoteAddress;
    ip = ip.split(',')[0];
    ip = ip.split(':').slice(-1); //in case the ip returned in a format: "::ffff:146.xxx.xxx.xxx"
    return ip;
}
function getFancy() {
    let fancy = {
        "mid": "",
        "sid": "",
        "nat": "",
        "b1": "0.00",
        "bs1": "0.00",
        "l1": "0.00",
        "ls1": "0.00",
        "b2": "0.00",
        "bs2": "0.00",
        "l2": "0.00",
        "ls2": "0.00",
        "b3": "0.00",
        "bs3": "0.00",
        "l3": "0.00",
        "ls3": "0.00",
        "gtype": "Fancy",
        "utime": "0",
        "gvalid": "0",
        "gstatus": "",
        "remark": "",
        "min": "",
        "max": "",
        "srno": "",
        "s1": "0",
        "s2": "0",
        "ballsess": "1"
    };

    return fancy;
}

function convertToDiamondFancy(data) {
    let diamondFancyFormat = [];
    // data = JSON.parse(data);
    if (data) {
        if (data.fancyBetMarkets) {
            // data.fancyBetMarkets = data.fancyBetMarkets.filter((item) => {
            //     return !item.marketName.toLowerCase().includes(' ball run'); // remove ball by ball fancy
            // });
            data.fancyBetMarkets = data.fancyBetMarkets.filter((item) => {
                return !item.marketName.toLowerCase().includes(' lottery'); // remove lottery fancy
            });
            data.fancyBetMarkets = data.fancyBetMarkets.filter((item) => {
                return !item.marketName.toLowerCase().includes(' khadda'); // remove KHADDA fancy
            });
            data.fancyBetMarkets = data.fancyBetMarkets.filter((item) => {
                return !item.marketName.toLowerCase().includes('note'); // remove note fancy
            });
            data.fancyBetMarkets.forEach((item, index) => {

                let fancy = getFancy();
                // if ((item.status == 2 || item.status == 6 || item.status == 10) && (item.marketType == 1 || item.marketType == 2 || item.marketType == 6)) {
                if ((item.status == 2 || item.status == 6 || item.status == 10)) {

                    if (item.status == 2) {
                        fancy.gstatus = "";
                    }
                    if (item.status == 6) {
                        fancy.gstatus = "SUSPENDED";
                    }
                    if (item.status == 10) {
                        fancy.gstatus = "BALL RUNNING";
                    }

                    fancy.nat = item.marketName.replace("\t", "");
                    fancy.nat = fancy.nat.replace("'", "");
                    // fancy.nat = item.marketName;
                    fancy.mid = data.highlightMarketId;
                    fancy.sid = item.marketId;
                    fancy.b1 = item.runsYes ? item.runsYes : 0;
                    fancy.bs1 = item.oddsYes ? item.oddsYes : 0;
                    fancy.l1 = item.runsNo ? item.runsNo : 0;
                    fancy.ls1 = item.oddsNo ? item.oddsNo : 0;

                    fancy.srno = item.sort;
                    fancy.min = item.min;
                    fancy.max = item.max;
                    fancy.marketType = item.marketType;
                    fancy.updateDate = item.updateDate;
                    fancy.updatetime = data.updatetime;


                    diamondFancyFormat.push(fancy);
                }
            })
            // diamondFancyFormat = diamondFancyFormat.sort((a, b) => {
            //   return new Date(a.updateDate) - new Date(b.updateDate)
            // });

            diamondFancyFormat = diamondFancyFormat.sort((a, b) => {
                return a.sid - b.sid;
            });
            diamondFancyFormat = diamondFancyFormat.sort((a, b) => {
                return a.marketType - b.marketType;
            });
        }
    }


    return diamondFancyFormat;
}

function getsky_fancy(handleData, eventId) {


    client.get('store_sky_fancy' + eventId, (err, data) => {
        if (data) {
            try {
                data = JSON.parse(data);
            } catch (err) {
                console.error(err)
            }
            handleData(convertToDiamondFancy(data));
        } else {
            fs.readFile('../../store_sky_fancy/' + eventId + '.json', 'utf8', (err, data) => {
                if (data) {
                    try {
                        data = JSON.parse(data);
                    } catch (err) {
                        console.error(err)
                    }
                    handleData(convertToDiamondFancy(data));
                }
                else {
                    handleData([]);
                }
            })
        }
    });

    // var config = {
    //     method: 'get',
    //     url: 'https://api3.streamingtv.fun:3470/api/sky_fancy/' + eventId,
    // };

    // axios(config)
    //     .then(function (response) {
    //         // console.log(JSON.stringify(response.data));

    //         handleData(convertToDiamondFancy(response.data));
    //     })
    //     .catch(function (error) {
    //         // console.log(error);
    //         handleData(error.message)

    //     });

}


function getbook() {
    let book = {
        "mid": "",
        "mname": "Bookmaker",
        "remark": "",
        "remark1": "",
        "min": "",
        "max": "",
        "sid": "",
        "nat": "",
        "b1": "0.00",
        "bs1": "0.00",
        "l1": "0.00",
        "ls1": "0.00",
        "s": "",
        "sr": "",
        "gtype": "Match1",
        "utime": "0",
        "b2": "0.00",
        "bs2": "0.00",
        "b3": "0.00",
        "bs3": "0.00",
        "l2": "0.00",
        "ls2": "0.00",
        "l3": "0.00",
        "ls3": "0.00",
        "b1s": "False",
        "b2s": "False",
        "b3s": "False",
        "l1s": "False",
        "l2s": "False",
        "l3s": "False"
    };

    return book;
}

function convertToDiamondBookMaking(data) {
    // data = JSON.parse(data);

    let diamondBookFormat = [];
    if (data) {
        if (data.bookMakerSelection) {
            data.bookMakerMarket.markets = data.bookMakerMarket.markets.filter((item) => {
                return item.status != 1;
            });
            if (data.bookMakerMarket.markets[0]) {
                data.bookMakerSelection.selections.forEach((item, index) => {

                    let book = getbook();

                    if (item.status == 1) {
                        book.s = "ACTIVE";
                    }
                    if (item.status == 2) {
                        book.s = "SUSPENDED";
                    }
                    if (item.status == 1 && data.bookMakerMarket.markets[0].status == 6) {
                        book.s = "SUSPENDED";
                    }
                    if (item.status == 1 && data.bookMakerMarket.markets[0].status == 10) {
                        book.s = "BALL RUNNING";
                    }
                    if (item.status == 1 && data.bookMakerMarket.markets[0].status == 18) {
                        book.s = "BALL RUNNING";
                    }

                    book.nat = item.runnerName;
                    book.mid = data.bookMakerEvent.highlightMarketId;
                    // book.mid = item.marketId;

                    book.sid = item.selectionId;
                    // book.b1 = item.backOddsInfo[0] ? item.backOddsInfo[0].replace('0000', '') : "0";
                    // book.bs1 = 1000000;
                    // book.l1 = item.layOddsInfo[0] ? item.layOddsInfo[0].replace('0000', '') : "0";
                    // book.ls1 = 1000000;

                    if (item.backOddsInfo) {
                        book.b1 = item.backOddsInfo[0] ? item.backOddsInfo[0].replace('0000', '') : "0";
                        book.bs1 = 1000000;
                    }
                    if (item.layOddsInfo) {
                        book.l1 = item.layOddsInfo[0] ? item.layOddsInfo[0].replace('0000', '') : "0";
                        book.ls1 = 1000000;
                    }


                    book.sr = item.sort;
                    book.min = data.bookMakerMarket.markets[0].min;
                    book.max = data.bookMakerMarket.markets[0].max;
                    book.updatetime = data.updatetime;


                    if (data.bookMakerMarket.markets[0].marketId == item.marketId) {
                        diamondBookFormat.push(book);

                    }


                })
            }

        }
    }

    return diamondBookFormat;

}

function getsky_book(handleData, eventId) {

    client.get('store_sky_book' + eventId, (err, data) => {
        if (data) {
            try {
                data = JSON.parse(data);
            } catch (err) {
                console.error(err)
            }
            handleData(convertToDiamondBookMaking(data));
        } else {
            fs.readFile('../../store_sky_book/' + eventId + '.json', 'utf8', (err, data) => {
                if (data) {
                    try {
                        data = JSON.parse(data);
                    } catch (err) {
                        console.error(err)
                    }
                    handleData(convertToDiamondBookMaking(data));
                }
                else {
                    handleData([]);
                }
            })
        }
    });

    // var config = {
    //     method: 'get',
    //     url: 'https://api3.streamingtv.fun:3470/api/sky_book/' + eventId,
    // };

    // axios(config)
    //     .then(function (response) {
    //         // console.log(JSON.stringify(response.data));

    //         handleData(convertToDiamondBookMaking(response.data));
    //     })
    //     .catch(function (error) {
    //         // console.log(error);
    //         handleData(error.message)

    //     });

}


express.get('/api/bm_fancy/:gameId', function (req, res) {
    var clientIp = getCallerIP(req);
    // console.log(clientIp)

    // if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    //   res.send({ errMsg: "Invalid authentication" });
    //   // console.error(err)
    //   return null;
    // }
    // -------------------------------------------
    let gameId = req.params.gameId;
    let skyEventId = "";
    let DiaMktId = "";
    let DiaEventId = "";

    if (gameId == "1806131356") {//sky soccer bm mapping
        skyEventId = "-10456437";
        DiaEventId = gameId;
        gameId = skyEventId;
        DiaMktId = "1.180613135858";
    }


    let finalData = {
        "data": {
            "t1": [],
            "t2": [],
            "t3": [],
            "t4": []
        },
        "message": true,
        gameId: gameId,
        "updatetime": "2022-11-17T18:27:00.021Z",
        "status": 200
    }
    getsky_fancy(function (data) {
        // console.log(JSON.stringify(data));

        // -------------------------------------------
        if (DiaEventId && data) {
            data.forEach((fancy) => {
                fancy.mid = DiaMktId;
            })
        }

        // -------------------------------------------

        finalData.data.t3 = data;
        if (data[0]) {
            finalData.updatetime = data[0].updatetime
        }
        getsky_book(function (data1) {
            if (data1.length > 0) {
                finalData.data.t2.push({ bm1: [] });

                // -------------------------------------------
                if (DiaEventId && data1[0]) {
                    data1.forEach((bmrunner) => {
                        bmrunner.mid = DiaMktId;
                    })
                }

                // -------------------------------------------

                finalData.data.t2[0].bm1 = data1;
                if (data1[0]) {
                    finalData.updatetime = data1[0].updatetime
                }
            }

            // console.log(JSON.stringify(data));
            if (finalData.data.t2.length == 0 && finalData.data.t3.length == 0) {
                finalData.data = null;
                finalData['eventId'] = gameId;
            }

            res.send(finalData);
        }, gameId)
    }, gameId);

});


express.get('/api/sky_book/:eventId', function (req, res) {

    // var clientIp = getCallerIP(req);
    // // console.log(clientIp)

    // if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    //   res.send({ errMsg: "Invalid authentication" });
    //   // console.error(err)
    //   return null;
    // }


    client.get('store_sky_book' + req.params.eventId, (err, data) => {
        if (data) {
            try {
                data = JSON.parse(data);
            } catch (err) {
                console.error(err)
            }
            res.send(data);
        } else {
            fs.readFile('../../store_sky_book/' + req.params.eventId + '.json', 'utf8', (err, data) => {
                if (data) {
                    try {
                        data = JSON.parse(data);
                    } catch (err) {
                        console.error(err)
                    }
                    res.send(data);
                }
                else {
                    res.send({ data: null, eventId: req.params.eventId });
                }
            })
        }
    });
    // fs.readFile('../../store_sky_book/' + req.params.eventId + '.json', 'utf8', (err, data) => {
    //     if (err) {
    //         res.send({ data: null, eventId: req.params.eventId });
    //         // console.error(err)
    //         return null;
    //     }
    //     // console.log(data)
    //     if (data) {
    //         res.send(data);
    //     }
    //     else {
    //         res.send({ data: null, eventId: req.params.eventId });
    //     }
    // })
});

express.get('/api/sky_fancy/:eventId', function (req, res) {

    // var clientIp = getCallerIP(req);
    // // console.log(clientIp)

    // if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    //   res.send({ errMsg: "Invalid authentication" });
    //   // console.error(err)
    //   return null;
    // }
    fs.readFile('../../store_sky_fancy/' + req.params.eventId + '.json', 'utf8', (err, data) => {
        if (err) {
            res.send({ data: null, eventId: req.params.eventId });
            // console.error(err)
            return null;
        }
        // console.log(data)
        if (data) {
            res.send(data);
        }
        else {
            res.send({ data: null, eventId: req.params.eventId });
        }
    })
});


function getBmFancyAsync(gameId) {
    return new Promise((resolve) => {
        let skyEventId = "";
        let DiaMktId = "";
        let DiaEventId = "";

        if (gameId == "1806131356") {//sky soccer bm mapping
            skyEventId = "-10456437";
            DiaEventId = gameId;
            gameId = skyEventId;
            DiaMktId = "1.180613135858";
        }

        let finalData = {
            "data": {
                "t1": [],
                "t2": [],
                "t3": [],
                "t4": []
            },
            "message": true,
            gameId: gameId,
            "updatetime": "2022-11-17T18:27:00.021Z",
            "status": 200
        }
        getsky_fancy(function (data) {

            // -------------------------------------------
            if (DiaEventId && data) {
                data.forEach((fancy) => {
                    fancy.mid = DiaMktId;
                })
            }

            // -------------------------------------------

            finalData.data.t3 = data;
            if (data[0]) {
                finalData.updatetime = data[0].updatetime
            }
            getsky_book(function (data1) {
                if (data1.length > 0) {
                    finalData.data.t2.push({ bm1: [] });

                    // -------------------------------------------
                    if (DiaEventId && data1[0]) {
                        data1.forEach((bmrunner) => {
                            bmrunner.mid = DiaMktId;
                        })
                    }

                    // -------------------------------------------

                    finalData.data.t2[0].bm1 = data1;
                    if (data1[0]) {
                        finalData.updatetime = data1[0].updatetime
                    }
                }

                if (finalData.data.t2.length == 0 && finalData.data.t3.length == 0) {
                    finalData.data = null;
                    finalData['eventId'] = gameId;
                }

                resolve(finalData);
            }, gameId)
        }, gameId);

    });
}

function getFormatData(results) {
    let resultData = {};
    for (let i = 0; i < results.length; i++) {
        resultData[results[i].gameId] = results[i];
    }

    return resultData;
}

express.get('/api/bm_fancy_multi/:gameIds', function (req, res) {
    var clientIp = getCallerIP(req);
    // console.log(clientIp)

    let splitgameIds = req.params.gameIds.split(',');

    const promises = [];

    for (let i = 0; i < splitgameIds.length; i++) {
        promises.push(getBmFancyAsync(splitgameIds[i]));
    }

    Promise.all(promises)
        .then((results) => {
            // res.send(getFormatData(results));
            res.send(results);

        })
        .catch((e) => {
            res.send(e);
        });

});



app.listen(3471, function () {
    console.log('listening on *:3471');
});

