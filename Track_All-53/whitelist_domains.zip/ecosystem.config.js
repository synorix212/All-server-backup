
// https://stackoverflow.com/questions/31502351/how-to-specify-a-port-number-for-pm2
// https://pm2.keymetrics.io/docs/usage/application-declaration/

// pm2 start index.js --exp-backoff-restart-delay=100
// pm2 start index_ssexch.js --exp-backoff-restart-delay=100

// pm2 start ecosystem.config.js --exp-backoff-restart-delay=100
// # Start all applications
// pm2 start ecosystem.config.js

// # Stop all
// pm2 stop ecosystem.config.js

// # Restart all
// pm2 restart ecosystem.config.js

// # Update all
// pm2 update ecosystem.config.js

// # Reload all
// pm2 reload ecosystem.config.js

// # Delete all
// pm2 delete ecosystem.config.js

module.exports = {
  apps: [{
    name: "app00",
    script: "./index00.js",
    instances: "10",
    exec_mode: "cluster",
    env: {
      NODE_ENV: "production",
      PORT: 3440,
    },
  },
  // {
  //   name: "app01",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3441,
  //   },
  // },
  // {
  //   name: "app02",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3442,
  //   },
  // },
  // {
  //   name: "app03",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3443,
  //   },
  // },
  // {
  //   name: "app04",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3444,
  //   },
  // },
  {
    name: "app05",
    script: "./index00.js",
    instances: "3",
    exec_mode: "cluster",
    env: {
      NODE_ENV: "production",
      PORT: 3445,
    },
  },
  {
    name: "app06",
    script: "./index00.js",
    instances: "3",
    exec_mode: "cluster",
    env: {
      NODE_ENV: "production",
      PORT: 3446,
    },
  },
  // {
  //   name: "app07",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3447,
  //   },
  // },
  // {
  //   name: "app08",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3448,
  //   },
  // },
  // {
  //   name: "app09",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3449,
  //   },
  // },
  // {
  //   name: "app10",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3450,
  //   },
  // },
  // {
  //   name: "app11",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3451,
  //   },
  // },
  // {
  //   name: "app12",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3452,
  //   },
  // },
  // {
  //   name: "app13",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3453,
  //   },
  // },
  // {
  //   name: "app14",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3454,
  //   },
  // },
  // {
  //   name: "app15",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3455,
  //   },
  // },
  // {
  //   name: "app17",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3457,
  //   },
  // },
  // {
  //   name: "app18",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3458,
  //   },
  // },
  // {
  //   name: "app19",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3459,
  //   },
  // },
  // {
  //   name: "app20",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3460,
  //   },
  // },

  // {
  //   name: "app21",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3461,
  //   },
  // },
  // {
  //   name: "app22",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3462,
  //   },
  // },
  // {
  //   name: "app23",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3463,
  //   },
  // },
  // {
  //   name: "app24",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3464,
  //   },
  // },
  // {
  //   name: "app25",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3465,
  //   },
  // },
  // {
  //   name: "app26",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3466,
  //   },
  // },
  // {
  //   name: "app27",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3467,
  //   },
  // },
  // {
  //   name: "app28",
  //   script: "./index00.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3468,
  //   },
  // },
  // {
  //   name: "index02",
  //   script: "./index02.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3470,
  //   },
  // },
  // {
  //   name: "index03",
  //   script: "./index03.js",
  //   instances: "1",
  //   exec_mode: "fork",
  //   env: {
  //     NODE_ENV: "production",
  //     PORT: 3471,
  //   },
  // },
  {
    name: "index35",
    script: "./index35.js",
    instances: "3",
    exec_mode: "cluster",
    env: {
      NODE_ENV: "production",
      PORT: 3475,
    },
  },
  {
    name: "index36",
    script: "./index36.js",
    instances: "1",
    exec_mode: "fork",
    env: {
      NODE_ENV: "production",
      PORT: 3476,
    },
  },
  {
    name: "authenticator",
    script: "./authenticator.js",
    instances: "1",
    exec_mode: "fork",
    env: {
      NODE_ENV: "production",
      PORT: 3479,
    },
  },
  {
    name: "index81",
    script: "./index81.js",
    instances: "1",
    exec_mode: "fork",
    env: {
      NODE_ENV: "production",
      PORT: 3481,
    },
  },
  {
    name: "index82",
    script: "./index82.js",
    instances: "1",
    exec_mode: "fork",
    env: {
      NODE_ENV: "production",
      PORT: 3482,
    },
  }]
}
