const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 3479;
const https = require('https');
const ssl_domain = require("./ssl/ssl_domain");
app.use(bodyParser.json());
app.use(cors());
const twilio = require('twilio');
const serviceAccount = require('./serviceAccountKey.json');
const admin = require('firebase-admin');
const server = https.createServer(ssl_domain.options, app);

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
});

const twilioClient = twilio('AC78c802d2890605789305128ce853996b', '39c66cd830210ba811a3b3bbaeaa895e');

server.addContext('api1.streamingtv.fun', ssl_domain.options1);
server.addContext('api2.streamingtv.fun', ssl_domain.options2);
server.addContext('api3.streamingtv.fun', ssl_domain.options3);
server.addContext('access.streamingtv.fun', ssl_domain.options4);

function generateUniqueId() {
    const randomId = Math.floor(1000 + Math.random() * 9000);
    return randomId.toString();
  }
let notifications = [];
const verificationCodes = {};

// POST request to add a notification
app.post('/notifications', (req, res) => {
    const { header, content } = req.body;

    // Check if both header and content are provided
    if (!header || !content) {
        return res.status(400).json({ errorCode: 1, errorDescription: 'Both header and content are required.' });
    }

    const newNotification = {
        id: generateUniqueId(), // Add a unique 4-digit ID
        header,
        content,
        receivedDate: new Date().toISOString()
    };

    notifications.push(newNotification);
    res.json({ errorCode: 0, errorDescription: null, result: notifications });
});
// GET request to retrieve all notifications
app.get('/get-notifications', (req, res) => {
    res.json({ errorCode: 0, errorDescription: null, result: notifications });
});
app.delete('/delete-notifications/:ids', (req, res) => {
    const ids = req.params.ids.split(',');

    // Remove notifications with specified IDs
    const deletedNotifications = [];
    ids.forEach(id => {
        const index = notifications.findIndex(notification => notification.id === id);
        if (index !== -1) {
            deletedNotifications.push(notifications[index]);
            notifications.splice(index, 1);
        }
    });

    if (deletedNotifications.length > 0) {
        res.json({ errorCode: 0, errorDescription: null, result: [] });
    } else {
        res.status(404).json({ errorCode: 2, errorDescription: 'Notifications not found.' });
    }
});


// app.post('/sendLoginCode', async (req, res) => {
//     const phoneNumber = req.body.phoneNumber;
//     try {
//         let user;
        
//         try {
//             user = await admin.auth().getUserByPhoneNumber(phoneNumber);
//         } catch (getUserError) {
//         }

//         if (user) {
//             const otp = generateRandomOTP();
//             console.log(`Generated OTP for ${phoneNumber}: ${otp}`);

//             // Store the OTP for the user
//             verificationCodes[phoneNumber] = otp;

//             await sendOTPWithTwilio(phoneNumber, otp);
//             return res.json({ success: true, message: 'Login code sent successfully', user });
//         } else {
//         }

//         user = await admin.auth().createUser({
//             phoneNumber: phoneNumber,
//         });

//         // Generate and send OTP
//         const otp = generateRandomOTP();
//         console.log(`Generated OTP for ${phoneNumber}: ${otp}`);

//         // Store the OTP for the user
//         verificationCodes[phoneNumber] = otp;

//         await sendOTPWithTwilio(phoneNumber, otp);
//         return res.json({ success: true, message: 'Login code sent successfully', user });
//     } catch (error) {
//         if (error.code === 'auth/phone-number-already-exists') {
//             // User with the provided phone number already exists
//             return res.json({ success: true, message: 'Login code sent successfully' });
//         } else {
//             // Log other errors as actual errors
//             console.error('Error sending login code:', error);
//             return res.status(500).json({ success: false, error: 'Failed to send login code' });
//         }
//     }
// });

//   const generateRandomOTP = () => Math.floor(100000 + Math.random() * 900000).toString();
//   const sendOTPWithTwilio = async (phoneNumber, otp) => {
//       try {
//           await twilioClient.messages.create({
//               body: `Your OTP is: ${otp}`,
//               from: '+13302869784',
//               to: phoneNumber,
//           });
//       } catch (error) {
//           console.error('Error sending OTP via Twilio:', error);
//           throw error;
//       }
//   };
  
//   app.post('/verifyLoginCode', async (req, res) => {
//       const { phoneNumber, verificationCode } = req.body;
  
//       try {
//           const storedOTP = verificationCodes[phoneNumber];
  
//           if (verificationCode === storedOTP) {
//               res.json({ success: true, message: 'OTP verification successfully' });
//           } else {
//               console.error('Invalid OTP');
//               res.status(400).json({ success: false, message: 'Invalid OTP' });
//           }
//       } catch (error) {
//           console.error(`Error verifying OTP: ${error}`);
//           res.status(500).json({ success: false, message: 'Failed to verify OTP' });
//       }
//   });

server.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
