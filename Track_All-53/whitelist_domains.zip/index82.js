var express = require('express')();
const bodyParser = require('body-parser')
var fs = require('fs');
var https = require('https');
var cors = require('cors')
const whitelist = ['lc247.live', 'agunbet.live', 'ag.lc247.live', 'ag.agunbet.live']
express.use(bodyParser.json())
const { json } = require('express');


var ssl_domain = require("./ssl/ssl_domain");
const Server = require('socket.io');


let server = https.createServer(ssl_domain.options, express);

server.addContext('api1.streamingtv.fun', ssl_domain.options1);
server.addContext('api2.streamingtv.fun', ssl_domain.options2);
server.addContext('api3.streamingtv.fun', ssl_domain.options3);
server.addContext('access.vrnl.net', ssl_domain.options4);
server.addContext('access.streamtv247.fun', ssl_domain.options5);
server.addContext('api3.streamtv247.fun', ssl_domain.options6);
server.addContext('api.bfoddsapi.in', ssl_domain.options7);
server.addContext('access.vrnlapi.live', ssl_domain.options8);
server.addContext('api3.vrnlapi.live', ssl_domain.options9);



express.get('/', function (req, res) {
  res.send('api_working');
});

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin || whitelist.indexOf(origin) !== -1) {
      callback(null, true);
    }
    else {
      const error = new Error('Pass origin in header and whitelist');
      error.statusCode = 403;
      error.data = { message: 'Pass origin in header and whitelist' };
      callback(error);
    }
  }
};
express.post('/api/post_Ticker', cors(corsOptions), (req, res) => {
  const { body, headers } = req;
  const originName = headers.origin;
  const currentDate = new Date();
  const userId = Math.floor(1000 + Math.random() * 9000);
  const { ticker, userType , isImportant } = body;

  if (!originName) {
    return res.status(400).json({ error: "Pass origin in header" });
  }

  if (!ticker || !userType) {
    return res.status(400).json({ error: "Ticker and userType are required" });
  }
  if (parseInt(userType) !== 0 && parseInt(userType) !== 1) {
    return res.status(400).json({ error: "Invalid userType value" });
  }

  const prohibitedKeywords = ["alert(", "script"];
  if (prohibitedKeywords.some(keyword => ticker.includes(keyword))) {
    return res.status(400).json({ error: "Prohibited content detected" });
  }

  try {
    let existingData = [];
    let rawData;

    // Check if the file exists before reading from it
    if (fs.existsSync(`/enterprise/store_sitewise/${originName}.json`)) {
      rawData = fs.readFileSync(`/enterprise/store_sitewise/${originName}.json`, 'utf8');
      existingData = JSON.parse(rawData) || [];
    }

    const data = { ticker, uid: userId, Date: currentDate, userType, isImportant };
    existingData.push(data);

    fs.writeFile(`/enterprise/store_sitewise/${originName}.json`, JSON.stringify(existingData), (err) => {
      if (err) {
        return res.status(500).json({ status: 500, message: 'Error writing file' });
      }
      res.status(200).json({ status: 200, message: 'Added Ticker Successfully' });
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(400).json({ error: "Invalid ticker data" });
  }
});


express.get('/api/get_AdminTicker', cors(corsOptions), async (req, res) => {
  const originName = req.headers.origin;

  if (!originName) {
    return res.status(400).json({ error: "Pass origin in header" });
  }

  try {
    const data = await fs.promises.readFile(`/enterprise/store_sitewise/${originName}.json`, 'utf8');
    const tickers = JSON.parse(data);
    const adminTicker = tickers.filter(item => item.userType === '1');
    res.status(200).json({ status: 200, result: adminTicker });
  } catch (error) {
    res.status(500).json({ status: 500, message: 'Error reading file' });
  }
});

express.delete('/api/delete_Ticker/:uid', cors(corsOptions), (req, res) => {
  const uidToDelete = parseInt(req.params.uid);
  const originName = req.headers.origin;

  if (!uidToDelete || !originName) {
    return res.status(400).json({ error: "Pass origin in header or pass uid in param" });
  }

  const filePath = `/enterprise/store_sitewise/${originName}.json`;

  try {
    const data = fs.readFileSync(filePath, 'utf8');
    let tickers = JSON.parse(data);

    const tickerToDeleteIndex = tickers.findIndex(item => item.uid === uidToDelete);

    if (tickerToDeleteIndex === -1) {
      return res.status(404).json({ status: 404, message: 'Ticker not found' });
    }

    tickers.splice(tickerToDeleteIndex, 1);

    fs.writeFileSync(filePath, JSON.stringify(tickers), 'utf8');
    return res.status(200).json({ status: 200, message: 'Ticker deleted successfully' });
  } catch (error) {
    return res.status(500).json({ status: 500, message: 'Error processing request' });
  }
});

function getDomainName(hostName) {
  if (!hostName) {
    return;
  }
  let formatedHost = "";
  let splithostName = hostName.split('.');
  if (splithostName.length > 2) {
    formatedHost = hostName.substring(hostName.lastIndexOf(".", hostName.lastIndexOf(".") - 1) + 1);
  } else {
    formatedHost = hostName.split('//')[1]
  }
  return formatedHost;
}

express.get('/api/get_ticker', function (req, res) {
  const originName = req.headers.origin;

  if (getDomainName(req.get('origin')) === 'betswiz.com' || getDomainName(req.get('origin')) === 'betswiz.in') {
    return res.send({ ticker: null });
  }

  let tickers = null;
  let tickers1 = [];

  try {
    const tickerData = JSON.parse(fs.readFileSync('../../store_site_ticker/ticker.json', 'utf8'));
    if (tickerData) {
      tickers = tickerData;
    }

    if (originName) {
      try {
        const sitewiseTickerData = JSON.parse(fs.readFileSync(`/enterprise/store_sitewise/${originName}.json`, 'utf8'));
        tickers1 = sitewiseTickerData.filter(item => item.userType === '0');
      } catch (error) {
        tickers1 = null;
      }
    }
    if (tickers !== null || tickers1 !== null) {
      return res.status(200).json({
        tickers: tickers,
        tickers1: tickers1,
      });
    }

    return res.status(404).json({
      status: 404,
      message: 'No ticker data found',
    });
  } catch (error) {
    return res.status(500).json({ error: "Internal server error" });
  }
});


server.listen(3482, () => {
  console.log('run port 3482')
})