const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const qr = require('qrcode');
const crypto = require('crypto');
const speakeasy = require('speakeasy');
const sql = require('mssql')
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const nodemailer = require('nodemailer');
const redis = require('redis');
const redisClient = redis.createClient();
const TelegramBot = require('node-telegram-bot-api');
const cron = require('node-cron');
const admin = require("firebase-admin");
const serviceAccount = require("./serviceAccountKey.json");
const {
    EC2Client,
    StartInstancesCommand,
    StopInstancesCommand,
    DescribeInstancesCommand
} = require("@aws-sdk/client-ec2");
const {
    CloudWatchClient,
    GetMetricStatisticsCommand
} = require("@aws-sdk/client-cloudwatch");

const si = require("systeminformation");
const emailConfigs = {
    'cricwin.io': {
        user: 'dev@cricwin.io',
        pass: 'vhco jvta qapn icll',
        from: '"Cricwin Team" <dev@cricwin.io>',
        to: '"Cricwin Team" <dev@cricwin.io>'
    },
    'foxplay.pro': {
        user: 'support@vrnl.net',
        pass: 'pcch acie wqqu ycsp',
        from: '"Foxplay Team" <support@vrnl.net>',
        to: '"Foxplay Team" <support@vrnl.net>',
    },
    'nagadsx.com': {
        host: 'mail.privateemail.com',
        port: 465,
        secure: true,
        auth: {
            user: 'nagadsxsupport@bonusgo247.live',
            pass: 'Nagadsx254987',
        },
        from: '"Nagadsx Team" <nagadsxsupport@bonusgo247.live>',
        to: '"Nagadsx Team" <nagadsxsupport@bonusgo247.live>',
    }
};

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
});
const app = express();
app.use(cors());
const PORT = process.env.PORT || 3479;
const https = require('https');
const httpsAgent = new https.Agent({
    rejectUnauthorized: false,
});

const ssl_domain = require("./ssl/ssl_domain");
const server = https.createServer(ssl_domain.options, app);
server.addContext('api1.streamingtv.fun', ssl_domain.options1);
server.addContext('api2.streamingtv.fun', ssl_domain.options2);
server.addContext('api3.streamingtv.fun', ssl_domain.options3);
server.addContext('access.vrnl.net', ssl_domain.options4);
server.addContext('access.streamtv247.fun', ssl_domain.options5);
server.addContext('api3.streamtv247.fun', ssl_domain.options6);
server.addContext('api.bfoddsapi.in', ssl_domain.options7);
server.addContext('access.vrnlapi.live', ssl_domain.options8);
server.addContext('api3.vrnlapi.live', ssl_domain.options9);
server.addContext('api2.vrnlapi.live', ssl_domain.options10);
const authorization = "DA2F665979B2AA4381B717E6FEAB9C8C";

const uploadDir = './uploads';
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
const otpStore = {};
const upload = multer({ storage: storage });

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
const config = {
    user: 'agents',
    password: '12345678',
    server: '78.141.233.65',
    database: 'agentsList',
    // driver: 'msnodesqlv8',
    "options": {
        "encrypt": true,
        "enableArithAbort": true,
        "trustServerCertificate": true
    },
    connectionTimeout: 30000,
    requestTimeout: 30000
};
const domainBotTokens = {
    'star365.live': {
        botToken: '7929027739:AAGJHhS6xT4LLXTDkoTeL7l-wlXCfBx4IuY',
        chatId: '8322795407',
    },
    'baaaji.win': {
        botToken: '8905160368:AAHJwKZDCYlhvK29qzVAXrrLgoimk7tYPos',
        chatId: '7596640068',
    },
    // 'vrnlexch.com': {
    //     botToken: '7813004802:AAGdMQxya0e6q-GOMirJUfsiIbhn1En12m8',
    //     chatId: '8322795407',
    // },
    // 'foxplay.pro': {
    //     botToken: '7813004802:AAGdMQxya0e6q-GOMirJUfsiIbhn1En12m8',
    //     chatId: '8322795407',
    // },
    // 'vrnl.net': {
    //     botToken: '7813004802:AAGdMQxya0e6q-GOMirJUfsiIbhn1En12m8',
    //     chatId: '8322795407',
    // },
    // 'cricketscoreapi.com': {
    //     botToken: '7813004802:AAGdMQxya0e6q-GOMirJUfsiIbhn1En12m8',
    //     chatId: '8322795407',
    // },
    // 'vrnlexchange.com': {
    //     botToken: '7813004802:AAGdMQxya0e6q-GOMirJUfsiIbhn1En12m8',
    //     chatId: '8322795407',
    // },
    // 'vrnlexchange.in': {
    //     botToken: '7813004802:AAGdMQxya0e6q-GOMirJUfsiIbhn1En12m8',
    //     chatId: '8322795407',
    // },
    // 'vrnlexchange.net': {
    //     botToken: '7813004802:AAGdMQxya0e6q-GOMirJUfsiIbhn1En12m8',
    //     chatId: '8322795407',
    // },
    '1xbet365.live': {
        botToken: '7734306206:AAFtInHtNVnJ3vznxM3SKHEc-woXvm1w3Bs',
        chatId: '-1002323511738',
    },
    'josh365.live': {
        botToken: '7724405943:AAGG931AfRxaKI5rcDN0BAensZrv4KKKMAU',
        chatId: '-1002350801489',
    },
    'crickeet.live': {
        botToken: '7553918721:AAHfjBmvkykyaDnXa9XaWWxcdkktQNAonj8',
        chatId: '-1002478380200',
    },
    'mybazzi.live': {
        botToken: '7645793380:AAHFpveAXwztZq5x33TgfQjNmTQORD6VwUk',
        chatId: '-1002472092388',
    },
    'bdcrickeet.com': {
        botToken: '7705465939:AAFBr_krA_wLKxD-c9VuMk_GPbPjGfY8yww',
        chatId: '-1002289722280',
    },

    '9xbaji.pro': {
        botToken: '7600664092:AAFsISKoa9zpt1Com5twCeoq8-gcBZnS7do',
        chatId: '-1002337643458',
    },
    'vellki.live': {
        botToken: '8020048777:AAEC-h0BXli7JYhbtLeHCxL0PChIZYpDuM4',
        chatId: '-1002361786425',
    },
    'betbari.com': {
        botToken: '7592265581:AAFoc_E_cal137NlwCIkG8jok23_R7NfuF4',
        chatId: '-4577180635',
    },
    'baji88.games': {
        botToken: '7937386487:AAEaiCbi2zwqVD_tHXtTySFKDUdD_6rtCzE',
        chatId: '-1002291941205',
    },
    'lagabaji.com': {
        botToken: '7825366251:AAFh2VXWP_gVCzu8lQA9JeCRzwwfDEPLjh8',
        chatId: '7465565073',
    },
    'lagabaji.com': {
        botToken: '8182502044:AAG4LiuW1QPl3OpIU__Teesrq6emtr1PuNI',
        chatId: '5011046154',
    },
    'velkibdt.online': {
        botToken: '7683120817:AAF1JG8F57x_QyxLHclzxGknve4PnS7QJE0',
        chatId: '-1002343107654',
    },
    'mx365.pro': {
        botToken: '7747102005:AAG4RJWjTuiqRj8RI6oYWNQwmdsDNy9PnMA',
        chatId: '-1002600079052',
    },
    'espnex.app': {
        botToken: '8086007532:AAELn0lxmJg5f2KXFV_tQaM6ma3fpnPIT8g',
        chatId: '7737209015',
    },
    // 'bdplay.live': {
    //     botToken: '7439978642:AAHz_xkSAsGCPlMt2qQFClX8P8HeNplxryk',
    //     chatId: '-1002693874241',
    // },
    'bdplay.live': {
        botToken: '8467673812:AAGh3q53XE-guEZm3ginMND2g-AKR-c_zsU',
        chatId: '-1002935837900',
    },
    'ashik247.bet': {
        botToken: '8110254879:AAHG6uINRnhVrURyjj-YXdpxhZpY474_LOY',
        chatId: '5301272014',
    },
    'cashwinbd.com': {
        botToken: '8134042874:AAHE21oF9uENNhlEfJw2vov_DU7eFcjj-D4',
        chatId: '-1002837468901',
    },
    'velkimax.com': {
        botToken: '8134042874:AAHE21oF9uENNhlEfJw2vov_DU7eFcjj-D4',
        chatId: '-1002837468901',
    },
    'baajistar.com': {
        botToken: '8149047877:AAFbpVlf26Fml0zn6h30hPnDsLGS_6J0ADg',
        chatId: '-1002709259839',
    },
    'nagadsx.com': {
        botToken: '8458931988:AAG19NMdCHb5yFYp74v6gokA_YLJPQAWqPU',
        chatId: '-1003134436148',
    },
    '4six.com': {
        botToken: '8572823654:AAE6o1cR37BKrhAgB-eedmpRMYth6MizAL8',
        chatId: '-1003668614839',
    },
    'velkil.live': {
        botToken: '8176505669:AAHUqG7rLfCHXOm5nqs6qR97IKKrGzHmGbI',
        chatId: '-5013698146',
    },
};
const allowedOrigins = {
    '1601277': 'http://localhost:4200/',
    '1601277': 'http://localhost:4200',
    '1601277': 'https://ag.vrnlexch.com',
    '1601277': 'https://panel.vrnlofficial.com',
    '1866687': 'https://ag.bety247.live',
    '1866687': 'https://panel.bety247.info',
    '2663463': 'https://panel.play25.live',
    '2663463': 'https://panel.playagentlist.com',
    '4112338': 'https://panel.risxbet.com',
    '4195031': 'https://panel.vellkielist.com',
    '3479882': 'https://panel.lcagentlist.com',
    '4749969': 'https://panel.foxplaybdagentlist.com',
    '1468077': 'https://panel.bazzi365agentlist.com',
    '5633374': 'https://panel.9wicktsvipagentlist.pro',

};

// Middleware
app.use(bodyParser.json({ limit: '10mb' })); // Adjust the limit
app.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));



let notifications = [];

function generateUniqueId() {
    const randomId = Math.floor(1000 + Math.random() * 9000);
    return randomId.toString();
}

app.post("/api/getFirebaseId", async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({ error: "Email is required" });
        }

        const userRecord = await admin.auth().getUserByEmail(email);
        return res.json({
            firebaseId: userRecord.uid,
            email: userRecord.email
        });

    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
})

//authrnticator start///////////////
async function generateSecretKey() {
    const base32EncodeModule = await import('base32-encode');
    const base32Encode = base32EncodeModule.default;
    const secretBytes = crypto.randomBytes(10); // Increase the number of bytes
    return base32Encode(secretBytes, 'RFC4648');
}
// Generate QR Code containing secret key and user info
function generateQRCode(username, secretKey, callback) {
    console.log(secretKey);
    const otpAuthUrl = speakeasy.otpauthURL({
        secret: secretKey,
        label: username, // Username as label
        issuer: 'authenticator app', // Replace 'YourApp' with your app name
        encoding: 'base32'
    });

    qr.toDataURL(otpAuthUrl, callback);
}
// Generate QR Code API
app.get('/member-service/otp/qr', async (req, res) => {
    try {
        // Extract the username from the request query parameters
        const { username } = req.query;

        // Generate the secret key
        const secretKey = await generateSecretKey();
        console.log(secretKey);

        // Generate QR code using the fetched username and secret key
        generateQRCode(username, secretKey, (err, url) => {
            if (err) {
                console.error(err);
                return res.status(500).send('Error generating QR code');
            }
            // Send QR code image as response
            res.send({
                qrCodeImageUrl: url,
                secretKey: secretKey
            });
        });
    } catch (error) {
        console.error('Error generating QR code:', error.message);
        res.status(500).send('Error generating QR code');
    }
});
// OTP Verification API
app.post('/verify-otp', (req, res) => {
    const { otp, secretKey } = req.body;
    console.log("OTP received:", otp);
    console.log("Secret Key received:", secretKey);

    // Validate OTP
    const verified = speakeasy.totp.verify({
        secret: secretKey,
        encoding: 'base32',
        token: otp
    });

    if (verified) {
        res.json({ message: 'OTP verified successfully' });
    } else {
        // res.status(400).json({ error: 'Invalid OTP' });
        res.json({ error: 'Invalid OTP' });

    }
});

//authrnticator end///////////////


//notifications start///////////////
app.post('/notifications', (req, res) => {
    const { header, content, domain, uid, userName } = req.body;
    if (!header || !content || !domain) {
        return res.status(200).json({ errorCode: 1, errorDescription: 'All fields are required.' });
    }
    const notificationsFilePath = path.join(__dirname, 'uploads', 'notifications.json');
    let notifications = [];
    if (fs.existsSync(notificationsFilePath)) {
        const data = fs.readFileSync(notificationsFilePath, 'utf-8');
        notifications = JSON.parse(data);
    }
    const newNotification = {
        id: generateUniqueId(),
        header,
        content,
        uid: uid ? Number(uid) : 0,
        domain,
        userName,
        read: false,
        receivedDate: new Date().toISOString()
    };
    notifications.push(newNotification);
    fs.writeFileSync(notificationsFilePath, JSON.stringify(notifications, null, 2));
    res.json({ errorCode: 0, errorDescription: null, result: 'Notification Send Successfully' });
});
// app.get('/get-notifications', (req, res) => {
//     const { domain, uid } = req.query;
//     const metadataPath = path.join(__dirname, 'uploads', 'notifications.json');
//     const data = fs.readFileSync(metadataPath, 'utf-8');
//     let result = JSON.parse(data);

//     if (domain) {
//         if (uid) {
//             const filteredByBoth = result.filter(
//                 (notification) => notification.domain === domain && notification.uid === Number(uid)
//             );

//             if (filteredByBoth.length > 0) {
//                 result = filteredByBoth;
//             } else {
//                 result = result.filter(
//                     (notification) => notification.domain === domain && notification.uid === 0
//                 );
//             }
//         } else {
//             result = result.filter(
//                 (notification) => notification.domain === domain && notification.uid === 0
//             );
//         }
//     }

//     res.json({ errorCode: 0, errorDescription: null, result });
// });

app.get('/get-notifications', (req, res) => {
    const { domain, uid } = req.query;
    const metadataPath = path.join(__dirname, 'uploads', 'notifications.json');

    if (!fs.existsSync(metadataPath)) {
        return res.json({ errorCode: 1, errorDescription: "Notifications file not found", result: [] });
    }

    const data = fs.readFileSync(metadataPath, 'utf-8');
    let result = JSON.parse(data || '[]'); // Ensure valid JSON

    if (domain) {
        if (uid) {
            // Get user-specific notifications
            const filteredByUser = result.filter(notification =>
                notification.domain === domain && notification.uid === Number(uid)
            );

            // Get admin notifications (`uid=0`)
            const filteredByAdmin = result.filter(notification =>
                notification.domain === domain && notification.uid === 0
            );

            // Combine both user-specific and admin notifications
            result = [...filteredByUser, ...filteredByAdmin];
        } else {
            // If only domain is provided, return only admin notifications
            result = result.filter(notification => notification.domain === domain && notification.uid === 0);
        }
    }

    res.json({ errorCode: 0, errorDescription: null, result });
});
app.get('/get-notifications-admin', (req, res) => {
    const { domain } = req.query;
    const metadataPath = path.join(__dirname, 'uploads', 'notifications.json');
    const data = fs.readFileSync(metadataPath, 'utf-8');
    let result = JSON.parse(data);
    if (domain) {
        result = result.filter(
            (notification) => notification.domain === domain && notification.uid === 0
        );
    }
    res.json({ errorCode: 0, errorDescription: null, result });
});
// app.get('/notifications/unread-count', (req, res) => {
//     const { domain, uid } = req.query;
//     const notificationsFilePath = path.join(__dirname, 'uploads', 'notifications.json');
//     let unreadCount = 0;

//     if (fs.existsSync(notificationsFilePath)) {
//         const data = fs.readFileSync(notificationsFilePath, 'utf-8');
//         const notifications = JSON.parse(data);
//         unreadCount = notifications.filter(notification =>
//             notification.read === false &&
//             notification.domain === domain &&
//             notification.uid === Number(uid)
//         ).length;
//     }

//     res.json({ errorCode: 0, errorDescription: null, unreadCount });
// });
// app.put('/notifications/mark-all-read', (req, res) => {
//     const { domain, uid } = req.query;
//     const notificationsFilePath = path.join(__dirname, 'uploads', 'notifications.json');
//     let notifications = [];
//     if (fs.existsSync(notificationsFilePath)) {
//         const data = fs.readFileSync(notificationsFilePath, 'utf-8');
//         notifications = JSON.parse(data);
//         notifications.forEach(notification => {
//             if (notification.read === false &&
//                 notification.domain === domain &&
//                 notification.uid === Number(uid)) {
//                 notification.read = true;
//             }
//         });
//         fs.writeFileSync(notificationsFilePath, JSON.stringify(notifications, null, 2));
//         res.json({ errorCode: 0, errorDescription: null, message: 'All notifications marked as read' });
//     } else {
//         res.status(404).json({ errorCode: 1, errorDescription: 'Notifications file not found' });
//     }
// });
app.put('/notifications/mark-all-read', (req, res) => {
    const { domain, uid } = req.query;
    const notificationsFilePath = path.join(__dirname, 'uploads', 'notifications.json');
    let notifications = [];

    if (fs.existsSync(notificationsFilePath)) {
        const data = fs.readFileSync(notificationsFilePath, 'utf-8');
        notifications = JSON.parse(data);

        notifications.forEach(notification => {
            if (notification.read === false && notification.domain === domain) {
                if (notification.uid === Number(uid)) {
                    // Mark user-specific notification as read
                    notification.read = true;
                } else if (notification.uid === 0) {
                    // Track users who have read the admin notification
                    if (!notification.readBy) {
                        notification.readBy = [];
                    }
                    if (!notification.readBy.includes(Number(uid))) {
                        notification.readBy.push(Number(uid));
                    }
                }
            }
        });

        fs.writeFileSync(notificationsFilePath, JSON.stringify(notifications, null, 2));
        res.json({ errorCode: 0, errorDescription: null, message: 'All notifications marked as read' });
    } else {
        res.status(404).json({ errorCode: 1, errorDescription: 'Notifications file not found' });
    }
});
// app.get('/notifications/unread-count', (req, res) => {
//     const { domain, uid } = req.query;
//     const notificationsFilePath = path.join(__dirname, 'uploads', 'notifications.json');
//     let unreadCount = 0;

//     if (fs.existsSync(notificationsFilePath)) {
//         try {
//             const data = fs.readFileSync(notificationsFilePath, 'utf-8');

//             if (!data.trim()) {
//                 return res.json({ errorCode: 1, errorDescription: "JSON file is empty", unreadCount: 0 });
//             }

//             const notifications = JSON.parse(data);

//             unreadCount = notifications.filter(notification =>
//                 notification.read === false &&
//                 notification.domain === domain &&
//                 (
//                     notification.uid === Number(uid) || 
//                     (notification.uid === 0 && (!notification.readBy || !notification.readBy.includes(Number(uid))))
//                 )
//             ).length;
//         } catch (error) {
//             return res.json({ errorCode: 2, errorDescription: "Invalid JSON format", unreadCount: 0 });
//         }
//     } else {
//         return res.json({ errorCode: 3, errorDescription: "File not found", unreadCount: 0 });
//     }

//     res.json({ errorCode: 0, errorDescription: null, unreadCount });
// });
app.delete('/delete-notifications/:ids', (req, res) => {
    const ids = req.params.ids.split(',');
    const notificationsFilePath = path.join(__dirname, 'uploads', 'notifications.json');
    let notifications = [];
    if (fs.existsSync(notificationsFilePath)) {
        const data = fs.readFileSync(notificationsFilePath, 'utf-8');
        notifications = JSON.parse(data);
    }
    const deletedNotifications = [];
    notifications = notifications.filter(notification => {
        if (ids.includes(notification.id)) {
            deletedNotifications.push(notification);
            return false;
        }
        return true;
    });
    fs.writeFileSync(notificationsFilePath, JSON.stringify(notifications, null, 2));
    if (deletedNotifications.length > 0) {
        res.json({ errorCode: 0, errorDescription: null, result: deletedNotifications });
    } else {
        res.status(404).json({ errorCode: 2, errorDescription: 'Notifications not found.' });
    }
});
//notifications end///////////////


//agentlist start///////////////
sql.connect(config)
    .then(() => {
        console.log('Connected to SQL Server');
    })
    .catch(err => {
        console.error('Error connecting to SQL Server:', err);
    });

//agentlist start///////////////

app.post('/api/agents', async (req, res) => {
    const {
        AGID, TYPE, NAME, WHATSAPP, WHATSAPP1, MESSENGER, PHONE_NUMBER,
        INSTAGRAM, TELEGRAM, STAR, REPORTNUMBER,
        ISQUICKAGENT, ISSERVICE, WLID,
        PARENT, PARENTID, DELETESTATUS, PROFILE
    } = req.body;

    if (!allowedOrigins[WLID] || req.headers.origin !== allowedOrigins[WLID]) {
        return res.status(401).json({ errorCode: 1, errorDescription: 'Invalid authentication' });
    }

    try {
        const request = new sql.Request();
        request.input('PARENTID', sql.VarChar, PARENTID);

        const parentResult = await request.query(
            'SELECT USERID FROM users WHERE ID = @PARENTID'
        );

        let userID = PARENTID;
        if (parentResult.recordset.length && parentResult.recordset[0].USERID) {
            userID = `${parentResult.recordset[0].USERID},${PARENTID}`;
        }

        // ✅ Handle base64 image
        let ProfilePath = null;

        if (PROFILE) {
            const buffer = Buffer.from(PROFILE, 'base64');
            const filename = `${AGID}_${Date.now()}.png`;
            const uploadPath = path.join(__dirname, 'uploads/profile', filename);

            await fs.promises.writeFile(uploadPath, buffer);
            ProfilePath = `/uploads/profile/${filename}`;
        }

        const insertRequest = new sql.Request();
        insertRequest
            .input('USERID', sql.VarChar, userID)
            .input('AGID', sql.VarChar, AGID)
            .input('TYPE', sql.VarChar, TYPE)
            .input('NAME', sql.VarChar, NAME)
            .input('WHATSAPP', sql.VarChar, WHATSAPP)
            .input('WHATSAPP1', sql.VarChar, WHATSAPP1)
            .input('MESSENGER', sql.VarChar, MESSENGER)
            .input('PHONE_NUMBER', sql.VarChar, PHONE_NUMBER)
            .input('INSTAGRAM', sql.VarChar, INSTAGRAM)
            .input('TELEGRAM', sql.VarChar, TELEGRAM)
            .input('STAR', sql.VarChar, STAR)
            .input('REPORTNUMBER', sql.VarChar, REPORTNUMBER)
            .input('ISQUICKAGENT', sql.Bit, ISQUICKAGENT)
            .input('ISSERVICE', sql.Bit, ISSERVICE)
            .input('WLID', sql.VarChar, WLID)
            .input('PARENT', sql.VarChar, PARENT)
            .input('PARENTID', sql.VarChar, PARENTID)
            .input('DELETESTATUS', sql.VarChar, DELETESTATUS)
            .input('PROFILE', sql.VarChar, ProfilePath);

        await insertRequest.query(`
            INSERT INTO users (
                AGID, TYPE, NAME, WHATSAPP, WHATSAPP1, MESSENGER, PHONE_NUMBER,
                INSTAGRAM, TELEGRAM, STAR, REPORTNUMBER,
                ISQUICKAGENT, ISSERVICE, WLID,
                PARENT, PARENTID, USERID, DELETESTATUS, PROFILE
            )
            VALUES (
                @AGID, @TYPE, @NAME, @WHATSAPP, @WHATSAPP1 ,@MESSENGER, @PHONE_NUMBER,
                @INSTAGRAM, @TELEGRAM, @STAR, @REPORTNUMBER,
                @ISQUICKAGENT, @ISSERVICE, @WLID,
                @PARENT, @PARENTID, @USERID, @DELETESTATUS, @PROFILE
            )
        `);

        res.status(200).json({
            errorCode: 0,
            message: 'Agent inserted successfully'
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            errorCode: 1,
            errorDescription: 'Error inserting agent',
            error
        });
    }
});
app.put('/api/Updateagents/:id', async (req, res) => {
    const id = req.params.id;

    const {
        AGID, TYPE, NAME, WHATSAPP, WHATSAPP1, MESSENGER, PHONE_NUMBER,
        INSTAGRAM, TELEGRAM, STAR, REPORTNUMBER,
        ISQUICKAGENT, ISSERVICE, WLID,
        PARENT, PARENTID, DELETESTATUS, PROFILE
    } = req.body;

    if (!allowedOrigins[WLID] || req.headers.origin !== allowedOrigins[WLID]) {
        return res.status(401).json({
            errorCode: 1,
            errorDescription: 'Invalid authentication'
        });
    }

    try {
        await sql.connect(config);

        /* ---------- GET PARENT USERID ---------- */
        const parentReq = new sql.Request();
        parentReq.input('PARENTID', sql.VarChar, PARENTID);

        const parentResult = await parentReq.query(
            'SELECT USERID FROM users WHERE ID = @PARENTID'
        );

        let userID = PARENTID;
        if (parentResult.recordset.length && parentResult.recordset[0].USERID) {
            userID = `${parentResult.recordset[0].USERID},${PARENTID}`;
        }

        /* ---------- GET OLD PROFILE ---------- */
        const oldProfileRes = await sql.query`
            SELECT PROFILE FROM users WHERE ID = ${id}
        `;

        let ProfilePath = oldProfileRes.recordset[0]?.PROFILE || null;

        /* ---------- HANDLE PROFILE ---------- */
        if (PROFILE) {
            // case 1: already a path
            if (PROFILE.startsWith('/uploads/')) {
                ProfilePath = PROFILE;
            }
            // case 2: base64 image
            else {
                const cleanBase64 = PROFILE.replace(/^data:image\/\w+;base64,/, '');
                const buffer = Buffer.from(cleanBase64, 'base64');

                const filename = `${AGID}_${Date.now()}.png`;
                const uploadPath = path.join(__dirname, 'uploads/profile', filename);

                // delete old image if exists
                if (ProfilePath && ProfilePath.startsWith('/uploads/')) {
                    const oldFile = path.join(__dirname, ProfilePath);
                    if (fs.existsSync(oldFile)) fs.unlinkSync(oldFile);
                }

                await fs.promises.writeFile(uploadPath, buffer);
                ProfilePath = `/uploads/profile/${filename}`;
            }
        }
        // else → PROFILE nahi aaya → old ProfilePath as-it-is

        /* ---------- UPDATE QUERY ---------- */
        const result = await sql.query`
            UPDATE users 
            SET 
                AGID = ${AGID},
                TYPE = ${TYPE},
                NAME = ${NAME},
                WHATSAPP = ${WHATSAPP},
                WHATSAPP1 = ${WHATSAPP1},
                MESSENGER = ${MESSENGER},
                PHONE_NUMBER = ${PHONE_NUMBER},
                INSTAGRAM = ${INSTAGRAM},
                TELEGRAM = ${TELEGRAM},
                STAR = ${STAR},
                REPORTNUMBER = ${REPORTNUMBER},
                ISQUICKAGENT = ${ISQUICKAGENT},
                ISSERVICE = ${ISSERVICE},
                WLID = ${WLID},
                PARENT = ${PARENT},
                PARENTID = ${PARENTID},
                USERID = ${userID},
                DELETESTATUS = ${DELETESTATUS},
                PROFILE = ${ProfilePath}
            WHERE ID = ${id}
        `;

        if (result.rowsAffected[0] === 0) {
            res.status(404).json({ errorCode: 1, errorDescription: 'Record not found', result: null });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, result: `Data updated successfully` });
        }

    } catch (err) {
        console.error('Update error:', err);
        res.status(500).json({
            errorCode: 1,
            errorDescription: err.message
        });
    }
});
app.get('/api/getAgentList/:WLID', async (req, res) => {
    const { WLID } = req.params;
    try {
        await sql.connect(config);
        const result = await sql.query`SELECT * FROM users WHERE WLID = ${WLID} AND DELETESTATUS = 'active'`;
        res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });
    } catch (err) {
        console.error('Error fetching agent list:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
// app.get('/api/getAgentList/:WLID/:TYPE', async (req, res) => {
//     const { WLID, TYPE } = req.params;
//     try {
//         await sql.connect(config);
//         const result = await sql.query`SELECT * FROM users WHERE WLID = ${WLID} AND TYPE = ${TYPE} AND DELETESTATUS = 'active'`;
//         res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });
//     } catch (err) {
//         console.error('Error fetching agent list:', err);
//         res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
//     }
// });
app.get('/api/getAgentList/:WLID/:TYPE', async (req, res) => {
    const { WLID, TYPE } = req.params;
    let result;

    try {
        await sql.connect(config);
        const query = TYPE == 11
            ? `SELECT * FROM users WHERE WLID = ${WLID} AND ISQUICKAGENT = 1 AND DELETESTATUS = 'active'`
            : `SELECT * FROM users WHERE WLID = ${WLID} AND TYPE = ${TYPE} AND DELETESTATUS = 'active'`;

        result = await sql.query(query);
        res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });

    } catch (err) {
        console.error('Error fetching agent list:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
app.get('/api/getAgentListAdmin/:WLID', async (req, res) => {
    const { WLID } = req.params;
    try {
        await sql.connect(config);
        const result = await sql.query`SELECT * FROM users WHERE WLID = ${WLID}`;
        res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });
    } catch (err) {
        console.error('Error fetching agent list:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
app.get('/api/getAgentListAdmin/:WLID/:TYPE', async (req, res) => {
    const { WLID, TYPE } = req.params;
    let result;

    try {
        await sql.connect(config);
        const query = TYPE == 11
            ? `SELECT * FROM users WHERE WLID = ${WLID} AND ISQUICKAGENT = 1`
            : `SELECT * FROM users WHERE WLID = ${WLID} AND TYPE = ${TYPE}`;

        result = await sql.query(query);
        res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });

    } catch (err) {
        console.error('Error fetching agent list:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
app.get('/api/getParent', (req, res) => {
    const { USERID } = req.query;
    if (!USERID) {
        return res.status(400).json({ errorCode: 1, errorDescription: 'USERID is required' });
    }
    const userIds = USERID.split(',').map(id => id.trim());
    const query = `SELECT * FROM users WHERE (ID IN (${userIds.map((id, index) => `'${id}'`).join(',')})) AND DELETESTATUS = 'active'`;
    new sql.Request().query(query)
        .then(result => {
            if (result.recordset.length > 0) {
                res.status(200).json({ errorCode: 0, data: result.recordset });
            } else {
                res.status(404).json({ errorCode: 1, errorDescription: 'No data found' });
            }
        })
        .catch(error => {
            res.status(500).json({ errorCode: 1, errorDescription: 'Error fetching data', error });
        });
});
app.get('/api/getChildren', (req, res) => {
    const { ID } = req.query;
    if (!ID) {
        return res.status(400).json({ errorCode: 1, errorDescription: 'ID is required' });
    }
    const query = `SELECT * FROM users WHERE (ID = ${ID} OR USERID LIKE '%,${ID},%' OR USERID LIKE '${ID},%' OR USERID LIKE '%,${ID}' OR USERID = '${ID}') AND DELETESTATUS = 'active'`;
    const request = new sql.Request();
    request.query(query)
        .then(result => {
            if (result.recordset.length > 0) {
                res.status(200).json({ errorCode: 0, data: result.recordset });
            } else {
                res.status(404).json({ errorCode: 1, errorDescription: 'No children found' });
            }
        })
        .catch(error => {
            res.status(500).json({ errorCode: 1, errorDescription: 'Error fetching data', error });
        });
});
app.delete('/api/deleteAgent/:id', async (req, res) => {
    const id = req.params.id;
    try {
        await sql.connect(config);
        const result = await sql.query`UPDATE users SET DELETESTATUS = 'deleted' WHERE ID = ${id}`;
        if (result.rowsAffected[0] === 0) {
            res.status(404).json({ errorCode: 1, errorDescription: 'Record not found', result: null });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, result: `Record deleted successfully` });
        }
    } catch (err) {
        console.error('Error deleting agent:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
app.delete('/api/deleteHierarchy/:ids', async (req, res) => {
    const ID = req.params.ids;

    try {
        await sql.connect(config);
        const query = `
            UPDATE users 
            SET DELETESTATUS = 'deleted' 
            WHERE ID = @ID 
            OR USERID LIKE '%,${ID},%' 
            OR USERID LIKE '${ID},%' 
            OR USERID LIKE '%,${ID}' 
            OR USERID = '${ID}'
        `;
        const request = new sql.Request();
        request.input('ID', sql.VarChar, ID);

        const result = await request.query(query);
        if (result.rowsAffected[0] > 0) {
            res.status(200).json({
                errorCode: 0,
                errorDescription: null,
                result: `User deleted successfully for ${result.rowsAffected[0]} record(s)`
            });
        } else {
            res.status(404).json({
                errorCode: 1,
                errorDescription: 'No matching records found',
                result: null
            });
        }
    } catch (err) {
        console.error('Error updating DELETESTATUS:', err);
        res.status(500).json({
            errorCode: 1,
            errorDescription: err.message,
            result: null
        });
    }
});
app.put('/api/ActiveHierarchy/:ids', async (req, res) => {
    const ID = req.params.ids;

    try {
        await sql.connect(config);
        const query = `
            UPDATE users 
            SET DELETESTATUS = 'active' 
            WHERE ID = @ID 
            OR USERID LIKE '%,${ID},%' 
            OR USERID LIKE '${ID},%' 
            OR USERID LIKE '%,${ID}' 
            OR USERID = '${ID}'
        `;
        const request = new sql.Request();
        request.input('ID', sql.VarChar, ID);

        const result = await request.query(query);
        if (result.rowsAffected[0] > 0) {
            res.status(200).json({
                errorCode: 0,
                errorDescription: null,
                result: `User active successfully for ${result.rowsAffected[0]} record(s)`
            });
        } else {
            res.status(404).json({
                errorCode: 1,
                errorDescription: 'No matching records found',
                result: null
            });
        }
    } catch (err) {
        console.error('Error updating DELETESTATUS:', err);
        res.status(500).json({
            errorCode: 1,
            errorDescription: err.message,
            result: null
        });
    }
});
app.post('/api/LoginAgent', async (req, res) => {
    const { userName, password } = req.body
    try {
        await sql.connect(config)
        const loginTime = new Date().toISOString();
        const result = await sql.query`SELECT * FROM createAgent WHERE userName = ${userName} AND password = ${password}`
        console.log(result, "real");
        if (result.rowsAffected[0] == 0) {
            res.status(200).json({ errorCode: 1, errorDescription: 'UserName or Password Wrong', result: 'UserName or Password Wrong' });
        } else {
            const user = result.recordset[0];
            res.status(200).json({
                errorCode: 0, errorDescription: null, result: [
                    {
                        username: userName,
                        loginTime: loginTime,
                        userId: user.userID,
                        WLID: user.WLID
                    }
                ]
            });
        }

    }
    catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
})
app.post('/api/proxylink', (req, res) => {
    const { Name, LinkText, HyperLink, Active, WLID } = req.body
    if (allowedOrigins[WLID] && req.headers.origin === allowedOrigins[WLID]) {
        const request = new sql.Request()
        request.input('Name', sql.VarChar, Name)
        request.input('LinkText', sql.VarChar, LinkText)
        request.input('HyperLink', sql.VarChar, HyperLink)
        request.input('Active', sql.Bit, Active)
        request.input('WLID', sql.VarChar, WLID)
        request.query('INSERT INTO proxyLink (Name ,LinkText ,HyperLink ,Active ,WLID) VALUES (@Name ,@LinkText ,@HyperLink ,@Active ,@WLID)')
            .then(result => {
                console.log('proxy Link inserted successfully:', result);
                res.status(200).json({ errorCode: 0, errorDescription: null, message: 'proxy Link Updated successfully' });
            })
            .catch(error => {
                console.error('Error inserting agent:', error);
                res.status(500).json({ errorCode: 1, errorDescription: null, error: 'Error inserting agent' });
            })

    }
    else {
        res.status(401).json({ errorCode: 1, errorDescription: 'Invalid authentication', result: null });
    }
})
app.get('/api/getproxyLink/:WLID', async (req, res) => {
    const { WLID } = req.params
    try {
        await sql.connect(config)
        const result = await sql.query`SELECT * FROM proxyLink WHERE WLID = ${WLID}`
        res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });
    }
    catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }

})
app.delete('/api/deleteproxyLink/:id', async (req, res) => {
    const { id } = req.params
    try {
        await sql.connect(config)
        const result = await sql.query`DELETE FROM proxyLink WHERE id = ${id}`
        if (result.rowsAffected[0] == 0) {
            res.status(200).json({ errorCode: 1, errorDescription: null, result: 'Record Not Found' });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, result: 'Data Deleted Successfully' });
        }
    }
    catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }

})
app.put('/api/editProxy/:id', async (req, res) => {
    const id = req.params.id
    const { Name, LinkText, HyperLink, Active, WLID } = req.body
    try {
        await sql.connect(config)
        const request = new sql.Request()
        request.input('id', sql.Int, id);
        request.input('Name', sql.VarChar, Name);
        request.input('LinkText', sql.VarChar, LinkText);
        request.input('HyperLink', sql.VarChar, HyperLink);
        request.input('Active', sql.Bit, Active);
        request.input('WLID', sql.VarChar, WLID);
        const resultfinal = await request.query(`UPDATE proxyLink SET 
        Name = @Name ,
        LinkText = @LinkText ,
        HyperLink = @HyperLink ,
        Active = @Active ,
        WLID = @WLID 
        WHERE id = @id`);
        if (resultfinal.rowsAffected[0] == 0) {
            res.status(404).json({ errorCode: 1, errorDescription: 'Record not found', resultfinal: null });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, message: `Result updated successfully` });
        }

    } catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }

})
app.post('/api/createAgent', async (req, res) => {
    const { userName, Password, Confirmpassword, WLID, domain } = req.body
    if (Password !== Confirmpassword) {
        return res.status(400).json({ errorCode: 1, errorDescription: 'Passwords do not match', result: null });
    }
    try {
        const request = new sql.Request()
        request.input('userName', sql.VarChar, userName)
        request.input('Password', sql.VarChar, Password)
        request.input('Confirmpassword', sql.VarChar, Confirmpassword)
        request.input('WLID', sql.VarChar, WLID)
        request.input('domain', sql.VarChar, domain)
        const result = await request.query('INSERT INTO createAgent (userName, Password, WLID ,domain) VALUES (@userName, @Password, @WLID, @domain)');
        res.status(200).json({ errorCode: 0, errorDescription: null, message: 'User created successfully' });

    } catch (err) {
        console.error('Error inserting create agent:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, err: 'Error inserting create agent' });
    }
})
app.get('/api/getWLID/:domain', async (req, res) => {
    const { domain } = req.params;
    try {
        await sql.connect(config);
        const result = await sql.query`SELECT WLID FROM createAgent WHERE domain = ${domain}`;
        res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });
    }
    catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
app.put('/api/changepassword-agentList', async (req, res) => {
    const { oldPassword, newpassword, confirmpassword, userID } = req.body
    if (!oldPassword) {
        res.status(200).json({ errorCode: 1, errorDescription: 'Old Password is required', result: null });
    }
    if (newpassword != confirmpassword) {
        res.status(200).json({ errorCode: 1, errorDescription: 'New passwords do not match', result: null });
    }
    try {
        await sql.connect(config)
        const getQwery = `SELECT Password FROM createAgent WHERE userID = ${userID}`
        const results = await sql.query(getQwery, {
            userID: userID
        });
        const storedPassword = results.recordset[0].Password;
        if (storedPassword != oldPassword) {
            return res.status(200).json({ errorCode: 1, errorDescription: 'Old Password is incorrect', result: null });
        }
        const result = await sql.query`
        UPDATE CreateAgent SET
        Password = ${newpassword}
         WHERE 
            userID = ${userID} `
        if (result.rowsAffected[0] === 0) {
            res.status(200).json({ errorCode: 1, errorDescription: 'Record not found', result: null });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, result: `Password updated successfully` });
        }
    } catch (err) {
        console.error('Error updating agent:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }

})
app.post('/api/AgentLatestUpdate', async (req, res) => {
    const { id, message, domain, document } = req.body;
    if (!id || !message || !domain || !document) {
        return res.status(400).json({ error: "All fields are required." });
    }
    let documentPath = null;

    if (document) {
        const buffer = Buffer.from(document, 'base64');
        const filename = `${id}_${Date.now()}.png`;
        const filepath = `./uploads/${filename}`;
        require('fs').writeFileSync(filepath, buffer);
        documentPath = filepath;
    }
    try {
        const request = new sql.Request()
        request.input('id', sql.VarChar, id)
        request.input('message', sql.NVarChar, message)
        request.input('domain', sql.VarChar, domain)
        request.input('document', sql.VarChar, documentPath)
        const result = await request.query('INSERT INTO LatestUpdate (id ,message ,domain ,document) VALUES (@id ,@message, @domain , @document)');
        res.status(200).json({ errorCode: 0, errorDescription: null, message: 'Data Update successfully' });

    } catch (err) {
        console.error('Error inserting Message:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, err: 'Error inserting Message' });
    }
})
app.get('/api/GetLatestUpdate/:domain', async (req, res) => {
    const { domain } = req.params;
    try {
        await sql.connect(config);
        const result = await sql.query`SELECT * FROM LatestUpdate WHERE domain = ${domain}`;
        res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });
    }
    catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
app.delete('/api/DeleteLatestUpdate/:id', async (req, res) => {
    const { id } = req.params
    try {
        await sql.connect(config)
        const result = await sql.query`DELETE FROM LatestUpdate WHERE id = ${id}`
        if (result.rowsAffected[0] == 0) {
            res.status(200).json({ errorCode: 1, errorDescription: null, result: 'Record Not Found' });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, result: 'Data Deleted Successfully' });
        }
    }
    catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }

})
app.put('/api/editLatestUpdate/:id', async (req, res) => {
    const id = req.params.id
    const { message, domain, document, Active, WLID } = req.body
    try {
        await sql.connect(config)
        const request = new sql.Request()
        request.input('id', sql.Int, id);
        request.input('message', sql.NVarChar, message);
        request.input('domain', sql.VarChar, domain);
        request.input('document', sql.VarChar, document);
        const resultfinal = await request.query(`UPDATE LatestUpdate SET 
        message = @message ,
        domain = @domain ,
        document = @document 
        WHERE id = @id`);
        if (resultfinal.rowsAffected[0] == 0) {
            res.status(404).json({ errorCode: 1, errorDescription: 'Record not found', resultfinal: null });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, message: `Result updated successfully` });
        }

    } catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }

})


//agentlist end///////////////



//social start///////////////

app.post('/api/updateSocial', async (req, res) => {
    const { FACEBOOK, WHATSAPP, WHATSAPP1, PHONENUMBER, PHONENUMBER1, INSTAGRAM, TELEGRAM, SKYPE, EMAIL, YOUTUBE, TWITTER, AGENTLINK, MESSENGER, PINTREST, AFFILIATE, BLOG, TIKTOK, isshow, depositMin, depositMax, withdrawMin, withdrawMax, MAINDOMAIN } = req.body;

    if (!MAINDOMAIN || MAINDOMAIN.trim() === '') {
        return res.status(400).json({ errorCode: 1, errorDescription: 'MAINDOMAIN is required', result: null });
    }

    try {
        await sql.connect(config);

        // Check if a record with the same MAINDOMAIN exists
        const checkResult = await sql.query`SELECT * FROM socialLink WHERE MAINDOMAIN = ${MAINDOMAIN}`;

        if (checkResult.recordset.length > 0) {
            // Update the existing record
            const updateRequest = new sql.Request();
            updateRequest.input('FACEBOOK', sql.VarChar, FACEBOOK);
            updateRequest.input('WHATSAPP', sql.VarChar, WHATSAPP);
            updateRequest.input('WHATSAPP1', sql.VarChar, WHATSAPP);
            updateRequest.input('PHONENUMBER', sql.VarChar, PHONENUMBER);
            updateRequest.input('PHONENUMBER1', sql.VarChar, PHONENUMBER1);
            updateRequest.input('INSTAGRAM', sql.VarChar, INSTAGRAM);
            updateRequest.input('TELEGRAM', sql.VarChar, TELEGRAM);
            updateRequest.input('SKYPE', sql.VarChar, SKYPE);
            updateRequest.input('EMAIL', sql.VarChar, EMAIL);
            updateRequest.input('YOUTUBE', sql.VarChar, YOUTUBE);
            updateRequest.input('TWITTER', sql.VarChar, TWITTER);
            updateRequest.input('AGENTLINK', sql.VarChar, AGENTLINK);
            updateRequest.input('MESSENGER', sql.VarChar, MESSENGER);
            updateRequest.input('PINTREST', sql.VarChar, PINTREST);
            updateRequest.input('AFFILIATE', sql.VarChar, AFFILIATE);
            updateRequest.input('BLOG', sql.VarChar, BLOG);
            updateRequest.input('TIKTOK', sql.VarChar, TIKTOK);
            updateRequest.input('isshow', sql.Bit, isshow);
            updateRequest.input('depositMin', sql.Bit, depositMin);
            updateRequest.input('depositMax', sql.Bit, depositMax);
            updateRequest.input('withdrawMin', sql.Bit, withdrawMin);
            updateRequest.input('withdrawMax', sql.Bit, withdrawMax);
            updateRequest.input('MAINDOMAIN', sql.VarChar, MAINDOMAIN);

            const updateQuery = `
                UPDATE socialLink 
                SET 
                    FACEBOOK = @FACEBOOK,
                    WHATSAPP = @WHATSAPP,
                    WHATSAPP1 = @WHATSAPP1,
                    PHONENUMBER = @PHONENUMBER,
                    PHONENUMBER1 = @PHONENUMBER1,
                    INSTAGRAM = @INSTAGRAM,
                    TELEGRAM = @TELEGRAM,
                    SKYPE = @SKYPE,
                    EMAIL = @EMAIL,
                    YOUTUBE = @YOUTUBE,
                    TWITTER = @TWITTER,
                    AGENTLINK = @AGENTLINK,
                    MESSENGER = @MESSENGER,
                    PINTREST = @PINTREST,
                    AFFILIATE = @AFFILIATE,
                    BLOG = @BLOG,
                    TIKTOK = @TIKTOK,
                    isshow = @isshow,
                    depositMin = @depositMin,
                    depositMax = @depositMax,
                    withdrawMin = @withdrawMin,
                    withdrawMax = @withdrawMax,
                WHERE 
                    MAINDOMAIN = @MAINDOMAIN;
            `;

            await updateRequest.query(updateQuery);

            res.status(200).json({ errorCode: 0, errorDescription: null, message: 'SocialLink Updated successfully' });
        } else {
            // Insert a new record if MAINDOMAIN doesn't exist
            const insertRequest = new sql.Request();
            insertRequest.input('FACEBOOK', sql.VarChar, FACEBOOK);
            insertRequest.input('WHATSAPP', sql.VarChar, WHATSAPP);
            insertRequest.input('WHATSAPP1', sql.VarChar, WHATSAPP1);
            insertRequest.input('PHONENUMBER', sql.VarChar, PHONENUMBER);
            insertRequest.input('PHONENUMBER1', sql.VarChar, PHONENUMBER1);
            insertRequest.input('INSTAGRAM', sql.VarChar, INSTAGRAM);
            insertRequest.input('TELEGRAM', sql.VarChar, TELEGRAM);
            insertRequest.input('SKYPE', sql.VarChar, SKYPE);
            insertRequest.input('EMAIL', sql.VarChar, EMAIL);
            insertRequest.input('YOUTUBE', sql.VarChar, YOUTUBE);
            insertRequest.input('TWITTER', sql.VarChar, TWITTER);
            insertRequest.input('AGENTLINK', sql.VarChar, AGENTLINK);
            insertRequest.input('MESSENGER', sql.VarChar, MESSENGER);
            insertRequest.input('PINTREST', sql.VarChar, PINTREST);
            insertRequest.input('AFFILIATE', sql.VarChar, AFFILIATE);
            insertRequest.input('BLOG', sql.VarChar, BLOG);
            insertRequest.input('TIKTOK', sql.VarChar, TIKTOK);
            insertRequest.input('isshow', sql.Bit, isshow);
            insertRequest.input('depositMin', sql.Bit, depositMin);
            insertRequest.input('depositMax', sql.Bit, depositMax);
            insertRequest.input('withdrawMin', sql.Bit, withdrawMin);
            insertRequest.input('withdrawMax', sql.Bit, withdrawMax);
            insertRequest.input('MAINDOMAIN', sql.VarChar, MAINDOMAIN);

            const insertQuery = `
                INSERT INTO socialLink (FACEBOOK, WHATSAPP,WHATSAPP1, PHONENUMBER, PHONENUMBER1, INSTAGRAM, TELEGRAM, SKYPE, EMAIL, YOUTUBE, TWITTER, AGENTLINK, MESSENGER, PINTREST, AFFILIATE, BLOG, TIKTOK, isshow, depositMin , depositMax ,withdrawMin ,withdrawMax, MAINDOMAIN)
                VALUES (@FACEBOOK, @WHATSAPP, @WHATSAPP1, @PHONENUMBER, @PHONENUMBER1, @INSTAGRAM, @TELEGRAM, @SKYPE, @EMAIL, @YOUTUBE, @TWITTER, @AGENTLINK, @MESSENGER, @PINTREST, @AFFILIATE, @BLOG, @TIKTOK, @isshow, @depositMin , @depositMax ,@withdrawMin ,@withdrawMax ,@MAINDOMAIN);
            `;

            await insertRequest.query(insertQuery);

            res.status(200).json({ errorCode: 0, errorDescription: null, message: 'New SocialLink Created successfully' });
        }
    } catch (err) {
        console.error('Error updating or inserting social link:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, error: 'Error' });
    }
});
app.put('/api/EditSocial/:id', async (req, res) => {
    const id = req.params.id;
    const { FACEBOOK, WHATSAPP, WHATSAPP1, PHONENUMBER, PHONENUMBER1, INSTAGRAM, TELEGRAM, SKYPE, EMAIL, YOUTUBE, TWITTER, AGENTLINK, MESSENGER, PINTREST, AFFILIATE, BLOG, TIKTOK, isshow, depositMin, depositMax, withdrawMin, withdrawMax, MAINDOMAIN } = req.body
    if (!MAINDOMAIN || MAINDOMAIN.trim() === '') {
        return res.status(400).json({ errorCode: 1, errorDescription: 'MAINDOMAIN is required', result: null });
    }
    try {
        await sql.connect(config);
        const result = await sql.query`
        UPDATE socialLink 
        SET 
        FACEBOOK = ${FACEBOOK}, 
        WHATSAPP = ${WHATSAPP}, 
        WHATSAPP1 = ${WHATSAPP1}, 
        PHONENUMBER = ${PHONENUMBER}, 
        PHONENUMBER1 = ${PHONENUMBER1}, 
        INSTAGRAM = ${INSTAGRAM}, 
        TELEGRAM = ${TELEGRAM}, 
        SKYPE = ${SKYPE}, 
        EMAIL = ${EMAIL}, 
        YOUTUBE = ${YOUTUBE}, 
        TWITTER = ${TWITTER}, 
        AGENTLINK = ${AGENTLINK}, 
        MESSENGER = ${MESSENGER}, 
        PINTREST = ${PINTREST}, 
        AFFILIATE = ${AFFILIATE}, 
        BLOG = ${BLOG}, 
        TIKTOK = ${TIKTOK}, 
        isshow = ${isshow}, 
        depositMin = ${depositMin}, 
        depositMax = ${depositMax}, 
        withdrawMin = ${withdrawMin}, 
        withdrawMax = ${withdrawMax}, 
        MAINDOMAIN = ${MAINDOMAIN}
        WHERE 
            ID = ${id}`;

        if (result.rowsAffected[0] === 0) {
            res.status(404).json({ errorCode: 1, errorDescription: 'Record not found', result: null });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, result: `Data updated successfully` });
        }
    } catch (err) {
        console.error('Error updating agent:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
app.get('/api/getSocialLink', async (req, res) => {
    try {
        const origin = req.headers.origin;
        let hostname;

        try {
            hostname = new URL(origin).hostname;
        } catch (err) {
            return res.status(400).json({ errorCode: 1, errorDescription: 'Invalid URL format' });
        }

        const mainDomain = hostname.split('.').slice(-2).join('.');

        redisClient.get(mainDomain, async (err, cachedData) => {
            if (err) {
                console.error('Redis Error:', err);
                return res.status(500).json({ errorCode: 1, errorDescription: 'Redis Failed' });
            }

            if (cachedData) {
                // console.log('✅ Cache Hit');
                return res.status(200).json({
                    errorCode: 0,
                    errorDescription: null,
                    result: JSON.parse(cachedData)
                });
            }

            const pool = await sql.connect(config);

            const result = await pool.request()
                .input('mainDomain', sql.VarChar, mainDomain)
                .query('SELECT * FROM socialLink WHERE MAINDOMAIN = @mainDomain');

            if (result.recordset.length === 0) {
                return res.status(201).json({ errorCode: 1, errorDescription: 'No Data Found' });
            }

            const modifiedResult = result.recordset.map(record => ({
                ...record,
                isshow: record.isshow === null ? false : record.isshow
            }));

            redisClient.setex(mainDomain, 600, JSON.stringify(modifiedResult));

            res.status(200).json({
                errorCode: 0,
                errorDescription: null,
                result: modifiedResult
            });
        });

    } catch (err) {
        console.error('API Error:', err.stack || err);
        res.status(500).json({
            errorCode: 1,
            errorDescription: 'Internal Server Error'
        });
    }
});

app.get('/api/getSocialLink/:domain', async (req, res) => {
    try {
        const origin = req.params.domain;
        const hostname = new URL(`http://${origin}`).hostname;
        const mainDomain = hostname.split('.').slice(-2).join('.');
        await sql.connect(config)
        const result = await sql.query`select * from socialLink where MAINDOMAIN LIKE '%' + ${mainDomain}`
        const modifiedResult = result.recordset.map(record => {
            return {
                ...record,
                isshow: record.isshow === null ? 0 : record.isshow
            };
        });

        res.status(200).json({ errorCode: 0, errorDescription: null, result: modifiedResult });
        // res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset })
    }
    catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: null, Error: 'No Data Found' })
    }
})
app.delete('/api/deletSocial/:id', async (req, res) => {
    const id = req.params.id
    try {
        await sql.connect(config)
        const result = await sql.query`DELETE FROM socialLink WHERE ID = ${id}`;
        if (result.rowsAffected[0] === 0) {
            res.status(500).json({ errorCode: 1, errorDescription: null, Error: 'Record Not Found' })
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, result: 'Record Delete Successfully' })
        }
    } catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: null, Error: 'Error' })
    }
})

//social end///////////////


//mostvip web QR start///////////////

app.get('/generate-mobile-QR/:origin', async (req, res) => {
    const origin = req.params.origin;
    if (!origin) {
        return res.status(400).send('Origin parameter is required');
    }
    const modifiedOrigin = origin + '/m/';
    try {
        const qrCodeImage = await qr.toDataURL(modifiedOrigin);
        res.json({ success: true, message: 'QR code generated successfully', img: qrCodeImage });
    } catch (err) {
        console.error('Error generating QR code:', err);
        res.status(500).send('Failed to generate QR code');
    }
});
app.get('/generate-apk-QR/:origin/:siteName', async (req, res) => {
    const siteName = req.params.siteName;
    const origin = req.params.origin;

    if (!siteName || !origin) {
        return res.status(400).send('siteName and origin parameters are required');
    }

    const modifiedOrigin = `https://${origin}/m/assets/apk/${siteName}.apk`;
    try {
        const qrCodeImage = await qr.toDataURL(modifiedOrigin);
        res.json({ success: true, message: 'QR code generated successfully', img: qrCodeImage });

    } catch (err) {
        console.error('Error generating QR code:', err);
        res.status(500).send('Failed to generate QR code');
    }
});

//mostvip web QR start///////////////


//mostvip Upload banner start///////////////
// const backupDomains = ['ninewickets.site', 'ninewickets.com'];

// app.post('/api/upload-images', upload.array('images', 10), (req, res) => {
//     const { ImageUrl, domain } = req.body;
//     try {
//         let metadata = [];
//         const metadataPath = path.join(__dirname, 'uploads', 'metadata.json');

//         if (fs.existsSync(metadataPath)) {
//             const data = fs.readFileSync(metadataPath);
//             metadata = JSON.parse(data);
//         }

//         req.files.forEach(file => {
//             console.log(file);

//             const uniqueId = generateUniqueId();

//             metadata.push({
//                 id: uniqueId,
//                 name: file.filename,
//                 mimeType: file.mimetype,
//                 ImageUrl: ImageUrl,
//                 domain: domain,
//                 originalName: file.originalname,
//                 uploadDate: new Date().toISOString(),
//                 url: `${req.protocol}://${req.get('host')}/uploads/${file.filename}`
//             });

//             if (domain === 'ninewiickets.com') {
//                 backupDomains.forEach(backupDomain => {
//                     metadata.push({
//                         id: uniqueId,
//                         name: file.filename,
//                         mimeType: file.mimetype,
//                         ImageUrl: ImageUrl,
//                         domain: backupDomain,
//                         originalName: file.originalname,
//                         uploadDate: new Date().toISOString(),
//                         url: `${req.protocol}://${req.get('host')}/uploads/${file.filename}`
//                     });
//                 });
//             }
//         });


//         fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 2));

//         res.status(200).json({ errorCode: 0, errorDescription: null, message: 'Images uploaded successfully' });
//     } catch (err) {
//         res.status(500).json({ errorCode: 1, errorDescription: err.message, message: 'Error uploading images' });
//     }
// });
// app.get('/api/images', (req, res) => {
//     const metadataPath = path.join(__dirname, 'uploads', 'metadata.json');
//     const { domain } = req.query;
//     if (!fs.existsSync(metadataPath)) {
//         return res.status(200).json({ errorCode: 0, errorDescription: null, images: [] });
//     }
//     const data = fs.readFileSync(metadataPath, 'utf-8');
//     let images = JSON.parse(data);
//     if (domain) {
//         images = images.filter(image => image.domain === domain);
//     }
//     res.status(200).json({ errorCode: 0, errorDescription: null, images });
// });
// app.delete('/api/delete-banner/:id', (req, res) => {
//     const bannerId = req.params.id;
//     const metadataPath = path.join(__dirname, 'uploads', 'metadata.json');

//     fs.readFile(metadataPath, (err, data) => {
//         if (err) {
//             console.error(err);
//             return res.status(500).json({ errorCode: 1, errorDescription: 'Error reading metadata', message: err.message });
//         }

//         let metadata = JSON.parse(data);

//         const filteredMetadata = metadata.filter(item => item.id !== bannerId);

//         if (filteredMetadata.length === metadata.length) {
//             return res.status(404).json({ errorCode: 1, errorDescription: 'Banner not found', message: 'Banner with the provided ID not found' });
//         }

//         const bannersToDelete = metadata.filter(item => item.id === bannerId);

//         bannersToDelete.forEach(banner => {
//             const bannerPath = path.join(__dirname, 'uploads', banner.name);

//             fs.unlink(bannerPath, (err) => {
//                 if (err) {
//                     console.error(err);
//                     return res.status(500).json({ errorCode: 1, errorDescription: 'Error deleting banner', message: err.message });
//                 }
//             });
//         });

//         fs.writeFile(metadataPath, JSON.stringify(filteredMetadata, null, 2), err => {
//             if (err) {
//                 console.error(err);
//                 return res.status(500).json({ errorCode: 1, errorDescription: 'Error updating metadata', message: err.message });
//             }
//             res.status(200).json({ errorCode: 0, errorDescription: null, message: 'Banner deleted successfully from all domains' });
//         });
//     });
// });


const backupDomains = ['ninewickets.site', 'ninewickets.com'];
const backupDomains9wicketspro = ['9wicketsprobd.com', '9wicketss.pro', 'nayaludis.xyz', 'ninewickets.pro'];

app.post('/api/upload-images', upload.array('images', 10), async (req, res) => {
    const { ImageLink, ImageUrl, domain, isEvent } = req.body;
    try {
        await sql.connect(config);
        const pool = new sql.Request();

        for (const file of req.files) {
            const uniqueId = generateUniqueId();
            const uploadDate = new Date().toISOString().slice(0, 19).replace('T', ' ');

            await pool.query(`
                INSERT INTO banners (id, name, mimeType, ImageLink, ImageUrl, domain, originalName, uploadDate, url , isEvent)
                VALUES ('${uniqueId}', '${file.filename}', '${file.mimetype}', '${ImageLink}', '${ImageUrl}', '${domain}', 
                '${file.originalname}', '${uploadDate}', '${req.protocol}://${req.get('host')}/uploads/${file.filename}','${isEvent}')
            `);

            if (domain === 'ninewiickets.com') {
                for (const backupDomain of backupDomains) {
                    try {
                        await pool.query(`
                            INSERT INTO banners (id, name, mimeType,  ImageLink, ImageUrl, domain, originalName, uploadDate, url , isEvent)
                            VALUES ('${uniqueId}', '${file.filename}', '${file.mimetype}', '${ImageLink}', '${ImageUrl}', '${backupDomain}', 
                            '${file.originalname}', '${uploadDate}', '${req.protocol}://${req.get('host')}/uploads/${file.filename}','${isEvent}')
                        `);

                        console.log(`✅ Inserted backup banner for domain: ${backupDomain}`);

                    } catch (error) {
                        console.error(`❌ Failed to insert for backupDomain: ${backupDomain}`, error.message);
                    }
                }
            }
            if (domain === '9wicketspro.vip') {
                for (const backupDomain of backupDomains9wicketspro) {
                    try {
                        await pool.query(`
                            INSERT INTO banners (id, name, mimeType,  ImageLink, ImageUrl, domain, originalName, uploadDate, url , isEvent)
                            VALUES ('${uniqueId}', '${file.filename}', '${file.mimetype}', '${ImageLink}', '${ImageUrl}', '${backupDomain}', 
                            '${file.originalname}', '${uploadDate}', '${req.protocol}://${req.get('host')}/uploads/${file.filename}','${isEvent}')
                        `);

                        console.log(`✅ Inserted backup banner for domain: ${backupDomain}`);

                    } catch (error) {
                        console.error(`❌ Failed to insert for backupDomain: ${backupDomain}`, error.message);
                    }
                }
            }
        }

        res.status(200).json({ errorCode: 0, message: 'Images uploaded successfully' });

    } catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message });
    }
});

app.get('/api/images', async (req, res) => {
    const { domain } = req.query;

    try {
        await sql.connect(config);
        let query = `SELECT * FROM banners WHERE 1=1`;
        if (domain) query += ` AND domain = '${domain}'`;

        const result = await sql.query(query);
        res.status(200).json({ errorCode: 0, images: result.recordset });

    } catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message });
    }
});

app.delete('/api/delete-banner/:id', async (req, res) => {
    const bannerId = req.params.id;

    try {
        await sql.connect(config);
        const result = await sql.query`SELECT * FROM banners WHERE id = ${bannerId}`;
        if (result.recordset.length === 0) {
            return res.status(404).json({ errorCode: 1, errorDescription: 'Banner not found' });
        }

        const filePath = path.join(__dirname, 'uploads', result.recordset[0].name);

        fs.unlink(filePath, async (err) => {
            if (err) console.error('Error deleting file:', err);

            await sql.query`DELETE FROM banners WHERE id = ${bannerId}`;
            res.status(200).json({ errorCode: 0, message: 'Banner deleted successfully' });
        });

    } catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message });
    }
});


//mostvip Upload banner end///////////////



// callback start
app.post('/api/payment-Gateway-history/', (req, res) => {
    const { approved_on, rejected_on, trn_date, trn_desc, trn_id, trn_type, status, coins, ref_no, payment_method, uid, parentId, username, type, isAgentStatus, UpiDetails, isDW, currencyCode, remark, orderId, domain, penalty, actual_coins, responseProvider, responseCoder } = req.body;
    const request = new sql.Request();
    request.input('approved_on', sql.VarChar, approved_on);
    request.input('coins', sql.VarChar, coins.toString());
    request.input('payment_method', sql.VarChar, payment_method);
    request.input('ref_no', sql.VarChar, ref_no);
    request.input('rejected_on', sql.VarChar, rejected_on);
    request.input('status', sql.Int, status);
    request.input('trn_date', sql.VarChar, trn_date);
    request.input('trn_desc', sql.VarChar, trn_desc);
    request.input('trn_id', sql.VarChar, trn_id);
    request.input('trn_type', sql.VarChar, trn_type);
    request.input('uid', sql.VarChar, uid);
    request.input('parentId', sql.VarChar, parentId);
    request.input('username', sql.VarChar, username);
    request.input('type', sql.VarChar, type);
    request.input('isAgentStatus', sql.TinyInt, isAgentStatus);
    request.input('isDW', sql.VarChar, isDW);
    request.input('currencyCode', sql.VarChar, currencyCode);
    request.input('UpiDetails', sql.NVarChar, UpiDetails);
    request.input('remark', sql.VarChar, remark);
    request.input('orderId', sql.VarChar, orderId);
    request.input('domain', sql.VarChar, domain);
    request.input('penalty', sql.VarChar, penalty);
    request.input('actual_coins', sql.VarChar, actual_coins?.toString());
    request.input('responseProvider', sql.NVarChar, responseProvider);
    request.input('responseCoder', sql.NVarChar, responseCoder);


    request.query(`
        IF EXISTS (SELECT 1 FROM ReportGateway WHERE orderId = @orderId)
        BEGIN
            UPDATE ReportGateway
            SET 
                approved_on = @approved_on,
                coins = @coins,
                payment_method = @payment_method,
                rejected_on = @rejected_on,
                status = @status,
                trn_date = @trn_date,
                trn_desc = @trn_desc,
                trn_id = @trn_id,
                trn_type = @trn_type,
                uid = @uid,
                parentId = @parentId,
                username = @username,
                type = @type,
                isAgentStatus = @isAgentStatus,
                UpiDetails = @UpiDetails,
                isDW = @isDW,
                currencyCode = @currencyCode,
                remark = @remark,
                domain = @domain,
                penalty = @penalty,
                actual_coins = @actual_coins,
                responseProvider = @responseProvider,
                responseCoder = @responseCoder,
                ref_no = @ref_no
            WHERE orderId = @orderId
        END
        ELSE
        BEGIN
            INSERT INTO ReportGateway (approved_on ,coins ,payment_method ,ref_no ,rejected_on,status , trn_date ,trn_desc , trn_id , trn_type, uid ,parentId ,username , type , isAgentStatus , UpiDetails , isDW ,currencyCode, remark ,orderId , domain , penalty , actual_coins ,responseProvider , responseCoder) 
            VALUES (@approved_on ,@coins ,@payment_method ,@ref_no ,@rejected_on,@status , @trn_date ,@trn_desc , @trn_id , @trn_type, @uid ,@parentId ,@username, @type , @isAgentStatus , @UpiDetails , @isDW , @currencyCode , @remark , @orderId , @domain , @penalty ,@actual_coins , @responseProvider , @responseCoder)
        END
    `)
        .then(result => {
            console.log('History Log Updated successfully:', result);
            res.status(200).json({ errorCode: 0, errorDescription: null, message: 'History Log Updated successfully' });
        })
        .catch(error => {
            console.error('Error inserting History:', error);
            res.status(500).json({ errorCode: 1, errorDescription: null, error: 'Error inserting History' });
        });
});
app.get('/api/getClientPaymentReport/', async (req, res) => {
    const { uid, status, type, from, to } = req.query;
    if (!uid || !status || !type || !from || !to) {
        return res.status(400).json({
            status: "Error",
            errorDescription: 'All query parameters are required',
            data: []
        });
    }
    try {
        const fromDate = new Date(from);
        const toDate = new Date(to);

        if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime())) {
            return res.status(400).json({
                status: "Error",
                errorDescription: 'Invalid date format',
                data: []
            });
        }

        // console.log(`Fetching records from ${fromDate.toISOString()} to ${toDate.toISOString()}`);

        await sql.connect(config);
        if (status == '5') {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE uid = ${uid}
                AND type = ${type}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        } else {
            // Filter by status if status is not 5
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE uid = ${uid}
                AND status = ${status}
                AND type = ${type}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        }
        // console.log(result);
        if (result.recordset.length === 0) {
            res.status(200).json({
                status: "Success",
                data: []
            });
        } else {
            res.status(200).json({
                status: "Success",
                data: result.recordset
            });
        }

    } catch (err) {
        console.error('Error fetching client payment report:', err);
        res.status(500).json({
            status: "Error",
            errorDescription: err.message,
            data: []
        });
    }
});
app.get('/api/getalltrnrequest/', async (req, res) => {
    const { uid, status, type, from, to, domain } = req.query;
    if (!uid || !status || !type || !from || !to || !domain) {
        return res.status(400).json({
            status: "Error",
            errorDescription: 'All query parameters are required',
            data: []
        });
    }

    try {
        const fromDate = new Date(from);
        const toDate = new Date(to);

        if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime())) {
            return res.status(400).json({
                status: "Error",
                errorDescription: 'Invalid date format',
                data: []
            });
        }

        await sql.connect(config);

        let result;

        // 🔁 specific check first
        if (uid === '0' && type === '0') {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE domain = ${domain}
                AND status = ${status}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        } else if (uid === '0') {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE domain = ${domain}
                AND type = ${type}
                AND status = ${status}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        } else if (status === '5') {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE parentId = ${uid}
                AND type = ${type}
                AND domain = ${domain}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        } else if (type === '0') {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE parentId = ${uid}
                AND status = ${status}
                AND domain = ${domain}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        } else {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE parentId = ${uid}
                AND status = ${status}
                AND domain = ${domain}
                AND type = ${type}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        }

        res.status(200).json({
            status: "Success",
            data: result.recordset || []
        });

    } catch (err) {
        console.error('Error fetching client payment report:', err);
        res.status(500).json({
            status: "Error",
            errorDescription: err.message,
            data: []
        });
    }
});
app.post('/api/deposit-Gateway/create-payment', async (req, res) => {
    try {
        const {
            currency,
            amount,
            actual_amount,
            buttons,
            payment_system,
            custom_transaction_id,
            custom_user_id,
            return_url,
            language,
            isPendingCheck,
            data,
            domain
        } = req.body;
        if (
            !currency ||
            !amount ||
            !actual_amount ||
            !buttons ||
            !payment_system ||
            !custom_transaction_id ||
            !return_url ||
            !language ||
            !domain ||
            !data
        ) {
            return res.status(201).json({ message: "All fields are required" });
        }

        if (!custom_transaction_id || custom_transaction_id.split("-").length !== 3) {
            return res.status(400).json({ message: "Invalid custom_transaction_id format" });
        }

        const parts = custom_transaction_id.split("-");
        const uid = parts[1];
        if (isPendingCheck === 1) {
            const pendingCheckRequest = new sql.Request();
            pendingCheckRequest.input('uid', sql.VarChar, uid);
            const result = await pendingCheckRequest.query(`
                SELECT TOP 1 * FROM ReportGateway 
                WHERE uid = @uid AND status = 0 AND trn_type = 'Deposit'
            `);
            if (result.recordset.length > 0) {
                return res.status(201).json({ message: "Previous Deposit Request Is Pending..." });
            }
        }
        const payload = {
            currency,
            amount,
            buttons,
            payment_system,
            custom_transaction_id,
            custom_user_id,
            return_url,
            language,
            data
        };

        const response = await axios.post('https://pay-crm.com/Remotes/create-payment-page', payload, {
            headers: {
                'Content-Type': 'application/json',
                'apikey': 'ef22332fe042f0fcaecdaa500e542be8'
            }
        });

        const externalResp = response.data;
        const logPayload = {
            approved_on: null,
            rejected_on: null,
            trn_date: new Date().toISOString(),
            trn_desc: 'Deposit',
            trn_id: null,
            trn_type: 'Deposit',
            ref_no: 'DW-' + Date.now(),
            isAgentStatus: 10,
            status: 0,
            coins: amount.toString(),
            actual_coins: actual_amount.toString(),
            orderId: externalResp?.order_id,
            payment_method: payment_system?.[0],
            isDW: parts[0],
            uid: parts[1],
            parentId: parts[2],
            username: custom_user_id,
            currencyCode: currency,
            domain: domain,
            type: "1"
        };

        // ⏳ Wait for log to complete
        await new Promise((resolve) => {
            depositToLogs((resp) => {
                console.log("Deposit log response:", resp);
                resolve();
            }, logPayload);
        });

        return res.status(200).json(externalResp);

    } catch (error) {
        console.error("❌ Error:", error.message);
        return res.status(error?.response?.status || 500).json({
            message: 'Failed to initiate payment',
            error: error?.response?.data || error.message
        });
    }
});
app.post('/api/deposit-Gateway/create-payment-bdplay', async (req, res) => {
    try {
        const {
            currency,
            amount,
            actual_amount,
            buttons,
            payment_system,
            custom_transaction_id,
            custom_user_id,
            return_url,
            language,
            isPendingCheck,
            data,
            domain
        } = req.body;
        if (
            !currency ||
            !amount ||
            !actual_amount ||
            !payment_system ||
            !custom_transaction_id ||
            !custom_user_id ||
            !return_url ||
            !language ||
            !domain ||
            !data
        ) {
            return res.status(400).json({ message: "All fields are required" });
        }

        if (!custom_transaction_id || custom_transaction_id.split("-").length !== 3) {
            return res.status(400).json({ message: "Invalid custom_transaction_id format" });
        }

        const parts = custom_transaction_id.split("-");
        const uid = parts[1];
        if (isPendingCheck === 1) {
            const pendingCheckRequest = new sql.Request();
            pendingCheckRequest.input('uid', sql.VarChar, uid);
            const result = await pendingCheckRequest.query(`
                SELECT TOP 1 * FROM ReportGateway 
                WHERE uid = @uid AND status = 0 AND trn_type = 'Deposit'
            `);
            if (result.recordset.length > 0) {
                return res.status(201).json({ message: "Previous Deposit Request Is Pending..." });
            }
        }
        const payload = {
            amount,
            order_id: custom_user_id + Date.now(),
            phone: data?.phone_number || phone_number || "",
            redirect_url: return_url,
            payment_method: payment_system
        };

        const response = await axios.post('https://api5.assanpay.com/api/cashin/direct/803c9cbc-efd1-4ba1-af2a-d104e82da79e', payload, {
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': 'SPAY-95e3-b61a-ca56-f70f'
            }
        });

        const externalResp = response.data;
        const logPayload = {
            approved_on: null,
            rejected_on: null,
            trn_date: new Date().toISOString(),
            trn_desc: 'Deposit',
            trn_id: null,
            trn_type: 'Deposit',
            ref_no: payload.order_id,
            isAgentStatus: 10,
            status: 0,
            coins: amount.toString(),
            actual_coins: actual_amount.toString(),
            orderId: payload.order_id,
            payment_method: payment_system,
            isDW: parts[0],
            uid: parts[1],
            parentId: parts[2],
            username: custom_user_id,
            currencyCode: currency,
            domain: domain,
            type: "1"
        };

        // ⏳ Wait for log to complete
        await new Promise((resolve) => {
            depositToLogs((resp) => {
                console.log("Deposit log response:", resp);
                resolve();
            }, logPayload);
        });

        return res.status(200).json(externalResp);

    } catch (error) {
        console.error("❌ Error:", error.message);
        return res.status(error?.response?.status || 500).json({
            message: 'Failed to initiate payment',
            error: error?.response?.data || error.message
        });
    }
});
app.post('/api/withdrawal-Gateway/create-withdrawal', async (req, res) => {
    try {
        const {
            amount,
            actual_amount,
            currency,
            payment_system,
            custom_transaction_id,
            custom_user_id,
            isPendingCheck,
            data,
            domain,
            penalty,
        } = req.body;

        if (
            !amount ||
            !actual_amount ||
            !currency ||
            !payment_system ||
            !custom_transaction_id ||
            !custom_user_id ||
            penalty == undefined ||
            !data) {
            return res.status(400).json({ message: "All fields are required" });
        }
        if (!custom_transaction_id || custom_transaction_id.split("-").length !== 3) {
            return res.status(400).json({ message: "Invalid custom_transaction_id format" });
        }
        const parts = custom_transaction_id.split("-");
        const uid = parts[1];
        if (isPendingCheck === 1) {
            const pendingCheckRequest = new sql.Request();
            pendingCheckRequest.input('uid', sql.VarChar, uid);
            const result = await pendingCheckRequest.query(`
                SELECT TOP 1 * FROM ReportGateway 
                WHERE uid = @uid AND status = 0 AND trn_type = 'withdrawal'
            `);
            if (result.recordset.length > 0) {
                return res.status(201).json({ message: "Previous withdrawal Request Is Pending..." });
            }
        }
        const logPayload = {
            approved_on: null,
            rejected_on: null,
            orderId: null,
            trn_date: new Date().toISOString(),
            trn_desc: 'withdrawal',
            trn_id: null,
            trn_type: 'withdrawal',
            isAgentStatus: 0,
            status: 0,
            coins: amount.toString(),
            actual_coins: actual_amount.toString(),
            ref_no: 'DW-' + Date.now(),
            payment_method: payment_system,
            isDW: parts[0],
            uid: parts[1],
            parentId: parts[2],
            username: custom_user_id,
            currencyCode: currency,
            penalty: penalty.toString(),
            type: "2",
            domain: domain,
            UpiDetails: JSON.stringify({
                account_number: data?.account_number || '',
                payment_system: payment_system || '',
                currency: currency || ''
            })
        };

        // console.log(logPayload);

        await new Promise((resolve) => {
            depositToLogs((resp) => {
                // console.log("Withdrawal log response:", resp);
                resolve();
            }, logPayload);
        });

        res.status(200).json({ errorCode: 0, errorDescription: null, result: "Withrawal Submit Successfully" });
    } catch (error) {
        res.status(201).json({ errorCode: 1, errorDescription: error.message, result: "Error" });
    }
});
app.post('/api/deposit-callback-test/', async (req, res) => {
    if (req.body && Array.isArray(req.body.transactions)) {
        const results = [];

        for (const txn of req.body.transactions) {
            try {
                const parts = txn.custom_transaction_id.split("-");
                if (parts.length !== 3) {
                    throw new Error("Invalid custom_transaction_id format");
                }

                // console.log(parts);
                const isDW = parts[0];
                const user_id = parts[1];
                const parentId = parts[2];
                const username = txn.custom_user_id;
                const status = txn.status;
                const currencyCode = txn.currency;
                const trn_id = txn.transaction_id;
                const transaction_amount = txn.amount.toString();
                const orderId = txn.order_id;
                const payment_method = txn.payment_system;
                const approved_on = status === "Success" ? new Date().toISOString() : null;
                const rejected_on = status === "Failed" ? new Date().toISOString() : null;
                const trn_date = new Date().toISOString();

                const existingTransaction = await sql.query`
                    SELECT * FROM ReportGateway WHERE orderId = ${orderId}
                `;

                // console.log(existingTransaction);


                if (existingTransaction.recordset.length > 0) {
                    let depositLog = {
                        ref_no: existingTransaction.recordset[0]?.ref_no,
                        approved_on,
                        coins: transaction_amount,
                        payment_method,
                        orderId: orderId,
                        rejected_on,
                        status,
                        isAgentStatus: 10,
                        trn_date,
                        trn_desc: "Deposit",
                        trn_id,
                        trn_type: "Deposit",
                        uid: user_id,
                        parentId,
                        currencyCode,
                        isDW,
                        username,
                        type: "1",
                        domain: existingTransaction.recordset[0]?.domain,

                    };
                    console.log(depositLog, "depositLog");
                    if (status === 'Success' && existingTransaction.recordset[0]?.status === 0) {
                        depositLog.status = 1;
                        let depositReq = {
                            password: "abcdr1245",
                            txntype: 1,
                            users: [
                                {
                                    userId: user_id,
                                    txnType: 1,
                                    amount: transaction_amount,
                                    remark: "Payment-Gateway-Testing",
                                    key: 0,
                                    mainUserId: isDW === "1" ? parentId : 5117212
                                }
                            ]
                        };
                        console.log(depositReq, "depositReq");
                        await new Promise((resolve) => {
                            depositAmount((resp) => {
                                console.log(resp, "resp or success");
                                if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                                    depositToLogs((respLog) => {
                                        if (respLog.errorCode === 0) {
                                            results.push({ user_id, message: "Payment successful", code: 0 });
                                        } else {
                                            results.push({ user_id, message: "Failed to log deposit", code: 1, error: respLog });
                                        }
                                        resolve();
                                    }, depositLog);
                                } else {
                                    results.push({ user_id, message: "Payment failed", code: 1, error: resp.result?.[0] || resp });
                                    resolve();
                                }
                            }, depositReq);
                        });

                    } else {
                        depositLog.status = 2;
                        await new Promise((resolve) => {
                            depositToLogs((respLog) => {
                                if (respLog.status === "Success") {
                                    results.push({ user_id, message: "Transaction failed", code: 1 });
                                } else {
                                    results.push({ user_id, message: "Failed to log failed deposit", code: 1, error: respLog });
                                }
                                resolve();
                            }, depositLog);
                        });
                    }
                } else {
                    results.push({ user_id, message: "Transaction already completed", code: 0 });
                }
            } catch (err) {
                console.error("❌ Error parsing transaction:", err);
                results.push({ error: "Exception", details: err.message });
            }
        }
        return res.status(200).send({ status: "OK" });
    }
    return res.status(400).send({ error: "Invalid payload or no transactions found" });
});
app.post('/api/deposit-callback-bdplay/', async (req, res) => {
    console.log(req.body);

    const results = [];

    try {
        const status = req.body.status;
        const transaction_amount = req.body.amount.toString();
        const orderId = req.body.order_id;
        const approved_on = status === "success" ? new Date().toISOString() : null;
        const rejected_on = status === "fail" ? new Date().toISOString() : null;
        const trn_date = req.body.time;

        const existingTransaction = await sql.query`
                    SELECT * FROM ReportGateway WHERE orderId = ${orderId}
                `;

        if (existingTransaction.recordset.length > 0) {
            const dbTxn = existingTransaction.recordset[0];

            let depositLog = {
                ref_no: dbTxn.ref_no,
                approved_on,
                coins: transaction_amount,
                payment_method: dbTxn.payment_method,
                orderId,
                rejected_on,
                status,
                isAgentStatus: 10,
                trn_date,
                trn_desc: "Deposit",
                trn_id,
                trn_type: "Deposit",
                uid: dbTxn.uid,
                parentId: dbTxn.parentId,
                currencyCode: dbTxn.currencyCode,
                isDW: dbTxn.isDW,
                username: dbTxn.username,
                type: "1",
                domain: dbTxn.domain,
            };

            console.log(depositLog, "depositLog");

            if (status === "success" && dbTxn.status === 0) {
                depositLog.status = 1;

                let depositReq = {
                    password: "abcdr1245",
                    txntype: 1,
                    users: [
                        {
                            userId: dbTxn.uid,
                            txnType: 1,
                            amount: transaction_amount,
                            remark: "Payment-Gateway-Testing",
                            key: 0,
                            mainUserId: dbTxn.isDW === "1" ? dbTxn.parentId : 5117212
                        }
                    ]
                };

                console.log(depositReq, "depositReq");

                await new Promise((resolve) => {
                    depositAmount((resp) => {
                        console.log(resp, "resp or success");
                        if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                            depositToLogs((respLog) => {
                                if (respLog.errorCode === 0) {
                                    results.push({ user_id: dbTxn.uid, message: "Payment successful", code: 0 });
                                } else {
                                    results.push({ user_id: dbTxn.uid, message: "Failed to log deposit", code: 1, error: respLog });
                                }
                                resolve();
                            }, depositLog);
                        } else {
                            results.push({ user_id: dbTxn.uid, message: "Payment failed", code: 1, error: resp.result?.[0] || resp });
                            resolve();
                        }
                    }, depositReq);
                });

            } else {
                depositLog.status = 2;
                await new Promise((resolve) => {
                    depositToLogs((respLog) => {
                        if (respLog.status === "Success") {
                            results.push({ user_id: dbTxn.uid, message: "Transaction failed", code: 1 });
                        } else {
                            results.push({ user_id: dbTxn.uid, message: "Failed to log failed deposit", code: 1, error: respLog });
                        }
                        resolve();
                    }, depositLog);
                });
            }
        } else {
            results.push({ orderId, message: "Transaction not found in DB", code: 404 });
        }
    } catch (err) {
        console.error("❌ Error parsing transaction:", err);
        results.push({ error: "Exception", details: err.message });
    }

    return res.status(200).send({ status: "OK", results });

});
app.post('/api/deposit-callback/', async (req, res) => {
    if (req.body && Array.isArray(req.body.transactions)) {
        const results = [];

        for (const txn of req.body.transactions) {
            try {
                const parts = txn.custom_transaction_id.split("-");
                if (parts.length !== 3) {
                    throw new Error("Invalid custom_transaction_id format");
                }

                // console.log(parts);
                const isDW = parts[0];
                const user_id = parts[1];
                const parentId = parts[2];
                const username = txn.custom_user_id;
                const status = txn.status;
                const currencyCode = txn.currency;
                const trn_id = txn.transaction_id;
                const transaction_amount = txn.amount.toString();
                const orderId = txn.order_id;
                const payment_method = txn.payment_system;
                const approved_on = status === "Success" ? new Date().toISOString() : null;
                const rejected_on = status === "Failed" ? new Date().toISOString() : null;
                const trn_date = new Date().toISOString();

                const existingTransaction = await sql.query`
                    SELECT * FROM ReportGateway WHERE orderId = ${orderId}
                `;

                // console.log(existingTransaction);


                if (existingTransaction.recordset.length > 0) {
                    let depositLog = {
                        ref_no: existingTransaction.recordset[0]?.ref_no,
                        approved_on,
                        coins: transaction_amount,
                        actual_coins: transaction_amount,
                        payment_method,
                        orderId: orderId,
                        rejected_on,
                        status,
                        isAgentStatus: 10,
                        trn_date,
                        trn_desc: "Deposit",
                        trn_id,
                        trn_type: "Deposit",
                        uid: user_id,
                        parentId,
                        currencyCode,
                        isDW,
                        username,
                        type: "1",
                        domain: existingTransaction.recordset[0]?.domain,
                        responseProvider: JSON.stringify(req.body),
                    };
                    console.log(depositLog, "depositLog");

                    if (status === 'Success' && existingTransaction.recordset[0]?.status === 0) {
                        depositLog.status = 1;
                        let depositReq = {
                            password: "abcdr1245",
                            txntype: 1,
                            users: [
                                {
                                    userId: user_id,
                                    txnType: 1,
                                    amount: transaction_amount,
                                    remark: "Payment-Gateway",
                                    key: 0,
                                    mainUserId: isDW === "1" ? parentId : 5117212
                                }
                            ]
                        };
                        console.log(depositReq, "depositReq");
                        await new Promise((resolve) => {
                            depositAmount((resp) => {
                                console.log(resp, "resp or success");
                                if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                                    depositToLogs((respLog) => {
                                        if (respLog.errorCode === 0) {
                                            results.push({ user_id, message: "Payment successful", code: 0 });
                                        } else {
                                            results.push({ user_id, message: "Failed to log deposit", code: 1, error: respLog });
                                        }
                                        resolve();
                                    }, depositLog);
                                } else {
                                    results.push({ user_id, message: "Payment failed", code: 1, error: resp.result?.[0] || resp });
                                    resolve();
                                }
                            }, depositReq);
                        });

                    } else {
                        depositLog.status = 2;
                        await new Promise((resolve) => {
                            depositToLogs((respLog) => {
                                if (respLog.status === "Success") {
                                    results.push({ user_id, message: "Transaction failed", code: 1 });
                                } else {
                                    results.push({ user_id, message: "Failed to log failed deposit", code: 1, error: respLog });
                                }
                                resolve();
                            }, depositLog);
                        });
                    }
                } else {
                    results.push({ user_id, message: "Transaction already completed", code: 0 });
                }
            } catch (err) {
                console.error("❌ Error parsing transaction:", err);
                results.push({ error: "Exception", details: err.message });
            }
        }
        return res.status(200).send({ status: "OK" });
    }
    return res.status(400).send({ error: "Invalid payload or no transactions found" });
});
app.post('/api/trasaction/SettleTrasaction', async (req, res) => {
    try {
        const {
            amount,
            currency,
            payment_system,
            custom_transaction_id,
            custom_user_id,
            ref_no,
            isAgentStatus,
            remark,
            penalty,
            data,
        } = req.body;
        if (
            !amount ||
            !currency ||
            !payment_system ||
            !custom_transaction_id ||
            !custom_user_id ||
            !ref_no ||
            penalty == undefined ||
            !isAgentStatus ||
            !data
        ) {
            return res.status(201).json({ message: "All fields are required" });
        }
        if (!custom_transaction_id || custom_transaction_id.split("-").length !== 3) {
            return res.status(400).json({ message: "Invalid custom_transaction_id format" });
        }
        const parts = custom_transaction_id.split("-");
        const isDW = parts[0];

        const originalAmount = parseFloat(amount);
        const penaltyFloat = parseFloat(penalty);
        const penaltyAmount = Math.round(originalAmount * (penaltyFloat / 100));
        const finalAmount = originalAmount - penaltyAmount;


        const payload = {
            amount: finalAmount,
            currency,
            payment_system,
            custom_transaction_id,
            custom_user_id,
            data
        };
        console.log(payload, "payload");
        if (isAgentStatus === 1) {
            let callbackResp;
            try {
                const callback = await axios.post(
                    'https://pay-crm.com/Remotes/create-withdrawal?project_id=5234239',
                    payload,
                    {
                        headers: {
                            'Content-Type': 'application/json',
                            'apikey': 'ef22332fe042f0fcaecdaa500e542be8'
                        }
                    }
                );
                callbackResp = callback.data;
                console.log(callbackResp, "callbackResp");
            } catch (error) {
                console.error("Callback API failed:", error.response?.data);
                return res.status(201).json({
                    errorCode: 1,
                    errorDescription: null,
                    result: error.response?.data.message
                });
            }
            if (callbackResp?.success && callbackResp?.status === "Pending") {
                const withdrawReq = {
                    password: "abcdr1245",
                    txntype: 2,
                    users: [
                        {
                            userId: parts[1],
                            txnType: 2,
                            amount: amount,
                            remark: "Payment-Gateway",
                            key: 0,
                            mainUserId: isDW === "1" ? parts[2] : 5117212
                        }
                    ]
                };
                console.log(callbackResp);
                console.log("✅ Callback successful. Proceeding with withdraw:", withdrawReq);
                let depositResp = null;
                await new Promise((resolve, reject) => {
                    depositAmount((resp) => {
                        depositResp = resp;
                        resolve();
                    }, withdrawReq);
                });
                if (depositResp?.errorCode === 0 && depositResp.result?.[0]?.result === "SUCCESS") {
                    const updateRequest = new sql.Request();
                    updateRequest.input('ref_no', sql.VarChar, ref_no);
                    updateRequest.input('remark', sql.VarChar, remark);
                    updateRequest.input('orderId', sql.VarChar, callbackResp.order_id);
                    updateRequest.input('coins', sql.VarChar, finalAmount.toString());
                    updateRequest.input('penalty', sql.VarChar, penaltyAmount.toString());

                    await updateRequest.query(`
                        UPDATE ReportGateway SET isAgentStatus = 1, orderId = @orderId,remark = @remark,  coins = @coins,penalty = @penalty, approved_on = GETDATE() WHERE ref_no = @ref_no
                    `);
                    return res.status(200).json({
                        errorCode: 0,
                        errorDescription: null,
                        result: "Transaction Settled Successfully"
                    });
                } else {
                    return res.status(201).json({
                        errorCode: 1,
                        errorDescription: "Deposit failed or insufficient funds",
                        result: depositResp?.result?.[0]?.result
                    });
                }
            } else {
                return res.status(400).json({
                    errorCode: 2,
                    errorDescription: "Callback response invalid",
                    callbackResponse: callbackResp
                });
            }
        }
        if (isAgentStatus === 2) {
            const updateRequest = new sql.Request();
            updateRequest.input('ref_no', sql.VarChar, ref_no);
            updateRequest.input('remark', sql.VarChar, remark);
            updateRequest.input('coins', sql.VarChar, finalAmount.toString());
            updateRequest.input('penalty', sql.VarChar, penaltyAmount.toString());

            await updateRequest.query(`
            UPDATE ReportGateway 
            SET isAgentStatus = 2, status = 2, remark = @remark,  coins = @coins, penalty = @penalty, approved_on = GETDATE() 
            WHERE ref_no = @ref_no
        `);
            return res.status(200).json({
                errorCode: 0,
                errorDescription: null,
                result: "Withdrawal Rejected Successfully"
            });
        }

    } catch (error) {
        console.error("❌ Error in /Settle:", error.message);
        return res.status(error?.response?.status || 500).json({
            message: 'Failed to initiate Withdrawal',
            error: error?.response?.data || error.message
        });
    }
});
app.post('/api/withdrawal-callback-test/', async (req, res) => {
    console.log(req.body, "withdrawal callback");

    if (!req.body || !Array.isArray(req.body.transactions)) {
        return res.status(400).send({ error: "Invalid payload or no transactions found" });
    }

    const results = [];

    for (const txn of req.body.transactions) {
        try {
            const parts = txn.custom_transaction_id?.split("-") || [];
            if (parts.length !== 3) {
                throw new Error("Invalid custom_transaction_id format");
            }

            const isDW = parts[0];
            const user_id = parts[1];
            const parentId = parts[2];
            const username = txn.custom_user_id;
            const currencyCode = txn.currency;
            const status = txn.status;
            const trn_id = txn.transaction_id;
            const transaction_amount = txn.amount.toString();
            const orderId = txn.order_id;
            const payment_method = txn.payment_system;
            const approved_on = status === "Success" ? new Date().toISOString() : null;
            const rejected_on = status === "Failed" ? new Date().toISOString() : null;
            const trn_date = new Date().toISOString();

            const existingTransaction = await sql.query`
                SELECT * FROM ReportGateway WHERE orderId = ${orderId}
            `;

            if (existingTransaction.recordset.length > 0) {
                let withdrawalLog = {
                    ref_no: existingTransaction.recordset[0]?.ref_no,
                    approved_on,
                    coins: transaction_amount,
                    payment_method,
                    isAgentStatus: existingTransaction.recordset[0]?.isAgentStatus,
                    orderId,
                    rejected_on,
                    status: status === "Success" ? 1 : 2,
                    trn_date,
                    trn_desc: "withdrawal",
                    trn_id,
                    trn_type: "withdrawal",
                    currencyCode,
                    uid: user_id,
                    UpiDetails: existingTransaction.recordset[0]?.UpiDetails,
                    remark: existingTransaction.recordset[0]?.remark,
                    parentId,
                    isDW,
                    username,
                    type: "2"
                };

                if (status === 'Success') {
                    await new Promise((resolve) => {
                        depositToLogs((respLog) => {
                            if (respLog.errorCode === 0) {
                                results.push({ user_id, message: "Payment successful", code: 0 });
                            } else {
                                results.push({ user_id, message: "Failed to log withdrawal", code: 1, error: respLog });
                            }
                            resolve();
                        }, withdrawalLog);
                    });
                }

                else if (status === 'Failed') {
                    const withdrawalReq = {
                        password: "abcdr1245",
                        txntype: 1,
                        users: [
                            {
                                userId: user_id,
                                txnType: 1,
                                amount: transaction_amount,
                                remark: "Payment-Gateway-Testing",
                                key: 0,
                                mainUserId: isDW === "1" && parentId ? parentId : 5117212
                            }
                        ]
                    };

                    await new Promise((resolve) => {
                        depositAmount((resp) => {
                            if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                                depositToLogs((respLog) => {
                                    if (respLog.errorCode === 0) {
                                        results.push({ user_id, message: "Reversed successfully", code: 0 });
                                    } else {
                                        results.push({ user_id, message: "Reverse success but log failed", code: 1, error: respLog });
                                    }
                                    resolve();
                                }, withdrawalLog);
                            } else {
                                results.push({ user_id, message: "Payment failed", code: 1, error: resp.result?.[0] || resp });
                                resolve();
                            }
                        }, withdrawalReq);
                    });
                }
            } else {
                results.push({ user_id, message: "Transaction already processed or not found in ReportGateway", code: 0 });
            }

        } catch (err) {
            console.error("❌ Error in transaction:", err.message);
            results.push({
                user_id: txn?.custom_user_id || 'unknown',
                message: "Exception occurred",
                code: 1,
                error: err.message
            });
        }
    }

    return res.status(200).send({ status: "OK", results });
});
app.post('/api/withdrawal-callback/', async (req, res) => {
    console.log(req.body, "withdrawal callback");

    if (!req.body || !Array.isArray(req.body.transactions)) {
        return res.status(400).send({ error: "Invalid payload or no transactions found" });
    }

    const results = [];

    for (const txn of req.body.transactions) {
        try {
            const parts = txn.custom_transaction_id?.split("-") || [];
            if (parts.length !== 3) {
                throw new Error("Invalid custom_transaction_id format");
            }

            const isDW = parts[0];
            const user_id = parts[1];
            const parentId = parts[2];
            const username = txn.custom_user_id;
            const currencyCode = txn.currency;
            const status = txn.status;
            const trn_id = txn.transaction_id;
            const transaction_amount = txn.amount.toString();
            const orderId = txn.order_id;
            const payment_method = txn.payment_system;
            const approved_on = status === "Success" ? new Date().toISOString() : null;
            const rejected_on = status === "Failed" ? new Date().toISOString() : null;
            const trn_date = new Date().toISOString();

            const existingTransaction = await sql.query`
                SELECT * FROM ReportGateway WHERE orderId = ${orderId}
            `;

            if (existingTransaction.recordset.length > 0) {
                let withdrawalLog = {
                    ref_no: existingTransaction.recordset[0]?.ref_no,
                    approved_on,
                    coins: transaction_amount,
                    actual_coins: existingTransaction.recordset[0]?.actual_coins,
                    payment_method,
                    isAgentStatus: existingTransaction.recordset[0]?.isAgentStatus,
                    orderId,
                    rejected_on,
                    status: status === "Success" ? 1 : 2,
                    trn_date,
                    trn_desc: "withdrawal",
                    trn_id,
                    trn_type: "withdrawal",
                    currencyCode,
                    uid: user_id,
                    UpiDetails: existingTransaction.recordset[0]?.UpiDetails,
                    remark: existingTransaction.recordset[0]?.remark,
                    parentId,
                    isDW,
                    username,
                    domain: existingTransaction.recordset[0]?.domain,
                    penalty: existingTransaction.recordset[0]?.penalty,
                    type: "2",
                    responseProvider: JSON.stringify(req.body),
                };

                if (status === 'Success') {
                    await new Promise((resolve) => {
                        depositToLogs((respLog) => {
                            if (respLog.errorCode === 0) {
                                results.push({ user_id, message: "Payment successful", code: 0 });
                            } else {
                                results.push({ user_id, message: "Failed to log withdrawal", code: 1, error: respLog });
                            }
                            resolve();
                        }, withdrawalLog);
                    });
                }

                else if (status === 'Failed') {
                    const withdrawalReq = {
                        password: "abcdr1245",
                        txntype: 1,
                        users: [
                            {
                                userId: user_id,
                                txnType: 1,
                                amount: existingTransaction.recordset[0]?.actual_coins,
                                remark: "Payment-Gateway",
                                key: 0,
                                mainUserId: isDW === "1" && parentId ? parentId : 5117212
                            }
                        ]
                    };

                    await new Promise((resolve) => {
                        depositAmount((resp) => {
                            if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                                depositToLogs((respLog) => {
                                    if (respLog.errorCode === 0) {
                                        results.push({ user_id, message: "Reversed successfully", code: 0 });
                                    } else {
                                        results.push({ user_id, message: "Reverse success but log failed", code: 1, error: respLog });
                                    }
                                    resolve();
                                }, withdrawalLog);
                            } else {
                                results.push({ user_id, message: "Payment failed", code: 1, error: resp.result?.[0] || resp });
                                resolve();
                            }
                        }, withdrawalReq);
                    });
                }
            } else {
                results.push({ user_id, message: "Transaction already processed or not found in ReportGateway", code: 0 });
            }

        } catch (err) {
            console.error("❌ Error in transaction:", err.message);
            results.push({
                user_id: txn?.custom_user_id || 'unknown',
                message: "Exception occurred",
                code: 1,
                error: err.message
            });
        }
    }

    return res.status(200).send({ status: "OK" });
});
app.get('/api/getPendingCount', async (req, res) => {
    const { uid, domain } = req.query;

    if (!uid || !domain) {
        return res.status(400).json({ status: "Failed", message: "uid and domain are required" });
    }

    try {
        await sql.connect(config);

        let depositResult, withdrawalResult;

        if (uid == 0) {
            depositResult = await sql.query`
                SELECT COUNT(*) AS deposit_count 
                FROM reportGateway 
                WHERE type = 1 AND status = 0 AND isDW = 0 AND domain = ${domain}
            `;
            withdrawalResult = await sql.query`
                SELECT COUNT(*) AS withdrawal_count 
                FROM reportGateway 
                WHERE type = 2 AND status = 0 AND isDW = 0 AND domain = ${domain}
            `;
        } else {
            depositResult = await sql.query`
                SELECT COUNT(*) AS deposit_count 
                FROM reportGateway 
                WHERE type = 1 AND status = 0 AND isDW = 1 AND parentId = ${uid} AND domain = ${domain}
            `;
            withdrawalResult = await sql.query`
                SELECT COUNT(*) AS withdrawal_count 
                FROM reportGateway 
                WHERE type = 2 AND status = 0 AND isDW = 1  AND parentId = ${uid} AND domain = ${domain}
            `;
        }

        return res.json({
            status: "Success",
            data: {
                deposit_count: depositResult.recordset[0].deposit_count.toString(),
                withdrawal_count: withdrawalResult.recordset[0].withdrawal_count.toString()
            }
        });

    } catch (err) {
        console.error("Error in getPendingCount:", err);
        return res.status(500).json({ status: "Failed", message: "Failed to Load Count" });
    }
});
async function recheckPendingDeposits() {
    try {
        await sql.connect(config);

        const pendingTxns = await sql.query`
            SELECT * FROM ReportGateway WHERE status = 0 AND type = 1
        `;
        pendingTxns.recordset.forEach(async txn => {
            try {
                const providerResp = await axios.get(`https://pay-crm.com/Remotes/deposit-info`, {
                    params: {
                        project_id: '5234239',
                        order_id: txn.orderId
                    },
                    headers: {
                        apikey: 'ef22332fe042f0fcaecdaa500e542be8'
                    }
                });
                const data = providerResp.data;
                if (data.success && data.status === 'Success' && txn.type === '1') {
                    console.log(`Provider shows success for txn ${txn.orderId}, re-attempting deposit...`);
                    const depositReq = {
                        password: "abcdr1245",
                        txntype: 1,
                        users: [{
                            userId: txn.uid,
                            txnType: 1,
                            amount: txn.coins,
                            remark: "Retry-Deposit",
                            key: 0,
                            mainUserId: txn.isDW === "1" && txn.parentId ? txn.parentId : 5117212
                        }]
                    };

                    await new Promise((resolve) => {
                        depositAmount((resp) => {
                            console.log(resp);
                            if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                                const updateRequest = new sql.Request();
                                updateRequest.input('orderId', sql.VarChar, txn.orderId);
                                updateRequest.query(`
                                UPDATE ReportGateway SET status = 1, approved_on = GETDATE() WHERE orderId = @orderId
                            `).then(() => {
                                    console.log(`Deposit success re-logged for ${txn.orderId}`);
                                });
                            } else {
                                console.warn(`Deposit retry failed for ${txn.orderId}`);
                            }
                            resolve();
                        }, depositReq);
                    });
                } else {
                    console.log(`Still pending or failed on provider for txn ${txn.orderId}`);
                }
            }
            catch (err) {
                if (
                    err.response &&
                    err.response.status === 400 &&
                    err.response.data?.message === 'invalid order'
                ) {
                    const updateRequest = new sql.Request();
                    updateRequest.input('orderId', sql.VarChar, txn.orderId);
                    await updateRequest.query(`UPDATE ReportGateway SET status = 2, approved_on = GETDATE() WHERE orderId = @orderId`);
                    console.log(`Marked order ${txn.orderId} as status 2 due to invalid order.`);
                } else {
                    console.error(`Error checking txn ${txn.orderId}:`, err.message);
                }
            }
        });
    } catch (err) {
        console.error("Recheck error:", err.message);
    }
}
function depositAmount(handleData, data) {

    var data = JSON.stringify(data);

    var config = {
        method: 'post',
        url: 'https://777777.today/pad=81/transferSpec',
        headers: {
            // 'authorization': authorization,
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            handleData(response.data);
            // console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
            // console.log(error);
            handleData(error.message)
        });

}
function depositToLogs(handleData, data) {
    console.log(data, "deposit log");
    console.log(`[depositToLogs] Sending deposit log request for transaction ID: ${data.trn_id}`);
    var config = {
        method: 'post',
        url: 'https://api2.streamingtv.fun:3479/api/payment-Gateway-history',
        httpsAgent,
        headers: { 'Content-Type': 'application/json' },
        data: JSON.stringify(data),
        timeout: 15000 // 15 seconds timeout
    };

    axios(config)
        .then(function (response) {
            console.log(`[depositToLogs] Response Status: ${response.status}`);
            handleData(response.data);
        })
        .catch(function (error) {
            const errorMsg = error.response ? error.response.data : error.message;
            console.error(`[depositToLogs] Error for transaction ID: ${data.trn_id} - ${error}`);
            handleData(errorMsg);
        });
}
// setInterval(() => {
//     console.log("🔄 Rechecking pending deposits...");
//     recheckPendingDeposits();
// }, 3 * 60 * 1000); // 3 minutes
app.get('/api/getDWSummary/', async (req, res) => {
    const { uid, from, to, domain } = req.query;

    if (!uid || !from || !to || !domain) {
        return res.status(400).json({
            status: "Error",
            errorDescription: 'All query parameters are required',
            data: []
        });
    }

    try {
        const fromDate = new Date(from);
        const toDate = new Date(to);

        if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime())) {
            return res.status(400).json({
                status: "Error",
                errorDescription: 'Invalid date format',
                data: []
            });
        }

        await sql.connect(config);

        const resultdeposit = await sql.query(`
            SELECT 
                SUM(CASE WHEN status = 1 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalSuccessfulDeposit,
                SUM(CASE WHEN status = 2 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalRejectedDeposit,
                SUM(CASE WHEN status = 0 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalPendingDeposit
            FROM ReportGateway
            WHERE parentId = '${uid}'
            AND domain = '${domain}'
            AND type = 1
            AND trn_date BETWEEN '${fromDate.toISOString()}' AND '${toDate.toISOString()}'
        `);

        const resultwithdrawal = await sql.query(`
            SELECT 
                SUM(CASE WHEN status = 1 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalSuccessfulWithdraw,
                SUM(CASE WHEN status = 2 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalRejectedWithdraw,
                SUM(CASE WHEN status = 0 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalPendingWithdraw
            FROM ReportGateway
            WHERE parentId = '${uid}'
            AND domain = '${domain}'
            AND type = 2
            AND trn_date BETWEEN '${fromDate.toISOString()}' AND '${toDate.toISOString()}'
        `);

        const summarydeposit = resultdeposit.recordset[0];
        const summarywithdrawal = resultwithdrawal.recordset[0];

        res.status(200).json({
            status: "Success",
            data: {
                totalSuccessfulDeposit: (summarydeposit.totalSuccessfulDeposit || 0).toFixed(2),
                totalRejectedDeposit: (summarydeposit.totalRejectedDeposit || 0).toFixed(2),
                totalPendingDeposit: (summarydeposit.totalPendingDeposit || 0).toFixed(2),
                totalSuccessfulWithdraw: (summarywithdrawal.totalSuccessfulWithdraw || 0).toFixed(2),
                totalRejectedWithdraw: (summarywithdrawal.totalRejectedWithdraw || 0).toFixed(2),
                totalPendingWithdraw: (summarywithdrawal.totalPendingWithdraw || 0).toFixed(2),
            }
        });

    } catch (err) {
        console.error('Error fetching client payment report:', err);
        res.status(500).json({
            status: "Error",
            errorDescription: err.message,
            data: []
        });
    }
});
app.post('/api/updateDWstatus/', async (req, res) => {
    const { parentId, status } = req.body;
    if (!parentId || status === undefined) {
        return res.status(400).json({ status: 'Error', message: 'All fields are required' });
    }
    try {
        await sql.connect(config);
        const result = await sql.query`
            UPDATE ReportGateway 
            SET isDW = ${status} 
            WHERE parentId = ${parentId}
        `;
        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ status: 'Error', message: 'No matching records found to update.' });
        }
        return res.status(200).json({ status: 'Success', message: 'DW status updated Successfully...' });
    } catch (err) {
        return res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});

// callback end

// Old lottery start
// app.post('/api/updateLottery/', async (req, res) => {
//     const { Id, fullname, phonenumber, username, NID, agId, result, document, deletestatus } = req.body;
//     try {
//         const checkrequest = new sql.Request()
//         checkrequest.input('NID', sql.VarChar, NID)
//         checkrequest.input('phonenumber', sql.VarChar, phonenumber)
//         checkrequest.input('username', sql.NVarChar, username)
//         const checkQuery = `SELECT * FROM lottryagent WHERE NID = @NID OR phonenumber = @phonenumber OR username = @username`;
//         const exitrecord = await checkrequest.query(checkQuery)
//         if (exitrecord.recordset.length > 0) {
//             return res.status(400).json({
//                 errorCode: 1,
//                 errorDescription: null,
//                 message: 'NID or phonenumber or username already exists',
//             });
//         }
//         let documentPath = null;

//         if (document) {
//             const buffer = Buffer.from(document, 'base64');
//             const filename = `${Id}_${Date.now()}.png`;
//             const filepath = `./uploads/${filename}`;
//             require('fs').writeFileSync(filepath, buffer);
//             documentPath = filepath;
//         }

//         const request = new sql.Request();
//         request.input('Id', sql.VarChar, Id);
//         request.input('fullname', sql.NVarChar, fullname);
//         request.input('phonenumber', sql.VarChar, phonenumber);
//         request.input('username', sql.NVarChar, username);
//         request.input('NID', sql.VarChar, NID);
//         request.input('agId', sql.VarChar, agId);
//         request.input('document', sql.VarChar, documentPath);
//         request.input('result', sql.VarChar, result);
//         request.input('deletestatus', sql.VarChar, deletestatus);
//         await request.query(`INSERT INTO lottryagent (Id, fullname, phonenumber, username, NID, agId, document, result , deletestatus) VALUES (@Id, @fullname, @phonenumber, @username, @NID, @agId, @document, @result , @deletestatus)`);

//         res.status(200).json({
//             errorCode: 0,
//             errorDescription: null,
//             message: 'Submit successfully',
//             NID: NID,
//             phonenumber: phonenumber
//         });

//         console.log('lottery update success');
//     } catch (err) {
//         console.error('Error inserting lottery:', err);
//         res.status(500).json({ errorCode: 1, errorDescription: null, error: 'Error inserting lottery' });
//     }
// });
// app.put('/api/updateLotteryResult/:userId', async (req, res) => {
//     const userId = req.params.userId
//     const { Id, fullname, phonenumber, username, NID, agId, result, deletestatus } = req.body
//     try {
//         await sql.connect(config)
//         const request = new sql.Request()
//         request.input('userId', sql.Int, userId);
//         request.input('Id', sql.VarChar, Id);
//         request.input('fullname', sql.VarChar, fullname);
//         request.input('phonenumber', sql.VarChar, phonenumber);
//         request.input('username', sql.VarChar, username);
//         request.input('NID', sql.VarChar, NID);
//         request.input('agId', sql.VarChar, agId);
//         request.input('result', sql.VarChar, result);
//         request.input('deletestatus', sql.VarChar, deletestatus);
//         const resultfinal = await request.query(`UPDATE lottryagent SET 
//         Id = @Id ,
//         fullname = @fullname ,
//         phonenumber = @phonenumber ,
//         username = @username ,
//         NID = @NID ,
//         agId = @agId ,
//         result = @result,
//         deletestatus = @deletestatus
//         WHERE userId = @userId`);
//         if (resultfinal.rowsAffected[0] == 0) {
//             res.status(404).json({ errorCode: 1, errorDescription: 'Record not found', resultfinal: null });
//         } else {
//             res.status(200).json({ errorCode: 0, errorDescription: null, message: `Result updated successfully` });
//         }

//     } catch (err) {
//         res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
//     }

// })
// app.get('/api/getlotteryAgent/', async (req, res) => {
//     try {
//         await sql.connect(config);
//         const result = await sql.query`SELECT * FROM lottryagent WHERE deletestatus = 'active'`;
//         res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });
//     } catch (err) {
//         console.error('Error fetching lottery agent data:', err);
//         res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
//     }
// });
// app.get('/api/getlotteryAgent/:phonenumber/:NID', async (req, res) => {
//     const { phonenumber, NID } = req.params
//     try {
//         await sql.connect(config)
//         const result = await sql.query`SELECT * FROM lottryagent WHERE phonenumber = ${phonenumber} AND NID = ${NID} AND deletestatus = 'active'`
//         if (result.recordset.length > 0) {
//             res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset })
//         } else {
//             res.status(500).json({ errorCode: 1, errorDescription: null, result: "Result Not Found" })

//         }
//     }
//     catch (err) {
//         res.status(500).json({ errorCode: 1, errorDescription: null, result: err })
//     }

// })
// app.delete('/api/deleteLottery/:userId', async (req, res) => {
//     const { userId } = req.params
//     try {
//         await sql.connect(config)
//         const result = await sql.query`UPDATE lottryagent SET deletestatus = 'deleted' WHERE userId = ${userId}`
//         if (result.rowsAffected[0] == 0) {
//             res.status(200).json({ errorCode: 1, errorDescription: null, message: `Result Not Found` });
//         } else {
//             res.status(200).json({ errorCode: 0, errorDescription: null, message: `Deleted Successfully` });
//         }
//     }
//     catch (err) {
//         res.status(500).json({ errorCode: 1, errorDescription: null, message: err });
//     }
// })
// app.get('/api/nextAvailableId', async (req, res) => {
//     try {
//         console.log('Connecting to the database...');
//         await sql.connect(config);
//         console.log('Connected to the database.');

//         const result = await sql.query`SELECT Id FROM lottryagent ORDER BY Id`;
//         // console.log('Query executed successfully:', result);

//         const existingIds = result.recordset.map(row => row.Id);
//         let nextId = 1;
//         while (existingIds.includes(nextId.toString())) {
//             nextId++;
//         }

//         res.status(200).json({ errorCode: 0, errorDescription: null, nextAvailableId: nextId });
//     } catch (err) {
//         // console.error('Error fetching next available ID:', err);
//         res.status(500).json({ errorCode: 1, errorDescription: 'Error fetching next available ID', error: err });
//     }
// });
app.get('/api/getlotteryAgentOld/', async (req, res) => {
    try {
        await sql.connect(config);
        const result = await sql.query`SELECT * FROM lottryagent WHERE deletestatus = 'active'`;
        res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });
    } catch (err) {
        console.error('Error fetching lottery agent data:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
// Old lottery end

// New lottery start
app.post('/api/updateLottery/', async (req, res) => {
    const { Id, fullname, phonenumber, username, NID, agId, result, document, deletestatus } = req.body;
    try {
        const checkrequest = new sql.Request()
        checkrequest.input('NID', sql.VarChar, NID)
        checkrequest.input('phonenumber', sql.VarChar, phonenumber)
        checkrequest.input('username', sql.NVarChar, username)
        const checkQuery = `SELECT * FROM lottryagentNew WHERE NID = @NID OR phonenumber = @phonenumber OR username = @username`;
        const exitrecord = await checkrequest.query(checkQuery)
        if (exitrecord.recordset.length > 0) {
            return res.status(400).json({
                errorCode: 1,
                errorDescription: null,
                message: 'NID or phonenumber or username already exists',
            });
        }
        let documentPath = null;

        if (document) {
            const buffer = Buffer.from(document, 'base64');
            const filename = `${Id}_${Date.now()}.png`;
            const filepath = `./uploads/${filename}`;
            require('fs').writeFileSync(filepath, buffer);
            documentPath = filepath;
        }

        const request = new sql.Request();
        request.input('Id', sql.VarChar, Id);
        request.input('fullname', sql.NVarChar, fullname);
        request.input('phonenumber', sql.VarChar, phonenumber);
        request.input('username', sql.NVarChar, username);
        request.input('NID', sql.VarChar, NID);
        request.input('agId', sql.VarChar, agId);
        request.input('document', sql.VarChar, documentPath);
        request.input('result', sql.VarChar, result);
        request.input('deletestatus', sql.VarChar, deletestatus);
        await request.query(`INSERT INTO lottryagentNew (Id, fullname, phonenumber, username, NID, agId, document, result , deletestatus) VALUES (@Id, @fullname, @phonenumber, @username, @NID, @agId, @document, @result , @deletestatus)`);

        res.status(200).json({
            errorCode: 0,
            errorDescription: null,
            message: 'Submit successfully',
            NID: NID,
            phonenumber: phonenumber
        });

        console.log('lottery update success');
    } catch (err) {
        console.error('Error inserting lottery:', err);
        res.status(500).json({ errorCode: 1, errorDescription: null, error: 'Error inserting lottery' });
    }
});
app.put('/api/updateLotteryResult/:userId', async (req, res) => {
    const userId = req.params.userId
    const { Id, fullname, phonenumber, username, NID, agId, result, deletestatus } = req.body
    try {
        await sql.connect(config)
        const request = new sql.Request()
        request.input('userId', sql.Int, userId);
        request.input('Id', sql.VarChar, Id);
        request.input('fullname', sql.VarChar, fullname);
        request.input('phonenumber', sql.VarChar, phonenumber);
        request.input('username', sql.VarChar, username);
        request.input('NID', sql.VarChar, NID);
        request.input('agId', sql.VarChar, agId);
        request.input('result', sql.VarChar, result);
        request.input('deletestatus', sql.VarChar, deletestatus);
        const resultfinal = await request.query(`UPDATE lottryagentNew SET 
        Id = @Id ,
        fullname = @fullname ,
        phonenumber = @phonenumber ,
        username = @username ,
        NID = @NID ,
        agId = @agId ,
        result = @result,
        deletestatus = @deletestatus
        WHERE userId = @userId`);
        if (resultfinal.rowsAffected[0] == 0) {
            res.status(404).json({ errorCode: 1, errorDescription: 'Record not found', resultfinal: null });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, message: `Result updated successfully` });
        }

    } catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }

})
app.get('/api/getlotteryAgent/', async (req, res) => {
    try {
        await sql.connect(config);
        const result = await sql.query`SELECT * FROM lottryagentNew WHERE deletestatus = 'active' ORDER BY Id`;
        res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });
    } catch (err) {
        console.error('Error fetching lottery agent data:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
app.get('/api/getlotteryAgent/:phonenumber/:NID', async (req, res) => {
    const { phonenumber, NID } = req.params
    try {
        await sql.connect(config)
        const result = await sql.query`SELECT * FROM lottryagentNew WHERE phonenumber = ${phonenumber} AND NID = ${NID} AND deletestatus = 'active'`
        if (result.recordset.length > 0) {
            res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset })
        } else {
            res.status(500).json({ errorCode: 1, errorDescription: null, result: "Result Not Found" })

        }
    }
    catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: null, result: err })
    }

})
app.delete('/api/deleteLottery/:userId', async (req, res) => {
    const { userId } = req.params
    try {
        await sql.connect(config)
        const result = await sql.query`UPDATE lottryagentNew SET deletestatus = 'deleted' WHERE userId = ${userId}`
        if (result.rowsAffected[0] == 0) {
            res.status(200).json({ errorCode: 1, errorDescription: null, message: `Result Not Found` });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, message: `Deleted Successfully` });
        }
    }
    catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: null, message: err });
    }
})
app.get('/api/nextAvailableId', async (req, res) => {
    try {
        console.log('Connecting to the database...');
        await sql.connect(config);
        console.log('Connected to the database.');

        const result = await sql.query`SELECT Id FROM lottryagentNew`;
        const existingIds = result.recordset
            .map(row => parseInt(row.Id))       // convert to integer
            .filter(id => !isNaN(id));           // filter only numeric

        let nextId = 1;
        while (existingIds.includes(nextId)) {
            nextId++;
        }

        res.status(200).json({
            errorCode: 0,
            errorDescription: null,
            nextAvailableId: nextId
        });
    } catch (err) {
        console.error('Error fetching next available ID:', err);
        res.status(500).json({
            errorCode: 1,
            errorDescription: 'Error fetching next available ID',
            error: err
        });
    }
});

// New lottery end


// b2cemail start
async function getLocationFromIP(ip) {
    try {
        const response = await fetch(`http://ip-api.com/json/${ip}`);
        return await response.json(); // contains country, city, region, etc.
    } catch (err) {
        console.error("Location fetch failed:", err);
        return null;
    }
}
const sendCampaignEmail = (toEmail, userName, origin, userId, parentId, agentRef, result, currencyCode, phoneNumber, welcomebonus, ip, country, city) => {
    const config = emailConfigs[origin];

    if (!config) {
        throw new Error(`No email config found for origin: ${origin}`);
    }
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: config.user,
            pass: config.pass
        },
        tls: {
            rejectUnauthorized: false
        }
    });
    const mailOptions = {
        from: config.from,
        to: toEmail,
        subject: 'Registration Successful - Welcome to Our Platform!',
        html: `
          <html>
            <body style="font-family: 'Google Sans'; margin: 0; padding: 0; background-color: #f0f2f5;">
              <table role="presentation" style="width: 100%; background-color: #ffffff; margin: 40px auto; padding: 30px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); max-width: 600px;">
                <tr>
                  <td style="text-align: center;">
                    <!-- Logo -->
                    <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Registration Successful!</h1>
                    <p style="font-size: 16px; color: #555555; margin-bottom: 20px;">Hello ${userName},</p>
                    <p style="font-size: 16px; color: #555555; margin-bottom: 20px;">Thank you for registering with us. We are excited to welcome you to our platform.</p>
                    <p style="font-size: 16px; color: #555555; margin-bottom: 20px;">Here’s what you can explore now:</p>
                    <ul style="list-style: none; padding: 0; margin: 0; color: #555555;">
                      <li style="margin: 15px 0; font-size: 16px; line-height: 1.5;">🎮 Discover our latest and most exciting games tailored just for you.</li>
                      <li style="margin: 15px 0; font-size: 16px; line-height: 1.5;">💰 Take advantage of our exclusive bonuses and promotions.</li>
                      <li style="margin: 15px 0; font-size: 16px; line-height: 1.5;">🎰 Try out our diverse range of slots and table games for endless fun.</li>
                    </ul>
                    <a href="${origin}" style="
                      display: inline-block;
                      padding: 15px 25px;
                      font-size: 18px;
                      font-weight: bold;
                      color: #ffffff;
                      background-color: #007bff;
                      text-align: center;
                      text-decoration: none;
                      border-radius: 5px;
                      border: 1px solid #007bff;
                      margin-top: 20px;
                      text-transform: uppercase;
                      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                    ">Get Started</a>
                    <p style="font-size: 14px; color: #777777; margin-top: 20px;">If you have any questions or need help, feel free to reply to this email. We’re here to assist you!</p>
                    <p style="font-size: 14px; color: #777777;">Best Regards,<br>The ${origin} Team</p>
                  </td>
                </tr>
              </table>
            </body>
          </html>
        `
    };

    // Send email
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log('Error:', error);
        } else {
            console.log('Email sent: ' + info.response);
            const request = new sql.Request();
            const sqlQuery = 'INSERT INTO email_logs (email, userName, origin , userId ,parentId, agentRef, result ,currencyCode , phoneNumber , welcomebonus, ip, country, city) VALUES (@Email, @UserName, @Origin, @userId, @parentId, @agentRef, @result , @currencyCode , @phoneNumber , @welcomebonus , @ip, @country, @city)';
            request.input('Email', sql.VarChar, toEmail);
            request.input('UserName', sql.VarChar, userName);
            request.input('Origin', sql.VarChar, origin);
            request.input('userId', sql.VarChar, userId);
            request.input('parentId', sql.VarChar, parentId);
            request.input('agentRef', sql.Bit, agentRef);
            request.input('result', sql.VarChar, result);
            request.input('currencyCode', sql.VarChar, currencyCode);
            request.input('phoneNumber', sql.VarChar, phoneNumber);
            request.input('welcomebonus', sql.VarChar, welcomebonus);
            request.input('ip', sql.VarChar, ip);
            request.input('country', sql.VarChar, country || '');
            request.input('city', sql.VarChar, city || '');
            request.query(sqlQuery, (err, result) => {
                if (err) {
                    console.error('Error inserting email data into database:', err);
                } else {
                    console.log('Email data stored in the database');
                }
            });
        }
    });
};
app.post('/send-register-email', async (req, res) => {
    const { email, userName, origin, userId, parentId, agentRef, result, currencyCode, phoneNumber, welcomebonus } = req.body;
    let ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    ip = ip.replace(/^::ffff:/, '');
    const locationData = await getLocationFromIP(ip);
    sendCampaignEmail(email, userName, origin, userId, parentId, agentRef, result, currencyCode, phoneNumber, welcomebonus, ip, locationData?.country, locationData?.city);
    res.status(200).send({ message: 'Register email sent successfully!' });
});
app.get('/register-email-log/:domain', async (req, res) => {
    try {
        const { domain } = req.params;
        const request = new sql.Request();

        request.input('Domain', sql.VarChar, domain);

        const query = `
            SELECT 
                email, 
                userName, 
                origin, 
                userId, 
                parentId, 
                agentRef, 
                currencyCode, 
                phoneNumber, 
                welcomebonus, 
                ip, 
                country, 
                created_at, 
                city
            FROM email_logs 
            WHERE origin = @Domain
            ORDER BY created_at DESC
        `;

        const result = await request.query(query);
        res.status(200).json(result.recordset);
    } catch (err) {
        // console.error('Error fetching email logs:', err);
        res.status(201).json({ message: 'Error fetching logs' });
    }
});
app.delete('/api/deleteLog/:userId', async (req, res) => {
    const userId = req.params.userId;
    try {
        await sql.connect(config);
        const result = await sql.query`UPDATE email_logs SET status = 1  WHERE userId = ${userId}`;
        if (result.rowsAffected[0] === 0) {
            res.status(404).json({ errorCode: 1, errorDescription: 'Record not found', result: null });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, result: `Record deleted successfully` });
        }
    } catch (err) {
        console.error('Error deleting agent:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
const sendDepositandwithdrawAcceptanceEmail = (toEmail, amount, remark, type, origin) => {
    const config = emailConfigs[origin];

    if (!config) {
        throw new Error(`No email config found for origin: ${origin}`);
    }
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: config.user,
            pass: config.pass
        },
        tls: {
            rejectUnauthorized: false
        }
    });
    const subject = type === 1 ? 'Deposit Accepted' : 'Withdrawal Accepted';
    const transactionType = type === 1 ? 'deposit' : 'withdrawal';
    const mailOptions = {
        from: config.from,
        to: toEmail,
        subject: subject,
        html: `
          <html>
            <body style="font-family: 'Google Sans'; margin: 0; padding: 0; background-color: #f4f4f4;">
              <table role="presentation" style="width: 100%; background-color: #ffffff; margin: 20px auto; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); max-width: 600px;">
                <tr>
                  <td style="text-align: center;">
                    <h1 style="color: #333;">${subject}</h1>
                    <p style="font-size: 16px; color: #555;">Your ${transactionType} of ${amount} has been successfully accepted.</p>
                    <p style="font-size: 16px; color: #555;">Thank you for your transaction!</p>
                  </td>
                </tr>
                <tr>
                  <td style="text-align: center; padding-top: 20px; border-top: 1px solid #ddd;">
                    <p style="font-size: 14px; color: #777;">For support, contact us at <a href="mailto:${config.from}">${config.from}</a></p>
                    <p style="font-size: 14px; color: #777;">&copy; 2024 ${config.from}. All rights reserved.</p>
                  </td>
                </tr>
              </table>
            </body>
          </html>
        `
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log('Error:', error);
        } else {
            console.log(`${subject} Email sent: ` + info.response);
        }
    });
};
const sendDepositandwithdrawRejectionEmail = (toEmail, amount, remark, type, origin) => {
    const config = emailConfigs[origin];

    if (!config) {
        throw new Error(`No email config found for origin: ${origin}`);
    }
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: config.user,
            pass: config.pass
        },
        tls: {
            rejectUnauthorized: false
        }
    });
    const subject = type === 1 ? 'Deposit Rejected' : 'Withdrawal Rejected';
    const transactionType = type === 1 ? 'deposit' : 'withdrawal';
    const mailOptions = {
        from: config.from,
        to: toEmail,
        subject: subject,
        html: `
          <html>
            <body style="font-family: 'Google Sans'; margin: 0; padding: 0; background-color: #f4f4f4;">
              <table role="presentation" style="width: 100%; background-color: #ffffff; margin: 20px auto; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); max-width: 600px;">
                <tr>
                  <td style="text-align: center;">
                    <h1 style="color: #333;">${subject}</h1>
                    <p style="font-size: 16px; color: #555;">We regret to inform you that your ${transactionType} of ${amount} has been rejected.</p>
                    <p style="font-size: 16px; color: #555;">Reason: ${remark}</p>
                    <p style="font-size: 16px; color: #555;">Please contact support if you have any questions.</p>
                  </td>
                </tr>
                <tr>
                  <td style="text-align: center; padding-top: 20px; border-top: 1px solid #ddd;">
                    <p style="font-size: 14px; color: #777;">For support, contact us at <a href="mailto:${config.from}">${config.from}</a></p>
                    <p style="font-size: 14px; color: #777;">&copy; 2024 ${config.from}. All rights reserved.</p>
                  </td>
                </tr>
              </table>
            </body>
          </html>
        `
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log('Error:', error);
        } else {
            console.log(`${subject} Email sent: ` + info.response);
        }
    });
};
app.post('/transaction-status', (req, res) => {
    const { email, amount, status, remark, type, origin } = req.body;
    console.log(req.body);
    if (status === 1) {
        sendDepositandwithdrawAcceptanceEmail(email, amount, remark, type, origin);
        res.status(200).send({ message: `${type === 1 ? 'Deposit' : 'Withdrawal'} acceptance email sent successfully!` });
    } else if (status === 2) {
        sendDepositandwithdrawRejectionEmail(email, amount, remark, type, origin);
        res.status(200).send({ message: `${type === 1 ? 'Deposit' : 'Withdrawal'} rejection email sent successfully!` });
    } else {
        res.status(400).send({ message: 'Invalid status provided!' });
    }
});
const sendKYCStatusEmail = (username, toEmail, status, remark, origin) => {
    const config = emailConfigs[origin];

    if (!config) {
        throw new Error(`No email config found for origin: ${origin}`);
    }
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: config.user,
            pass: config.pass
        },
        tls: {
            rejectUnauthorized: false
        }
    });
    let subject, message, action, color;
    switch (status) {
        case 1:
            subject = 'KYC Accepted';
            message = `Dear ${username}, we are thrilled to inform you that your KYC has been successfully accepted! You now have full access to all features on our platform.`;
            action = `Thank you for completing the verification process. Feel free to explore our exciting bonuses, games, and features. We're excited to have you with us!`;
            color = 'green'; // Green for Accepted
            break;
        case 2:
            subject = 'KYC Rejected';
            message = `Dear ${username}, unfortunately, your KYC submission has been rejected. We understand this may be disappointing, but don't worry, you can try again.`;
            action = `Reason: ${remark}. Please review the submission guidelines and resubmit your documents. For any assistance, feel free to contact our support team. In the meantime, explore our platform's bonuses and features!`;
            color = 'red'; // Red for Rejected
            break;
        case 0:
            subject = 'KYC Pending';
            message = `Dear ${username}, your KYC verification is currently under review.`;
            action = `While we process your verification, we invite you to explore our bonuses and exciting features. We'll notify you as soon as your KYC is completed!`;
            color = '#ed8c0e'; // Yellow for Pending
            break;
        default:
            return null;
    }

    // Mail options
    const mailOptions = {
        from: config.from,
        to: toEmail,
        subject: subject,
        html: `
          <html>
            <body style="font-family: 'Google Sans', Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f4;">
              <table role="presentation" style="width: 100%; background-color: #ffffff; margin: 20px auto; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); max-width: 600px;">
                  <td style="text-align: center;">
                    <h1 style="color: ${color}; font-size: 24px;">${subject}</h1>
                    <p style="font-size: 14px; color: #888; border-bottom: 2px solid #ddd; padding-bottom: 5px; margin-bottom: 15px;">Status: ${status === 1 ? 'Accepted' : status === 2 ? 'Rejected' : 'Pending'}</p>
                    <p style="font-size: 16px; color: #555; line-height: 1.6;">${message}</p>
                    <p style="font-size: 16px; color: #555; line-height: 1.6;">${action}</p>
                    <p style="font-size: 16px; color: #555; line-height: 1.6;">If you have any questions, feel free to contact our support team.</p>
                  </td>
                </tr>
                <tr>
                  <td style="text-align: center; padding-top: 20px; border-top: 1px solid #ddd;">
                    <p style="font-size: 14px; color: #777;">For support, contact us at <a href="mailto:${config.from}">${config.from}</a></p>
                    <p style="font-size: 14px; color: #777;">&copy; 2024 ${config.from}. All rights reserved.</p>
                  </td>
                </tr>
              </table>
            </body>
          </html>
        `
    };

    // Send mail
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log('Error:', error);
        } else {
            console.log(`${subject} Email sent: ` + info.response);
        }
    });
};
app.post('/kyc-status', (req, res) => {
    const { username, email, status, remark, origin } = req.body;
    if ([1, 2, 0].includes(status)) {
        sendKYCStatusEmail(username, email, status, remark, origin);
        res.status(200).send({ message: `KYC email sent successfully!` });
    } else {
        res.status(400).send({ message: 'Invalid KYC status provided!' });
    }
});
app.post('/send-email-otp', (req, res) => {

    const { email, userName, origin } = req.body;
    if (!email && !userName) {
        return res.status(400).json({ message: 'Email and userName is required' });
    }
    const otp = generateUniqueId();
    otpStore[email] = { otp, createdAt: Date.now() };

    const config = emailConfigs[origin];

    if (!config) {
        throw new Error(`No email config found for origin: ${origin}`);
    }
    let transporter;

    if (config.host) {
        // For PrivateEmail / Custom domains
        transporter = nodemailer.createTransport({
            host: config.host,
            port: config.port,
            secure: config.secure,
            auth: config.auth,
            tls: { rejectUnauthorized: false }
        });
    } else {
        // Default Gmail config
        transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: config.user,
                pass: config.pass
            },
            tls: { rejectUnauthorized: false }
        });
    }

    const mailOptions = {
        from: config.from,
        to: email,
        subject: 'Confirmation Code',
        html: `
        <html>
          <head>
            <style>
              body {
                font-family: 'Google Sans';
                background-color: #f4f4f4;
                margin: 0;
                padding: 0;
                
              }
              .email-container {
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
                background-color: #ffffff;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
              }
              .email-header {
                text-align: center;
                
              }
              .email-header img {
                width: 100%;
                height: auto;
              }
              .email-body {
                text-align: center;
                color: #333;
              }
              .email-body h1 {
                color: #2c3e50;
                margin-bottom: 20px;
                font-size: 24px;
              }
              .email-body p {
                font-size: 16px;
                line-height: 1.6;
                color: #555;
              }
              .otp-code {
                display: inline-block;
                width: 80%; /* Set width to 80% */
                background-color: #f2f2f2; /* Set background color */
                color: #8cc1c1; /* Set text color */
                font-size: 22px;
                font-weight: bold; /* Bold OTP */
                padding: 10px 20px;
                letter-spacing: 4px;
                border-radius: 4px;
                margin-top: 20px;
                font-weight: 900;
              }
              .email-footer {
                text-align: center;
                padding-top: 20px;
                border-top: 1px solid #ddd;
                margin-top: 20px;
                color: #777;
              }
              .email-footer a {
                color: #2c3e50;
                text-decoration: none;
              }
              .email-footer p {
                font-size: 14px;
              }
            </style>
          </head>
          <body style="font-family: 'Google Sans'; margin: 0; padding: 0; background-color: #f4f4f4;">
            <div class="email-container">
              <div class="email-body">
                <h1>Verification needed</h1>
                <p>Dear ${userName},</p>
                <p>We received a request to access your account. Please use the OTP code below to complete your KYC process. This OTP is valid for 5 minutes.</p>
                <div class="otp-code">${otp}</div>
                <p>If you did not request this, please ignore this email or contact support if you have any concerns.</p>
              </div>
              <div class="email-footer">
              <p>For support, contact us at <a href="mailto:${config.from}">${config.fromName || config.from}</a></p>
                <p>&copy; 2024 ${config.from}. All rights reserved.</p>
              </div>
            </div>
          </body>
        </html>
      
      `
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            // return res.status(500).json({ message: 'Error sending email', error });
            res.status(201).json({ errorCode: 1, errorDescription: null, message: 'Error sending email' })
        }
        // res.status(200).json({ message: 'OTP sent successfully', info });
        res.status(200).json({ errorCode: 0, errorDescription: null, message: 'OTP has been sent. Please check your email.' })

    });
});
app.post('/verify-email-otp', (req, res) => {
    const { email, otp } = req.body;
    if (!email || !otp) {
        return res.status(400).json({ message: 'Email and OTP are required' });
    }
    const storedOTP = otpStore[email];

    if (!storedOTP) {
        res.status(201).json({ errorCode: 1, errorDescription: null, message: 'OTP not found or expired' })
    }
    const currentTime = Date.now();
    const otpAge = (currentTime - storedOTP.createdAt) / 1000 / 60; // in minutes

    if (otpAge > 5) { // OTP is valid for 5 minutes
        delete otpStore[email]; // Remove expired OTP
        res.status(201).json({ errorCode: 1, errorDescription: null, message: 'OTP has expired' })
    }
    if (storedOTP.otp === otp) {
        delete otpStore[email];
        res.status(200).json({ errorCode: 0, errorDescription: null, message: 'Email verified successfully' })
    } else {
        res.status(201).json({ errorCode: 1, errorDescription: null, message: 'Invalid OTP' })
    }
});
app.post('/send-self-exclusion', (req, res) => {
    const { fullName, email, userName, period, reason, date, origin } = req.body;


    if (!fullName || !email || !userName || !period || !date || !origin) {
        return res.status(400).json({ message: 'Required fields are missing' });
    }

    const request = new sql.Request();
    const sqlQuery = `
        INSERT INTO selfexclusion (fullName, email, userName, period, reason, date, origin)
        VALUES (@fullName, @email, @userName, @period, @reason, @date, @origin)
    `;

    request.input('fullName', sql.VarChar, fullName);
    request.input('email', sql.VarChar, email);
    request.input('userName', sql.VarChar, userName);
    request.input('period', sql.VarChar, period);
    request.input('reason', sql.VarChar, reason || null);
    request.input('date', sql.DateTime, date);
    request.input('origin', sql.VarChar, origin);

    request.query(sqlQuery, (err, result) => {
        if (err) {
            console.error('Error inserting data into database:', err);
            return res.status(500).json({ errorCode: 1, message: 'Database insert failed' });
        } else {
            console.log('Data stored in the database');
        }
    });

    const config = emailConfigs[origin];
    if (!config) {
        return res.status(400).json({ message: `No email config found for origin: ${origin}` });
    }

    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: { user: config.user, pass: config.pass },
        tls: { rejectUnauthorized: false }
    });

    const mailOptions = {
        from: config.from,
        to: email,
        subject: 'Self-Exclusion Request Confirmation',
        html: `
        <html>
        <head>
        <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f6f9fc; margin: 0; padding: 0; }
            .email-container { max-width: 650px; margin: 30px auto; background: #ffffff; border-radius: 10px; overflow: hidden; box-shadow: 0 6px 20px rgba(0,0,0,0.08); border: 1px solid #e6e6e6; }
            .email-header { background: linear-gradient(135deg, #2563eb, #1e40af); padding: 20px; text-align: center; color: white; }
            .email-header h1 { margin: 0; font-size: 22px; font-weight: 600; }
            .email-body { padding: 25px; color: #333; }
            .email-body p { font-size: 15px; line-height: 1.6; }
            .details { margin-top: 20px; }
            .details table { width: 100%; border-collapse: collapse; font-size: 14px; }
            .details th { background-color: #f3f4f6; text-align: left; padding: 10px; font-weight: 600; color: #111827; border-bottom: 1px solid #ddd; width: 40%; }
            .details td { padding: 10px; border-bottom: 1px solid #f0f0f0; color: #374151; }
            .highlight { font-weight: 600; color: #2563eb; }
            .email-footer { background: #f9fafb; padding: 15px; text-align: center; font-size: 13px; color: #6b7280; border-top: 1px solid #e5e7eb; }
            .email-footer a { color: #2563eb; text-decoration: none; }
        </style>
        </head>
        <body>
        <div class="email-container">
            <div class="email-header">
                <h1>Self-Exclusion Request Received</h1>
            </div>
            <div class="email-body">
                <p>Dear <span class="highlight">${fullName}</span>,</p>
                <p>We have received your self-exclusion request with the following details:</p>
                
                <div class="details">
                    <table>
                        <tr><th>Full Name</th><td>${fullName}</td></tr>
                        <tr><th>Email</th><td>${email}</td></tr>
                        <tr><th>User Name</th><td>${userName}</td></tr>
                        <tr><th>Selected Period</th><td>${period}</td></tr>
                        <tr><th>Reason</th><td>${reason || 'N/A'}</td></tr>
                        <tr><th>Date</th><td>${date}</td></tr>
                        <tr><th>Domain</th><td>${origin}</td></tr>
                    </table>
                </div>
    
                <p>This request will be processed as per our Self-Exclusion Terms & Conditions.<br>
                If you did not submit this request, please contact our support team immediately.</p>
            </div>
            <div class="email-footer">
                <p>For support, contact us at <a href="mailto:${config.from}">${config.fromName || config.from}</a></p>
                <p>&copy; 2024 ${config.from}. All rights reserved.</p>
            </div>
        </div>
        </body>
        </html>
        `
    };

    transporter.sendMail(mailOptions, (error) => {
        if (error) {
            return res.status(500).json({ errorCode: 1, message: 'Error sending self-exclusion email' });
        }
        res.status(200).json({ errorCode: 0, message: 'Self-exclusion request email sent successfully' });
    });
});
app.post('/send-self-exclusion-admin', (req, res) => {
    const { fullName, email, userName, period, reason, date, origin } = req.body;

    if (!fullName || !email || !userName || !period || !date || !origin) {
        return res.status(400).json({ message: 'Required fields are missing' });
    }

    const config = emailConfigs[origin];
    if (!config) {
        throw new Error(`No email config found for origin: ${origin}`);
    }

    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: config.user,
            pass: config.pass
        },
        tls: {
            rejectUnauthorized: false
        }
    });

    const mailOptions = {
        from: config.from,
        to: config.to,
        subject: 'New Self-Exclusion Request Received',
        html: `
        <html>
        <head>
        <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f6f9fc; margin: 0; padding: 0; }
            .email-container { max-width: 650px; margin: 30px auto; background: #ffffff; border-radius: 10px; overflow: hidden; box-shadow: 0 6px 20px rgba(0,0,0,0.08); border: 1px solid #e6e6e6; }
            .email-header { background: linear-gradient(135deg, #dc2626, #b91c1c); padding: 20px; text-align: center; color: white; }
            .email-header h1 { margin: 0; font-size: 22px; font-weight: 600; }
            .alert-box { background: #fff5f5; border-left: 5px solid #dc2626; padding: 10px 15px; margin: 15px 0; color: #991b1b; font-weight: 500; font-size: 14px; }
            .email-body { padding: 25px; color: #333; }
            .details table { width: 100%; border-collapse: collapse; font-size: 14px; }
            .details th { background-color: #f3f4f6; text-align: left; padding: 10px; font-weight: 600; border-bottom: 1px solid #ddd; width: 40%; }
            .details td { padding: 10px; border-bottom: 1px solid #f0f0f0; }
            .terms { background: #f9fafb; padding: 15px; font-size: 13px; margin-top: 20px; border-top: 1px solid #e5e7eb; }
            .email-footer { background: #f3f4f6; padding: 15px; text-align: center; font-size: 13px; color: #6b7280; border-top: 1px solid #e5e7eb; }
        </style>
        </head>
        <body>
        <div class="email-container">
            <div class="email-header">
                <h1>New Self-Exclusion Request</h1>
            </div>
            <div class="email-body">
                <div class="alert-box">A user has submitted a new self-exclusion request. Please review the details below.</div>
                <div class="details">
                    <table>
                        <tr><th>Full Name</th><td>${fullName}</td></tr>
                        <tr><th>Email</th><td>${email}</td></tr>
                        <tr><th>User Name</th><td>${userName}</td></tr>
                        <tr><th>Selected Period</th><td>${period}</td></tr>
                        <tr><th>Reason</th><td>${reason || 'N/A'}</td></tr>
                        <tr><th>Date</th><td>${date}</td></tr>
                        <tr><th>Domain</th><td>${origin}</td></tr>
                    </table>
                </div>
                <div class="terms">
                    <p>This request is subject to our Self-Exclusion Policy. Once processed, the user's account will be restricted for the selected period and cannot be reactivated until the period expires. In case of permanent exclusion, the account will be closed permanently.</p>
                </div>
            </div>
            <div class="email-footer">
                <p>For any queries, contact: <a href="mailto:${config.from}">${config.from}</a></p>
                <p>&copy; 2024 ${config.fromName || config.from}. All rights reserved.</p>
            </div>
        </div>
        </body>
        </html>
        `
    };

    transporter.sendMail(mailOptions, (error) => {
        if (error) {
            return res.status(500).json({ errorCode: 1, message: 'Error sending self-exclusion email' });
        }
        res.status(200).json({ errorCode: 0, message: 'Self-exclusion request email sent to admin successfully' });
    });
});
const sendReminderEmail = (email, origin, userName = '') => {
    const config = emailConfigs[origin];

    if (!config) {
        throw new Error(`No email config found for origin: ${origin}`);
    }
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: config.user,
            pass: config.pass
        },
        tls: {
            rejectUnauthorized: false
        }
    });
    const mailOptions = {
        from: config.from,
        to: email,
        subject: "Reminder: Reactivate Your Foxplay Account",
        html: `
        <html>
          <body style="font-family: 'Google Sans', sans-serif; background-color: #f9f9f9;">
            <table style="max-width: 600px; margin: 30px auto; background-color: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 0 8px rgba(0,0,0,0.05);">
              <tr>
                <td style="text-align: center;">
                  <h2 style="color: #222;">Hi${userName ? ' ' + userName : ''},</h2>
                  <p style="font-size: 16px; color: #444;">We noticed your Foxplay account has been inactive for 3 months.</p>
                  <p style="font-size: 16px; color: #444;">To continue enjoying uninterrupted access to your favorite features, please log in and use your account.</p>
                  <p style="font-size: 16px; color: #d9534f; font-weight: bold;">
                  Important: If your account remains inactive, a <strong>15% deduction</strong> will be applied next month.
                </p>
                  <p style="font-size: 16px; color: #444;">If you have any questions, contact us at <a href="mailto:support@vrnl.net">support@vrnl.net</a>.</p>
                  <br>
                  <p style="font-size: 14px; color: #999;">– Team Foxplay</p>
                </td>
              </tr>
            </table>
          </body>
        </html>
        `
    };
    transporter.sendMail(mailOptions);
};
const sendDeductionEmail = (email, origin, userName = '') => {
    const config = emailConfigs[origin];

    if (!config) {
        throw new Error(`No email config found for origin: ${origin}`);
    }
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: config.user,
            pass: config.pass
        },
        tls: {
            rejectUnauthorized: false
        }
    });
    const mailOptions = {
        from: config.from,
        to: email,
        subject: "Notice: Foxplay Account Service Deduction",
        html: `
        <html>
          <body style="font-family: 'Google Sans', sans-serif; background-color: #f9f9f9;">
            <table style="max-width: 600px; margin: 30px auto; background-color: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 0 8px rgba(0,0,0,0.05);">
              <tr>
                <td style="text-align: center;">
                  <h2 style="color: #222;">Hi${userName ? ' ' + userName : ''},</h2>
                  <p style="font-size: 16px; color: #444;">Your Foxplay account remains inactive for 4 months.</p>
                  <p style="font-size: 16px; color: #444;">As per our policy, service charges will now begin to apply. Please reactivate your account to avoid further deductions.</p>
                  <p style="font-size: 16px; color: #d9534f; font-weight: bold;">
                  ⚠️ Final Warning: If your account continues to remain inactive, your <strong>entire balance will be deducted</strong> and your account will be <strong>frozen permanently</strong>.
                </p>
                  <p style="font-size: 16px; color: #444;">For any support, reach out to <a href="mailto:support@vrnl.net">support@vrnl.net</a>.</p>
                  <br>
                  <p style="font-size: 14px; color: #999;">– Team Foxplay</p>
                </td>
              </tr>
            </table>
          </body>
        </html>
        `
    };
    transporter.sendMail(mailOptions);
};
const sendFreezeEmail = (email, origin, userName = '') => {
    const config = emailConfigs[origin];

    if (!config) {
        throw new Error(`No email config found for origin: ${origin}`);
    }
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: config.user,
            pass: config.pass
        },
        tls: {
            rejectUnauthorized: false
        }
    });
    const mailOptions = {
        from: config.from,
        to: email,
        subject: "Account Frozen: Inactivity on Foxplay",
        html: `
        <html>
          <body style="font-family: 'Google Sans', sans-serif; background-color: #f9f9f9;">
            <table style="max-width: 600px; margin: 30px auto; background-color: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 0 8px rgba(0,0,0,0.05);">
              <tr>
                <td style="text-align: center;">
                  <h2 style="color: #222;">Hi${userName ? ' ' + userName : ''},</h2>
                  <p style="font-size: 16px; color: #444;">Your Foxplay account has been inactive for over 6 months.</p>
                  <p style="font-size: 16px; color: #444;">Due to prolonged inactivity, your account has been temporarily frozen. Please contact support to reactivate it.</p>
                  <p style="font-size: 16px; color: #444;">Email us at <a href="mailto:support@vrnl.net">support@vrnl.net</a> for assistance.</p>
                  <br>
                  <p style="font-size: 14px; color: #999;">– Team Foxplay</p>
                </td>
              </tr>
            </table>
          </body>
        </html>
        `
    };
    transporter.sendMail(mailOptions);
};
app.post('/reminder-mail', (req, res) => {
    const { email, month, origin, userName } = req.body;
    console.log(req.body);

    try {
        if (month >= 3 && month < 4) {
            sendReminderEmail(email, origin, userName);
            return res.status(200).send({ message: '3-hour reminder email sent.' });

        } else if (month >= 4 && month < 6) {
            sendDeductionEmail(email, origin, userName);
            return res.status(200).send({ message: '4-hour deduction email sent.' });

        } else if (month >= 6) {
            sendFreezeEmail(email, origin, userName);
            return res.status(200).send({ message: '6-hour freeze email sent.' });

        } else {
            return res.status(400).send({ message: 'Invalid hoursDiff provided!' });
        }

    } catch (error) {
        console.error('Error sending email:', error);
        return res.status(500).send({ message: 'Server error while sending email.' });
    }
});
async function callTxnSummaryAPI() {
    try {
        const result = await sql.query(`
            SELECT agentRef, parentId, userId, origin, email, userName, last_stage_sent, remaining_balance
            FROM email_logs
            WHERE userId IS NOT NULL AND origin IS NOT NULL
        `);

        const rows = result.recordset || result;
        if (!rows.length) {
            console.log("No data found");
            return;
        }

        for (let row of rows) {
            const { agentRef, parentId, userId, origin, email, userName, last_stage_sent, remaining_balance } = row;

            try {
                // Get last deposit data
                const { data } = await axios.get(`https://b2c.111111.info:15552/api/getUserTxnSummary/${userId}`, {
                    headers: { origin: `https://${origin}` }
                });

                const lastDate = data?.data?.last_deposit_date;
                const lastDepositAmount = parseFloat(data?.data?.last_deposit_amount);

                if (!lastDate || isNaN(lastDepositAmount)) {
                    console.log(`No deposit data for ${email}`);
                    continue;
                }

                // Set current balance first time
                let currentBalance;
                if (remaining_balance === null) {
                    currentBalance = lastDepositAmount;
                    await updateBalance(userId, currentBalance);
                } else {
                    currentBalance = parseFloat(remaining_balance);
                }

                // Hours since last deposit
                // const hoursDiff = Math.floor((Date.now() - new Date(lastDate)) / (1000 * 60 * 60));
                const monthsDiff = (now.getFullYear() - start.getFullYear()) * 12 + (now.getMonth() - start.getMonth());
                console.log(email, monthsDiff, "minutes since last deposit");

                // Stage selection
                let currentStage = null;
                if (monthsDiff >= 6) currentStage = '6M';
                else if (monthsDiff >= 4) currentStage = '4M';
                else if (monthsDiff >= 3) currentStage = '3M';

                if (!currentStage || last_stage_sent === currentStage) {
                    console.log(`⏩ Skipping ${email}, already processed stage ${last_stage_sent}`);
                    continue;
                }

                let finalAmount = 0;

                if (currentStage === '3M') {
                    // Only mail, no deduction
                    await sendMail(email, userName, monthsDiff, origin);
                    await updateStageWithBalance(userId, currentStage, null, currentBalance);
                    continue;
                }

                if (currentStage === '4M') {
                    finalAmount = currentBalance * 0.15;
                    currentBalance -= finalAmount;
                } else if (currentStage === '6M') {
                    finalAmount = currentBalance;
                    currentBalance = 0;
                }
                await updateStageWithBalance(userId, currentStage, null, currentBalance);

                // Deduction API
                const withdrawalReq = {
                    password: "abcdr1245",
                    txntype: 1,
                    users: [
                        {
                            userId,
                            txnType: 2,
                            amount: finalAmount,
                            remark: "Inactivity Deduction",
                            key: 0,
                            mainUserId: agentRef === 1 && parentId ? parentId : 5549622
                        }
                    ]
                };

                await new Promise((resolve) => {
                    depositAmount(async (resp) => {
                        console.log("Deduction resp", resp);
                        if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                            await sendMail(email, userName, monthsDiff, origin);
                            await updateStageWithBalance(userId, currentStage, resp, currentBalance);
                        } else {
                            console.log(`❌ Deduction failed for ${email}, mail not sent`);
                        }
                        resolve();
                    }, withdrawalReq);
                });

            } catch (err) {
                console.error(`Error for ${email}:`, err.response?.data || err.message);
            }
        }

    } catch (err) {
        console.error("DB Error:", err.message);
    }
}
async function updateBalance(userId, balance) {
    const reqInsert = new sql.Request();
    reqInsert.input('remaining_balance', sql.Decimal(18, 2), balance);
    reqInsert.input('userId', sql.VarChar(50), userId);
    await reqInsert.query(`
        UPDATE email_logs
        SET remaining_balance = @remaining_balance
        WHERE userId = @userId
    `);
}
async function updateStageWithBalance(userId, stage, resp, balance) {
    const request = new sql.Request();
    request.input('result', sql.NVarChar(sql.MAX), resp ? JSON.stringify(resp) : null);
    request.input('last_stage_sent', sql.VarChar(255), stage);
    request.input('remaining_balance', sql.Decimal(18, 2), balance);
    request.input('userId', sql.VarChar(255), userId);

    await request.query(`
        UPDATE email_logs
        SET result = @result,
            last_stage_sent = @last_stage_sent,
            last_stage_date = GETDATE(),
            remaining_balance = @remaining_balance
        WHERE userId = @userId
    `);
}
async function sendMail(email, userName, hoursDiff, origin) {
    try {
        await axios.post(`https://api2.streamingtv.fun:3479/reminder-mail`, {
            email,
            userName,
            month: hoursDiff,
            origin
        });
        console.log(`📧 Mail sent to ${email}`);
    } catch (err) {
        console.error(`❌ Mail sending failed for ${email}:`, err.message);
    }
}
app.get('/check-active-user/:userId', async (req, res) => {
    try {
        const { userId } = req.params;

        const request = new sql.Request();
        request.input('userId', sql.VarChar(50), userId);

        const result = await request.query(`
            SELECT 
                userId,
                CASE WHEN last_stage_sent = '6H' THEN 1 ELSE 0 END AS isInactiveUser
            FROM email_logs
            WHERE userId = @userId
        `);

        if (!result.recordset.length) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json(result.recordset[0]);

    } catch (err) {
        console.error('DB Error:', err.message);
        res.status(500).json({ error: 'Internal server error' });
    }
});
cron.schedule('0 0 * * *', () => {
    console.log("⏰ Running at midnight");
    callTxnSummaryAPI();
});
// setInterval(() => {
//     console.log("🔄 Rechecking pending deposits...");
//     callTxnSummaryAPI();
// }, 1 * 60 * 1000); // 1 minutes

// telegram bot msg start
// app.post('/api/stbm', async (req, res) => {
//     // console.log(req.body);
//     try {
//         const { domain, amount, type, userName, currency, paymentType, trasactionId, paid_to } = req.body;
//         if (!domain || !amount || !type || !userName || !currency) {
//             return res.status(201).json({ message: 'All fields are required' });
//         }

//         const botConfig = domainBotTokens[domain];
//         if (!botConfig) {
//             return res.status(201).json({ message: 'Invalid domain or not configured' });
//         }

//         const bot = new TelegramBot(botConfig.botToken, { polling: false });
//         const chatId = botConfig.chatId;

//         const message = type == 1
//             ? `D/W: "Deposit",\n` +
//             `Player: "${userName}",\n` +
//             `Amount: "${amount}" ${currency},\n` +
//             `Type: ${paid_to},\n` +
//             `Transaction ID: ${trasactionId},\n` +
//             `has submitted a new "deposit" to ${domain}.`
//             : `D/W: "Withdrawal",\n` +
//             `Player: "${userName}",\n` +
//             `Amount: "${amount}" ${currency},\n` +
//             `Type: ${paymentType}/${paid_to},\n` +
//             `has submitted a new "withdrawal" request from ${domain}.`;

//         await bot.sendMessage(chatId, message);
//         const logEntry = {
//             domain,
//             amount,
//             type: type == 1 ? 'Deposit' : 'Withdrawal',
//             userName,
//             currency,
//             paymentType,
//             trasactionId,
//             paid_to,
//             timestamp: new Date().toISOString()
//         };

//         const logPath = path.join(__dirname, 'logs', 'transactionLogs.json');

//         // Ensure 'logs' folder exists
//         if (!fs.existsSync(path.join(__dirname, 'logs'))) {
//             fs.mkdirSync(path.join(__dirname, 'logs'));
//         }

//         let logs = [];
//         if (fs.existsSync(logPath)) {
//             const data = fs.readFileSync(logPath);
//             logs = JSON.parse(data);
//         }

//         logs.push(logEntry);
//         fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));

//         res.status(200).json({ message: 'Message sent and logged successfully' });
//     } catch (error) {
//         console.error('Error:', error);
//         res.status(201).json({ message: 'Bot channel not found' });
//     }
// });
// app.post('/api/send-telegram', async (req, res) => {
//     console.log(req.body);
//     try {
//         const { domain, amount, type, userName, currency, paymentType, trasactionId, paid_to } = req.body;
//         if (!domain || !amount || !type || !userName) {
//             return res.status(201).json({ message: 'All fields are required' });
//         }

//         const botConfig = domainBotTokens[domain];
//         if (!botConfig) {
//             return res.status(201).json({ message: 'Invalid domain or not configured' });
//         }

//         const bot = new TelegramBot(botConfig.botToken, { polling: false });
//         const chatId = botConfig.chatId;

//         const message = type == 1
//             ? `D/W: "Deposit",\n` +
//             `Player: "${userName}",\n` +
//             `Amount: "${amount}" ${currency},\n` +
//             `Type: ${paid_to},\n` +
//             `Transaction ID: ${trasactionId},\n` +
//             `has submitted a new "deposit" to ${domain}.`
//             : `D/W: "Withdrawal",\n` +
//             `Player: "${userName}",\n` +
//             `Amount: "${amount}" ${currency},\n` +
//             `Type: ${paymentType}/${paid_to},\n` +
//             `has submitted a new "withdrawal" request from ${domain}.`;

//         await bot.sendMessage(chatId, message);
//         const logEntry = {
//             domain,
//             amount,
//             type: type == 1 ? 'Deposit' : 'Withdrawal',
//             userName,
//             currency,
//             paymentType,
//             trasactionId,
//             paid_to,
//             timestamp: new Date().toISOString()
//         };

//         const logPath = path.join(__dirname, 'logs', 'transactionLogs.json');

//         // Ensure 'logs' folder exists
//         if (!fs.existsSync(path.join(__dirname, 'logs'))) {
//             fs.mkdirSync(path.join(__dirname, 'logs'));
//         }

//         let logs = [];
//         if (fs.existsSync(logPath)) {
//             const data = fs.readFileSync(logPath);
//             logs = JSON.parse(data);
//         }

//         logs.push(logEntry);
//         fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));

//         res.status(200).json({ message: 'Message sent and logged successfully' });
//         console.log('Message sent and logged successfully');
//     } catch (error) {
//         console.error('Error:', error);
//         res.status(201).json({ message: 'Bot channel not found' });
//     }
// });
app.post('/api/stbm', async (req, res) => {
    try {
        const { domain, amount, type, userName, currency, paymentType, trasactionId, paid_to } = req.body;
        if (!domain || !amount || !type || !userName || !currency) {
            return res.status(201).json({ message: 'All fields are required' });
        }

        const botConfig = domainBotTokens[domain];
        if (!botConfig) {
            return res.status(201).json({ message: 'Invalid domain or not configured' });
        }

        const bot = new TelegramBot(botConfig.botToken, { polling: false });
        const chatId = botConfig.chatId;

        const message = type == 1
            ? `D/W: "Deposit",\n` +
            `Player: "${userName}",\n` +
            `Amount: "${amount}" ${currency},\n` +
            `Type: ${paid_to},\n` +
            `Transaction ID: ${trasactionId},\n` +
            `has submitted a new "deposit" to ${domain}.`
            : `D/W: "Withdrawal",\n` +
            `Player: "${userName}",\n` +
            `Amount: "${amount}" ${currency},\n` +
            `Type: ${paymentType}/${paid_to},\n` +
            `has submitted a new "withdrawal" request from ${domain}.`;

        await bot.sendMessage(chatId, message);

        res.status(200).json({ message: 'Message sent successfully' });
    } catch (error) {
        console.error('Error:', error);
        res.status(201).json({ message: 'Bot channel not found' });
    }
});
app.post('/api/send-info-demo', async (req, res) => {
    try {
        const {
            domain, name, email, country, district, whatsapp, turnover,
            users, platform, issues, telegramStatus, telegramHandle,
            site, timestamp, ip, requestedFrom
        } = req.body;

        // Required fields check
        if (!domain || !name || !email || !country || !district || !whatsapp ||
            !turnover || !users || !platform || !issues || !telegramStatus ||
            !telegramHandle || !site || !timestamp || !ip || !requestedFrom) {
            return res.status(201).json({ message: 'All fields are required' });
        }

        // Bot config check
        const botConfig = domainBotTokens[domain];
        if (!botConfig) {
            return res.status(201).json({ message: 'Invalid domain or not configured' });
        }

        const bot = new TelegramBot(botConfig.botToken, { polling: false });
        const chatId = botConfig.chatId;

        // One-by-one line format like /api/stbm
        const message =
            `📢 New Info Request from ${domain}
Name: ${name}
Email: ${email}
Country: ${country}
District: ${district}
WhatsApp: ${whatsapp}
Turnover: ${turnover}
Users: ${users}
Platform: ${platform}
Issues: ${issues}
Telegram Status: ${telegramStatus}
Telegram Handle: ${telegramHandle}
Site: ${site}
Timestamp: ${timestamp}
IP: ${ip}
Requested From: ${requestedFrom}`;

        await bot.sendMessage(chatId, message);

        res.status(200).json({ message: 'Message sent successfully' });

    } catch (error) {
        console.error('Error:', error);
        res.status(201).json({ message: 'Bot channel not found' });
    }
});
app.post('/api/send-telegram', async (req, res) => {
    console.log(req.body);
    try {
        const { domain, amount, type, userName, currency, paymentType, trasactionId, paid_to } = req.body;
        if (!domain || !amount || !type || !userName) {
            return res.status(201).json({ message: 'All fields are required' });
        }

        const botConfig = domainBotTokens[domain];
        if (!botConfig) {
            return res.status(201).json({ message: 'Invalid domain or not configured' });
        }

        const bot = new TelegramBot(botConfig.botToken, { polling: false });
        const chatId = botConfig.chatId;

        const message = type == 1
            ? `D/W: "Deposit",\n` +
            `Player: "${userName}",\n` +
            `Amount: "${amount}" ${currency},\n` +
            `Type: ${paid_to},\n` +
            `Transaction ID: ${trasactionId},\n` +
            `has submitted a new "deposit" to ${domain}.`
            : `D/W: "Withdrawal",\n` +
            `Player: "${userName}",\n` +
            `Amount: "${amount}" ${currency},\n` +
            `Type: ${paymentType}/${paid_to},\n` +
            `has submitted a new "withdrawal" request from ${domain}.`;

        await bot.sendMessage(chatId, message);

        res.status(200).json({ message: 'Message sent successfully' });
        console.log('Message sent successfully');
    } catch (error) {
        console.error('Error:', error);
        res.status(201).json({ message: 'Bot channel not found' });
    }
});
// telegram bot msg end

// b2cemail end

// axios.get('https://p.streamingtv.fun/transaction-status', {
//   body: 
//   {
//     "email":"aaron111griffith@gmail.com",
//     "amount":"1000",
//     "status":1,
//     "remark":"deposit not Accepted",
//     "type":2,
//     "origin":"cricwin.io"

// }
// })
// .then(response => {
//   console.log(response.data);  // Check the response data
// })
// .catch(error => {
//   console.error('Error:', error.response ? error.response.data : error.message);
// });


// jaragateway start

// async function logResponseToDatabase(response) {
//     try {
//         await sql.connect(config);
//         const request = new sql.Request();
//         request.input('responseData', sql.NVarChar, JSON.stringify(response));  
//         const result = await request.query('INSERT INTO transactions_log (response_data) VALUES (@responseData)');
//         console.log('Response logged successfully:', result);
//     } catch (error) {
//         console.error('Error logging response to database:', error);
//     }
// }
// function getDateRange() {
//     const now = new Date();
//     const fromDate = new Date(now);
//     fromDate.setDate(fromDate.getDate() - 10); // 10 days back
//     fromDate.setHours(12, 0, 0, 0); // Set time to 12:00:00 PM

//     const toDate = now; // Current date and time

//     return {
//         from: fromDate.toISOString().slice(0, 19).replace('T', ' '),
//         to: toDate.toISOString().slice(0, 19).replace('T', ' '),
//     };
// }

// let intervalId = null;
// async function fetchTransactionData() {
//     try {
//         const { from, to } = getDateRange();
//         //   console.log(from , to);
//         const response = await axios.get('https://sc.cricbuzzer.io:15552/api/getalltrnrequest', {
//             params: {
//                 uid: 0,
//                 type: 1,
//                 status: 0,
//                 from: from,
//                 to: to,
//                 domain: 'express11.bet'
//             },
//             headers: {
//                 'Authorization': 'BEA72561CA6A15A8D963A2DB52EE8EF0',
//                 'Origin': 'https://ag.express11.bet',
//             }
//         });


//         let isLogged = false;
//         if (!isLogged && response.data.status === "Success" && response.data.data.length > 0) {
//             // isLogged = true;
//             const trnData = response.data.data[0];
//             const { trn_id, uid, paid_to , coins } = trnData;

//             if (
//                 paid_to.includes("PhonePe_") ||
//                 paid_to.includes("Paytm_") ||
//                 paid_to.includes("GPay_")
//             ) {
//                 console.log("❌ Transaction blocked due to restricted payment method:", paid_to);
//                 return; 
//             }

//             isLogged = true;
//             const settleDepositData = {
//                 password: 'Ajjj1234',
//                 parentId: 4701886,
//                 status: '1',
//                 remark: 'Fund Auto Transfer',
//                 trnDetails: [{
//                     uid: uid,
//                     trn_id: trn_id,
//                     amount: coins,
//                 }],
//                 trn_type: 1
//             };
//             // console.log(settleDepositData ,"payload");
//             await postSettleDeposit(settleDepositData, response.data);
//             resetInterval();

//         } else {
//             console.log('No transactions found');
//         }
//     } catch (error) {
//         // console.error('Error fetching transaction data:', error);
//     }
// }
// function resetInterval() {
//     if (intervalId) {
//         clearInterval(intervalId); 
//     }
//     intervalId = setInterval(fetchTransactionData, 12000);
// }
// async function postSettleDeposit(data, getAllTrnRequestResponse) {
//     try {
//         const response = await axios.post('https://sc.cricbuzzer.io:15552/api/settleDeposit', data, {
//             headers: {
//                 'Authorization': 'BEA72561CA6A15A8D963A2DB52EE8EF0',
//                 'Origin': 'https://ag.express11.bet',
//                 'Content-Type': 'application/json',
//             }
//         });

//         // console.log('Response from settleDeposit API:', response.data);

//         if (response.data.status === "Success") {
//             await logResponseToDatabase(getAllTrnRequestResponse);
//         } else {
//             console.log('SettleDeposit API response did not indicate success');
//         }
//     } catch (error) {
//         // console.error('Error posting to settleDeposit API:', error);
//     }
// }
// resetInterval();

// jaragateway end

// WL DOMAIN WHITELIST START
app.post('/AddDomain', async (req, res) => {
    const { Domain, isStaticDomain, isSkyfancy, isMainscore } = req.body;

    if (Domain && isStaticDomain !== undefined && isSkyfancy !== undefined && isMainscore !== undefined) {
        try {
            await sql.connect(config);
            const query = `
                INSERT INTO whitelistDomain (Domain, isStaticDomain, isSkyfancy, isMainscore)
                VALUES (@Domain, @isStaticDomain, @isSkyfancy, @isMainscore)
            `;
            const request = new sql.Request();
            request.input('Domain', sql.VarChar, Domain);
            request.input('isStaticDomain', sql.Bit, isStaticDomain);
            request.input('isSkyfancy', sql.Bit, isSkyfancy);
            request.input('isMainscore', sql.Bit, isMainscore);

            await request.query(query);

            res.status(200).send({ message: `Domain Added Successfully` });
        } catch (err) {
            console.error('Error adding domain:', err);
            res.status(500).json({
                errorCode: 1,
                errorDescription: err.message,
                result: null
            });
        }
    } else {
        res.status(400).send({ message: 'Invalid details provided!' });
    }
});
app.get('/getDomain', async (req, res) => {
    try {
        await sql.connect(config);
        const request = new sql.Request();
        const result = await request.query('SELECT * FROM whitelistDomain');
        res.status(200).json({ errorCode: 0, errorDescription: null, result: result.recordset });
    } catch (err) {
        console.error('Error fetching whitelist:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
app.put('/EditDomain/:ids', async (req, res) => {
    const ID = req.params.ids;
    const { Domain, isStaticDomain, isSkyfancy, isMainscore } = req.body;

    if (!Domain || isStaticDomain === undefined || isSkyfancy === undefined || isMainscore === undefined) {
        return res.status(400).json({ errorCode: 1, errorDescription: 'Missing fields in request body', result: null });
    }

    try {
        await sql.connect(config);
        const query = `
            UPDATE whitelistDomain
            SET Domain = @Domain, 
                isStaticDomain = @isStaticDomain, 
                isSkyfancy = @isSkyfancy, 
                isMainscore = @isMainscore
            WHERE ID = @ID
        `;
        const request = new sql.Request();
        request.input('ID', sql.VarChar, ID);
        request.input('Domain', sql.VarChar, Domain);
        request.input('isStaticDomain', sql.Bit, isStaticDomain);
        request.input('isSkyfancy', sql.Bit, isSkyfancy);
        request.input('isMainscore', sql.Bit, isMainscore);

        const result = await request.query(query);
        if (result.rowsAffected[0] > 0) {
            res.status(200).json({
                errorCode: 0,
                errorDescription: null,
                result: `Domain updated successfully for ${result.rowsAffected[0]} record(s)`
            });
        } else {
            res.status(404).json({
                errorCode: 1,
                errorDescription: 'No matching records found',
                result: null
            });
        }
    } catch (err) {
        console.error('Error updating whitelistDomain:', err);
        res.status(500).json({
            errorCode: 1,
            errorDescription: err.message,
            result: null
        });
    }
});
app.delete('/DeleteDomain/:id', async (req, res) => {
    const { id } = req.params;

    if (!id) {
        return res.status(400).json({ errorCode: 1, errorDescription: 'Missing ID parameter', result: null });
    }

    try {
        await sql.connect(config);
        const query = `DELETE FROM whitelistDomain WHERE id = @id`;
        const request = new sql.Request();
        request.input('id', sql.Int, id);

        const result = await request.query(query);
        if (result.rowsAffected[0] === 0) {
            res.status(404).json({ errorCode: 1, errorDescription: null, result: 'Record Not Found' });
        } else {
            res.status(200).json({ errorCode: 0, errorDescription: null, result: 'Deleted Successfully' });
        }
    } catch (err) {
        console.error('Error deleting proxy link:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
// WL DOMAIN WHITELIST END




// Maintenance start

// const maintenanceFilePath = path.join(__dirname, "uploads", "maintenance.json");

// app.post('/setMaintenance', (req, res) => {
//     const { msg, Maintenance } = req.body;

//     if (typeof msg !== "string" || typeof Maintenance !== "boolean") {
//         return res.status(200).json({ errorCode: 1, errorDescription: "Invalid data format." });
//     }

//     const maintenanceStatus = {
//         msg,
//         Maintenance,
//         receivedDate: new Date().toISOString()
//     };

//     fs.writeFileSync(maintenanceFilePath, JSON.stringify(maintenanceStatus, null, 2));

//     res.json({ errorCode: 0, errorDescription: null, result: "Maintenance status updated successfully." });
// });


// app.get('/getMaintenance', (req, res) => {
//     if (!fs.existsSync(maintenanceFilePath)) {
//         return res.json({ maintenance: false, message: "" });
//     }

//     const data = fs.readFileSync(maintenanceFilePath, "utf-8");
//     const status = JSON.parse(data);
//     res.json({ maintenance: status.Maintenance, message: status.msg });
// });


// Maintenance end

// Set OpratorID

app.post('/api/updateOprator', async (req, res) => {
    const domains = req.body;
    if (!domains || domains.length === 0) {
        return res.status(400).json({ errorCode: 1, errorDescription: 'No domains provided.' });
    }
    try {
        await sql.connect(config);
        let values = domains.map(item => `('${item.domain}', '${item.operatorId}')`).join(', ');
        const query = `
            INSERT INTO AmanOperatorId (domain, operatorId)
            VALUES ${values}
        `;
        const result = await sql.query(query);
        res.status(200).json({ errorCode: 0, errorDescription: null, result: 'Operators inserted successfully' });
    } catch (err) {
        console.error('Error inserting operators:', err);
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});
app.get('/api/getAuraOperators/:domain', async (req, res) => {
    const { domain } = req.params;
    try {
        await sql.connect(config);
        const result = await sql.query`SELECT operatorId FROM AmanOperatorId WHERE domain = ${domain}`;

        if (result.recordset.length > 0) {
            const operatorId = result.recordset[0].operatorId;
            res.status(200).json({ errorCode: 0, errorDescription: null, result: operatorId });
        } else {
            res.status(404).json({ errorCode: 1, errorDescription: 'Domain not found', result: null });
        }
    } catch (err) {
        res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});

app.post('/api/withdraw', async (req, res) => {
    try {
        const { userName, password, amount, domain, penalty } = req.body;

        const response = await axios.post(
            'https://111111.info/pad=82/withdraw',
            { userName, password, amount, domain, penalty },
            {
                headers: { 'Content-Type': 'application/json' },
                timeout: 15000
            }
        );

        console.log('API Response:', response.data);

        res.status(200).json({
            message: 'Request successful',
            data: response.data
        });

    } catch (error) {
        console.error('API Error:', error.response ? error.response.data : error.message);
        res.status(500).json({
            message: 'Request failed',
            error: error.response ? error.response.data : error.message
        });
    }
});

// let domainCache = [];

// app.get('/api/getAuraOperators/:domain', async (req, res) => {
//     const requestedDomain = req.params.domain;
//     try {
//       if (domainCache.length === 0) {
//         const response = await axios.get('https://222222.digital/pad=81/getAuraOperators', {
//           headers: {
//             Authorization: 'EE9BDED525816CBB0EE3DE5F7D656C00'
//           }
//         });

//         if (response.data.errorCode === 0) {
//           domainCache = response.data.result;
//         } else {
//           return res.status(500).json({ message: 'Remote API error', error: response.data.errorDescription });
//         }
//       }
//      const found = domainCache.find(item => item.domain === requestedDomain);
//       if (found) {
//         res.status(200).json({ errorCode: 0, errorDescription: null, result: found.operatorId  });
//       } else {
//         res.status(201).json({ errorCode: 1, errorDescription: null, result: 'Domain not found' });
//       }

//     } catch (error) {
//       console.error('Error fetching operator:', error.message);
//       return res.status(500).json({ message: 'Server error', error: error.message });
//     }
//   });

// Set OpratorID End

// let domainCache = [];

// app.get('/api/getAuraOperators/:domain', async (req, res) => {
//     const requestedDomain = req.params.domain;
//     try {
//       if (domainCache.length === 0) {
//         const response = await axios.get('https://222222.digital/pad=81/getAuraOperators', {
//           headers: {
//             Authorization: 'EE9BDED525816CBB0EE3DE5F7D656C00'
//           }
//         });

//         if (response.data.errorCode === 0) {
//           domainCache = response.data.result;
//         } else {
//           return res.status(500).json({ message: 'Remote API error', error: response.data.errorDescription });
//         }
//       }
//      const found = domainCache.find(item => item.domain === requestedDomain);
//       if (found) {
//         res.status(200).json({ errorCode: 0, errorDescription: null, result: found.operatorId  });
//       } else {
//         res.status(201).json({ errorCode: 1, errorDescription: null, result: 'Domain not found' });
//       }

//     } catch (error) {
//       console.error('Error fetching operator:', error.message);
//       return res.status(500).json({ message: 'Server error', error: error.message });
//     }
//   });

// Set OpratorID End


// Support System Start
app.post('/api/supportSystem', async (req, res) => {
    const { name, number, domain } = req.body;

    if (!domain || domain.trim() === '') {
        return res.status(400).json({
            errorCode: 1,
            errorDescription: 'domain is required'
        });
    }

    try {
        await sql.connect(config);

        const request = new sql.Request();
        request.input('name', sql.VarChar, name);
        request.input('number', sql.VarChar, number);
        request.input('domain', sql.VarChar, domain.trim().toLowerCase());

        await request.query(`
            INSERT INTO supportSystem (name, number, domain)
            VALUES (@name, @number, @domain)
        `);

        res.json({
            errorCode: 0,
            message: 'Inserted successfully'
        });

    } catch (err) {
        res.status(500).json({
            errorCode: 1,
            errorDescription: err.message
        });
    }
});
app.delete('/api/supportSystem/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await sql.connect(config);
        await sql.query`
            DELETE FROM supportSystem WHERE id = ${id}
        `;
        res.json({ errorCode: 0, message: 'Deleted successfully' });
    } catch (err) {
        res.status(500).json({
            errorCode: 1,
            errorDescription: err.message
        });
    }
});
app.get('/api/supportSystem/:domain', async (req, res) => {
    const { domain } = req.params;

    try {
        await sql.connect(config);
        const result = await sql.query`
            SELECT * FROM supportSystem WHERE domain = ${domain}
        `;
        res.json({
            errorCode: 0,
            result: result.recordset
        });
    } catch (err) {
        res.status(500).json({
            errorCode: 1,
            errorDescription: err.message
        });
    }
});
app.put('/api/supportSystem/:id', async (req, res) => {
    const { id } = req.params;
    const { name, number } = req.body;

    if (!id) {
        return res.status(400).json({
            errorCode: 1,
            errorDescription: 'id is required'
        });
    }

    try {
        await sql.connect(config);
        const request = new sql.Request();
        request.input('id', sql.Int, id);
        request.input('name', sql.VarChar, name);
        request.input('number', sql.VarChar, number);

        await request.query(`
            UPDATE supportSystem
            SET 
                name = @name,
                number = @number
            WHERE id = @id
        `);

        res.json({
            errorCode: 0,
            message: 'Updated successfully'
        });

    } catch (err) {
        res.status(500).json({
            errorCode: 1,
            errorDescription: err.message
        });
    }
});
// Support System End


//dailycheckin start
// const CHECKIN_INTERVAL_HOURS = 1 / 60;
// const MISSED_RESET_HOURS = 2 / 60;
const CHECKIN_INTERVAL_HOURS = 24;
const MISSED_RESET_HOURS = 48;

app.post('/api/checkin', async (req, res) => {

    const { userId, parentId, userName, domain } = req.body;

    try {

        const TZ = 'Asia/Dubai';

        const nowLocal = moment().tz(TZ);

        const weekStart = nowLocal
            .clone()
            .startOf('isoWeek');

        const logReq = new sql.Request();

        logReq
            .input('userId', sql.VarChar, userId)
            .input('domain', sql.VarChar, domain)
            .input('weekStart', sql.DateTime, weekStart.toDate());

        const logRes = await logReq.query(`
            SELECT id, day, api_status, created_at
            FROM checkin_logs
            WHERE userId = @userId
            AND domain = @domain
            AND api_status IN ('SUCCESS', 'MISSED')
            AND created_at >= @weekStart
            ORDER BY day ASC, id ASC
        `);

        const todaySuccess = logRes.recordset.find(x => {
            return x.api_status === 'SUCCESS' &&
                moment(x.created_at).tz(TZ).isSame(nowLocal, 'day');
        });

        if (todaySuccess) {
            return res.json({
                errorCode: 1,
                message: "Already checked in today"
            });
        }

        const claimedDays = logRes.recordset
            .filter(x => x.api_status === 'SUCCESS')
            .map(x => Number(x.day));

        const missedDays = logRes.recordset
            .filter(x => x.api_status === 'MISSED')
            .map(x => Number(x.day));

        const availableDays = [1, 2, 3, 4, 5, 6, 7].filter(d =>
            !claimedDays.includes(d) &&
            !missedDays.includes(d)
        );

        let day = availableDays[0];

        if (!day) {
            day = 1;
        }

        const rewardReq = new sql.Request();

        rewardReq
            .input('day', sql.Int, day)
            .input('domain', sql.VarChar, domain);

        const rewardRes = await rewardReq.query(`
            SELECT amount AS vip_points
            FROM checkin_rewards
            WHERE day_number = @day
            AND domain = @domain
            AND is_active = 1
        `);

        if (rewardRes.recordset.length === 0) {
            return res.json({
                errorCode: 1,
                message: "Reward not configured"
            });
        }

        const vipPoints = rewardRes.recordset[0].vip_points;

        const walletReq = new sql.Request();

        walletReq
            .input('userId', sql.VarChar, userId)
            .input('parentId', sql.VarChar, parentId)
            .input('userName', sql.VarChar, userName)
            .input('domain', sql.VarChar, domain)
            .input('vipPoints', sql.Int, vipPoints);

        await walletReq.query(`
            IF EXISTS (
                SELECT 1 FROM user_vip_wallet
                WHERE userId = @userId
                AND domain = @domain
            )
            BEGIN
                UPDATE user_vip_wallet
                SET
                    vip_points = ISNULL(vip_points, 0) + @vipPoints,
                    parentId = @parentId,
                    userName = @userName,
                    updated_at = GETDATE()
                WHERE userId = @userId
                AND domain = @domain
            END
            ELSE
            BEGIN
                INSERT INTO user_vip_wallet
                (
                    userId,
                    parentId,
                    userName,
                    domain,
                    vip_points,
                    updated_at
                )
                VALUES
                (
                    @userId,
                    @parentId,
                    @userName,
                    @domain,
                    @vipPoints,
                    GETDATE()
                )
            END
        `);

        const saveReq = new sql.Request();

        saveReq
            .input('userId', sql.VarChar, userId)
            .input('parentId', sql.VarChar, parentId)
            .input('userName', sql.VarChar, userName)
            .input('domain', sql.VarChar, domain)
            .input('day', sql.Int, day)
            .input('vipPoints', sql.Int, vipPoints);

        await saveReq.query(`
            INSERT INTO checkin_logs
            (
                userId,
                parentId,
                userName,
                domain,
                day,
                amount,
                api_status,
                created_at
            )
            VALUES
            (
                @userId,
                @parentId,
                @userName,
                @domain,
                @day,
                @vipPoints,
                'SUCCESS',
                GETDATE()
            )
        `);

        return res.json({
            errorCode: 0,
            message: "Check-in successful",
            day,
            vip_points: vipPoints
        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({
            errorCode: 1,
            message: "Server error"
        });

    }

});
app.get('/api/checkin/status', async (req, res) => {

    const { userId, domain } = req.query;

    try {
        const TZ = 'Asia/Dubai';
        const now = moment().tz(TZ);

        const weekStart = now.clone().startOf('isoWeek');
        const nextDayStart = now.clone().add(1, 'day').startOf('day');

        const currentWeekDay = now.isoWeekday(); // Monday=1, Sunday=7
        const daysPassedBeforeToday = currentWeekDay - 1;

        const rewardReq = new sql.Request();
        rewardReq.input('domain', sql.VarChar, domain);

        const rewardRes = await rewardReq.query(`
            SELECT day_number, amount AS vip_points
            FROM checkin_rewards
            WHERE domain = @domain
            AND is_active = 1
            ORDER BY day_number
        `);

        const logReq = new sql.Request();
        logReq
            .input('userId', sql.VarChar, userId)
            .input('domain', sql.VarChar, domain)
            .input('weekStart', sql.DateTime, weekStart.toDate());

        let logRes = await logReq.query(`
            SELECT id, day, api_status, created_at
            FROM checkin_logs
            WHERE userId = @userId
            AND domain = @domain
            AND created_at >= @weekStart
            AND api_status IN ('SUCCESS', 'MISSED')
            ORDER BY id ASC
        `);

        let claimedDays = logRes.recordset
            .filter(x => x.api_status === 'SUCCESS')
            .map(x => x.day);

        let missedDays = logRes.recordset
            .filter(x => x.api_status === 'MISSED')
            .map(x => x.day);

        const todaySuccess = logRes.recordset.find(x =>
            x.api_status === 'SUCCESS' &&
            moment(x.created_at).tz(TZ).isSame(now, 'day')
        );

        const today_checked = !!todaySuccess;

        const claimedBeforeToday = logRes.recordset.filter(x =>
            x.api_status === 'SUCCESS' &&
            moment(x.created_at).tz(TZ).isBefore(now.clone().startOf('day'))
        ).length;

        let missedCount = daysPassedBeforeToday - claimedBeforeToday;

        if (missedCount < 0) missedCount = 0;
        if (missedCount > 7) missedCount = 7;

        for (let i = 0; i < missedCount; i++) {

            const missedDay = 7 - i;

            if (!missedDays.includes(missedDay) && !claimedDays.includes(missedDay)) {

                const missedReq = new sql.Request();

                missedReq
                    .input('userId', sql.VarChar, userId)
                    .input('domain', sql.VarChar, domain)
                    .input('day', sql.Int, missedDay);

                await missedReq.query(`
                    INSERT INTO checkin_logs
                    (
                        userId,
                        domain,
                        day,
                        amount,
                        api_status,
                        created_at
                    )
                    VALUES
                    (
                        @userId,
                        @domain,
                        @day,
                        0,
                        'MISSED',
                        GETDATE()
                    )
                `);

                missedDays.push(missedDay);
            }
        }

        const maxClaimableDay = 7 - missedDays.length;
        const nextAvailableDay = claimedDays.length + 1;

        const next_login_seconds = today_checked
            ? nextDayStart.diff(now, 'seconds')
            : 0;

        const next_login_time = today_checked
            ? nextDayStart.format('YYYY-MM-DD HH:mm:ss')
            : null;

        const rewards = rewardRes.recordset.map(item => {

            let status = "locked";

            if (claimedDays.includes(item.day_number)) {
                status = "claimed";
            }

            if (missedDays.includes(item.day_number)) {
                status = "missed";
            }

            if (
                !today_checked &&
                item.day_number === nextAvailableDay &&
                item.day_number <= maxClaimableDay &&
                status === "locked"
            ) {
                status = "available";
            }

            return {
                day: item.day_number,
                vip_points: item.vip_points,
                status
            };
        });

        return res.json({
            errorCode: 0,
            streak: claimedDays.length + missedDays.length,
            today_checked,
            next_login_seconds,
            next_login_time,
            rewards
        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({
            errorCode: 1,
            message: "Server error"
        });
    }
});
app.get('/api/vip/wallet', async (req, res) => {

    const { userId, domain } = req.query;

    if (!userId || !domain) {
        return res.json({
            errorCode: 1,
            message: "userId and domain required"
        });
    }

    try {

        const request = new sql.Request();
        request
            .input('userId', sql.VarChar, userId)
            .input('domain', sql.VarChar, domain);

        const result = await request.query(`
        SELECT ISNULL(vip_points, 0) AS vip_points
        FROM user_vip_wallet
        WHERE userId = @userId
        AND domain = @domain
    `);
        const result1 = await request.query(`
    SELECT 
        ISNULL(minimum_vp, 0) AS minimum_vp,
        ISNULL(conversion_ratio, 0) AS conversion_ratio
    FROM vip_conversion_settings
    WHERE domain = @domain
    AND is_active = 1
`);

        return res.json({

            errorCode: 0,

            vip_points:
                result.recordset.length > 0
                    ? result.recordset[0].vip_points
                    : 0,

            minimum_vp:
                result1.recordset.length > 0
                    ? result1.recordset[0].minimum_vp
                    : 0,

            conversion_ratio:
                result1.recordset.length > 0
                    ? result1.recordset[0].conversion_ratio
                    : 0

        });

    } catch (error) {

        return res.status(500).json({
            errorCode: 1,
            message: "Server error"
        });

    }

});
app.post('/api/vip/convert', async (req, res) => {

    const { userId, parentId, userName, domain, convertVipPoints } = req.body;
    const adminToken = req.headers["authorization"] || "";

    try {

        const requestedVP = Number(convertVipPoints);

        const settingReq = new sql.Request();

        settingReq.input('domain', sql.VarChar, domain);

        const settingRes = await settingReq.query(`
            SELECT TOP 1
                ISNULL(minimum_vp, 0) AS minimum_vp,
                ISNULL(conversion_ratio, 0) AS conversion_ratio
            FROM vip_conversion_settings
            WHERE domain = @domain
            AND is_active = 1
        `);

        if (settingRes.recordset.length === 0) {
            return res.json({
                errorCode: 1,
                message: "Conversion setting not found"
            });
        }

        const minimumVP = Number(settingRes.recordset[0].minimum_vp);
        const conversionRatio = Number(settingRes.recordset[0].conversion_ratio);

        if (!requestedVP || requestedVP < minimumVP) {
            return res.json({
                errorCode: 1,
                message: `Minimum ${minimumVP} VIP points required`
            });
        }

        if (conversionRatio <= 0) {
            return res.json({
                errorCode: 1,
                message: "Invalid conversion ratio"
            });
        }

        if (requestedVP % conversionRatio !== 0) {
            return res.json({
                errorCode: 1,
                message: `VIP points must be multiple of ${conversionRatio}`
            });
        }

        const walletReq = new sql.Request();

        walletReq
            .input('userId', sql.VarChar, userId)
            .input('domain', sql.VarChar, domain);

        const walletRes = await walletReq.query(`
            SELECT ISNULL(vip_points, 0) AS vip_points
            FROM user_vip_wallet
            WHERE userId = @userId
            AND domain = @domain
        `);

        if (walletRes.recordset.length === 0) {
            return res.json({
                errorCode: 1,
                message: "VIP wallet not found"
            });
        }

        const availableVipPoints = walletRes.recordset[0].vip_points;

        if (availableVipPoints < requestedVP) {
            return res.json({
                errorCode: 1,
                message: "Insufficient VIP points"
            });
        }

        const realAmount = requestedVP / conversionRatio;
        const trnId = `VIP_${userId}_${Date.now()}`;

        const payload = {
            password: "abcdr1245",
            users: [
                {
                    mainUserId: parentId,
                    userId: userId,
                    key: 1,
                    txnType: 1,
                    amount: realAmount,
                    remark: "VIP Convert",
                    trnId: trnId
                }
            ]
        };

        let apiStatus = "FAILED";
        let apiResponse = "";

        try {

            const apiResp = await axios.post(
                "https://2585sd.info/pad=81/transferSpec",
                payload,
                {
                    headers: {
                        Authorization: adminToken
                    },
                    timeout: 20000
                }
            );

            apiResponse = JSON.stringify(apiResp.data);

            const status = String(
                apiResp?.data?.status ||
                apiResp?.data?.result?.[0]?.result ||
                ""
            ).toUpperCase();

            if (status === "SUCCESS") {
                apiStatus = "SUCCESS";
            }

        } catch (err) {
            apiResponse = err.message;
        }

        if (apiStatus === "SUCCESS") {

            await new sql.Request()
                .input('userId', sql.VarChar, userId)
                .input('domain', sql.VarChar, domain)
                .input('requestedVP', sql.Int, requestedVP)
                .query(`
                    UPDATE user_vip_wallet
                    SET vip_points = ISNULL(vip_points, 0) - @requestedVP,
                        updated_at = GETDATE()
                    WHERE userId = @userId
                    AND domain = @domain
                `);

        }

        const saveReq = new sql.Request();

        saveReq
            .input('userId', sql.VarChar, userId)
            .input('parentId', sql.VarChar, parentId)
            .input('userName', sql.VarChar, userName)
            .input('domain', sql.VarChar, domain)
            .input('vipPoints', sql.Int, requestedVP)
            .input('conversionRatio', sql.Decimal(18, 2), conversionRatio)
            .input('realAmount', sql.Decimal(18, 2), realAmount)
            .input('trnId', sql.VarChar, trnId)
            .input('apiStatus', sql.VarChar, apiStatus)
            .input('apiResponse', sql.NVarChar(sql.MAX), apiResponse);

        await saveReq.query(`
            INSERT INTO vip_convert_logs
            (
                userId,
                parentId,
                userName,
                domain,
                vip_points,
                conversion_ratio,
                real_amount,
                trn_id,
                api_status,
                api_response,
                created_at
            )
            VALUES
            (
                @userId,
                @parentId,
                @userName,
                @domain,
                @vipPoints,
                @conversionRatio,
                @realAmount,
                @trnId,
                @apiStatus,
                @apiResponse,
                GETDATE()
            )
        `);

        return res.json({
            errorCode: apiStatus === "SUCCESS" ? 0 : 1,
            message: apiStatus === "SUCCESS"
                ? "VIP converted successfully"
                : "Transfer failed",
            converted_vip_points: requestedVP,
            conversion_ratio: conversionRatio,
            minimum_vp: minimumVP,
            remaining_vip_points: apiStatus === "SUCCESS"
                ? availableVipPoints - requestedVP
                : availableVipPoints,
            real_amount: realAmount
        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({
            errorCode: 1,
            message: "Server error"
        });

    }

});
app.get('/api/vip/received-report', async (req, res) => {

    const { userId, domain } = req.query;

    try {

        const request = new sql.Request();

        request
            .input('userId', sql.VarChar, userId)
            .input('domain', sql.VarChar, domain);

        const result = await request.query(`
            SELECT
                ROW_NUMBER() OVER (ORDER BY created_at DESC) AS no,
                amount AS vip_points,
                'Manual' AS source,
                created_at
            FROM checkin_logs
            WHERE userId = @userId
            AND domain = @domain
            AND api_status = 'SUCCESS'
            ORDER BY created_at DESC
        `);

        return res.json({
            errorCode: 0,
            result: result.recordset
        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({
            errorCode: 1,
            message: "Server error"
        });

    }

});
app.get('/api/vip/used-report', async (req, res) => {

    const { userId, domain } = req.query;

    try {

        const request = new sql.Request();

        request
            .input('userId', sql.VarChar, userId)
            .input('domain', sql.VarChar, domain);

        const result = await request.query(`
            SELECT
                ROW_NUMBER() OVER (ORDER BY created_at DESC) AS no,
                vip_points,
                real_amount AS amount,
                created_at
            FROM vip_convert_logs
            WHERE userId = @userId
            AND domain = @domain
            AND api_status = 'SUCCESS'
            ORDER BY created_at DESC
        `);

        return res.json({
            errorCode: 0,
            result: result.recordset
        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({
            errorCode: 1,
            message: "Server error"
        });

    }

});

//dailycheckin end



// server load start
const AWS_ACCESS_KEY_VRNL = "AKIAU54IBP34VCUK3XII";
const AWS_SECRET_KEY_VRNL = "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";

const AWS_ACCESS_KEY_BETSWIZ = "AKIAXZEFH2RVS3A4BZVI";
const AWS_SECRET_KEY_BETSWIZ = "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";

const ec2_vrnl = new EC2Client({
    region: "ap-south-1",
    credentials: {
        accessKeyId: AWS_ACCESS_KEY_VRNL.trim(),
        secretAccessKey: AWS_SECRET_KEY_VRNL.trim()
    }
});

const ec2_betswiz = new EC2Client({
    region: "ap-south-1",
    credentials: {
        accessKeyId: AWS_ACCESS_KEY_BETSWIZ.trim(),
        secretAccessKey: AWS_SECRET_KEY_BETSWIZ.trim()
    }
});

const cloudwatch_vrnl = new CloudWatchClient({
    region: "ap-south-1",
    credentials: {
        accessKeyId: AWS_ACCESS_KEY_VRNL.trim(),
        secretAccessKey: AWS_SECRET_KEY_VRNL.trim()
    }
});

const cloudwatch_betswiz = new CloudWatchClient({
    region: "ap-south-1",
    credentials: {
        accessKeyId: AWS_ACCESS_KEY_BETSWIZ.trim(),
        secretAccessKey: AWS_SECRET_KEY_BETSWIZ.trim()
    }
});

const CF_TOKEN = "cfut_4uHZgW0OKUQmu7t54YA9oBNUhrj8GqAD3Al5L3Oq1e4ae958";
const CF_ACCOUNT_ID = "57e342352b055eea88c0debf4a8350cb";
const CF_POOL_ID = "05fff94911b7d4fc416256b9e7a67cd3";

const CF_TOKEN_VRNLBF = "cfut_34tSFFphZVnK8Ibc67wKoTSJ0HAivkDWjHCr9xjq90d4827e";
const CF_ACCOUNT_ID_VRNLBF = "3116e210610ee61cd9e32cdbee13aba9";
const CF_POOL_ID_VRNLBF = "42ac5d9220a62d34c36455b55e00ed01";

const CF_TOKEN_API_BETSWIZ = "cfut_jgzTjQ6ie6RNDtX9Vly4PtSC69UphwddRPbdw38j9b615136";
const CF_ACCOUNT_ID_API_BETSWIZ = "43e704043be04e19cfc624fbaafaf3aa";
const CF_POOL_ID_API_BETSWIZ = "d3c976ee4fb16bf421ee5e04df213bbc";

const CF_TOKEN_BF_BETSWIZ = "cfut_jgzTjQ6ie6RNDtX9Vly4PtSC69UphwddRPbdw38j9b615136";
const CF_ACCOUNT_ID_BF_BETSWIZ = "43e704043be04e19cfc624fbaafaf3aa";
const CF_POOL_ID_BF_BETSWIZ = "6105cfcdb750320c9e1f1edbd60f3b61";

const vrnl_api_server = {
    "api-1": {
        instanceId: "i-0f2d94446facadae6",
        ip: "13.127.63.61",
        endpointName: "API-1"
    },
    "api-2": {
        instanceId: "i-0940dbbe423957f1f",
        ip: "3.108.29.88",
        endpointName: "API-2"
    },
    "api-3": {
        instanceId: "i-044b4451e6368a949",
        ip: "13.204.164.196",
        endpointName: "API-3"
    },
};
const vrnl_bf_server = {
    "bf-serve-1": {
        ip: "194.61.31.29",
        endpointName: "bf-server-1"
    },
    "bf-serve-3": {
        ip: "80.65.208.72",
        endpointName: "bf-server-3"
    },
    "bf-serve-4": {
        ip: "194.61.31.76",
        endpointName: "bf-server-4"
    },
};
const betswiz_api_server = {
    "api-1": {
        instanceId: "i-0fae78f7f010d9ba6",
        ip: "15.207.94.90",
        endpointName: "API-1"
    },
    "api-2": {
        instanceId: "i-0cf39b2ce1fb9e5b5",
        ip: "3.111.70.27",
        endpointName: "API-2"
    },
    "api-3": {
        instanceId: "i-035e8961f9ec40df0",
        ip: "35.154.134.127",
        endpointName: "API-3"
    },
    "api-4": {
        instanceId: "i-00d1f44c348ebe4d9",
        ip: "13.202.95.68",
        endpointName: "API-4"
    },
};
const betswiz_bf_server = {
    "bf-serve-1": {
        instanceId: "i-0cb1b73d168f5963d",
        ip: "43.205.56.45",
        endpointName: "bf-server-1"
    },
    "bf-serve-2": {
        instanceId: "i-018b6d5928c64f428",
        ip: "43.205.60.179",
        endpointName: "bf-server-2"
    },
    "bf-serve-3": {
        instanceId: "i-0de92e38fc79951aa",
        ip: "13.203.162.171",
        endpointName: "bf-server-3"
    },
    "bf-serve-4": {
        instanceId: "i-0f142bd589bcabc73",
        ip: "13.200.69.123",
        endpointName: "bf-server-4"
    },
    "bf-serve-5": {
        instanceId: "i-09f6940ee7733975f",
        ip: "15.207.32.211",
        endpointName: "bf-server-5"
    },
};
async function startInstance(instanceId) {
    return await ec2_vrnl.send(new StartInstancesCommand({
        InstanceIds: [instanceId]
    }));
}
async function stopInstance(instanceId) {
    return await ec2_vrnl.send(new StopInstancesCommand({
        InstanceIds: [instanceId]
    }));
}
async function getInstanceStatevrnl(instanceId) {
    const result = await ec2_vrnl.send(new DescribeInstancesCommand({
        InstanceIds: [instanceId]
    }));

    return result.Reservations?.[0]?.Instances?.[0]?.State?.Name;
}
async function getInstanceStatebetswiz(instanceId) {
    const result = await ec2_betswiz.send(new DescribeInstancesCommand({
        InstanceIds: [instanceId]
    }));

    return result.Reservations?.[0]?.Instances?.[0]?.State?.Name;
}
async function getCpuUsage(instanceId, cloudwatchClient) {

    try {

        const endTime = new Date();
        const startTime = new Date(endTime.getTime() - 15 * 60 * 1000);

        const response = await cloudwatchClient.send(
            new GetMetricStatisticsCommand({
                Namespace: "AWS/EC2",
                MetricName: "CPUUtilization",
                Dimensions: [
                    {
                        Name: "InstanceId",
                        Value: instanceId
                    }
                ],
                StartTime: startTime,
                EndTime: endTime,
                Period: 300,
                Statistics: ["Average"]
            })
        );

        if (!response.Datapoints?.length) {
            return 0;
        }

        const latest = response.Datapoints.sort(
            (a, b) => new Date(b.Timestamp) - new Date(a.Timestamp)
        )[0];

        return Number(latest.Average.toFixed(2));

    } catch (err) {
        return 0;
    }
}
// vrnl 
async function getCloudflarePool() {
    const url = `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID}/load_balancers/pools/${CF_POOL_ID}`;

    console.log("CF URL:", url);

    const res = await axios.get(url, {
        headers: {
            Authorization: `Bearer ${CF_TOKEN}`,
            "Content-Type": "application/json"
        }
    });

    return res.data.result;
}
async function getCloudflarePool_bf() {
    const url = `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID_VRNLBF}/load_balancers/pools/${CF_POOL_ID_VRNLBF}`;

    console.log("CF URL:", url);

    const res = await axios.get(url, {
        headers: {
            Authorization: `Bearer ${CF_TOKEN_VRNLBF}`,
            "Content-Type": "application/json"
        }
    });

    return res.data.result;
}

async function getCloudflarePoolbetswiz() {
    const url = `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID_API_BETSWIZ}/load_balancers/pools/${CF_POOL_ID_API_BETSWIZ}`;

    console.log("CF URL:", url);

    const res = await axios.get(url, {
        headers: {
            Authorization: `Bearer ${CF_TOKEN_API_BETSWIZ}`,
            "Content-Type": "application/json"
        }
    });

    return res.data.result;
}
async function getCloudflarePoolbetswiz_bf() {
    const url = `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID_API_BETSWIZ}/load_balancers/pools/${CF_POOL_ID_BF_BETSWIZ}`;

    console.log("CF URL:", url);

    const res = await axios.get(url, {
        headers: {
            Authorization: `Bearer ${CF_TOKEN_BF_BETSWIZ}`,
            "Content-Type": "application/json"
        }
    });

    return res.data.result;
}
async function getContaboUsage() {
    try {
        const cpu = await si.currentLoad();
        const mem = await si.mem();

        return {
            cpuUsage: Number(cpu.currentLoad.toFixed(2)),
            ramUsage: Number(((mem.used / mem.total) * 100).toFixed(2)),
            totalRamGB: Number((mem.total / 1024 / 1024 / 1024).toFixed(2)),
            usedRamGB: Number((mem.used / 1024 / 1024 / 1024).toFixed(2))
        };
    } catch (err) {
        console.log("Usage error:", err.message);

        return {
            cpuUsage: 0,
            ramUsage: 0,
            totalRamGB: 0,
            usedRamGB: 0
        };
    }
}
app.get("/server-health", async (req, res) => {
    const usage = await getContaboUsage();

    return res.json({
        errorCode: 0,
        ...usage
    });
});
// 1. Sirf AWS instance start
app.post("/aws/start-instance", async (req, res) => {
    try {
        const { server } = req.body;

        const item = vrnl_api_server[server];

        if (!item) {
            return res.status(404).json({
                errorCode: 1,
                message: "Server not found"
            });
        }

        await startInstance(item.instanceId);

        return res.json({
            errorCode: 0,
            message: "Instance start command sent",
            server
        });

    } catch (err) {
        return res.status(500).json({
            errorCode: 1,
            message: err.message
        });
    }
});
// 2. Sirf AWS instance stop
app.post("/aws/stop-instance", async (req, res) => {
    try {

        const { server } = req.body;

        const item = vrnl_api_server[server];

        if (!item) {
            return res.status(404).json({
                errorCode: 1,
                message: "Server not found"
            });
        }

        await stopInstance(item.instanceId);

        return res.json({
            errorCode: 0,
            message: "Instance stop command sent",
            server
        });

    } catch (err) {
        return res.status(500).json({
            errorCode: 1,
            message: err.message
        });
    }
});

// 3. Instance status check vrnl
app.get("/aws/all-status-vrnlapi", async (req, res) => {
    try {

        const result = [];

        const pool = await getCloudflarePool();

        for (const key of Object.keys(vrnl_api_server)) {

            const item = vrnl_api_server[key];

            const state = await getInstanceStatevrnl(item.instanceId);

            const origin = pool.origins.find(
                o => o.name === item.endpointName
            );

            const load = origin
                ? Number(((origin.weight || 0) * 100).toFixed(2))
                : 0;

            const endpointHealth = origin
                ? (origin.healthy === true ? "Healthy" : "Unhealthy")
                : "Unknown";

            const cpuUsage = await getCpuUsage(
                item.instanceId,
                cloudwatch_vrnl
            );

            result.push({
                server: key,
                endpointName: item.endpointName,
                ip: item.ip,
                instanceId: item.instanceId,
                load, // <-- extra field
                state,
                endpointHealth,
                cpuUsage
            });
        }

        return res.json({
            errorCode: 0,
            servers: result
        });

    } catch (err) {

        return res.status(500).json({
            errorCode: 1,
            message: err.message
        });

    }
});
app.get("/aws/all-status-vrnlbf", async (req, res) => {
    try {

        const result = [];

        const pool = await getCloudflarePool_bf();

        for (const key of Object.keys(vrnl_bf_server)) {

            const item = vrnl_bf_server[key];

            const state = await getInstanceStatevrnl(item.instanceId);

            const origin = pool.origins.find(
                o => o.name === item.endpointName
            );

            const load = origin
                ? Number(((origin.weight || 0) * 100).toFixed(2))
                : 0;

            const endpointHealth = origin
                ? (origin.healthy === true ? "Healthy" : "Unhealthy")
                : "Unknown";

            const cpuUsage = await getContaboUsage(item.ip);
            console.log(cpuUsage);
            result.push({
                server: key,
                endpointName: item.endpointName,
                ip: item.ip,
                instanceId: item.instanceId,
                load, // <-- extra field
                state,
                endpointHealth,
                cpuUsage: cpuUsage.cpuUsage,
            });
        }

        return res.json({
            errorCode: 0,
            servers: result
        });

    } catch (err) {

        return res.status(500).json({
            errorCode: 1,
            message: err.message
        });

    }
});


// 3. Instance status check betswiz
app.get("/aws/all-status-betswiz", async (req, res) => {
    try {

        const result = [];

        const pool = await getCloudflarePoolbetswiz();

        for (const key of Object.keys(betswiz_api_server)) {

            const item = betswiz_api_server[key];

            const state = await getInstanceStatebetswiz(item.instanceId);

            const origin = pool.origins.find(
                o => o.name === item.endpointName
            );

            const load = origin
                ? Number(((origin.weight || 0) * 100).toFixed(2))
                : 0;

            const endpointHealth = origin
                ? (origin.healthy === true ? "Healthy" : "Unhealthy")
                : "Unknown";
            const cpuUsage = await getCpuUsage(
                item.instanceId,
                cloudwatch_betswiz
            );
            result.push({
                server: key,
                endpointName: item.endpointName,
                ip: item.ip,
                instanceId: item.instanceId,
                load, // <-- extra field
                state,
                endpointHealth,
                cpuUsage
            });
        }

        return res.json({
            errorCode: 0,
            servers: result
        });

    } catch (err) {

        return res.status(500).json({
            errorCode: 1,
            message: err.message
        });

    }
});
app.get("/aws/all-status-betswiz-bf", async (req, res) => {
    try {

        const result = [];

        const pool = await getCloudflarePoolbetswiz_bf();

        for (const key of Object.keys(betswiz_bf_server)) {

            const item = betswiz_bf_server[key];

            const state = await getInstanceStatebetswiz(item.instanceId);

            const origin = pool.origins.find(
                o => o.name === item.endpointName
            );

            const load = origin
                ? Number(((origin.weight || 0) * 100).toFixed(2))
                : 0;

            const endpointHealth = origin
                ? (origin.healthy === true ? "Healthy" : "Unhealthy")
                : "Unknown";

            const cpuUsage = await getCpuUsage(
                item.instanceId,
                cloudwatch_betswiz
            );
            result.push({
                server: key,
                endpointName: item.endpointName,
                ip: item.ip,
                instanceId: item.instanceId,
                load, // <-- extra field
                state,
                endpointHealth,
                cpuUsage
            });
        }

        return res.json({
            errorCode: 0,
            servers: result
        });

    } catch (err) {

        return res.status(500).json({
            errorCode: 1,
            message: err.message
        });

    }
});
// 4. Sirf Cloudflare load set/update
app.post("/cf/set-bulk-load-vrnlapi", async (req, res) => {
    try {
        const { loads } = req.body;

        if (!Array.isArray(loads) || loads.length === 0) {
            return res.status(400).json({
                errorCode: 1,
                message: "loads array required"
            });
        }

        const total = loads.reduce((sum, item) => {
            return sum + Number(item.percentage || 0);
        }, 0);

        if (total > 100) {
            return res.status(400).json({
                errorCode: 1,
                message: "Total load cannot be more than 100%"
            });
        }

        const pool = await getCloudflarePool();

        const origins = pool.origins.map(origin => {
            const matchedLoad = loads.find(item => {
                const serverConfig = vrnl_api_server[item.server];
                return serverConfig && serverConfig.endpointName === origin.name;
            });

            if (!matchedLoad) {
                return origin;
            }

            const percentage = Number(matchedLoad.percentage);
            const weight = percentage / 100;

            return {
                ...origin,
                enabled: percentage > 0,
                weight: percentage > 0 ? weight : 0
            };
        });

        const payload = {
            ...pool,
            origins
        };

        const cfRes = await axios.put(
            `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID}/load_balancers/pools/${CF_POOL_ID}`,
            payload,
            {
                headers: {
                    Authorization: `Bearer ${CF_TOKEN}`,
                    "Content-Type": "application/json"
                }
            }
        );

        return res.json({
            errorCode: 0,
            message: "Bulk load updated successfully",
            total,
            loads,
            cloudflare: cfRes.data
        });

    } catch (err) {
        return res.status(500).json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.post("/cf/set-bulk-load-vrnlbf", async (req, res) => {
    try {
        const { loads } = req.body;

        if (!Array.isArray(loads) || loads.length === 0) {
            return res.status(400).json({
                errorCode: 1,
                message: "loads array required"
            });
        }

        const total = loads.reduce((sum, item) => {
            return sum + Number(item.percentage || 0);
        }, 0);

        if (total > 100) {
            return res.status(400).json({
                errorCode: 1,
                message: "Total load cannot be more than 100%"
            });
        }

        const pool = await getCloudflarePool_bf();

        const origins = pool.origins.map(origin => {
            const matchedLoad = loads.find(item => {
                const serverConfig = vrnl_bf_server[item.server];
                return serverConfig && serverConfig.endpointName === origin.name;
            });

            if (!matchedLoad) {
                return origin;
            }

            const percentage = Number(matchedLoad.percentage);
            const weight = percentage / 100;

            return {
                ...origin,
                enabled: percentage > 0,
                weight: percentage > 0 ? weight : 0
            };
        });

        const payload = {
            ...pool,
            origins
        };

        const cfRes = await axios.put(
            `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID_VRNLBF}/load_balancers/pools/${CF_POOL_ID_VRNLBF}`,
            payload,
            {
                headers: {
                    Authorization: `Bearer ${CF_TOKEN_VRNLBF}`,
                    "Content-Type": "application/json"
                }
            }
        );

        return res.json({
            errorCode: 0,
            message: "Bulk load updated successfully",
            total,
            loads,
            cloudflare: cfRes.data
        });

    } catch (err) {
        return res.status(500).json({
            errorCode: 1,
            message: err.message
        });
    }
});


app.post("/cf/set-bulk-load-betswizapi", async (req, res) => {
    try {
        const { loads } = req.body;

        if (!Array.isArray(loads) || loads.length === 0) {
            return res.status(400).json({
                errorCode: 1,
                message: "loads array required"
            });
        }

        const total = loads.reduce((sum, item) => {
            return sum + Number(item.percentage || 0);
        }, 0);

        if (total > 100) {
            return res.status(400).json({
                errorCode: 1,
                message: "Total load cannot be more than 100%"
            });
        }

        const pool = await getCloudflarePoolbetswiz();

        const origins = pool.origins.map(origin => {
            const matchedLoad = loads.find(item => {
                const serverConfig = betswiz_api_server[item.server];
                return serverConfig && serverConfig.endpointName === origin.name;
            });

            if (!matchedLoad) {
                return origin;
            }

            const percentage = Number(matchedLoad.percentage);
            const weight = percentage / 100;

            return {
                ...origin,
                enabled: percentage > 0,
                weight: percentage > 0 ? weight : 0
            };
        });

        const payload = {
            ...pool,
            origins
        };

        const cfRes = await axios.put(
            `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID_API_BETSWIZ}/load_balancers/pools/${CF_POOL_ID_API_BETSWIZ}`,
            payload,
            {
                headers: {
                    Authorization: `Bearer ${CF_TOKEN_APICF_TOKEN_API_BETSWIZ_BETSWIZ}`,
                    "Content-Type": "application/json"
                }
            }
        );


        return res.json({
            errorCode: 0,
            message: "Bulk load updated successfully",
            total,
            loads,
            cloudflare: cfRes.data
        });

    } catch (err) {
        return res.status(500).json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.post("/cf/set-bulk-load-betswizbf", async (req, res) => {
    try {
        const { loads } = req.body;

        if (!Array.isArray(loads) || loads.length === 0) {
            return res.status(400).json({
                errorCode: 1,
                message: "loads array required"
            });
        }

        const total = loads.reduce((sum, item) => {
            return sum + Number(item.percentage || 0);
        }, 0);

        if (total > 100) {
            return res.status(400).json({
                errorCode: 1,
                message: "Total load cannot be more than 100%"
            });
        }

        const pool = await getCloudflarePoolbetswiz_bf();

        const origins = pool.origins.map(origin => {
            const matchedLoad = loads.find(item => {
                const serverConfig = betswiz_bf_server[item.server];
                return serverConfig && serverConfig.endpointName === origin.name;
            });

            if (!matchedLoad) {
                return origin;
            }

            const percentage = Number(matchedLoad.percentage);
            const weight = percentage / 100;

            return {
                ...origin,
                enabled: percentage > 0,
                weight: percentage > 0 ? weight : 0
            };
        });

        const payload = {
            ...pool,
            origins
        };

        const cfRes = await axios.put(
            `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID_BF_BETSWIZ}/load_balancers/pools/${CF_POOL_ID_BF_BETSWIZ}`,
            payload,
            {
                headers: {
                    Authorization: `Bearer ${CF_TOKEN_BF_BETSWIZ}`,
                    "Content-Type": "application/json"
                }
            }
        );

        return res.json({
            errorCode: 0,
            message: "Bulk load updated successfully",
            total,
            loads,
            cloudflare: cfRes.data
        });

    } catch (err) {
        return res.status(500).json({
            errorCode: 1,
            message: err.message
        });
    }
});
// server load end





// quiz start -----------------
app.post("/createQuiz", upload.single("banner_image"), async (req, res) => {
    try {
        const {
            title,
            match_name,
            start_time,
            end_time,
            prize_text,
            rules
        } = req.body;

        const banner_image = req.file ? `/uploads/${req.file.filename}` : "";

        const request = new sql.Request();

        request.input("title", sql.NVarChar(sql.MAX), title);
        request.input("match_name", sql.NVarChar(sql.MAX), match_name);
        request.input("start_time", sql.DateTime, start_time);
        request.input("end_time", sql.DateTime, end_time);
        request.input("prize_text", sql.NVarChar(sql.MAX), prize_text);
        request.input("rules", sql.NVarChar(sql.MAX), rules);
        request.input("banner_image", sql.NVarChar(sql.MAX), banner_image);

        const duplicate = await request.query(`
            SELECT id
            FROM quiz_master
            WHERE title=@title
            AND match_name=@match_name
            AND start_time=@start_time
            AND end_time=@end_time
        `);

        if (duplicate.recordset.length > 0) {
            return res.json({
                errorCode: 1,
                message: "This quiz already exists"
            });
        }

        const result = await request.query(`
            INSERT INTO quiz_master
            (
                title,
                match_name,
                banner_image,
                start_time,
                end_time,
                prize_text,
                rules
            )
            OUTPUT INSERTED.id
            VALUES
            (
                @title,
                @match_name,
                @banner_image,
                @start_time,
                @end_time,
                @prize_text,
                @rules
            )
        `);

        res.json({
            errorCode: 0,
            message: "Quiz created successfully",
            quiz_id: result.recordset[0].id,
            banner_image
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.put("/updateQuiz", upload.single("banner_image"), async (req, res) => {
    try {
        const {
            quiz_id,
            title,
            match_name,
            start_time,
            end_time,
            prize_text,
            rules
        } = req.body;

        let is_active = req.body.is_active;

        if (!quiz_id || quiz_id === "undefined") {
            return res.json({
                errorCode: 1,
                message: "quiz_id is required"
            });
        }

        is_active = is_active === undefined || is_active === "undefined" || is_active === ""
            ? 1
            : Number(is_active);

        const checkRequest = new sql.Request();
        checkRequest.input("quiz_id", sql.Int, Number(quiz_id));

        const checkQuiz = await checkRequest.query(`
            SELECT id, banner_image
            FROM quiz_master
            WHERE id=@quiz_id
        `);

        if (!checkQuiz.recordset.length) {
            return res.json({
                errorCode: 1,
                message: "Quiz not found"
            });
        }

        const oldBanner = checkQuiz.recordset[0].banner_image;

        const finalBanner = req.file
            ? `/uploads/${req.file.filename}`
            : oldBanner;

        const updateRequest = new sql.Request();

        updateRequest.input("quiz_id", sql.Int, Number(quiz_id));
        updateRequest.input("title", sql.NVarChar(sql.MAX), title);
        updateRequest.input("match_name", sql.NVarChar(sql.MAX), match_name);
        updateRequest.input("banner_image", sql.NVarChar(sql.MAX), finalBanner);
        updateRequest.input("start_time", sql.DateTime, start_time);
        updateRequest.input("end_time", sql.DateTime, end_time);
        updateRequest.input("prize_text", sql.NVarChar(sql.MAX), prize_text);
        updateRequest.input("rules", sql.NVarChar(sql.MAX), rules);
        updateRequest.input("is_active", sql.Int, is_active);

        await updateRequest.query(`
            UPDATE quiz_master
            SET
                title=@title,
                match_name=@match_name,
                banner_image=@banner_image,
                start_time=@start_time,
                end_time=@end_time,
                prize_text=@prize_text,
                rules=@rules,
                is_active=@is_active
            WHERE id=@quiz_id
        `);

        res.json({
            errorCode: 0,
            message: "Quiz updated successfully",
            banner_image: finalBanner
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.post("/addQuizQuestion", async (req, res) => {
    try {
        const { quiz_id, question, options } = req.body;

        if (!quiz_id || !question || !options || options.length < 2) {
            return res.json({
                errorCode: 1,
                message: "quiz_id, question and minimum 2 options required"
            });
        }

        const quizId = Number(quiz_id);

        const duplicateReq = new sql.Request();
        duplicateReq.input("quiz_id", sql.Int, quizId);
        duplicateReq.input("question", sql.NVarChar(sql.MAX), question);

        const duplicateQuestion = await duplicateReq.query(`
            SELECT id
            FROM quiz_questions
            WHERE quiz_id=@quiz_id
            AND question_text=@question
        `);

        if (duplicateQuestion.recordset.length > 0) {
            return res.json({
                errorCode: 1,
                message: "This question already exists in this quiz"
            });
        }

        const questionReq = new sql.Request();
        questionReq.input("quiz_id", sql.Int, quizId);
        questionReq.input("question", sql.NVarChar(sql.MAX), question);
        questionReq.input("question_type", sql.NVarChar(50), "single");

        const result = await questionReq.query(`
            INSERT INTO quiz_questions
            (
                quiz_id,
                question_text,
                question_type
            )
            OUTPUT INSERTED.id
            VALUES
            (
                @quiz_id,
                @question,
                @question_type
            )
        `);

        const questionId = result.recordset[0].id;

        for (const item of options) {
            const optionReq = new sql.Request();
            optionReq.input("question_id", sql.Int, questionId);
            optionReq.input("option_text", sql.NVarChar(sql.MAX), item.text);
            optionReq.input("is_correct", sql.Bit, item.correct ? 1 : 0);

            await optionReq.query(`
                INSERT INTO quiz_options
                (
                    question_id,
                    option_text,
                    is_correct
                )
                VALUES
                (
                    @question_id,
                    @option_text,
                    @is_correct
                )
            `);
        }

        res.json({
            errorCode: 0,
            message: "Question added successfully",
            question_id: questionId
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.put("/updateQuizQuestion", async (req, res) => {
    try {
        const { question_id, question, options } = req.body;

        if (!question_id) {
            return res.json({
                errorCode: 1,
                message: "question_id is required"
            });
        }

        const questionId = Number(question_id);

        const updateReq = new sql.Request();
        updateReq.input("question_id", sql.Int, questionId);
        updateReq.input("question", sql.NVarChar(sql.MAX), question);

        await updateReq.query(`
            UPDATE quiz_questions
            SET question_text=@question
            WHERE id=@question_id
        `);

        const deleteReq = new sql.Request();
        deleteReq.input("question_id", sql.Int, questionId);

        await deleteReq.query(`
            DELETE FROM quiz_options
            WHERE question_id=@question_id
        `);

        for (const item of options) {
            const optionReq = new sql.Request();
            optionReq.input("question_id", sql.Int, questionId);
            optionReq.input("option_text", sql.NVarChar(sql.MAX), item.text);
            optionReq.input("is_correct", sql.Bit, item.correct ? 1 : 0);

            await optionReq.query(`
                INSERT INTO quiz_options
                (
                    question_id,
                    option_text,
                    is_correct
                )
                VALUES
                (
                    @question_id,
                    @option_text,
                    @is_correct
                )
            `);
        }

        res.json({
            errorCode: 0,
            message: "Question updated successfully"
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.get("/getQuizList", async (req, res) => {
    try {

        await sql.query(`
            UPDATE quiz_master
            SET is_active = 0
            WHERE is_active = 1
            AND GETDATE() > end_time
        `);

        const result = await sql.query(`
            SELECT *,
            CASE
                WHEN is_active = 1
                AND GETDATE() BETWEEN start_time AND end_time
                THEN 1
                ELSE 0
            END AS is_current
            FROM quiz_master
            ORDER BY id DESC
        `);

        res.json({
            errorCode: 0,
            data: result.recordset
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.post("/disableQuiz", async (req, res) => {
    try {

        const { quiz_id } = req.body;

        await sql.query(`
            UPDATE quiz_master
            SET is_active = 0
            WHERE id = ${quiz_id}
        `);

        res.json({
            errorCode: 0,
            message: "Quiz disabled successfully"
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.get("/getQuizDetails", async (req, res) => {
    try {
        const { quiz_id } = req.query;

        if (!quiz_id) {
            return res.json({
                errorCode: 1,
                message: "quiz_id is required"
            });
        }

        const quiz = await sql.query(`
            SELECT *
            FROM quiz_master
            WHERE id=${quiz_id}
        `);

        if (!quiz.recordset.length) {
            return res.json({
                errorCode: 1,
                message: "Quiz not found"
            });
        }

        const questions = await sql.query(`
            SELECT
                q.id AS question_id,
                q.question_text,
                q.question_type,
                o.id AS option_id,
                o.option_text,
                o.is_correct
            FROM quiz_questions q
            LEFT JOIN quiz_options o
                ON q.id = o.question_id
            WHERE q.quiz_id=${quiz_id}
            ORDER BY q.id, o.id
        `);

        res.json({
            errorCode: 0,
            quiz: quiz.recordset[0],
            questions: questions.recordset
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.get("/getActiveQuiz", async (req, res) => {
    try {

        // End time nikal gaya to auto disable
        await sql.query(`
            UPDATE quiz_master
            SET is_active = 0
            WHERE is_active = 1
            AND GETDATE() > end_time
        `);

        const quiz = await sql.query(`
            SELECT TOP 1 qm.*
            FROM quiz_master qm
            WHERE qm.is_active = 1
            AND GETDATE() BETWEEN qm.start_time AND qm.end_time
            AND EXISTS (
                SELECT 1
                FROM quiz_questions qq
                WHERE qq.quiz_id = qm.id
            )
            ORDER BY qm.id DESC
        `);

        if (!quiz.recordset.length) {
            return res.json({
                errorCode: 1,
                message: "No active quiz found"
            });
        }

        const quizId = quiz.recordset[0].id;

        const result = await sql.query(`
            SELECT
                q.id AS question_id,
                q.question_text,
                o.id AS option_id,
                o.option_text
            FROM quiz_questions q
            INNER JOIN quiz_options o
                ON q.id = o.question_id
            WHERE q.quiz_id = ${quizId}
            ORDER BY q.id, o.id
        `);

        const questionMap = {};

        result.recordset.forEach(row => {
            if (!questionMap[row.question_id]) {
                questionMap[row.question_id] = {
                    question_id: row.question_id,
                    question_text: row.question_text,
                    options: []
                };
            }

            questionMap[row.question_id].options.push({
                option_id: row.option_id,
                option_text: row.option_text
            });
        });

        res.json({
            errorCode: 0,
            quiz: quiz.recordset[0],
            questions: Object.values(questionMap)
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.delete("/deleteQuizQuestion", async (req, res) => {
    try {

        const { question_id } = req.query;

        await sql.query(`
            DELETE FROM quiz_options
            WHERE question_id=${question_id}
        `);

        await sql.query(`
            DELETE FROM quiz_questions
            WHERE id=${question_id}
        `);

        res.json({
            errorCode: 0,
            message: "Question deleted successfully"
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.post("/submitQuiz", async (req, res) => {
    try {
        const {
            quiz_id,
            user_id,
            user_name,
            phone,
            email,
            answers
        } = req.body;

        if (!quiz_id || !user_id || !user_name || !phone || !answers || !answers.length) {
            return res.json({
                errorCode: 1,
                message: "Required fields missing"
            });
        }

        const quizId = Number(quiz_id);

        const quizReq = new sql.Request();
        quizReq.input("quiz_id", sql.Int, quizId);

        const quizCheck = await quizReq.query(`
            SELECT *
            FROM quiz_master
            WHERE id = @quiz_id
            AND is_active = 1
            AND GETDATE() BETWEEN start_time AND end_time
        `);

        if (!quizCheck.recordset.length) {
            return res.json({
                errorCode: 1,
                message: "Quiz expired or not active"
            });
        }

        const alreadyReq = new sql.Request();

        alreadyReq.input("quiz_id", sql.Int, quizId);
        alreadyReq.input("user_id", sql.NVarChar(100), user_id);
        alreadyReq.input("user_name", sql.NVarChar(sql.MAX), user_name);
        alreadyReq.input("phone", sql.NVarChar(50), phone);
        alreadyReq.input("email", sql.NVarChar(255), email || "");

        const already = await alreadyReq.query(`
            SELECT id
            FROM quiz_submissions
            WHERE quiz_id = @quiz_id
            AND (
                user_id = @user_id
                OR user_name = @user_name
                OR phone = @phone
                OR email = @email
            )
        `);

        if (already.recordset.length) {
            return res.json({
                errorCode: 1,
                message: "This user ID, username, phone or email has already participated"
            });
        }

        let totalCorrect = 0;

        const submitReq = new sql.Request();

        submitReq.input("quiz_id", sql.Int, quizId);
        submitReq.input("user_id", sql.NVarChar(100), user_id);
        submitReq.input("user_name", sql.NVarChar(sql.MAX), user_name);
        submitReq.input("phone", sql.NVarChar(50), phone);
        submitReq.input("email", sql.NVarChar(255), email || "");

        const submit = await submitReq.query(`
            INSERT INTO quiz_submissions
            (
                quiz_id,
                user_id,
                user_name,
                phone,
                email
            )
            OUTPUT INSERTED.id
            VALUES
            (
                @quiz_id,
                @user_id,
                @user_name,
                @phone,
                @email
            )
        `);

        const submissionId = submit.recordset[0].id;

        for (const item of answers) {
            const checkReq = new sql.Request();

            checkReq.input("option_id", sql.Int, Number(item.option_id));
            checkReq.input("question_id", sql.Int, Number(item.question_id));

            const check = await checkReq.query(`
                SELECT is_correct
                FROM quiz_options
                WHERE id = @option_id
                AND question_id = @question_id
            `);

            const isCorrect =
                check.recordset.length &&
                check.recordset[0].is_correct;

            if (isCorrect) {
                totalCorrect++;
            }

            const answerReq = new sql.Request();

            answerReq.input("submission_id", sql.Int, submissionId);
            answerReq.input("question_id", sql.Int, Number(item.question_id));
            answerReq.input("option_id", sql.Int, Number(item.option_id));
            answerReq.input("is_correct", sql.Bit, isCorrect ? 1 : 0);

            await answerReq.query(`
                INSERT INTO quiz_answers
                (
                    submission_id,
                    question_id,
                    option_id,
                    is_correct
                )
                VALUES
                (
                    @submission_id,
                    @question_id,
                    @option_id,
                    @is_correct
                )
            `);
        }

        const totalReq = new sql.Request();
        totalReq.input("quiz_id", sql.Int, quizId);

        const totalQuestions = await totalReq.query(`
            SELECT COUNT(*) AS total
            FROM quiz_questions
            WHERE quiz_id = @quiz_id
        `);

        const isWinner =
            totalCorrect == totalQuestions.recordset[0].total ? 1 : 0;

        const updateReq = new sql.Request();

        updateReq.input("total_correct", sql.Int, totalCorrect);
        updateReq.input("is_winner", sql.Bit, isWinner);
        updateReq.input("submission_id", sql.Int, submissionId);

        await updateReq.query(`
            UPDATE quiz_submissions
            SET
                total_correct = @total_correct,
                is_winner = @is_winner
            WHERE id = @submission_id
        `);

        res.json({
            errorCode: 0,
            message: "Quiz submitted successfully",
            isWinner: isWinner,
            totalCorrect: totalCorrect
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.get("/getAllQuizReport", async (req, res) => {
    try {
        const result = await sql.query(`
            SELECT
                qs.*,
                qm.title,
                qm.match_name
            FROM quiz_submissions qs
            LEFT JOIN quiz_master qm ON qs.quiz_id = qm.id
            ORDER BY qs.id DESC
        `);

        res.json({
            errorCode: 0,
            data: result.recordset
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
})
app.get("/getQuizReport", async (req, res) => {
    try {

        const { submission_id } = req.query;

        if (!submission_id) {
            return res.json({
                errorCode: 1,
                message: "submission_id is required"
            });
        }

        const result = await sql.query(`
            SELECT
                qs.id AS submission_id,
                qs.user_id,
                qs.user_name,
                qs.phone,
                qs.email,
                qq.question_text,
                qo.option_text AS selected_answer,
                qa.is_correct
            FROM quiz_answers qa
            INNER JOIN quiz_submissions qs
                ON qa.submission_id = qs.id
            INNER JOIN quiz_questions qq
                ON qa.question_id = qq.id
            INNER JOIN quiz_options qo
                ON qa.option_id = qo.id
            WHERE qa.submission_id = ${Number(submission_id)}
            ORDER BY qq.id
        `);

        res.json({
            errorCode: 0,
            data: result.recordset
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.get("/getQuizWinners", async (req, res) => {
    try {
        const { quiz_id } = req.query;

        const result = await sql.query(`
            SELECT *
            FROM quiz_submissions
            WHERE quiz_id=${quiz_id}
            AND is_winner=1
            ORDER BY id DESC
        `);

        res.json({
            errorCode: 0,
            data: result.recordset
        });

    } catch (err) {
        res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
// quiz end -------------------



// whitelist start start----------------------
app.post("/add-domain", (req, res) => {
    try {
        const { arrayName, domain } = req.body;

        const filePath = "C:\\enterprise\\Tracker_All\\ssl_api_server\\whitelist_domains\\domains.js";

        let fileContent = fs.readFileSync(filePath, "utf8");

        const regex = new RegExp(
            `(let|var)\\s+${arrayName}\\s*=\\s*\\[([\\s\\S]*?)\\]`,
            "m"
        );

        const match = fileContent.match(regex);

        if (!match) {
            return res.json({
                errorCode: 1,
                message: "Array not found"
            });
        }

        const arrayContent = match[2];

        if (arrayContent.includes(`"${domain}"`)) {
            return res.json({
                errorCode: 1,
                message: "Domain already exists"
            });
        }

        const updatedArray = `${arrayContent}
    "${domain}",`;

        const updatedBlock = match[0].replace(
            arrayContent,
            updatedArray
        );

        fileContent = fileContent.replace(match[0], updatedBlock);

        fs.writeFileSync(filePath, fileContent, "utf8");

        return res.json({
            errorCode: 0,
            message: "Domain added successfully"
        });

    } catch (err) {
        return res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.get("/get-domains", (req, res) => {
    try {

        const filePath = "C:\\enterprise\\Tracker_All\\ssl_api_server\\whitelist_domains\\domains.js";

        // Cache clear karo taki latest data mile
        delete require.cache[require.resolve(filePath)];

        const domains = require(filePath);

        return res.json({
            errorCode: 0,
            data: {
                hostNames: domains.hostNames || [],
                hostNames_banner: domains.hostNames_banner || [],
                hostNames_removeBanner: domains.hostNames_removeBanner || [],
                hostNames_velkibanner: domains.hostNames_velkibanner || [],
                fancySourceAllow: domains.fancySourceAllow || [],
                removeTvVRNL: domains.removeTvVRNL || [],
                mainScore: domains.mainScore || [],
                velkiexchbanner: domains.velkiexchbanner || []
            }
        });

    } catch (error) {
        return res.json({
            errorCode: 1,
            message: error.message
        });
    }
});
function updateArrayInFile(arrayName, updater) {
    const domainFilePath =
        "C:\\enterprise\\Tracker_All\\ssl_api_server\\whitelist_domains\\domains.js";
    let fileContent = fs.readFileSync(domainFilePath, "utf8");

    const regex = new RegExp(
        `(let|var|const)\\s+${arrayName}\\s*=\\s*\\[([\\s\\S]*?)\\]`,
        "m"
    );

    const match = fileContent.match(regex);

    if (!match) {
        throw new Error("Array not found");
    }

    const arrayContent = match[2];

    let domains = arrayContent
        .split(",")
        .map(x => x.replace(/["'\n\r]/g, "").trim())
        .filter(Boolean);

    domains = updater(domains);

    const newArrayContent =
        domains.length > 0
            ? "\n    " + domains.map(d => `"${d}"`).join(",\n    ") + ",\n"
            : "\n";

    const newBlock = match[0].replace(arrayContent, newArrayContent);

    fileContent = fileContent.replace(match[0], newBlock);

    fs.writeFileSync(domainFilePath, fileContent, "utf8");
}
app.delete("/delete-domain", (req, res) => {
    try {
        const { arrayName, domain } = req.body;

        if (!arrayName || !domain) {
            return res.json({
                errorCode: 1,
                message: "arrayName and domain required"
            });
        }

        let found = false;

        updateArrayInFile(arrayName, (domains) => {

            const filteredDomains = domains.filter(d => {
                const match = d.toLowerCase() === domain.toLowerCase();

                if (match) {
                    found = true;
                }

                return !match;
            });

            return filteredDomains;
        });

        if (!found) {
            return res.json({
                errorCode: 1,
                message: "Domain not found"
            });
        }

        return res.json({
            errorCode: 0,
            message: "Domain deleted successfully"
        });

    } catch (error) {
        return res.json({
            errorCode: 1,
            message: error.message
        });
    }
});
app.post("/add-domain-streaming", (req, res) => {
    try {
        const { arrayName, domain } = req.body;

        const filePath = "C:\\enterprise\\Tracker_All\\ssl_api_server\\index35.js";

        let fileContent = fs.readFileSync(filePath, "utf8");

        const regex = new RegExp(
            `(let|var)\\s+${arrayName}\\s*=\\s*\\[([\\s\\S]*?)\\]`,
            "m"
        );

        const match = fileContent.match(regex);

        if (!match) {
            return res.json({
                errorCode: 1,
                message: "Array not found"
            });
        }

        const arrayContent = match[2];

        if (arrayContent.includes(`"${domain}"`)) {
            return res.json({
                errorCode: 1,
                message: "Domain already exists"
            });
        }

        const updatedArray = `${arrayContent}
    "${domain}",`;

        const updatedBlock = match[0].replace(
            arrayContent,
            updatedArray
        );

        fileContent = fileContent.replace(match[0], updatedBlock);

        fs.writeFileSync(filePath, fileContent, "utf8");

        return res.json({
            errorCode: 0,
            message: "Domain added successfully"
        });

    } catch (err) {
        return res.json({
            errorCode: 1,
            message: err.message
        });
    }
});
app.get("/get-domains-streaming", (req, res) => {
    try {

        const filePath = "C:\\enterprise\\Tracker_All\\ssl_api_server\\index35.js";

        // Cache clear karo taki latest data mile
        delete require.cache[require.resolve(filePath)];

        const domains = require(filePath);

        return res.json({
            errorCode: 0,
            data: {
                hostNames: domains.hostNames || [],
                hostNames2: domains.hostNames2 || [],
                hostNames3: domains.hostNames3 || [],
                isStativDomain: domains.isStativDomain || []
            }
        });

    } catch (error) {
        return res.json({
            errorCode: 1,
            message: error.message
        });
    }
});
function updateArrayInFileStream(arrayName, updater) {
    const streamingFilePath =
        "C:\\enterprise\\Tracker_All\\ssl_api_server\\index35.js";
    let fileContent = fs.readFileSync(streamingFilePath, "utf8");

    const regex = new RegExp(
        `(let|var|const)\\s+${arrayName}\\s*=\\s*\\[([\\s\\S]*?)\\]`,
        "m"
    );

    const match = fileContent.match(regex);

    if (!match) {
        throw new Error("Array not found");
    }

    const arrayContent = match[2];

    let domains = arrayContent
        .split(",")
        .map(x => x.replace(/["'\n\r]/g, "").trim())
        .filter(Boolean);

    domains = updater(domains);

    const newArrayContent =
        domains.length > 0
            ? "\n    " + domains.map(d => `"${d}"`).join(",\n    ") + ",\n"
            : "\n";

    const newBlock = match[0].replace(arrayContent, newArrayContent);

    fileContent = fileContent.replace(match[0], newBlock);

    fs.writeFileSync(streamingFilePath, fileContent, "utf8");
}
app.delete("/delete-domain-streaming", (req, res) => {
    try {
        const { arrayName, domain } = req.body;

        if (!arrayName || !domain) {
            return res.json({
                errorCode: 1,
                message: "arrayName and domain required"
            });
        }

        let found = false;

        updateArrayInFileStream(arrayName, (domains) => {

            const filteredDomains = domains.filter(d => {
                const match = d.toLowerCase() === domain.toLowerCase();

                if (match) {
                    found = true;
                }

                return !match;
            });

            return filteredDomains;
        });

        if (!found) {
            return res.json({
                errorCode: 1,
                message: "Domain not found"
            });
        }

        return res.json({
            errorCode: 0,
            message: "Domain deleted successfully"
        });

    } catch (error) {
        return res.json({
            errorCode: 1,
            message: error.message
        });
    }
});

// whitelist start end----------------------
process.on('SIGINT', () => {
    console.log('Server shutting down...');
    sql.close();
    process.exit(0);
});


//agentlist end///////////////

// Start server
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
