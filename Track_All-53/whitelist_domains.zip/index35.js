var express = require('express')();
var https = require('https');
var axios = require('axios');
var fs = require('fs');
var _ = require('lodash');
var cors = require('cors')

var ssl_domain = require("./ssl/ssl_domain");
var whitelist_domain = require("./whitelist_domains/domains");

const { json } = require('express');

const redis = require('redis');
const redisPort = 6379;
const client = redis.createClient(redisPort);
let app = https.createServer(ssl_domain.options, express);

app.addContext('api1.streamingtv.fun', ssl_domain.options1);
app.addContext('api2.streamingtv.fun', ssl_domain.options2);
app.addContext('api3.streamingtv.fun', ssl_domain.options3);
app.addContext('access.vrnl.net', ssl_domain.options4);
app.addContext('access.streamtv247.fun', ssl_domain.options5);
app.addContext('api3.streamtv247.fun', ssl_domain.options6);
app.addContext('api.bfoddsapi.in', ssl_domain.options7);
app.addContext('access.vrnlapi.live', ssl_domain.options8);
app.addContext('api3.vrnlapi.live', ssl_domain.options9);
app.addContext('api2.vrnlapi.live', ssl_domain.options10);
app.addContext('api2.vrnlapi.xyz', ssl_domain.options11);


express.use(cors());
express.get('/', function (req, res) {
    res.send('VRNL.NET');
});

let hostNames = [
    "baji247.win",
    "velk365.live",
    "baji88.games",
    "baji88.win",
    "lc247.ink",
    "velkiex365.win",
    "bajimat.xyz",
    "baaji7.live",
    "bajiex123.live",
    "betskyexch.com",
    "betfair24.live",
    "1xbdt.bet",
    "espnex.app",
    "ar100.live",
    "velkimax.com",
    "velkimax.win",
    "cashwinbd.com",
    "cashwinbd.live",
    "nagadsx.com",
    "nagadsx.live",
    "betbari.com",
    "bdcrickeet.com",
    "baajistar.com",
    "mybazzi.live",
    "mybazzi.vip",
    "jara11.com",
    "bdplay247.live",
    "bdplay247.com",
    "bdplay247.pro",
    "cricbuzzer.io",
    "lc247.co",
    "baaji365.org",
    "rajbet.pro",
    "cricexch.xyz",
    "velkis123.com",
    "9velki.com",
    "maza247.vip",
    "9wickts.win",
    "9wickts.club",
    "betswiz.in",
    "plabon25.com",
    "bee25.live",
    "bee25.site",
    "play25.live",
    "plabon.live",
    "seanscric247.club",
    "wickspin24.org",
    "velkiexz123.live",
    "9xbett9.com",
    "9xbett9.club",
    "9xbett9.live",
    "play123.live",
    "play25.bet",
    "play25.games",
    "powarplay.com",
    "betguru.win",
    "betguru.live",
    "velkiex123.win",
    "velkipro.com",
    "igstech.net",
    "maza247.vip",
    "1xbet247.live",
    "1xbet247.bet",
    "365betx.live",
    "betx7.pro",
    "betx7.win",
    "bigwin.fit",
    "tusky.fit",
    "bw247.live",
    "vellki.live",
    "velkil.live",
    "wicksppin24.live",
    "heppnni247.live",
    "khalo11.live",
    "openn.online",
    "enjoy247.live",
    "velkki.com",
    "wickspin24.cc",
    "heppni247.cc",
    "wickspin.live",
    "velkie365.com",
    "9xbet6.live",
    "9xbet6.org",
    "9xbet6.online",
    "wickspin365.live",
    "adhmor123.live",
    "velkibdt.online",
    "velkibdt.bet",
    "velki1234.online",
    "vellkie.com",
    "velki24.com",
    "heppnii247.live",
    "wickspiin24.live",
    "velke365.live",
    "veilki365.com",
    "velkicx365.live",
    "veilki365.live",
    "heppeni247.live",
    "veilkiex123.live",
    "onbet247.net",
    "onbet247.live",
    "moza247.com",
    "maza247.net",
    "easy247.pro",
    "giogiobetbuzz.com",
    "localhost:4200",
    "megabets.store",
    "megabets.pro",
    "bazipbu.com",
    "bazipbu.bet",
    "bazzi365.cc",
    "ninewiickets.com",
    "4six.com",
    "4six.vip",
    "4six.pro",
    "velki100.com",
    "ballbaji.com",
    "baji71.com",
    "ninewickets.com",
    "ninewickets.site",
    "betx365.me",
    "skyfairx.live",
    "megabets.live",
    "megabets.biz",
    "baaji365.in",
    "bajii365.cc",
    "baaji365.co",
    "bazi365.co",
    "baaji365.life",
    "skyex247.pro",
    "betbuzzexch.online",
    "betguruu.live",
    "betguruu.com",
    "plabonbd.com",
    "bet247.bet",
    "jibon247.bet",
    "lc247.cam",
    "lc247.top",
    "baaaji.win",
    "velkibd.pro",
    "velkibd.pro",
    "9wicketspro.vip",
    "nayaludis.xyz",
    "9wicktsvip.pro",
    "9wicketsvip.xyz",
    "9wicketsprobd.com",
    "love365.live",
    "1xbet365.live",
    "josh365.live",
    "josh247.live",
    "joshs365.live",
    "1xbets365.live",
    "1xbet365.buzz",
    "easy24.site",
    "easy24.us",
    "easy24.online",
    "exsky.site",
    "wifibet.com",
    "bdbet21.pro",
    "bdbet21.fun",
    "bdbet21.live",
    "bdplay.bet",
    "ninewickets.pro",
    "bety247.com",
    "9xbaji.pro",
    "bajimat365.com",
    "4wickets.com",
    "liveodds.live",
    "megaexch.live",
    "gxwickets.com",
    "velkicx.online",
    "velkicx.site",
    "velkicx.club",
    "velkipro.com",
    "heppni247.pro",
    "velkixx123.live",
    "baajifair.vip",
    "baajifair.world",
    "baaji365x.life",
    "bdbaji.live",
    "baji365.fit",
    "9xbeit9.live",
    "nayaludus.win",



    "ac247.live",];
let hostNames2 = [

];
let hostNames3 = [

];

let isStativDomain = [
    "play25.live",
    "plabon.live",
    "seanscric247.club",
    "wickspin24.org",
    "velkiexz123.live",
    "9xbett9.com",
    "9xbett9.club",
    "9xbett9.live",
    "plabon25.com",
    "skyex247.pro",
    "exsky.site",
    "play25.bet",
    "play123.live",
    "play25.games",
    "bee25.live",
    "bee25.site",
    "plabonbd.com",
    "onbet247.net",
    "onbet247.live",
    "skyexch.vrnlexch.com",
    "igstech.net",
    "velkipro.com",
    "ninewiickets.com",
    "4six.com",
    "4six.vip",
    "4six.pro",
    "velki100.com",
    "ballbaji.com",
    "baji71.com",
    "ninewickets.site",
    "ninewickets.com",
    "ninewickets.pro",
    "bet247.bet",
    "jibon247.bet",
    "wifibet.com",
    "betcx365.com",
    "9wicketspro.vip",
    "bdplay247.com",
    "bdplay247.live",
    "bdplay247.pro",
    "4wickets.com",
    "liveodds.live",
    "megaexch.live",
    "gxwickets.com",
    "velkicx.online",
    "velkicx.site",
    "velkicx.club",
    "velkipro.com",
    "heppni247.pro",
    "cricexch.xyz",

    "ac247.live",];

function getCallerIP(request) {
    var ip = request.headers['x-forwarded-for'] ||
        request.connection.remoteAddress ||
        request.socket.remoteAddress ||
        request.connection.socket.remoteAddress;
    ip = ip.split(',')[0];
    ip = ip.split(':').slice(-1); //in case the ip returned in a format: "::ffff:146.xxx.xxx.xxx"
    return ip;
}

function getDomainName(hostName) {
    if (!hostName) {
        return;
    }
    let formatedHost = "";
    let splithostName = hostName.split('.');
    if (splithostName.length > 2) {
        formatedHost = hostName.substring(hostName.lastIndexOf(".", hostName.lastIndexOf(".") - 1) + 1);
    } else {
        formatedHost = hostName.split('//')[1]
    }
    return formatedHost;
}

let tvstream = {};
let scoreAvailbale = {};
let tvAvailbale = {};

let token;
let TimerInteval;
let TimerInteval2;
let removeTvVRNL = whitelist_domain.removeTvVRNL;


let alreadyStoredLiveTv = {};


function startInteval() {
    if (TimerInteval) {
        clearInterval(TimerInteval);
    }
    if (TimerInteval2) {
        clearInterval(TimerInteval2);
    }

    getstreaminfo();
    TimerInteval = setInterval(getstreaminfo, 20000);
    TimerInteval2 = setInterval(getlistGames, 20000);

    // get_access_token();

    // TimerInteval = setInterval(get_access_token, 900000);

    // TimerInteval2 = setInterval(getlistGames, 600000);

}
startInteval();



function get_access_token() {
    var axios = require('axios');
    var data = JSON.stringify({
        "agentcode": "laserbook247",
        "secretkey": "e779a4142f87679a4a2e4fafe6de5f9809389c7b4e2d9a869b2d2b60786db11f"
    });

    var config = {
        method: 'post',
        url: 'https://bfrates.com/api/get_access_token',
        headers: {
            'Content-Type': 'application/json',
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            if (response.data) {
                token = response.data.token;
                getlistGames();

            }
        })
        .catch(function (error) {
            console.log(error);
        });

}
function get_scoreurl_by_centralid(match) {
    var axios = require('axios');
    var data = JSON.stringify({
        "access_token": token,
        "match_id": match.eventId,
        "domain_name": "ss247.com"
    });

    var config = {
        method: 'post',
        url: 'https://bfrates.com/api/get_scoreurl_by_centralid',
        headers: {
            'Content-Type': 'application/json',
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            if (response.data) {
                if (response.data.data) {
                    if (response.data.data.streamingUrl) {
                        // response.data.data.streamingUrl="https://555555.services/live_tv/index.html?eventId="+match.eventId
                        // console.log(response.data.data.streamingUrl);
                        content = JSON.stringify(response.data.data);

                        client.set('tvstream_' + match.eventId, content);
                    }
                }
            }
            // console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
            console.log(error);
        });

}

function getstreaminfo() {
    var config = {
        method: 'get',
        // url: 'https://ss247.life/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/streaminfo.php',
        // url: 'https://e765432.xyz/static/dfc5b4a8b3793cb1176ab4a56dfb3e896ed419aa/geteventlist.php',
        url: 'https://streamingtv.fun:3447/api/streaminfo'
    };
    axios(config)
        .then(function (response) {
            if (response.data.data) {
                response.data.data.getMatches.forEach((match, index) => {

                    // let link = "https://11gref-1en.com/" + match.Channel + "/index.m3u8" //1 runnning
                    // let link = "https://a35618zr3eiwx9.cc/" + match.Channel + "/index.m3u8" //1 runnning

                    let link = "https://cceucceu.cc/" + match.Channel + "/index.m3u8" //1 runnning

                    // let link2 = "https://11gref-1en.com/" + match.Channel + "/index.m3u8" //1 runnning
                    let link2 = "https://a35618zr3eiwx9.cc/" + match.Channel + "/index.m3u8" //1 runnning
                    // let link2 = "https://cceucceu.cc/" + match.Channel + "/index.m3u8" //1 runnning



                    // let link2 = "https://live-ngenix-live-das-ss247-ipv4-d6-hs-usdhp60.com/" + match.Channel + "/index.m3u8" //1 runnning
                    // let link2 = "https://bw-sixlogics.com/" + match.Channel + "/index.m3u8" //1 runnning


                    // let link = "https://inf52mediasrv-ss247.live/" + match.Channel + "/index.m3u8" //1 runnning

                    // let link= "https://mediasrv789-ss247-23-prod-sa-ulivestreaming.com/" + match.Channel + "/index.m3u8" // backup url

                    if (match.MatchID == "32798993") {
                        match.Channel = 6010;
                    }

                    let tvData = {
                        "scoreUrl": "",
                        "NowPlaying": match.NowPlaying == 1 ? true : false,
                        "Channel": match.Channel,
                        "link": link,
                        "link2": link2,
                        "type": match.Type,
                        // "streamingUrl": "https://ss247.life/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/Nstreamapi.php?chid=" + match.Channel + "&ip=",
                        // "streamingUrl": "https://ss247.life/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/Nstreamapipng.php?chid=" + match.Channel + "&ip=",
                        // "streamingUrl2": "https://ss247.life/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/Nstreamapipng.php?chid=" + match.Channel + "&ip="
                        // "streamingUrl": "https://e765432.xyz/static/dfc5b4a8b3793cb1176ab4a56dfb3e896ed419aa/getdata.php?chid=" + match.Channel + "&ip=", //old tv url
                        "streamingUrl": "https://oddsdata.org/score/19de33c17953fdf79123abd5fb01c17803d1be77/" + match.Channel, //new TV URL

                        // "streamingUrl2": "https://e765432.xyz/static/dfc5b4a8b3793cb1176ab4a56dfb3e896ed419aa/getdata.php?chid=" + match.Channel + "&ip=" //old tv url
                        "streamingUrl2": "https://oddsdata.org/score/19de33c17953fdf79123abd5fb01c17803d1be77/" + match.Channel //new TV URL

                    };
                    // https://ss247.life/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/Nstreamapipng.php?chid= //for jio25.live
                    if (match.MatchID < 0) {
                        let gameId = -(match.MatchID);
                        match.MatchID = '17' + gameId;
                    }
                    content = JSON.stringify(tvData);
                    client.set('tvstream_' + match.MatchID, content);
                    tvstream[match.MatchID] = content;

                    // if (match.Type != "CRICKET" && match.IsLive == 1) {
                    if (match.IsLive == 1) {
                        let url = "https://access.vrnlapi.live/VRN/v1/api/LiveTv/post";

                        let tvDatas = {
                            "channelIp": "",
                            "channelNo": "",
                            "hdmi": "",
                            "link": "",
                            "matchId": "",
                            "program": "p1",
                            "type": 6,
                            "SportId": 0
                        };
                        var lastDigit = index.toString().slice(-1)

                        let tvdomain = ["betskyexch.com",
                            "betskyexch.com", "betskyexch.com", "betskyexch.com",
                            "betskyexch.com", "betskyexch.com", "betskyexch.com", "betskyexch.com",
                            "betskyexch.com", "betskyexch.com",
                            "betskyexch.com", "betskyexch.com", "betskyexch.com", "betskyexch.com"]
                        // console.log(lastDigit,match.MatchID)
                        tvDatas.link = "https://www." + tvdomain[lastDigit] + "/livetv/index.html?eventId=" + match.MatchID;
                        // tvDatas.link = "https://runx.bet/livetv/index.html?eventId=" + match.MatchID;

                        tvDatas.link2 = tvDatas.link;
                        // console.log(tvDatas.link)
                        tvDatas.matchId = match.MatchID;
                        tvDatas.SportId = 1;
                        // tvDatas.channelNo = data.streamingChannel;
                        tvDatas.type = 6;
                        if (tvDatas.matchId < 4453453322) {
                            if (!alreadyStoredLiveTv[tvDatas.matchId]) {
                                // SaveLiveTv(tvDatas, url);
                            }
                        }

                    }



                });
            }

        })
        .catch(function (error) {
            // console.log(error);
        });
}

function getlistGames() {

    var config = {
        method: 'get',
        // url: 'https://121212.digital/pad=82/listGames',
        // url: 'https://444444.club/pad=82/listGames',
        // url: "https://555555.today/pad=82/listAllGames",
        url: "https://111111.info/pad=82/listAllGames",



    };
    axios(config)
        .then(function (response) {
            // console.log(response)
            if (response.data.result.length > 0) {
                response.data.result.forEach((match, index) => {
                    // console.log(match.eventId)
                    // if (!scoreAvailbale[eventId]) {
                    // getScoreId(match.eventId);
                    // }
                    // if (!tvAvailbale[eventId]) {
                    // if (match.isInPlay == 1) {
                    // getLiveTv(match.eventId);
                    // }
                    // }
                });
            }

        })
        .catch(function (error) {
            console.log(error);
        });

}

function getScoreId(eventId) {

    var config = {
        method: 'get',
        url: 'https://access.vrnlapi.live/VRN/v1/api/scoreid/get?eventid=' + eventId,
    };
    axios(config)
        .then(function (response) {
            // console.log(response.data);

            if (response.data.result.length > 0) {
                content = JSON.stringify(response.data.result[0]);
                client.set('scoreAvailbale_' + eventId, content);
                scoreAvailbale[eventId] = content;
            }




        })
        .catch(function (error) {
            console.log(error);
        });

}

function getLiveTv(eventId) {

    var config = {
        method: 'get',
        url: 'https://access.vrnlapi.live/VRN/v1/api/livetv/get?matchid=' + eventId,
    };
    axios(config)
        .then(function (response) {

            if (response.data.result.length > 0) {
                content = JSON.stringify(response.data.result[0]);
                client.set('tvAvailbale_' + eventId, content);
                tvAvailbale[eventId] = content;
            }

        })
        .catch(function (error) {
            console.log(error);
        });

}


function SaveLiveTv(data, url) {

    // console.log(JSON.stringify(data))
    var config = {
        method: 'post',
        data: JSON.stringify(data),
        headers: {
            'Content-Type': 'application/json'
        },
        // url: url,
        url: "https://access.vrnlapi.live/VRN/v1/api/LiveTv/post"
    };
    axios(config)
        .then(function (response) {
            alreadyStoredLiveTv[data.matchId] = data;
            // console.log(response.data)


        })
        .catch(function (error) {
            console.log(error);
        });


    // $.ajax({
    //   url: url,
    //   method: 'POST',
    //   data: JSON.stringify(data),
    //   headers: {
    //     'content-type': 'application/json'
    //   },
    //   success: function (data) {
    //     console.log(data)
    //   },
    //   error: function (err) {
    //     console.log(err)
    //   }
    // });
}

let count = 0;
express.get('/api/get_live_tv_url/:eventId', function (req, res) {
    var clientIp = getCallerIP(req);
    let scoreTvData = {
        "scoreUrl": "",
        "NowPlaying": false,
        "streamingUrl": "",
        "link": "",
        "Channel": "",
        "isStatic": false

    };
    // if (getDomainName(req.get('origin')) == "betswiz.in" && req.params.eventId != '32855346' && count % 2 === 0) {
    //     res.send(scoreTvData);
    //     count++;
    //     return;
    // } else {
    //     count++;
    // }
    if (getDomainName(req.get('origin')) == "betswiz.in7") {
        res.send(scoreTvData);
        return;
    }
    client.get('scoreAvailbale_' + req.params.eventId, (err, scoreData) => {
        if (scoreData) {
            scoreData = JSON.parse(scoreData);
            scoreTvData.scoreUrl = 'https://www.satsports.net/score_widget/index.html?id=' + scoreData.score_id + '&aC=bGFzZXJib29rMjQ3';
        } else {
            if (scoreAvailbale[req.params.eventId]) {
                scoreData = JSON.parse(scoreAvailbale[req.params.eventId]);
                scoreTvData.scoreUrl = 'https://www.satsports.net/score_widget/index.html?id=' + scoreData.score_id + '&aC=bGFzZXJib29rMjQ3';
            }
        }
        client.get('tvAvailbale_' + req.params.eventId, (err, tvData) => {
            if (tvData) {
                tvData = JSON.parse(tvData);
                scoreTvData.NowPlaying = true;
                scoreTvData.streamingUrl = "https://streamingtv.fun/live_tv/index.html?eventId=" + req.params.eventId;
            } else {
                if (tvAvailbale[req.params.eventId]) {
                    tvData = JSON.parse(tvAvailbale[req.params.eventId]);
                    scoreTvData.NowPlaying = true;
                    scoreTvData.streamingUrl = "https://streamingtv.fun/live_tv/index.html?eventId=" + req.params.eventId;
                }
            }

            if (hostNames2.indexOf(getDomainName(req.get('origin'))) > -1) {
                if (tvData) {
                    scoreTvData.NowPlaying = true;
                    scoreTvData.streamingUrl = "https://sportbet.id/live_tv/index.html?eventId=" + req.params.eventId;
                }
                // let tvData = {
                //   "scoreUrl": "",
                //   "streamingUrl": "https:///yorkerclub.xyz/live_tv/index.html?eventId=" + req.params.eventId
                // };
                res.send(scoreTvData);
            }
            else if (hostNames3.indexOf(getDomainName(req.get('origin'))) > -1) {
                if (tvData) {
                    scoreTvData.NowPlaying = true;
                    scoreTvData.streamingUrl = "https://sportbet.id/live_tv/index.html?eventId=" + req.params.eventId;
                }
                // let tvData = {
                //   "scoreUrl": "",
                //   "streamingUrl": "https://sportbet.id/live_tv/index.html?eventId=" + req.params.eventId
                // };
                res.send(scoreTvData);
            }
            else if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1) {
                if (tvData) {
                    scoreTvData.NowPlaying = true;
                    scoreTvData.streamingUrl = "https://streamingtv.fun/live_tv/index.html?eventId=" + req.params.eventId;
                }
                // let tvData = {
                //   "scoreUrl": "",
                //   "streamingUrl": "https://access.streamingtv.fun/live_tv/index.html?eventId=" + req.params.eventId
                // };
                res.send(scoreTvData);


            }
            else {
                client.get('tvstream_' + req.params.eventId, (err, data) => {
                    // console.log(data)
                    if (data) {

                        data = JSON.parse(data);
                        // if (removeTvVRNL.indexOf(getDomainName(req.get('origin'))) > -1
                        //     || getDomainName(req.get('origin')) == 'play25.live' || getDomainName(req.get('origin')) == 'ninewickets.com') {
                        //     // data.streamingUrl = data.streamingUrl2;
                        //     // data.link = data.link2;
                        // }

                        if (isStativDomain.indexOf(getDomainName(req.get('origin'))) > -1) {
                            scoreTvData.isStatic = true;
                        }

                        scoreTvData.NowPlaying = data.NowPlaying;
                        scoreTvData.link = data.link;
                        scoreTvData.Channel = data.Channel;
                        scoreTvData.type = data.type;
                        // scoreTvData.streamingUrl = data.streamingUrl + clientIp[0];
                        scoreTvData.streamingUrl = data.streamingUrl;

                        if (getDomainName(req.get('origin')) == 'vrnlexch222.com' || getDomainName(req.get('origin')) == 'betgame222.live' || getDomainName(req.get('origin')) == 'lc247_222.live') {
                            // scoreTvData.streamingUrl = "https://www.lc247.bet/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653_staging/?eventId=" + req.params.eventId;
                            scoreTvData.streamingUrl = "https://www.lc247.bet/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/?eventId=" + req.params.eventId;
                        }
                        // scoreTvData.streamingUrl = "https://www.lc247.bet/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653_staging/?eventId="+ req.params.eventId;

                        // data.streamingUrl = data.streamingUrl + clientIp[0]; //for old tv
                        // if (getDomainName(req.get('origin')) == 'betskyexch.com') {
                        //     scoreTvData.streamingUrl = data.streamingUrl2;
                        //     // scoreTvData.link = data.link2;
                        // }
                        if (count % 2 === 0) {
                            scoreTvData.link = data.link;
                            count++;
                        } else {
                            scoreTvData.link = data.link2;
                            count++;
                        }

                    } else {
                        // scoreTvData.streamingUrl = null;
                        if (tvstream[req.params.eventId]) {
                            data = JSON.parse(tvstream[req.params.eventId]);

                            // if (removeTvVRNL.indexOf(getDomainName(req.get('origin'))) > -1
                            //     || getDomainName(req.get('origin')) == 'play25.live' || getDomainName(req.get('origin')) == 'ninewickets.com') {
                            //     // data.streamingUrl = data.streamingUrl2;
                            //     // data.link = data.link2;
                            // }

                            if (isStativDomain.indexOf(getDomainName(req.get('origin'))) > -1) {
                                scoreTvData.isStatic = true;
                            }
                            scoreTvData.NowPlaying = data.NowPlaying;
                            scoreTvData.link = data.link;
                            scoreTvData.Channel = data.Channel;
                            scoreTvData.type = data.type;

                            scoreTvData.streamingUrl = data.streamingUrl;

                            // scoreTvData.streamingUrl = data.streamingUrl + clientIp[0]; //for old tv 

                            // if (getDomainName(req.get('origin')) == 'bee25.site') {
                            //     scoreTvData.streamingUrl = data.streamingUrl2;
                            //     // scoreTvData.link = data.link2;
                            // }
                            if (count % 2 === 0) {
                                scoreTvData.link = data.link;
                                count++;
                            } else {
                                scoreTvData.link = data.link2;
                                count++;
                            }

                        }
                    }
                    // scoreTvData.streamingUrl = "https://www.play25.live/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653_staging/?eventId=" + req.params.eventId;


                    // if (req.params.eventId == '35181650') {
                    // if (scoreTvData.type != 'CRICKET') {
                    //     // scoreTvData.streamingUrl = "https://player.twitch.tv/?channel=livet10tv&parent=www." + getDomainName(req.get('origin'));
                    //     scoreTvData.link = "https://420420.live/" + scoreTvData.Channel + "/mono.m3u8";
                    // }
                    if (getDomainName(req.get('origin')) == 'bee25.site' || getDomainName(req.get('origin')) == 'play25.live' ||
                        getDomainName(req.get('origin')) == 'plabon.live' || getDomainName(req.get('origin')) == 'plabon25.com' ||
                        getDomainName(req.get('origin')) == 'play25.bet' || getDomainName(req.get('origin')) == 'play25.games') {
                        // scoreTvData.link = "https://a35618zr3eiwx9.cc/" + scoreTvData.Channel + "/index.m3u8";
                        scoreTvData.link = "https://182beter.com/" + scoreTvData.Channel + "/index.m3u8";
                        // scoreTvData.link = scoreTvData.link2;

                    }
                    res.send(scoreTvData);

                })
            }
        })
    })


});

express.get('/api/get_live_tv_score_url/:eventId', function (req, res) {
    var clientIp = getCallerIP(req);
    // console.log(clientIp[0])
    let scoreTvData = {
        "scoreUrl": "",
        "streamingUrl": ""
    };
    client.get('scoreAvailbale_' + req.params.eventId, (err, scoreData) => {
        if (scoreData) {
            scoreData = JSON.parse(scoreData);
            scoreTvData.scoreUrl = 'https://www.satsports.net/score_widget/index.html?id=' + scoreData.score_id + '&aC=bGFzZXJib29rMjQ3';
        } else {

        }

        client.get('tvstream_' + req.params.eventId, (err, data) => {
            // console.log(data)
            if (data) {
                data = JSON.parse(data);
                scoreTvData.streamingUrl = data.streamingUrl + clientIp[0];
                // data.streamingUrl = data.streamingUrl + clientIp[0];
            }
            res.send(scoreTvData);

        })
    })


});


app.listen(3475, function () {
    console.log('listening on *:3475');
});

