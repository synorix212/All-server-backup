const rateLimit = require('express-rate-limit');

const apiRateLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 15 min in milliseconds
  max: 60,
  handler: function (req, res, /*next*/) {
        return res.status(429).json({
        status:'Error',
        message: 'You sent too many requests. Please wait a while then try again'
        })
    },
  headers: true,
});
module.exports = { apiRateLimiter }