// npm install pm2 -g
// pm2 start index.js --exp-backoff-restart-delain=100
// pm2 stop index.js

var express = require('express')();
var https = require('https');
var axios = require('axios');
var fs = require('fs');
var _ = require('lodash');
var cors = require('cors')
const path = require('path');

var ssl_domain = require("./ssl/ssl_domain");
var whitelist_domain = require("./whitelist_domains/domains");


const { json } = require('express');

const redis = require('redis');
const redisPort = 6379;
const client = redis.createClient(redisPort);

// let enabled_ports = [
//   { port: 3440, app: "" }, { port: 3441, app: "" }, { port: 3442, app: "" },
//   { port: 3443, app: "" }, { port: 3444, app: "" }, { port: 3445, app: "" },
//   { port: 3446, app: "" }, { port: 3447, app: "" }, { port: 3448, app: "" },
//   { port: 3449, app: "" }, { port: 3450, app: "" }, { port: 3451, app: "" },
//   // { port: 3452, app: "" }, { port: 3453, app: "" }, { port: 3454, app: "" },
//   // { port: 3455, app: "" }, { port: 3456, app: "" }, { port: 3457, app: "" },
//   // { port: 3458, app: "" }, { port: 3459, app: "" }, { port: 3460, app: "" }
// ];

// enabled_ports.forEach((element, index) => {
//   element.app = https.createServer(ssl_domain.options, express);
//   // app.addContext('score2.streamingtv.fun', ssl_domain.options2);
// });

let app = https.createServer(ssl_domain.options, express);

app.addContext('api1.streamingtv.fun', ssl_domain.options1);
app.addContext('api2.streamingtv.fun', ssl_domain.options2);
app.addContext('api3.streamingtv.fun', ssl_domain.options3);
app.addContext('access.vrnl.net', ssl_domain.options4);
app.addContext('access.streamtv247.fun', ssl_domain.options5);
app.addContext('api3.streamtv247.fun', ssl_domain.options6);
app.addContext('api.bfoddsapi.in', ssl_domain.options7);
app.addContext('access.vrnlapi.live', ssl_domain.options8);
app.addContext('api3.vrnlapi.live', ssl_domain.options9);
app.addContext('api2.vrnlapi.live', ssl_domain.options10);
app.addContext('api2.vrnlapi.xyz', ssl_domain.options11);





express.use(cors());
express.get('/', function (req, res) {
  res.send('VRNL.NET');
});

// setInterval(() => {
//   fs.readdir('../../store_sky_sportbook/', (err, files) => {
//     files.forEach(file => {
//       // console.log(file);
//       fs.unlinkSync('../../store_sky_sportbook/' + file);
//     });
//   });

// }, 500 * 1000);

// client.flushdb(function (err, succeeded) {
//   console.log(succeeded); // will be true if successfull
// });

let hostNames = whitelist_domain.hostNames;
let removeBanner = whitelist_domain.hostNames_banner;
let velkiBanner = whitelist_domain.hostNames_velkibanner;
let hostNames_removeBanner = whitelist_domain.hostNames_removeBanner;
let fancySourceAllow = whitelist_domain.fancySourceAllow;
let mainScore = whitelist_domain.mainScore;
let velkiexchbanner = whitelist_domain.velkiexchbanner;


function getCallerIP(request) {
  var ip = request.headers['x-forwarded-for'] ||
    request.connection.remoteAddress ||
    request.socket.remoteAddress ||
    request.connection.socket.remoteAddress;
  ip = ip.split(',')[0];
  ip = ip.split(':').slice(-1); //in case the ip returned in a format: "::ffff:146.xxx.xxx.xxx"
  return ip;
}

function getDomainName(hostName) {
  if (!hostName) {
    return;
  }
  let formatedHost = "";
  let splithostName = hostName.split('.');
  if (splithostName.length > 2) {
    formatedHost = hostName.substring(hostName.lastIndexOf(".", hostName.lastIndexOf(".") - 1) + 1);
  } else {
    formatedHost = hostName.split('//')[1]
  }
  return formatedHost;
}

express.post('/api/store_all_apis', json({ type: '*/*' }), function (req, res) {
  var content = JSON.stringify(req.body);
  fs.writeFile('../../store_vrnl_apis/all_apis_vrnl.json', content, (err) => {
    if (err) {
      res.send({ result: "failed" })
      throw err;
    }
    res.send({ result: "Data saved!" })
  });
});

express.post('/api/store_ticker', json({ type: '*/*' }), function (req, res) {
  var content = JSON.stringify(req.body.ticker);
  fs.writeFile('../../store_site_ticker/ticker.json', content, (err) => {
    if (err) {
      res.send({ result: "failed" })
      throw err;
    }
    res.send({ result: "ticker saved!" })
  });

});



let scoreApi = "https://api3.vrnlapi.live:3440"; //63
let scoreApi_betwiz = "https://api3.vrnlapi.live:3440"; //132

let premiumApi = "https://api3.vrnlapi.live:3440"; //63
let premiumApi_betwiz = "https://api3.vrnlapi.live:3440"; //132

// let fanApi = "https://api3.vrnlapi.live:3455";
// let fanApi_betwiz = "https://api3.vrnlapi.live:3462";
// let sslSportApi = "https://141414.live";
// let sslsportSocketApi = "wss://141414.life";

let count = 0;

setInterval((value) => {
  if (count == 0) {
    //     scoreApi = "https://api3.vrnlapi.live:3441";
    //     scoreApi_betwiz = "https://api4.vrnlapi.live:3441";
    //     premiumApi = "https://api3.vrnlapi.live:3451";
    //     premiumApi_betwiz = "https://api3.vrnlapi.live:3460";
    count = 1;
  } else if (count == 1) {
    //     scoreApi = "https://api3.vrnlapi.live:3442";
    //     scoreApi_betwiz = "https://api4.vrnlapi.live:3442";
    //     premiumApi = "https://api3.vrnlapi.live:3452";
    //     premiumApi_betwiz = "https://api3.vrnlapi.live:3457";
    count = 2;
  } else if (count == 2) {
    //     scoreApi = "https://api3.vrnlapi.live:3443";
    //     scoreApi_betwiz = "https://api4.vrnlapi.live:3445";
    //     premiumApi = "https://api3.vrnlapi.live:3453";
    //     premiumApi_betwiz = "https://api3.vrnlapi.live:3458";
    count = 3;
  } else if (count == 3) {
    //     scoreApi = "https://api3.vrnlapi.live:3444";
    //     scoreApi_betwiz = "https://api4.vrnlapi.live:3444";
    //     premiumApi = "https://api3.vrnlapi.live:3454";
    //     premiumApi_betwiz = "https://api3.vrnlapi.live:3459";
    count = 4;
  } else if (count == 4) {
    //     scoreApi = "https://api3.vrnlapi.live:3440";
    //     scoreApi_betwiz = "https://api4.vrnlapi.live:3440";
    //     premiumApi = "https://api3.vrnlapi.live:3450";
    //     premiumApi_betwiz = "https://api3.vrnlapi.live:3455";
    count = 0;
  }
}, 1000 * 20);



express.get('/api/all_apis', function (req, res) {
  // var clientIp = getCallerIP(req);
  // if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1) {
  //     res.send({errMsg:"Invalid authentication"});
  //     return null;
  // }
  const data = fs.readFile('../../store_vrnl_apis/all_apis_vrnl.json', 'utf8', (err, data) => {
    if (err) {
      res.send(null);
      return null;
    }
    if (data) {
      try {
        data = JSON.parse(data);
      } catch (err) {
        console.error(err)
      }
      // data.premiumApi = premiumApi;
      // data.scoreApi = scoreApi;

      if (data.changeBFApi == 1) {
        data.fanApi = data.fanApi2;
        data.sslSportApi = data.sslSportApi2;
        data.fanApi1 = data.sslSportApi2;
        data.sslSportApi1 = data.fanApi2;
      }

      let fanApi = data.fanApi;
      let sslSportApi = data.sslSportApi;
      let fanApi1 = data.fanApi1;
      let sslSportApi1 = data.sslSportApi1;




      if (count == 1 || count == 3) {
        data.fanApi = fanApi1;
        data.sslSportApi = sslSportApi1;
        data.fanApi1 = fanApi;
        data.sslSportApi1 = sslSportApi;
      }

      if (velkiBanner.indexOf(getDomainName(req.get('origin'))) > -1 || req.get('origin') == 'https://velki.vrnlexch.com' || req.get('origin') == 'https://velki.skyex247.live' || req.get('origin') == 'https://velki.skyex247.pro' || req.get('origin') == 'https://velki.skynext247.live' || req.get('origin') == 'https://velki.skynext247.com' || req.get('origin') == 'https://gullybet.vrnlexch.com' || req.get('origin') == 'https://velki.foxplay.pro' || req.get('origin') == 'https://velki.jara11.bet' || req.get('origin') == 'https://velki.bdcricket.bet' || req.get('origin') == 'https://velki.nagadsx.com' || req.get('origin') == 'https://velki.nagadsx.live') {
        data.bannerImg.forEach((banner, index) => {
          data.bannerImg[index] = banner.replace("promo", "velkibanner");
        });
      }

      if (removeBanner.indexOf(getDomainName(req.get('origin'))) > -1 || req.get('origin') == 'https://smartexch147.vrnlexch.com' || req.get('origin') == 'https://smartexch.vrnlexch.com' || req.get('origin') == 'https://exch.crxw.live') {
        data.bannerImg.forEach((banner, index) => {
          banner = banner.replace("velkibanner", "velkibanner2");
          data.bannerImg[index] = banner.replace("promo", "promo2");
        });
      }

      if (hostNames_removeBanner.indexOf(getDomainName(req.get('origin'))) > -1) {
        data.bannerImg = [];
      }
      // if (domainsName0.indexOf(getDomainName(req.get('origin'))) > -1) {
      if (data.shiftApi == '0') {
        data.sslclient = data.site1 + '/pad=82';
        data.ssladmin = data.site2 + '/pad=81';
      } else {
        data.sslclient = data.site3 + '/pad=82';
        data.ssladmin = data.site4 + '/pad=81';
      }

      data.adminReport = data.adminReport;
      // data.scoreApi = data.scoreApi;

      data.sslSportApi = data.sslSportApi;
      data.sslsportSocketApi = data.sslsportSocketApi;

      // }

      let respData = {};
      respData['devAdminIp'] = data.ssladmin;
      respData['devIp'] = data.sslclient;
      respData['awcApi'] = data.awcApi;
      respData['boApi'] = data.boApi;
      respData['auraApi'] = data.auraApi;
      respData['snApi'] = data.snApi;
      respData['slotApi'] = data.slotApi;
      respData['betGameApi'] = data.betGameApi;
      // respData['sportApi'] = data.sportApi;
      // respData['sportSocketApi'] = data.sportSocketApi;
      respData['liveTvApi'] = data.liveTvApi;
      respData['ipCheckApi'] = data.ipCheckApi;

      respData['scoreApi'] = data.scoreApi;
      respData['fanApi'] = data.fanApi;
      respData['fancyApi'] = data.fanApi;
      respData['premiumApi'] = data.premiumApi;
      respData['casApi'] = data.casApi;
      respData['casinoApi'] = data.casApi;
      respData['sslRacingApi'] = data.sslRacingApi;
      respData['sslracingSocketApi'] = data.sslracingSocketApi;
      respData['sslAllSportApi'] = data.sslAllSportApi;
      respData['sslAllSportSocketApi'] = data.sslAllSportSocketApi;
      respData['sslExchangeGamesApi'] = data.sslExchangeGamesApi;
      respData['sslSportApi'] = data.sslSportApi;
      respData['sslsportSocketApi'] = data.sslsportSocketApi;
      respData['ssladmin'] = data.ssladmin;
      respData['adminReport'] = data.adminReport;
      respData['booksLiveBets'] = data.booksLiveBets;
      respData['sslclient'] = data.sslclient;
      respData['fSource'] = data.fSource;
      respData['maintanance'] = data.maintanance;
      respData['maintananceAdmin'] = data.maintanance;
      respData['bannerImg'] = data.bannerImg;
      respData['AngelaApi'] = data.AngelaApi;
      respData['RuthApi'] = data.RuthApi;
      respData['KrystApi'] = data.KrystApi;
      respData['KrystestApi'] = data.KrystestApi;

      if (getDomainName(req.get('origin')) == 'cricexch.net' || getDomainName(req.get('origin')) == 'cricbuzzer.io' || getDomainName(req.get('origin')) == 'vrnlexch.com' || getDomainName(req.get('origin')) == 'betskyexch.com') {
        // respData['maintanance'] = 2;
      }
      // respData['maintananceAdmin'] = 2;

      // if (getDomainName(req.get('origin')) == 'ninewiickets.com' || getDomainName(req.get('origin')) == 'adminak.com' ||
      //   getDomainName(req.get('origin')) == 'ninewickets.com' || getDomainName(req.get('origin')) == 'ninewickets.site') {
      // respData['maintanance'] = 2;
      // }



      // if (getDomainName(req.get('origin')) != '9wiicket.win' && getDomainName(req.get('origin')) != 'mpk.live' && getDomainName(req.get('origin')) != 'vellkiex123.com') {
      // respData['sslclient'] = "https://222222.digital/pad=822";
      // respData['ssladmin'] = "https://111111.info/pad=812";
      // respData['adminReport'] = "https://111111.info/pad=812";
      // }
      if (fancySourceAllow.indexOf(getDomainName(req.get('origin'))) > -1) {
        respData['fSource'] = data.fSource1; //allowed sky fancy 1
      }

      // if (getDomainName(req.get('origin')) == 'diamondex_2222.live' || getDomainName(req.get('origin')) == 'betskyexch.com' || getDomainName(req.get('origin')) == 'exchdiamond_2222.net' || getDomainName(req.get('origin')) == 'dia.skyex247.live') {
      //   respData['fSource'] = 0;
      // }

      // if (getDomainName(req.get('origin')) == 'bdplay.live' || getDomainName(req.get('origin')) == 'bdplay247.live' || getDomainName(req.get('origin')) == 'bdplay247.pro' || getDomainName(req.get('origin')) == 'bdplay247.com' || getDomainName(req.get('origin')) == '112233bdplay.live') {
      //   respData['liveTvApi'] = "https://api3.vrnlapi.live:3475";
      // }

      if (getDomainName(req.get('origin')) == 'baaaji.win') {
        respData['RuthApi'] = "https://b2cnew.vrnlapi.xyz:15552";
      }

      if (req.get('origin') == 'https://adm.cricbuzzer.io' || req.get('origin') == 'https://adm.play25.live' || req.get('origin') == 'https://adm.ninewiickets.com' || req.get('origin') == 'https://adm.9wicketspro.pro') {
        respData['ssladmin'] = "https://old.333333.space/pad=81";
        respData['adminReport'] = "https://old.333333.space/pad=81";
      }

      if (req.get('origin') == 'https://old.cricbuzzer.io' || req.get('origin') == 'https://old.play25.live' || req.get('origin') == 'https://old.ninewiickets.com' || req.get('origin') == 'https://old.9wicketspro.pro') {
        respData['sslclient'] = "https://old.333333.space/pad=82";
      }


      // if (getDomainName(req.get('origin')) == 'bee25.live' || getDomainName(req.get('origin')) == 'play25.live' ||
      // getDomainName(req.get('origin')) == 'plabon25.live' || getDomainName(req.get('origin')) == 'plabon25.com' ||
      // getDomainName(req.get('origin')) == 'vellkie.com' || getDomainName(req.get('origin')) == 'velki24.com') {
      //   respData['maintanance'] = 2;
      // }

      // if (getDomainName(req.get('origin')) != 'bazzi365.pro' && getDomainName(req.get('origin')) != 'bazzi365.com' && getDomainName(req.get('origin')) != 'betguru.win' && getDomainName(req.get('origin')) != 'lc247.live' && getDomainName(req.get('origin')) != 'lc247.bet' && getDomainName(req.get('origin')) != 'lc247.games' && getDomainName(req.get('origin')) != 'bee25.live' && getDomainName(req.get('origin')) != 'play25.live'
      //   && getDomainName(req.get('origin')) != 'plabon25.live' && getDomainName(req.get('origin')) != 'plabon25.com' && getDomainName(req.get('origin')) != 'ninewiickets.com' && getDomainName(req.get('origin')) != 'ninewickets.com' && getDomainName(req.get('origin')) != 'ninewickets.site' && getDomainName(req.get('origin')) != 'skyex247.live' && getDomainName(req.get('origin')) != 'skyex247.pro' && getDomainName(req.get('origin')) != 'velkiclub.com' && getDomainName(req.get('origin')) != 'heppni247.com') {
      //   respData['sslSportApi'] = data.sslSportApi1;
      //   respData['fanApi'] = data.fanApi1;
      //   respData['fancyApi'] = data.fanApi1;
      // }


      if (getDomainName(req.get('origin')) == 'cricexch.net') {
        respData['fSource'] = 1;
      }


      // if (getDomainName(req.get('origin')) == 'play25.live' || getDomainName(req.get('origin')) == 'plabon25.com' || getDomainName(req.get('origin')) == 'play25.bet'
      //   || getDomainName(req.get('origin')) == 'play25.games' || getDomainName(req.get('origin')) == 'play25.win' || getDomainName(req.get('origin')) == 'play786.live'
      //   || getDomainName(req.get('origin')) == 'vellkie.com' || getDomainName(req.get('origin')) == 'velki24.com') {
      //   respData['sslSportApi'] = "https://141414.live";
      //   respData['fanApi'] = "https://141414.live";
      //   respData['fancyApi'] = "https://141414.live";
      // }

      res.send(respData);
    }
    else {
      res.send(null);
    }
  })
});

express.get('/score_api/:id', function (req, res) {
  // var clientIp = getCallerIP(req);
  // if (!req.get('referrer')) {
  //   console.log(req.get('referrer'), clientIp[0], req.get('origin'), 'score_data');
  // }
  // if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
  //   res.send({ errMsg: "Invalid authentication" });
  //   return null;
  // }
  client.get('store_scores' + req.params.id, (err, data) => {
    if (data) {
      res.send(data);
    }
    else {
      fs.readFile('../../store_scores/' + req.params.id + '.json', 'utf8', (err, data) => {
        if (err) {
          fs.readFile('../../store_scores/' + req.params.id + '_4.json', 'utf8', (err, data) => {
            if (err) {
              res.send({ score: null, eventId: req.params.id });
              return null;
            }
            if (data) {
              res.send(data);
            }
            else {
              res.send({ score: null, eventId: req.params.id });
            }
          })
          return null;
        }
        if (data) {
          res.send(data);
        }
        else {
          res.send({ score: null, eventId: req.params.id });
        }
      })
    }
  })
});

express.get('/api/getScoreId3/:eventid', function (req, res) {
  var clientIp = getCallerIP(req);
  if (!req.get('referrer')) {
    console.log(req.get('referrer'), clientIp[0], req.get('origin'), 'score_id');
  }

  if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
    res.send({ errMsg: "Invalid authentication" });
    return null;
  }
  if (!req.params.eventid) {
    res.send({ errMsg: "EventId is Missing" });
    return null;
  }

  let config = {
    method: 'get',
    url: 'https://access.vrnlapi.live/VRN/v1/api/scoreid/get?eventid=' + req.params.eventid,
    headers: {}
  };
  axios.request(config)
    .then((response) => {
      res.send(response.data);
    })
    .catch((error) => {
      console.log(error);
      console.log(clientIp, getDomainName(req.get('origin')))

    });

});

express.get('/api/getScoreId/:eventid', function (req, res) {
  // var clientIp = getCallerIP(req);
  // if (!req.get('referrer')) {
  //   console.log(req.get('referrer'), clientIp[0], req.get('origin'), 'score_id');
  // }

  // if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
  //   res.send({ errMsg: "Invalid authentication" });
  //   return null;
  // }
  if (!req.params.eventid) {
    res.send({ errMsg: "EventId is Missing" });
    return null;
  }

  client.get('score_id_' + req.params.eventid, (err, data) => {
    if (data) {
      // console.log('cache file ' + req.params.eventid)
      res.send(data);
    } else {
      let config = {
        method: 'get',
        url: 'https://access.vrnlapi.live/VRN/v1/api/scoreid/get?eventid=' + req.params.eventid,
        headers: {}
      };
      axios.request(config)
        .then((response) => {
          // console.log('api file ' + req.params.eventid)
          if (response.data?.result) {
            if (response.data?.result.length > 0) {
              response.data.result[0]['ScoreUrl'] = 'https://lmt.vrnlscore.com/scores/index.html?scoreId=' + response.data.result[0].score_id;
            }
          }
          let content = JSON.stringify(response.data)
          client.set('score_id_' + req.params.eventid, content, 'EX', 30);
          res.send(response.data);
        })
        .catch((error) => {
          console.log('error /scoreid api');
          // console.log(clientIp, getDomainName(req.get('origin')))

        });
    }
  });



});
express.get('/api/getScoreId/:eventid/:sportId', function (req, res) {
  // var clientIp = getCallerIP(req);
  // if (!req.get('referrer')) {
  //   console.log(req.get('referrer'), clientIp[0], req.get('origin'), 'score_id');
  // }

  // if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
  //   res.send({ errMsg: "Invalid authentication" });
  //   return null;
  // }
  if (!req.params.eventid) {
    res.send({ errMsg: "EventId is Missing" });
    return null;
  }

  client.get('score_id_' + req.params.eventid, (err, data) => {
    if (data) {
      data = JSON.parse(data);
      if (data?.result) {
        if (data?.result.length > 0) {
          // if (mainScore.indexOf(getDomainName(req.get('origin'))) > -1) {
          //   data.result[0]['ScoreUrl'] = 'https://lmt.vrnlscore.com/scores/index.html?scoreId=' + data.result[0].score_id;
          // }
          // else if (getDomainName(req.get('origin')) == 'velkiclub.com' || getDomainName(req.get('origin')) == 'heppni247.com') {
          //   data.result[0]['ScoreUrl'] = 'https://lmt.vrnlscore.com/scoress/index.html?scoreId=' + data.result[0].score_id;
          // } else {
          data.result[0]['ScoreUrl'] = 'https://www.satsports.net/score_widget/index.html?id=' + data.result[0].score_id;
          // }
        }
      }
      res.send(data);
    } else {
      let config = {
        method: 'get',
        url: 'https://access.vrnlapi.live/VRN/v1/api/scoreid/get?eventid=' + req.params.eventid,
        headers: {}
      };
      axios.request(config)
        .then((response) => {
          // console.log('api file ' + req.params.eventid)
          if (response.data?.result) {
            if (response.data?.result.length > 0) {
              // if (mainScore.indexOf(getDomainName(req.get('origin'))) > -1) {
              //   response.data.result[0]['ScoreUrl'] = 'https://lmt.vrnlscore.com/scores/index.html?scoreId=' + response.data.result[0].score_id;
              // }
              // else if (getDomainName(req.get('origin')) == 'velkiclub.com' || getDomainName(req.get('origin')) == 'heppni247.com') {
              //   response.data.result[0]['ScoreUrl'] = 'https://lmt.vrnlscore.com/scoress/index.html?scoreId=' + response.data.result[0].score_id;
              // }
              // else {
              response.data.result[0]['ScoreUrl'] = 'https://www.satsports.net/score_widget/index.html?id=' + response.data.result[0].score_id;
              // }
            }
          }
          let content = JSON.stringify(response.data)
          client.set('score_id_' + req.params.eventid, content, 'EX', 30);
          res.send(response.data);
        })
        .catch((error) => {
          console.log('error /scoreid api');
          // console.log(clientIp, getDomainName(req.get('origin')))

        });
    }
  });



});

function getFormattedScore(data) {

  let scoreData = [];
  _.forEach(data, (item) => {
    let scoretext = "";
    if (item.eventTypeId == 2) {
      scoretext = '(' + item?.score?.home.sets + ') ' + item?.score?.home.games + ' - ' + item?.score?.away.games + ' (' + item?.score?.away.sets + ') ';
      scoreData.push({ eventId: item.eventId, score: scoretext });
    }

    if (item.eventTypeId == 1) {
      scoretext = item?.score?.home.score + ' - ' + item?.score?.away.score;
      scoreData.push({ eventId: item.eventId, score: scoretext, timeElapsed: item.timeElapsed + "'" });
    }
  })
  return scoreData;
}

express.get('/get_all_score', function (req, res) {
  // var clientIp = getCallerIP(req);
  // console.log(req)
  // if (!req.get('referrer')) {
  //   console.log(req.get('referrer'), clientIp[0], req.get('origin'), 'all_score_data');
  // }
  // if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
  //   res.send({ errMsg: "Invalid authentication" });
  //   return null;
  // }
  client.get('store_all_scores', (err, data) => {
    if (data) {
      res.send(getFormattedScore(JSON.parse(data)));
    } else {
      res.send([]);
    }
  })

});

express.get('/api/get_ticker2', function (req, res) {

  // if (getDomainName(req.get('origin')) == 'betswiz.com') {
  //   res.send({ ticker: null });
  //   return null;
  // }

  fs.readFile('../../store_site_ticker/ticker.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ ticker: null });
      return null;
    }
    if (data) {
      data = JSON.parse(data);
      res.send({ ticker: data });
    }
    else {
      res.send({ ticker: null });
    }
  })
});

express.get('/api/get_ticker', (req, res) => {
  const origin = req.header('origin');
  if (getDomainName(req.get('origin')) == 'betswiz.com' || getDomainName(req.get('origin')) == 'betswiz.in') {
    res.send({ ticker: "", ticker1: [] });
    return null;
  }
  // const sanitizedOrigin = origin?.replace(/^(https?:\/\/)?(ag\.)?/, '');
  const sanitizedOrigin = getDomainName(req.get('origin'));

  // if (!origin) return res.send({ errorCode: 1, result: 'Origin parameter is required.' });
  let filePath;
  let existingDataContent;
  let existingData;
  let tickerDataForOrigin = [];

  if (sanitizedOrigin) {
    filePath = path.join("/enterprise/site_ticker", `${sanitizedOrigin}.json`);
    existingDataContent = fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf-8') : null;
    existingData = existingDataContent ? JSON.parse(existingDataContent).data : null;
    tickerDataForOrigin = existingData || [];
  }


  fs.readFile('../../store_site_ticker/ticker.json', 'utf8', (err, data) => {
    if (err) {
      return res.send({ ticker: "", ticker1: [] });
    }
    if (data) {
      // if (getDomainName(req.get('origin')) == 'jio25.live') {
      //   data = data.replace('PARLAY/MULTI BETS AVAILABLE ||', '');
      // }
      data = JSON.parse(data);
      const userType0Data = tickerDataForOrigin.filter(entry => String(entry.userType) === "0");
      return res.send({ ticker: data, ticker1: userType0Data });
    } else {
      return res.send({ ticker: "", ticker1: [] });
    }
  });
});



function formatBmFancy(data) {
  let BM_FancyData = {
    "BMmarket": {},
    "Fancymarket": [],
  }
  if (!data.data) {
    return BM_FancyData;
  }
  if (data.data) {
    data = data.data;
  }
  if (data.t2) {
    BM_FancyData.BMmarket = data.t2[0];
  }
  if (data.t3) {
    BM_FancyData.Fancymarket = data.t3;

  }
  return BM_FancyData;
}

express.get('/api/bm_fancy/:gameId', function (req, res) {
  var clientIp = getCallerIP(req);
  if (!req.get('referrer')) {
    console.log(req.get('referrer'), clientIp[0], req.get('origin'), 'bm_fancy');
  }
  if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
    res.send({ errMsg: "Invalid authentication" });
    return null;
  }
  client.get('store_markets' + req.params.gameId, (err, data) => {
    if (data) {
      try {
        data = JSON.parse(data);
      } catch (err) {
        console.error(err)
      }
      res.send(formatBmFancy(data));

    } else {
      fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
        if (err) {
          res.send(null);
          return null;
        }
        if (data) {
          try {
            data = JSON.parse(data);
          } catch (err) {
            console.error(err)
          }
          res.send(formatBmFancy(data));
        }
        else {
          res.send(null);
        }
      })
    }
  });
});

express.get('/api/bm_fancy/:gameId/:fSource', function (req, res) {
  var clientIp = getCallerIP(req);
  if (!req.get('referrer')) {
    console.log(req.get('referrer'), clientIp[0], req.get('origin'), 'bm_fancy');
  }
  // console.log(clientIp[0],getDomainName(req.get('origin')))
  if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
    res.send({ errMsg: "Invalid authentication" });
    return null;
  }

  if (req.params.fSource == 0) {
    client.get('store_markets' + req.params.gameId, (err, data) => {
      // console.log(data)
      if (data) {
        try {
          data = JSON.parse(data);
        } catch (err) {
          console.error(err)
        }

        // data = JSON.parse(data);
        data.data['t1'] = null;
        data.data['t4'] = null;


        if (data['eventTypeName'] == "football") {
          data['eventTypeName'] = "Soccer";
        }


        res.send(formatBmFancy(data));


        // res.send(data);
      } else {
        fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
          if (err) {
            res.send(null);
            // console.error(err)
            return null;
          }
          // console.log(data)
          if (data) {
            try {
              data = JSON.parse(data);
            } catch (err) {
              console.error(err)
            }
            // data = JSON.parse(data);
            data.data['t1'] = null;
            data.data['t4'] = null;

            if (data['eventTypeName'] == "football") {
              data['eventTypeName'] = "Soccer";
            }
            res.send(formatBmFancy(data));


            // res.send(data);
          }
          else {
            res.send(null);
          }
        })
      }
    });
  } else {

    client.get('store_sky_markets' + req.params.gameId, (err, data) => {
      if (data) {
        try {
          data = JSON.parse(data);
        } catch (err) {
          console.error(err)
        }
        res.send(formatBmFancy(data));
      } else {
        var config = {
          method: 'get',
          url: 'https://api3.streamingtv.fun:3470/api/bm_fancy/' + req.params.gameId,
        };

        axios(config)
          .then(function (response) {
            response.data = formatBmFancy(response.data)
            res.send(response.data);
          })
          .catch(function (error) {
            res.send(null);

          });
      }
    });

  }

});

express.get('/api/bm_fancy2/:gameId', function (req, res) {

  client.get('store_markets' + req.params.gameId, (err, data) => {
    if (data) {
      try {
        data = JSON.parse(data);
      } catch (err) {
        console.error(err)
      }
      res.send(data);

    } else {
      fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
        if (err) {
          res.send(null);
          return null;
        }
        if (data) {
          try {
            data = JSON.parse(data);
          } catch (err) {
            console.error(err)
          }
          res.send(data);
        }
        else {
          res.send(null);
        }
      })
    }
  });
});

express.get('/api/sports_book/:eventId', function (req, res) {
  var clientIp = getCallerIP(req);
  // if (!req.get('referrer')) {
  //   console.log(req.get('referrer'), clientIp[0], req.get('origin'), 'sportbook');
  // }
  // if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
  //   res.send({ errMsg: "Invalid authentication" });
  //   return null;
  // }
  // // if (getDomainName(req.get('origin')) != 'betskyexch.com') {
  // //   res.send({ data: null, eventId: req.params.eventId });
  // //   return null;
  // // }
  client.get('store_sky_sportbook' + req.params.eventId, (err, data) => {
    if (data) {
      res.send(data);
    } else {
      // fs.readFile('../../store_sky_sportbook/' + req.params.eventId + '.json', 'utf8', (err, data) => {
      //   if (err) {
      //     res.send({ data: null, eventId: req.params.eventId });
      //     return null;
      //   }
      //   if (data) {
      //     res.send(data);
      //   }
      // else {
      res.send({ data: null, eventId: req.params.eventId });
      //     }
      //   })
    }
  });
});

function doSomethingSportBookAsync(eventId) {
  return new Promise((resolve) => {

    client.get('store_sky_sportbook' + eventId, (err, data) => {
      if (data) {
        data = JSON.parse(data);
        resolve(data);
      } else {
        fs.readFile('../../store_sky_sportbook/' + eventId + '.json', 'utf8', (err, data) => {
          if (err) {
            resolve({ data: null, eventId: eventId });
            return null;
          }
          if (data) {
            data = JSON.parse(data);
            resolve(data);
          }
          else {
            resolve({ data: null, eventId: eventId });
          }
        })
      }
    });

  });
}
function getFormatSportBookData(results) {
  let resultData = {};
  for (let i = 0; i < results.length; i++) {
    resultData[results[i].eventId] = results[i];
  }
  return resultData;
}

express.get('/api/sports_book_multi/:eventIds', function (req, res) {
  var clientIp = getCallerIP(req);
  if (!req.get('referrer')) {
    console.log(req.get('referrer'), clientIp[0], req.get('origin'), 'sportbook');
  }
  if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
    res.send({ errMsg: "Invalid authentication" });
    return null;
  }
  let splitEventIds = req.params.eventIds.split(',');
  const promises = [];
  for (let i = 0; i < splitEventIds.length; i++) {
    promises.push(doSomethingSportBookAsync(splitEventIds[i]));
  }
  Promise.all(promises)
    .then((results) => {
      res.send(getFormatSportBookData(results));
    })
    .catch((e) => {
      res.send(e);
    });
});

express.get('/api/d_rate/:gtype', function (req, res) {
  var clientIp = getCallerIP(req);
  if (!req.get('referrer')) {
    console.log(req.get('referrer'), clientIp[0], req.get('origin'), 'tp');
  }
  if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
    res.send({ errMsg: "Invalid authentication" });
    return null;
  }
  fs.readFile('../../store_diamond_teenpatti_rates/' + req.params.gtype + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, gtype: req.params.gtype });
      return null;
    }
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: null, gtype: req.params.gtype });
    }
  })
});
express.get('/api/l_result/:gtype', function (req, res) {
  var clientIp = getCallerIP(req);
  if (!req.get('referrer')) {
    console.log(req.get('referrer'), clientIp[0], req.get('origin'), 'tp_result');
  }
  if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
    res.send({ errMsg: "Invalid authentication" });
    return null;
  }
  fs.readFile('../../store_diamond_teenpatti_last_result/' + req.params.gtype + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, gtype: req.params.gtype });
      return null;
    }
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: null, gtype: req.params.gtype });
    }
  })
});
express.get('/api/r_result/:gtype/:rid', function (req, res) {
  var clientIp = getCallerIP(req);
  // if (!req.get('referrer')) {
  //   console.log(req.get('referrer'), clientIp[0], req.get('origin'),'tp_result_r');
  // }
  if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
    res.send({ errMsg: "Invalid authentication" });
    return null;
  }
  fs.readFile('../../store_diamond_teenpatti_popup_result/' + req.params.gtype + '_' + req.params.rid + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, gtype: req.params.gtype, rid: req.params.rid });
      return null;
    }
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: null, gtype: req.params.gtype, rid: req.params.rid });
    }
  })
});

express.get('/api/eventresults/:sportId/:type', function (req, res) {
  var clientIp = getCallerIP(req);
  // if (!req.get('referrer')) {
  //   console.log(req.get('referrer'), clientIp[0], req.get('origin'),'score_result');
  // }
  if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {
    res.send({ errMsg: "Invalid authentication" });
    return null;
  }
  fs.readFile('../../store_sky_event_result/' + req.params.sportId + '_' + req.params.type + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: [] });
      return null;
    }
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: [] });
    }
  })
});

express.get('/api/queryMarketDepth/:marketId/:selectionId', function (req, res) {
  var config = {
    method: 'get',
    url: 'http://175.111.97.41:3030/api/queryMarketDepth/' + req.params.marketId + '/' + req.params.selectionId,
    headers: {
    }
  };
  axios(config)
    .then(function (response) {
      res.send(response.data);
    })
    .catch(function (error) {
      console.log('error');
    });
});

express.get('/api/LoadRunnerInfoChartAction/:marketId/:selectionId/:logarithmic', function (req, res) {
  var config = {
    method: 'get',
    url: 'https://xtsd.betfair.com/LoadRunnerInfoChartAction/?marketId=' + req.params.marketId + '&selectionId=' + req.params.selectionId + '&handicap=0&logarithmic=' + req.params.logarithmic,
    responseType: 'arraybuffer'
  };
  axios(config)
    .then(function (response) {
      res.send(JSON.stringify(Buffer.from(response.data, 'binary').toString('base64')));
    })
    .catch(function (error) {
      console.log('error');
    });
});

// enabled_ports.forEach((element, index) => {
//   element.app.listen(element.port, function () {
//     console.log('listening on *:' + element.port);
//   });
// });

express.get('/api/getIpDetails/:ip', function (req, res) {
  var config = {
    method: 'get',
    url: 'https://pro.ip-api.com/json/' + req.params.ip + '?key=jsDMBilMXhi68Vs',
    headers: {
    }
  };
  axios(config)
    .then(function (response) {
      res.send(response.data);
    })
    .catch(function (error) {
      console.log('error');
    });
});


express.get('/api/score_id/:domain', function (req, res) {
  // // get the Console class
  // const { Console } = require("console");
  // // make a new logger
  // const myLogger = new Console({
  //   stdout: fs.createWriteStream("domainsList.txt"),
  //   // stderr: fs.createWriteStream("errStdErr.txt"),
  // });
  // myLogger.log(req.params.domain)

  let content = req.params.domain;
  content += "\n";
  fs.appendFile("store_domain.txt", content, (err) => {
    // return console.log(err);
  });
  console.log(req.params.domain)
  res.send('ok');
});


app.listen(process.env.PORT, function () {
  console.log('listening on port*:' + process.env.PORT);
});


