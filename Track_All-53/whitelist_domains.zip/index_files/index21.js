// npm install pm2 -g
// pm2 start server.js --exp-backoff-restart-delay=100
// pm2 stop index.js

var express = require('express')();
//var http = require('http').createServer(app);
var fs = require('fs');
var https = require('https');
var axios = require('axios');

const { json } = require('express');

const redis = require('redis');
const redisPort = 6379;
const client = redis.createClient(redisPort);


var options = {
  key: fs.readFileSync('./ssl/api2.streamingtv.fun/api2.streamingtv.fun-key.pem'),
  cert: fs.readFileSync('./ssl/api2.streamingtv.fun/api2.streamingtv.fun-crt.pem'),
  ca: fs.readFileSync('./ssl/api2.streamingtv.fun/api2.streamingtv.fun-chain.pem'),
}
var options2 = {
  key: fs.readFileSync('./ssl/score2.streamingtv.fun/score2.streamingtv.fun-key.pem'),
  cert: fs.readFileSync('./ssl/score2.streamingtv.fun/score2.streamingtv.fun-crt.pem'),
  ca: fs.readFileSync('./ssl/score2.streamingtv.fun/score2.streamingtv.fun-chain.pem'),
}
var app = https.createServer(options, express);

app.addContext('score2.streamingtv.fun', options);


var io = require('socket.io')(https);
var _ = require('lodash');

var cors = require('cors')

express.use(cors());
// express.use(function(req, res, next) {
//   res.header("Access-Control-Allow-Origin", "*");
//   res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//   next();
// })

express.get('/', function (req, res) {
  res.send('Hello world');
});


// setInterval(() => {
//   fs.readdir('../../store_sky_sportbook/', (err, files) => {
//     files.forEach(file => {
//       // console.log(file);
//       fs.unlinkSync('../../store_sky_sportbook/' + file);
//     });
//   });

// }, 180 * 1000);

let hostNames = [
  "78.141.233.65",
  "45.76.128.133",
  "78.141.230.81",
  "18.134.247.58",

  "lc247.xyz",
  "lc247.live",
  "lc247.bet",
  "lc365.in",

  "runexch.pro",
  "lc247.co",
  "winplus99.com",
  "winplus247.com",
  "sky-exch.com",
  "baajighor365.live",
  "tripbets.io",
  "betx365.asia",
  "lcbuzz.com",
  "runexch.co",
  "betbuzz369.live",
  "bajix365.vip",
  "baaji24.live",
"maza246.live",
  "winbet365.win",
  "vellkei.live",
  "velkei.live",
  "betfair365.bet",
  "betswiz.in",
  "vellkii.live",
  "playbet365.live",
  "fiarsky.com",
  "velkiex123.bet",
  "palki.bet",
  
  "neyaludis.live",
  "bet-365.bet",
  "4wickets.com",
  
  "9wickets.bet",
   "baaji365.bet",
"baaji365.pro",
  "runexch365.io",
  "cricbuzz365.live",
  
  "3wickets.bet",
  "winbuzz.asia",
  
  "skyexch.win",
  "velkibuzz.bet",
  "bett365.live",
  "bdwicket.com",
  "xpgexch.com",
  "betwinners.live",
  "baaji365vip.live",
  "skyexch777.net",
  "4wickets.in",
  "runx.bet",
  "sports365.pro",
  
  "lc247.life",
  "skyfair.life",
  "9ex365.bet",
  "bajimat.win",
  "bajimat.site",
  "velkii.bet",
  "sportss365.vip",
  "dreamcric247.com",

  "localhost:5500",
  "localhost:5501",
  "localhost:5502",
  "localhost:3200",
  "localhost:3201",
  "localhost:3202",
  "localhost:4200",
  "localhost:4300",
  "localhost:4201",
  "localhost:4202",
  "localhost:4203",
  "localhost:4204",

  "localhost:8081",
  "localhost:8082",
  "localhost:8083",
];

let domainsName0 = [
  "lc247.xyz",
  "lc365.in",
]

function getCallerIP(request) {
  var ip = request.headers['x-forwarded-for'] ||
    request.connection.remoteAddress ||
    request.socket.remoteAddress ||
    request.connection.socket.remoteAddress;
  ip = ip.split(',')[0];
  ip = ip.split(':').slice(-1); //in case the ip returned in a format: "::ffff:146.xxx.xxx.xxx"
  return ip;
}

function getDomainName(hostName) {
  if (!hostName) {
    return;
  }
  let formatedHost = "";
  let splithostName = hostName.split('.');
  if (splithostName.length > 2) {
    formatedHost = hostName.substring(hostName.lastIndexOf(".", hostName.lastIndexOf(".") - 1) + 1);
  } else {
    formatedHost = hostName.split('//')[1]
  }
  return formatedHost;
}

express.post('/api/store_all_apis', json({ type: '*/*' }), function (req, res) {

  var content = JSON.stringify(req.body);
  fs.writeFile('../../store_vrnl_apis/all_apis_vrnl.json', content, (err) => {
    // console.log(err)
    if (err) {
      res.send({ result: "failed" })
      throw err;
    }
    // console.log('File saved!');
    res.send({ result: "Data saved!" })
  });


});

express.post('/api/store_ticker', json({ type: '*/*' }), function (req, res) {

  var content = JSON.stringify(req.body.ticker);

  fs.writeFile('../../store_site_ticker/ticker.json', content, (err) => {
    // console.log(err)
    if (err) {
      res.send({ result: "failed" })
      throw err;
    }
    // console.log('File saved!');
    res.send({ result: "ticker saved!" })
  });

});

express.get('/api/all_apis', function (req, res) {

  // var clientIp = requestIp.getClientIp(req);
  // var clientIp = getCallerIP(req);



  // console.log(clientIp[0])

  // if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1) {

  //     res.send({errMsg:"Invalid authentication"});
  //     // console.error(err)
  //     return null;
  // }
  // console.log(req.get('origin'));
  const data = fs.readFile('../../store_vrnl_apis/all_apis_vrnl.json', 'utf8', (err, data) => {
    if (err) {
      res.send(null);
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      try {
        data = JSON.parse(data);
      } catch (err) {
        console.error(err)
      }

      // if (domainsName0.indexOf(getDomainName(req.get('origin'))) > -1) {
      data.sslclient = data.lc247 + '/pad=82';
      data.ssladmin = data.lc247Admin + '/pad=81';
      data.adminReport = data.ssladmin;
      data.scoreApi = data.scoreApiLc247;
      data.fanApi = data.fanApiLc247;
      data.premiumApi = data.premiumApiLc247;

      data.sslSportApi = data.sslSportApiLc247;
      data.sslsportSocketApi = data.sslsportSocketApiLc247;
      // data.sslSportApi = data.sslSportApiEasy;
      // data.sslsportSocketApi = data.sslsportSocketApiEasy;
      // }

      let respData = {};
      respData['devAdminIp'] = data.devAdminIp;
      respData['devIp'] = data.devIp;
      respData['sportApi'] = data.sportApi;
      respData['sportSocketApi'] = data.sportSocketApi;
      respData['liveTvApi'] = data.liveTvApi;
      respData['scoreApi'] = data.scoreApi;
      respData['fanApi'] = data.fanApi;
      respData['fancyApi'] = data.fanApi;
      respData['premiumApi'] = data.premiumApi;
      respData['casApi'] = data.casApi;
      respData['casinoApi'] = data.casApi;
      respData['sslRacingApi'] = data.sslRacingApi;
      respData['sslracingSocketApi'] = data.sslracingSocketApi;
      respData['sslAllSportApi'] = data.sslAllSportApi;
      respData['sslAllSportSocketApi'] = data.sslAllSportSocketApi;
      respData['sslExchangeGamesApi'] = data.sslExchangeGamesApi;
      respData['sslSportApi'] = data.sslSportApi;
      respData['sslsportSocketApi'] = data.sslsportSocketApi;
      respData['ssladmin'] = data.ssladmin;
      respData['adminReport'] = data.adminReport;
      respData['sslclient'] = data.sslclient;
      respData['fSource'] = data.fSource;
      respData['maintanance'] = data.maintanance;
      respData['AngelaApi'] = data.AngelaApi;



      res.send(respData);
    }
    else {
      res.send(null);
    }
  })
});

express.get('/score_api/:id', function (req, res) {

  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  // console.log(req.get('origin'));

  client.get('store_scores' + req.params.id, (err, data) => {
    if (data) {
      res.send(data);
    }
    else {
      const data = fs.readFile('../../store_scores/' + req.params.id + '.json', 'utf8', (err, data) => {
        if (err) {
          // res.send({ score: null, eventId: req.params.id });
          const data = fs.readFile('../../store_scores/' + req.params.id + '_4.json', 'utf8', (err, data) => {
            if (err) {
              res.send({ score: null, eventId: req.params.id });
              // console.error(err)
              return null;
            }
            // console.log(data)
            if (data) {
              res.send(data);
            }
            else {
              res.send({ score: null, eventId: req.params.id });
            }
          })
          // console.error(err)
          return null;
        }
        // console.log(data)
        if (data) {
          res.send(data);
        }
        else {
          res.send({ score: null, eventId: req.params.id });
        }
      })
    }

  })

});
function getFormattedScore(data) {

  let scoreData = [];
  _.forEach(data, (item) => {
    let scoretext = "";
    if (item.eventTypeId == 2) {
      scoretext = '(' + item?.score?.home.sets + ') ' + item?.score?.home.games + ' - ' + item?.score?.away.games + ' (' + item?.score?.away.sets + ') ';
      scoreData.push({ eventId: item.eventId, score: scoretext });
    }

    if (item.eventTypeId == 1) {
      scoretext = item?.score?.home.score + ' - ' + item?.score?.away.score;
      scoreData.push({ eventId: item.eventId, score: scoretext, timeElapsed: item.timeElapsed + "'" });
    }
  })
  return scoreData;
}

express.get('/get_all_score', function (req, res) {

  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  // // console.log(req.get('origin'));

  client.get('store_all_scores', (err, data) => {
    if (data) {

      res.send(getFormattedScore(JSON.parse(data)));
    } else {
      res.send([]);
    }
  })

});

express.get('/api/getScoreId/:eventid', function (req, res) {

  https.get('https://streamingtv.fun/VRN/v1/api/scoreid/get?eventid=' + req.params.eventid, (resp) => {

    // console.log(resp)
    let data = '';

    // // A chunk of data has been received.
    resp.on('data', (chunk) => {
      data += chunk;
    });

    // // The whole response has been received. Print out the result.
    resp.on('end', () => {
      data = JSON.parse(data);
      res.send(data);
    });

  }).on("error", (err) => {
    // console.log("Error: " + err.message);
    res.send(err);
  });
});


express.get('/api/sports_book/:eventId', function (req, res) {

  var clientIp = getCallerIP(req);
  // if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

  //   res.send({ errMsg: "Invalid authentication" });
  //   // console.error(err)
  //   return null;
  // }
  fs.readFile('../../store_sky_sportbook/' + req.params.eventId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.eventId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.eventId });
    }
  })
});

express.get('/api/get_ticker', function (req, res) {

  const data = fs.readFile('../../store_site_ticker/ticker.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ ticker: null });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      data = JSON.parse(data);
      res.send({ ticker: data });
    }
    else {
      res.send({ ticker: null });
    }
  })
});

function formatBmFancy(data) {
  let BM_FancyData = {
    "BMmarket": {},
    "Fancymarket": [],
  }


  if (!data.data) {
    return BM_FancyData;
  }
  // console.log(data)
  if (data.data) {
    data = data.data;
  }



  if (data.t2) {
    BM_FancyData.BMmarket = data.t2[0];
  }
  if (data.t3) {
    // BM_FancyData.Fancymarket.push(data.t3);
    BM_FancyData.Fancymarket = data.t3;

  }
  if (data.t4) {
    // BM_FancyData.Fancymarket.push(data.t4);
  }

  return BM_FancyData;

}

express.get('/api/bm_fancy/:gameId', function (req, res) {
  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  // if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

  //   res.send({ errMsg: "Invalid authentication" });
  //   // console.error(err)
  //   return null;
  // }

  if (req.params.gameId > 0) {
    // console.log(req.params.gameId)

    client.get('store_markets' + req.params.gameId, (err, data) => {
      // console.log(data)
      if (data) {
        try {
          data = JSON.parse(data);
        } catch (err) {
          console.error(err)
        }
        // data = JSON.parse(data);
        data.data['t1'] = null;
        data.data['t4'] = null;


        if (data['eventTypeName'] == "football") {
          data['eventTypeName'] = "Soccer";
        }


        res.send(formatBmFancy(data));


        // res.send(data);
      } else {
        const data = fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
          if (err) {
            res.send(null);
            // console.error(err)
            return null;
          }
          // console.log(data)
          if (data) {
            try {
              data = JSON.parse(data);
            } catch (err) {
              console.error(err)
            }
            // data = JSON.parse(data);
            data.data['t1'] = null;
            data.data['t4'] = null;

            if (data['eventTypeName'] == "football") {
              data['eventTypeName'] = "Soccer";
            }
            res.send(formatBmFancy(data));


            // res.send(data);
          }
          else {
            res.send(null);
          }
        })
      }
    });


    // const data = fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
    //   if (err) {
    //     res.send(null);
    //     // console.error(err)
    //     return null;
    //   }
    //   // console.log(data)
    //   if (data) {
    //     try {
    //       data = JSON.parse(data);
    //     } catch (err) {
    //       console.error(err)
    //     }
    //     // data = JSON.parse(data);
    //     data.data['t1'] = null;
    //     data.data['t4'] = null;

    //     if (data['eventTypeName'] == "football") {
    //       data['eventTypeName'] = "Soccer";
    //     }
    //     res.send(formatBmFancy(data));


    //     // res.send(data);
    //   }
    //   else {
    //     res.send(null);
    //   }
    // })

  } else {
    // console.log(req.params.gameId);
    var config = {
      method: 'get',
      url: 'https://streamingtv.fun:34477/api/bm_fancy/' + req.params.gameId,
    };

    axios(config)
      .then(function (response) {
        // console.log(JSON.stringify(response));

        response.data = formatBmFancy(response.data)
        res.send(response.data);
      })
      .catch(function (error) {
        // console.log(error);
        res.send(null);

      });
  }

});

express.get('/api/bm_fancy/:gameId/:fSource', function (req, res) {
  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  // if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

  //   res.send({ errMsg: "Invalid authentication" });
  //   // console.error(err)
  //   return null;
  // }

  if (req.params.gameId > 0) {
    // console.log(req.params.gameId)

    if (req.params.fSource == 0) {
      client.get('store_markets' + req.params.gameId, (err, data) => {
        // console.log(data)
        if (data) {
          try {
            data = JSON.parse(data);
          } catch (err) {
            console.error(err)
          }
          // data = JSON.parse(data);
          data.data['t1'] = null;
          data.data['t4'] = null;


          if (data['eventTypeName'] == "football") {
            data['eventTypeName'] = "Soccer";
          }


          res.send(formatBmFancy(data));


          // res.send(data);
        } else {
          const data = fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
            if (err) {
              res.send(null);
              // console.error(err)
              return null;
            }
            // console.log(data)
            if (data) {
              try {
                data = JSON.parse(data);
              } catch (err) {
                console.error(err)
              }
              // data = JSON.parse(data);
              data.data['t1'] = null;
              data.data['t4'] = null;

              if (data['eventTypeName'] == "football") {
                data['eventTypeName'] = "Soccer";
              }
              res.send(formatBmFancy(data));


              // res.send(data);
            }
            else {
              res.send(null);
            }
          })
        }
      });
    } else {

      client.get('store_sky_markets' + req.params.gameId, (err, data) => {
        // console.log(data)
        if (data) {
          try {
            data = JSON.parse(data);
          } catch (err) {
            console.error(err)
          }
          res.send(formatBmFancy(data));
        } else {
          var config = {
            method: 'get',
            url: 'https://api2.streamingtv.fun:3442/api/bm_fancy/' + req.params.gameId,
          };

          axios(config)
            .then(function (response) {
              // console.log(JSON.stringify(response));

              response.data = formatBmFancy(response.data)
              res.send(response.data);
            })
            .catch(function (error) {
              // console.log(error);
              res.send(null);

            });
        }
      });

    }




    // const data = fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
    //   if (err) {
    //     res.send(null);
    //     // console.error(err)
    //     return null;
    //   }
    //   // console.log(data)
    //   if (data) {
    //     try {
    //       data = JSON.parse(data);
    //     } catch (err) {
    //       console.error(err)
    //     }
    //     // data = JSON.parse(data);
    //     data.data['t1'] = null;
    //     data.data['t4'] = null;

    //     if (data['eventTypeName'] == "football") {
    //       data['eventTypeName'] = "Soccer";
    //     }
    //     res.send(formatBmFancy(data));


    //     // res.send(data);
    //   }
    //   else {
    //     res.send(null);
    //   }
    // })

  } else {
    // console.log(req.params.gameId);
    var config = {
      method: 'get',
      url: 'https://streamingtv.fun:34477/api/bm_fancy/' + req.params.gameId,
    };

    axios(config)
      .then(function (response) {
        // console.log(JSON.stringify(response));

        response.data = formatBmFancy(response.data)
        res.send(response.data);
      })
      .catch(function (error) {
        // console.log(error);
        res.send(null);

      });
  }

});



express.get('/api/sky_book/:eventId', function (req, res) {

  // var clientIp = getCallerIP(req);
  // // console.log(clientIp)

  // if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

  //   res.send({ errMsg: "Invalid authentication" });
  //   // console.error(err)
  //   return null;
  // }
  fs.readFile('../../store_sky_book/' + req.params.eventId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.eventId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.eventId });
    }
  })
});

express.get('/api/sky_fancy/:eventId', function (req, res) {

  // var clientIp = getCallerIP(req);
  // // console.log(clientIp)

  // if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

  //   res.send({ errMsg: "Invalid authentication" });
  //   // console.error(err)
  //   return null;
  // }
  fs.readFile('../../store_sky_fancy/' + req.params.eventId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.eventId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.eventId });
    }
  })
});

express.get('/api/eventresults/:sportId/:type', function (req, res) {

  const data = fs.readFile('../../store_sky_event_result/' + req.params.sportId + '_' + req.params.type + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: [] });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: [] });
    }
  })
});

express.get('/api/queryMarketDepth/:marketId/:selectionId', function (req, res) {

  var config = {
    method: 'get',
    url: 'http://175.111.97.41:3030/api/queryMarketDepth/' + req.params.marketId + '/' + req.params.selectionId,
    headers: {
    }
  };

  axios(config)
    .then(function (response) {
      res.send(response.data);
      // console.log(JSON.stringify(response.data));
    })
    .catch(function (error) {
      console.log(error);
    });
});



express.get('/api/LoadRunnerInfoChartAction/:marketId/:selectionId/:logarithmic', function (req, res) {


  var config = {
    method: 'get',
    url: 'https://xtsd.betfair.com/LoadRunnerInfoChartAction/?marketId=' + req.params.marketId + '&selectionId=' + req.params.selectionId + '&handicap=0&logarithmic=' + req.params.logarithmic,
    responseType: 'arraybuffer'
  };

  axios(config)
    .then(function (response) {
      res.send(JSON.stringify(Buffer.from(response.data, 'binary').toString('base64')));
      // const buffer = Buffer.from(response.data, 'base64');
      // res.send(buffer);

      // var reader = new window.FileReader();
      // reader.readAsDataURL(response.data); 
      // reader.onload = function() {

      //     var imageDataUrl = reader.result;
      //     imageElement.setAttribute("src", imageDataUrl);

      // }
      // let imgUrl = URL.createObjectURL(response.data)
      // res.send(imgUrl);

      // res.send(response.data);
      // console.log(JSON.stringify(response.data));
    })
    .catch(function (error) {
      console.log(error);
    });
});

app.listen(3461, function () {
  console.log('listening on *:3461');
});

