// npm install pm2 -g
// pm2 start server.js --exp-backoff-restart-delay=100
// pm2 stop index.js

var express = require('express')();
//var http = require('http').createServer(app);
var fs = require('fs');
var https = require('https');
var axios = require('axios');

const { json } = require('express');
var moment = require('moment');

const redis = require('redis');
const redisPort = 6379;
const client = redis.createClient(redisPort);


var options = {
  key: fs.readFileSync('./ssl/api2.streamingtv.fun/api2.streamingtv.fun-key.pem'),
  cert: fs.readFileSync('./ssl/api2.streamingtv.fun/api2.streamingtv.fun-crt.pem'),
  ca: fs.readFileSync('./ssl/api2.streamingtv.fun/api2.streamingtv.fun-chain.pem'),
}
var options2 = {
  key: fs.readFileSync('./ssl/score2.streamingtv.fun/score2.streamingtv.fun-key.pem'),
  cert: fs.readFileSync('./ssl/score2.streamingtv.fun/score2.streamingtv.fun-crt.pem'),
  ca: fs.readFileSync('./ssl/score2.streamingtv.fun/score2.streamingtv.fun-chain.pem'),
}
var app = https.createServer(options, express);

app.addContext('score2.streamingtv.fun', options);


var io = require('socket.io')(https);
var _ = require('lodash');

var cors = require('cors')

express.use(cors());
// express.use(function(req, res, next) {
//   res.header("Access-Control-Allow-Origin", "*");
//   res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//   next();
// })

express.get('/', function (req, res) {
  res.send('Hello world');
});



let hostNames = [
  "78.141.233.65",
  "45.76.128.133",
  "78.141.230.81",
  "35.179.70.8",
  "18.135.89.19",
  "196.235.42.92",
  "78.141.197.32",
  "209.250.242.175",//coder odds server
  "136.244.79.114",//coder fancy server
  "18.135.122.161",//coder lc server
  "13.41.211.5",//coder odds server
  "18.132.108.166",
  "13.41.211.5",
  "3.8.53.74",
  "3.9.88.93",
  "196.235.87.190",//coder local
  "18.134.247.58",//lc server
  // "18.133.89.1",// hypex alternative odds server
  "51.195.220.62",//coder testing server
  "196.235.138.36",
  "196.235.226.141",
  "196.235.235.83",
  "196.235.197.15",//coder new
  "196.235.160.180", //coder local
  "196.235.159.81",
  "78.141.244.211",
  // "78.141.232.77",
  "192.248.159.250",
  "192.248.154.109",
  "196.234.196.242",
  "196.235.80.192",
  "196.235.181.223",
  "196.235.28.60",
  "18.169.251.254",
  "18.130.162.108",//
  "18.133.46.50",
  "35.179.70.8",
  "18.135.89.19",
  "18.169.251.254",
  "3.10.40.240",
  "35.177.255.110",
  "136.244.77.249",
  "18.168.9.94",
  "45.32.176.187",
  "13.41.5.203",//dev
  "196.234.182.6",
  "13.40.241.144",
  "185.225.233.199",
  "18.182.1.111",
  // "45.76.130.41",//dream ip
  // "35.78.178.117",//sikwin server
  // "43.204.85.214",// sikwin
  // "13.41.154.164",//sikwin
];

function getCallerIP(request) {
  var ip = request.headers['x-forwarded-for'] ||
    request.connection.remoteAddress ||
    request.socket.remoteAddress ||
    request.connection.socket.remoteAddress;
  ip = ip.split(',')[0];
  ip = ip.split(':').slice(-1); //in case the ip returned in a format: "::ffff:146.xxx.xxx.xxx"
  return ip;
}

express.get('/api/fancy_result/:eventId/:fancyName', function (req, res) {

  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }

  if (req.params.fancyName) {
    req.params.fancyName = req.params.fancyName.trim();
  }

  const data = fs.readFile('../../store_fancy_result/' + req.params.eventId + '_' + req.params.fancyName + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ result: null });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      // data = JSON.parse(data);
      res.send({ result: data });
    }
    else {
      res.send({ result: null });
    }
  })
});

express.get('/api/fancy_result/:eventId/:fancyName/:fSource', function (req, res) {

  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }

  if (req.params.fancyName) {
    req.params.fancyName = req.params.fancyName.trim();
  }

  const data = fs.readFile('../../store_fancy_result/' + req.params.eventId + '_' + req.params.fSource + '_' + req.params.fancyName + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ result: null });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      // data = JSON.parse(data);
      res.send({ result: data });
    }
    else {
      res.send({ result: null });
    }
  })
});

express.get('/score_api/:id', function (req, res) {

  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  // console.log(req.get('origin'));
  const data = fs.readFile('../../store_scores/' + req.params.id + '.json', 'utf8', (err, data) => {
    if (err) {
      // res.send({ score: null, eventId: req.params.id });
      const data = fs.readFile('../../store_scores/' + req.params.id + '_4.json', 'utf8', (err, data) => {
        if (err) {
          res.send({ score: null, eventId: req.params.id });
          // console.error(err)
          return null;
        }
        // console.log(data)
        if (data) {
          res.send(data);
        }
        else {
          res.send({ score: null, eventId: req.params.id });
        }
      })
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      res.send(data);
    }
    else {
      res.send({ score: null, eventId: req.params.id });
    }
  })
});

express.get('/api/d_rate/:gtype', function (req, res) {

  // var clientIp = getCallerIP(req);
  // // console.log(clientIp)

  // if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

  //   res.send({ errMsg: "Invalid authentication" });
  //   // console.error(err)
  //   return null;
  // }

  // if (casinoType.indexOf(req.params.gtype) == -1) {
  //   res.send({ data: null, gtype: req.params.gtype });
  //   // console.error(err)
  //   return null;
  // }
  const data = fs.readFile('../../store_diamond_teenpatti_rates/' + req.params.gtype + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, gtype: req.params.gtype });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      // data = JSON.parse(data);

      res.send(data);
    }
    else {
      res.send({ data: null, gtype: req.params.gtype });
    }
  })
});
express.get('/api/l_result/:gtype', function (req, res) {

  // var clientIp = getCallerIP(req);
  // // console.log(clientIp)

  // if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

  //   res.send({ errMsg: "Invalid authentication" });
  //   // console.error(err)
  //   return null;
  // }
  // if (casinoType.indexOf(req.params.gtype) == -1) {
  //   res.send({ data: null, gtype: req.params.gtype });
  //   // console.error(err)
  //   return null;
  // }
  const data = fs.readFile('../../store_diamond_teenpatti_last_result/' + req.params.gtype + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, gtype: req.params.gtype });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      // data = JSON.parse(data);

      res.send(data);
    }
    else {
      res.send({ data: null, gtype: req.params.gtype });
    }
  })
});
express.get('/api/r_result/:gtype/:rid', function (req, res) {

  // var clientIp = getCallerIP(req);
  // // console.log(clientIp)

  // if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

  //   res.send({ errMsg: "Invalid authentication" });
  //   // console.error(err)
  //   return null;
  // }
  const data = fs.readFile('../../store_diamond_teenpatti_popup_result/' + req.params.gtype + '_' + req.params.rid + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, gtype: req.params.gtype, rid: req.params.rid });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      // data = JSON.parse(data);

      res.send(data);
    }
    else {
      res.send({ data: null, gtype: req.params.gtype, rid: req.params.rid });
    }
  })
});

function GetMarketName(mktType) {
  if (mktType == "MATCH_ODDS") {
    return "Match Odds"
  } else if (mktType == "OVER_UNDER_05") {
    return "Over/Under 0.5"
  } else if (mktType == "OVER_UNDER_15") {
    return "Over/Under 1.5"
  } else if (mktType == "OVER_UNDER_25") {
    return "Over/Under 2.5"
  } else if (mktType == "OVER_UNDER_35") {
    return "Over/Under 3.5"
  } else if (mktType == "OVER_UNDER_45") {
    return "Over/Under 4.5"
  } else if (mktType == "OVER_UNDER_55") {
    return "Over/Under 5.5"
  } else if (mktType == "OVER_UNDER_65") {
    return "Over/Under 6.5"
  } else if (mktType == "OVER_UNDER_75") {
    return "Over/Under 7.5"
  } else if (mktType == "OVER_UNDER_85") {
    return "Over/Under 8.5"
  } else if (mktType == "ASIAN_HANDICAP") {
    return "Asian Handicap"
  } else if (mktType == "ALT_TOTAL_GOALS") {
    return "Goal Lines"
  } else if (mktType == "HALF_TIME") {
    return "Half Time"
  } else if (mktType == "BOTH_TEAMS_TO_SCORE") {
    return "Both teams to Score?"
  } else if (mktType == "DOUBLE_CHANCE") {
    return "Double Chance"
  } else if (mktType == "DRAW_NO_BET") {
    return "Draw no Bet"
  } else if (mktType == "FIRST_HALF_GOALS_05") {
    return "First Half Goals 0.5"
  } else if (mktType == "FIRST_HALF_GOALS_15") {
    return "First Half Goals 1.5"
  } else if (mktType == "FIRST_HALF_GOALS_25") {
    return "First Half Goals 2.5"
  }
}

// function formatMktData(marketData) {
//   let formattedData = []

//   if (marketData.eventTypeName == "football") {
//     marketData.eventTypeName = "Soccer";
//   }

//   _.forEach(marketData.data?.t1, (item) => {

//     let market = {
//       "sport": marketData.eventTypeName,
//       "sportId": marketData.eventTypeId,
//       "eventId": marketData.gameId,
//       "MarketId": "",
//       "marketName": "",
//       "marketType": "",
//       "source": 1,
//       "IsMarketDataDelayed": false,
//       "Status": "",
//       "IsInplay": false,
//       "inplay": false,
//       "NumberOfRunners": 0,
//       "NumberOfActiveRunners": 0,
//       "TotalMatched": 0,
//       "Runners": []
//     };

//     market.NumberOfRunners = item.length;
//     market.NumberOfActiveRunners = item.length;

//     _.forEach(item, (item2) => {
//       market.MarketId = item2.mid;
//       market.marketName = GetMarketName(item2.mname);
//       market.marketType = item2.mname;
//       market.Status = item2.mstatus;
//       market.IsInplay = item2.iplay == "False" ? false : true;
//       market.inplay = market.IsInplay;

//       let runner = {
//         "SelectionId": item2.sid,
//         "runnerName": item2.nat,
//         "Status": item2.status,
//         "LastPriceTraded": null,
//         "TotalMatched": 0,
//         "ExchangePrices": {
//           "AvailableToBack": [
//             {
//               "price": item2.b1,
//               "size": item2.bs1
//             },
//             {
//               "price": item2.b2,
//               "size": item2.bs2
//             },
//             {
//               "price": item2.b3,
//               "size": item2.bs3
//             }
//           ],
//           "AvailableToLay": [
//             {
//               "price": item2.l1,
//               "size": item2.ls1
//             },
//             {
//               "price": item2.l2,
//               "size": item2.ls2
//             },
//             {
//               "price": item2.l3,
//               "size": item2.ls3
//             }
//           ]
//         }
//       }
//       market.Runners.push(runner);
//     })

//     formattedData.push(market);
//   })
//   return formattedData;

// }
// function formatMktData(marketData) {
//   let formattedData = []

//   if (marketData.eventTypeName == "football") {
//     marketData.eventTypeName = "Soccer";
//   }
//   if (marketData.eventName.indexOf(' T10 v') > -1) {
//     _.forEach(marketData.data?.t2, (item) => {

//       let market = {
//         "sport": marketData.eventTypeName,
//         "sportId": marketData.eventTypeId,
//         "eventId": marketData.gameId,
//         "MarketId": "",
//         "marketName": "",
//         "marketType": "",
//         "source": 1,
//         "IsMarketDataDelayed": false,
//         "Status": "",
//         "IsInplay": false,
//         "inplay": false,
//         "NumberOfRunners": 0,
//         "NumberOfActiveRunners": 0,
//         "TotalMatched": 0,
//         "Runners": []
//       };

//       market.NumberOfRunners = item.bm1.length;
//       market.NumberOfActiveRunners = item.bm1.length;

//       _.forEach(item.bm1, (item2) => {
//         market.MarketId = item2.mid;
//         // market.marketName = GetMarketName(item2.mname);
//         market.marketName = "Match Odds";

//         market.marketType = "MATCH_ODDS";
//         market.Status = "OPEN";
//         market.IsInplay = true;
//         market.inplay = market.IsInplay;

//         let runner = {
//           "SelectionId": '10' + item2.sid,
//           "runnerName": item2.nat,
//           "Status": "ACTIVE",
//           "LastPriceTraded": null,
//           "TotalMatched": 0,
//           "ExchangePrices": {
//             "AvailableToBack": [
//               {
//                 "price": "0.00",
//                 "size": "0.00"
//               },
//               {
//                 "price": "0.00",
//                 "size": "0.00"
//               },
//               {
//                 "price": "0.00",
//                 "size": "0.00"
//               }
//             ],
//             "AvailableToLay": [
//               {
//                 "price": "0.00",
//                 "size": "0.00"
//               },
//               {
//                 "price": "0.00",
//                 "size": "0.00"
//               },
//               {
//                 "price": "0.00",
//                 "size": "0.00"
//               }
//             ]
//           }
//         }
//         market.Runners.push(runner);
//       })

//       formattedData.push(market);
//     })

//   } else {
//     _.forEach(marketData.data?.t1, (item) => {

//       let market = {
//         "sport": marketData.eventTypeName,
//         "sportId": marketData.eventTypeId,
//         "eventId": marketData.gameId,
//         "MarketId": "",
//         "marketName": "",
//         "marketType": "",
//         "source": 1,
//         "IsMarketDataDelayed": false,
//         "Status": "",
//         "IsInplay": false,
//         "inplay": false,
//         "NumberOfRunners": 0,
//         "NumberOfActiveRunners": 0,
//         "TotalMatched": 0,
//         "Runners": []
//       };

//       market.NumberOfRunners = item.length;
//       market.NumberOfActiveRunners = item.length;

//       _.forEach(item, (item2) => {
//         market.MarketId = item2.mid;
//         market.marketName = GetMarketName(item2.mname);
//         market.marketType = item2.mname;
//         market.Status = item2.mstatus;
//         market.IsInplay = item2.iplay == "False" ? false : true;
//         market.inplay = market.IsInplay;

//         let runner = {
//           "SelectionId": item2.sid,
//           "runnerName": item2.nat,
//           "Status": item2.status,
//           "LastPriceTraded": null,
//           "TotalMatched": 0,
//           "ExchangePrices": {
//             "AvailableToBack": [
//               {
//                 "price": item2.b1,
//                 "size": item2.bs1
//               },
//               {
//                 "price": item2.b2,
//                 "size": item2.bs2
//               },
//               {
//                 "price": item2.b3,
//                 "size": item2.bs3
//               }
//             ],
//             "AvailableToLay": [
//               {
//                 "price": item2.l1,
//                 "size": item2.ls1
//               },
//               {
//                 "price": item2.l2,
//                 "size": item2.ls2
//               },
//               {
//                 "price": item2.l3,
//                 "size": item2.ls3
//               }
//             ]
//           }
//         }
//         market.Runners.push(runner);
//       })

//       formattedData.push(market);
//     })
//   }

//   return formattedData;

// }

function formatMktData(marketData) {
  let formattedData = []

  if (marketData.eventTypeName == "football") {
    marketData.eventTypeName = "Soccer";
  }

  if (marketData.eventName && marketData.eventName.indexOf(' T10') > -1) {
    if (marketData.data.t2.length > 0) {
      _.forEach(marketData.data.t2, (item) => {

        let market = {
          "sport": marketData.eventTypeName,
          "sportId": marketData.eventTypeId,
          "eventId": marketData.gameId,
          "MarketId": "",
          "marketName": "",
          "marketType": "",
          "source": 1,
          "IsMarketDataDelayed": false,
          "Status": "",
          "IsInplay": false,
          "inplay": false,
          "NumberOfRunners": 0,
          "NumberOfActiveRunners": 0,
          "TotalMatched": 0,
          "Runners": []
        };

        market.NumberOfRunners = item.bm1.length;
        market.NumberOfActiveRunners = item.bm1.length;

        _.forEach(item.bm1, (item2) => {
          market.MarketId = item2.mid;
          // market.marketName = GetMarketName(item2.mname);
          market.marketName = "Match Odds";

          market.marketType = "MATCH_ODDS";
          market.Status = "OPEN";
          market.IsInplay = true;
          market.inplay = market.IsInplay;

          let runner = {
            "SelectionId": '10' + item2.sid,
            "runnerName": item2.nat,
            "Status": "ACTIVE",
            "LastPriceTraded": null,
            "TotalMatched": 0,
            "ExchangePrices": {
              "AvailableToBack": [
                {
                  "price": "0.00",
                  "size": "0.00"
                },
                {
                  "price": "0.00",
                  "size": "0.00"
                },
                {
                  "price": "0.00",
                  "size": "0.00"
                }
              ],
              "AvailableToLay": [
                {
                  "price": "0.00",
                  "size": "0.00"
                },
                {
                  "price": "0.00",
                  "size": "0.00"
                },
                {
                  "price": "0.00",
                  "size": "0.00"
                }
              ]
            }
          }
          market.Runners.push(runner);
        })

        formattedData.push(market);
      })
    } else if (marketData.data.t3) {

      if (marketData.data.t3.length > 0) {
        let market = {
          "sport": marketData.eventTypeName,
          "sportId": marketData.eventTypeId,
          "eventId": marketData.gameId,
          "MarketId": "",
          "marketName": "",
          "marketType": "",
          "source": 1,
          "IsMarketDataDelayed": false,
          "Status": "",
          "IsInplay": false,
          "inplay": false,
          "NumberOfRunners": 0,
          "NumberOfActiveRunners": 0,
          "TotalMatched": 0,
          "Runners": []
        };

        market.NumberOfRunners = 2;
        market.NumberOfActiveRunners = 2;

        let dataArray = [1, 2];
        let runnerNameArr = marketData.name.split(' v ');
        _.forEach(dataArray, (item2, index) => {
          market.MarketId = marketData.data.t3[0]?.mid;
          // market.marketName = GetMarketName(item2.mname);
          market.marketName = "Match Odds";

          market.marketType = "MATCH_ODDS";
          market.Status = "OPEN";
          market.IsInplay = true;
          market.inplay = market.IsInplay;

          let runner = {
            "SelectionId": '10' + item2,
            "runnerName": runnerNameArr[index],
            "Status": "ACTIVE",
            "LastPriceTraded": null,
            "TotalMatched": 0,
            "ExchangePrices": {
              "AvailableToBack": [
                {
                  "price": "0.00",
                  "size": "0.00"
                },
                {
                  "price": "0.00",
                  "size": "0.00"
                },
                {
                  "price": "0.00",
                  "size": "0.00"
                }
              ],
              "AvailableToLay": [
                {
                  "price": "0.00",
                  "size": "0.00"
                },
                {
                  "price": "0.00",
                  "size": "0.00"
                },
                {
                  "price": "0.00",
                  "size": "0.00"
                }
              ]
            }
          }
          market.Runners.push(runner);
        })
        formattedData.push(market);

      }


    }


  } else {
    _.forEach(marketData.data?.t1, (item) => {

      let market = {
        "sport": marketData.eventTypeName,
        "sportId": marketData.eventTypeId,
        "eventId": marketData.gameId,
        "updatetime": marketData.updatetime,
        "MarketId": "",
        "marketName": "",
        "marketType": "",
        "source": 1,
        "IsMarketDataDelayed": false,
        "Status": "",
        "IsInplay": false,
        "inplay": false,
        "NumberOfRunners": 0,
        "NumberOfActiveRunners": 0,
        "TotalMatched": marketData.gameId.length == 8 ? '5056' : 0,
        "Runners": []
      };

      market.NumberOfRunners = item.length;
      market.NumberOfActiveRunners = item.length;

      _.forEach(item, (item2) => {
        market.MarketId = item2.mid;
        market.marketName = GetMarketName(item2.mname);
        market.marketType = item2.mname;
        market.Status = item2.mstatus;
        market.IsInplay = item2.iplay == "False" ? false : true;
        market.inplay = market.IsInplay;

        let runner = {
          "SelectionId": item2.sid,
          "runnerName": item2.nat,
          "Status": item2.status,
          "LastPriceTraded": null,
          "TotalMatched": 0,
          "ExchangePrices": {
            "AvailableToBack": [
              {
                "price": item2.b1,
                "size": item2.bs1
              },
              {
                "price": item2.b2,
                "size": item2.bs2
              },
              {
                "price": item2.b3,
                "size": item2.bs3
              }
            ],
            "AvailableToLay": [
              {
                "price": item2.l1,
                "size": item2.ls1
              },
              {
                "price": item2.l2,
                "size": item2.ls2
              },
              {
                "price": item2.l3,
                "size": item2.ls3
              }
            ]
          }
        }
        market.Runners.push(runner);
      })

      formattedData.push(market);
    })
  }

  return formattedData;

}

express.get('/api/bf_odds/:gameId', function (req, res) {

  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  client.get('store_markets' + req.params.gameId, (err, data) => {
    // console.log(data)
    if (data) {
      try {
        data = JSON.parse(data);
      } catch (err) {
        console.error(err)
      }
      // data.data.t1 = formatMktData(data);
      // data.data.t2 = null;
      // data.data.t3 = null;
      // data.data.t4 = null;
      data.data = formatMktData(data);


      // res.send(data);

      const dataInfo = fs.readFile('../../store_game_info/' + req.params.gameId + '.json', 'utf8', (err, dataInfo) => {
        if (err) {
          res.send(data);
          return null;

        } else {
          if (dataInfo) {
            dataInfo = JSON.parse(dataInfo);
            data['competitionId'] = dataInfo?.upMenu.menuId;
            data['competitionName'] = dataInfo?.upMenu.name;
            data['competitionType'] = dataInfo?.upMenu.type;


            res.send(data);
          } else {
            res.send(data);
          }

        }
      });
    } else {
      const data = fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
        if (err) {
          res.send({ data: null, eventId: req.params.gameId });
          // console.error(err)
          return null;
        }
        // console.log(data)
        if (data) {
          // data = JSON.parse(data);
          try {
            data = JSON.parse(data);
          } catch (err) {
            console.error(err);
          }
          // data.data.t1 = formatMktData(data);
          // data.data.t2 = null;
          // data.data.t3 = null;
          // data.data.t4 = null;
          data.data = formatMktData(data);


          // res.send(data);

          const dataInfo = fs.readFile('../../store_game_info/' + req.params.gameId + '.json', 'utf8', (err, dataInfo) => {
            if (err) {
              res.send(data);
              return null;

            } else {
              if (dataInfo) {
                dataInfo = JSON.parse(dataInfo);
                data['competitionId'] = dataInfo?.upMenu.menuId;
                data['competitionName'] = dataInfo?.upMenu.name;
                data['competitionType'] = dataInfo?.upMenu.type;


                res.send(data);
              } else {
                res.send(data);
              }

            }
          });
        }
        else {
          res.send({ data: null, eventId: req.params.gameId });
        }
      })
    }
  });

  // const data = fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
  //   if (err) {
  //     res.send({ data: null, eventId: req.params.gameId });
  //     // console.error(err)
  //     return null;
  //   }
  //   // console.log(data)
  //   if (data) {
  //     // data = JSON.parse(data);
  //     try {
  //       data = JSON.parse(data);
  //     } catch (err) {
  //       console.error(err)
  //     }
  //     // data.data.t1 = formatMktData(data);
  //     // data.data.t2 = null;
  //     // data.data.t3 = null;
  //     // data.data.t4 = null;
  //     data.data = formatMktData(data);


  //     // res.send(data);

  //     const dataInfo = fs.readFile('../../store_game_info/' + req.params.gameId + '.json', 'utf8', (err, dataInfo) => {
  //       if (err) {
  //         res.send(data);
  //         return null;

  //       } else {
  //         if (dataInfo) {
  //           dataInfo = JSON.parse(dataInfo);
  //           data['competitionId'] = dataInfo?.upMenu.menuId;
  //           data['competitionName'] = dataInfo?.upMenu.name;
  //           data['competitionType'] = dataInfo?.upMenu.type;


  //           res.send(data);
  //         } else {
  //           res.send(data);
  //         }

  //       }
  //     });
  //   }
  //   else {
  //     res.send({ data: null, eventId: req.params.gameId });
  //   }
  // })
});
express.get('/api/fancy/:gameId', function (req, res) {
  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  const data = fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.gameId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      try {
        data = JSON.parse(data);
      } catch (err) {
        console.error(err)
      }
      data.data['t1'] = null;
      data.data['t2'] = null;
      if (data['eventTypeName'] == "football") {
        data['eventTypeName'] = "Soccer";
      }

      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.gameId });
    }
  })
});

express.get('/api/bm_fancy2/:gameId', function (req, res) {
  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  const data = fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.gameId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      try {
        data = JSON.parse(data);
      } catch (err) {
        console.error(err)
      }
      // data = JSON.parse(data);
      data.data['t1'] = null;
      if (data['eventTypeName'] == "football") {
        data['eventTypeName'] = "Soccer";
      }

      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.gameId });
    }
  })
});

express.get('/api/new_bm_fancy/:gameId', function (req, res) {

  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  const data = fs.readFile('../../store_world_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.gameId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      try {
        data = JSON.parse(data);
      } catch (err) {
        console.error(err)
      }
      data.data['t1'] = null;
      if (data['eventTypeName'] == "football") {
        data['eventTypeName'] = "Soccer";
      }

      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.gameId });
    }
  })
});

express.get('/api/sports_book/:eventId', function (req, res) {

  var clientIp = getCallerIP(req);
  if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  fs.readFile('../../store_sky_sportbook/' + req.params.eventId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.eventId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.eventId });
    }
  })
});

function getFancy() {
  let fancy = {
    "mid": "",
    "sid": "",
    "nat": "",
    "b1": "0.00",
    "bs1": "0.00",
    "l1": "0.00",
    "ls1": "0.00",
    "b2": "0.00",
    "bs2": "0.00",
    "l2": "0.00",
    "ls2": "0.00",
    "b3": "0.00",
    "bs3": "0.00",
    "l3": "0.00",
    "ls3": "0.00",
    "gtype": "Fancy",
    "utime": "0",
    "gvalid": "0",
    "gstatus": "",
    "remark": "",
    "min": "",
    "max": "",
    "srno": "",
    "s1": "0",
    "s2": "0",
    "ballsess": "1"
  };

  return fancy;
}

function convertToDiamondFancy(data) {
  let diamondFancyFormat = [];
  // data = JSON.parse(data);
  if (data) {
    if (data.fancyBetMarkets) {
      data.fancyBetMarkets.forEach((item, index) => {

        let fancy = getFancy();
        if ((item.status == 2 || item.status == 6 || item.status == 10) && (item.marketType == 1 || item.marketType == 2 || item.marketType == 6)) {
          if (item.status == 2) {
            fancy.gstatus = "";
          }
          if (item.status == 6) {
            fancy.gstatus = "SUSPENDED";
          }
          if (item.status == 10) {
            fancy.gstatus = "BALL RUNNING";
          }

          fancy.nat = item.marketName;
          fancy.mid = data.highlightMarketId;
          fancy.sid = item.marketId;
          fancy.b1 = item.runsYes ? item.runsYes : 0;
          fancy.bs1 = item.oddsYes ? item.oddsYes : 0;
          fancy.l1 = item.runsNo ? item.runsNo : 0;
          fancy.ls1 = item.oddsNo ? item.oddsNo : 0;

          fancy.srno = item.sort;
          fancy.min = item.min;
          fancy.max = item.max;

          diamondFancyFormat.push(fancy);
        }
      })
    }
  }


  return diamondFancyFormat;
}

function getsky_fancy(handleData, eventId) {


  var config = {
    method: 'get',
    url: 'https://sportbet.id:3447/api/sky_fancy/' + eventId,
  };

  axios(config)
    .then(function (response) {
      // console.log(JSON.stringify(response.data));

      handleData(convertToDiamondFancy(response.data));
    })
    .catch(function (error) {
      // console.log(error);
      handleData(error.message)

    });

}

function getbook() {
  let book = {
    "mid": "",
    "mname": "Bookmaker",
    "remark": "",
    "remark1": "",
    "min": "",
    "max": "",
    "sid": "",
    "nat": "",
    "b1": "0.00",
    "bs1": "0.00",
    "l1": "0.00",
    "ls1": "0.00",
    "s": "",
    "sr": "",
    "gtype": "Match1",
    "utime": "0",
    "b2": "0.00",
    "bs2": "0.00",
    "b3": "0.00",
    "bs3": "0.00",
    "l2": "0.00",
    "ls2": "0.00",
    "l3": "0.00",
    "ls3": "0.00",
    "b1s": "False",
    "b2s": "False",
    "b3s": "False",
    "l1s": "False",
    "l2s": "False",
    "l3s": "False"
  };

  return book;
}

function convertToDiamondBookMaking(data) {
  // data = JSON.parse(data);

  let diamondBookFormat = [];
  if (data) {
    if (data.bookMakerSelection) {
      data.bookMakerSelection.selections.forEach((item, index) => {

        let book = getbook();

        if (item.status == 1) {
          book.s = "ACTIVE";
        }
        if (item.status == 2) {
          book.s = "SUSPENDED";
        }
        if (item.status == 1 && data.bookMakerMarket.markets[0].status == 6) {
          book.s = "SUSPENDED";
        }
        if (item.status == 1 && data.bookMakerMarket.markets[0].status == 10) {
          book.s = "BALL RUNNING";
        }
        if (item.status == 1 && data.bookMakerMarket.markets[0].status == 18) {
          book.s = "BALL RUNNING";
        }

        book.nat = item.runnerName;
        // book.mid = data.bookMakerEvent.highlightMarketId;
        book.mid = item.marketId;

        book.sid = item.selectionId;
        book.b1 = item.backOddsInfo[0] ? item.backOddsInfo[0] : 0;
        book.bs1 = 1000000;
        book.l1 = item.layOddsInfo[0] ? item.layOddsInfo[0] : 0;
        book.ls1 = 1000000;

        book.sr = item.sort;
        book.min = data.bookMakerMarket.markets[0].min;
        book.max = data.bookMakerMarket.markets[0].max;

        if (data.bookMakerMarket.markets[0].marketId == item.marketId) {
          diamondBookFormat.push(book);

        }


      })
    }
  }

  return diamondBookFormat;

}

function getsky_book(handleData, eventId) {


  var config = {
    method: 'get',
    url: 'https://sportbet.id:3447/api/sky_book/' + eventId,
  };

  axios(config)
    .then(function (response) {
      // console.log(JSON.stringify(response.data));

      handleData(convertToDiamondBookMaking(response.data));
    })
    .catch(function (error) {
      // console.log(error);
      handleData(error.message)

    });

}

express.get('/api/bm_fancy/:gameId', function (req, res) {
  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  // if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

  //   res.send({ errMsg: "Invalid authentication" });
  //   // console.error(err)
  //   return null;
  // }
  if (req.params.gameId > -1) {
    client.get('store_markets' + req.params.gameId, (err, data) => {
      // console.log(data)
      if (data) {
        try {
          data = JSON.parse(data);
        } catch (err) {
          console.error(err)
        }
        // data = JSON.parse(data);
        data.data['t1'] = null;
        if (data['eventTypeName'] == "football") {
          data['eventTypeName'] = "Soccer";
        }

        res.send(data);
      } else {
        const data = fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
          if (err) {
            res.send({ data: null, eventId: req.params.gameId });
            // console.error(err)
            return null;
          }
          // console.log(data)
          if (data) {
            try {
              data = JSON.parse(data);
            } catch (err) {
              console.error(err)
            }
            // data = JSON.parse(data);
            data.data['t1'] = null;
            if (data['eventTypeName'] == "football") {
              data['eventTypeName'] = "Soccer";
            }

            res.send(data);
          }
          else {
            res.send({ data: null, eventId: req.params.gameId });
          }
        })
      }
    });

    // const data = fs.readFile('../../store_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
    //   if (err) {
    //     res.send({ data: null, eventId: req.params.gameId });
    //     // console.error(err)
    //     return null;
    //   }
    //   // console.log(data)
    //   if (data) {
    //     // try {
    //     //   data = JSON.parse(data);
    //     // } catch (err) {
    //     //   console.error(err)
    //     // }
    //     // // data = JSON.parse(data);
    //     // data.data['t1'] = null;
    //     // if (data['eventTypeName'] == "football") {
    //     //   data['eventTypeName'] = "Soccer";
    //     // }

    //     res.send(data);
    //   }
    //   else {
    //     res.send({ data: null, eventId: req.params.gameId });
    //   }
    // })

  } else {
    let finalData = {
      "data": {
        "t1": [],
        "t2": [],
        "t3": [],
        "t4": []
      },
      "message": true,
      "status": 200
    }
    getsky_fancy(function (data) {
      // console.log(JSON.stringify(data));
      finalData.data.t3 = data;
      getsky_book(function (data1) {
        if (data1.length > 0) {
          finalData.data.t2.push({ bm1: [] });
          finalData.data.t2[0].bm1 = data1;
        }

        // console.log(JSON.stringify(data));

        res.send(finalData);
      }, req.params.gameId)
    }, req.params.gameId)
  }

});

function doSomethingAsync(gameId) {
  return new Promise((resolve) => {

    client.get('store_markets' + gameId, (err, data) => {
      // console.log(data)
      if (data) {
        try {
          data = JSON.parse(data);
        } catch (err) {
          console.error(err)
        }
        // data = JSON.parse(data);
        data.data['t1'] = null;
        if (data['eventTypeName'] == "football") {
          data['eventTypeName'] = "Soccer";
        }

        resolve(data);
      } else {
        const data = fs.readFile('../../store_markets/' + gameId + '.json', 'utf8', (err, data) => {
          if (err) {
            resolve({ data: null, eventId: gameId });
            // console.error(err)
            return null;
          }
          // console.log(data)
          if (data) {
            try {
              data = JSON.parse(data);
            } catch (err) {
              console.error(err)
            }
            // data = JSON.parse(data);
            data.data['t1'] = null;
            if (data['eventTypeName'] == "football") {
              data['eventTypeName'] = "Soccer";
            }

            resolve(data);
          }
          else {
            resolve({ data: null, eventId: gameId });
          }
        })
      }
    });

    // const data = fs.readFile('../../store_markets/' + gameId + '.json', 'utf8', (err, data) => {
    //   if (err) {
    //     resolve({ data: null, eventId: gameId });
    //     // console.error(err)
    //     return null;
    //   }
    //   // console.log(data)
    //   if (data) {
    //     try {
    //       data = JSON.parse(data);
    //     } catch (err) {
    //       console.error(err)
    //     }
    //     // data = JSON.parse(data);
    //     data.data['t1'] = null;
    //     if (data['eventTypeName'] == "football") {
    //       data['eventTypeName'] = "Soccer";
    //     }

    //     resolve(data);
    //   }
    //   else {
    //     resolve({ data: null, eventId: gameId });
    //   }
    // })
  });
}


function getFormatData(results) {
  let resultData = {};
  for (let i = 0; i < results.length; i++) {
    resultData[results[i].gameId] = results[i];
  }

  return resultData;
}
express.get('/api/bm_fancy_multi/:gameIds', function (req, res) {
  var clientIp = getCallerIP(req);

  // console.log(clientIp)

  // console.log(req.get('origin'))


  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }

  let splitgameIds = req.params.gameIds.split(',');

  // console.log(splitGtypes);

  const promises = [];

  for (let i = 0; i < splitgameIds.length; i++) {
    promises.push(doSomethingAsync(splitgameIds[i]));
  }

  Promise.all(promises)
    .then((results) => {
      // res.send(JSON.parse(getFormatData(results)));
      res.send(getFormatData(results));

      // res.send(results);

    })
    .catch((e) => {
      // Handle errors here
      res.send(e);
    });

});

// function IfBfMatch(item) {
//   return item.gameId.length == 8;
// }
// function IfBfMatch(item) {
//   return ((item.vir == 1 && item.name.indexOf(' T10 v ') == -1) || (item.vir == 1 && item.name.indexOf(' T10 v ') > -1 && item.m1 == "True")) && item.eventName.indexOf('Testing ') == -1;
// }

function IfBfMatch(item) {
  return (item.vir == 1 && item.eventName.toLowerCase().indexOf('test ') == -1 && item.eventName.toLowerCase().indexOf('testing ') == -1);
}
// function IfInplayMatch(item) {
//   return item.gameId.length == 8 && item.inPlay == "True";
// }
function IfInplayMatch(item) {
  return (item.vir == 1 || item.vir == 2) && item.inPlay == "True";
}

express.get('/api/highlights/:eventTypeId', function (req, res) {
  // var clientIp = getCallerIP(req);
  // // console.log(clientIp)

  // if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

  //   res.send({ errMsg: "Invalid authentication" });
  //   // console.error(err)
  //   return null;
  // }
  fs.readFile('../../store_highlights/' + req.params.eventTypeId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.eventTypeId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      data = JSON.parse(data);
      // console.log(data.data.filter(IfBfMatch));

      data.data.forEach((item, index) => {
        // if (item.vir == 1 && item.gameId.length > 8) {
        if (item.vir == 1) {

          let dateSplit = item.eventDate.split('-');
          // console.log(item.openDate);
          if (dateSplit.length > 1) {
            if (item.gameId == "1708062244") {
              // item.inPlay = "True";
              delete data.data[index];
              return false;
            }
            item.eventDate = item.eventDate.replace('-1T', '-01T').replace('T1:', 'T01:');
            item.eventDate = item.eventDate.replace('-2T', '-02T').replace('T2:', 'T02:');
            item.eventDate = item.eventDate.replace('-3T', '-03T').replace('T3:', 'T03:');
            item.eventDate = item.eventDate.replace('-4T', '-04T').replace('T4:', 'T04:');
            item.eventDate = item.eventDate.replace('-5T', '-05T').replace('T5:', 'T05:');
            item.eventDate = item.eventDate.replace('-6T', '-06T').replace('T6:', 'T06:');
            item.eventDate = item.eventDate.replace('-7T', '-07T').replace('T7:', 'T07:');
            item.eventDate = item.eventDate.replace('-8T', '-08T').replace('T8:', 'T08:');
            item.eventDate = item.eventDate.replace('-9T', '-09T').replace('T9:', 'T09:');

            item.eventName = item.eventName.replace(' vs ', ' v ');
            item.name = item.name.replace(' V ', ' v ');
            item.eventName = item.eventName.replace(' vs ', ' v ');
            item.name = item.name.replace(' V ', ' v ');
            item.eventDate = moment(item.eventDate).utc().format();


            if (item.eventDate) {
              item.eventDate = moment(item.eventDate).utc().format('MM/DD/YYYY h:mm:ss A') + " +00:00";

            }

            // item.inPlay="True"
            if (req.params.eventTypeId == 52) {
              if (item.gameId.length > 8) {
                // item['competitionName'] = "T10 Virtual Cricket League";
                item['competitionName'] = "Pro Kabaddi 2021-22";

                item['competitionId'] = "2107191543";
              }
            } else if (req.params.eventTypeId == 85) {
              if (item.gameId.length > 8) {
                item['competitionName'] = "Election 2022";

                item['competitionId'] = "2107191733";
              }
            } else {
              if (item.gameId.length > 8) {
                // item['competitionName'] = "T10 Virtual Cricket League";
                item['competitionName'] = "T10 Cricket League";

                item['competitionId'] = "2107191543";
              }
            }

          }

        }
      })
      data.data = data.data.filter(IfBfMatch);
      let diamondEvent = data;

      fs.readFile('../../store_sky_highlight/' + req.params.eventTypeId + '.json', 'utf8', (err, data2) => {
        if (err) {
          res.send(diamondEvent);
          // console.error(err)
          return null;
        }
        // console.log(data)
        if (data2) {

          data2 = JSON.parse(data2);

          data2.events.forEach((item, index) => {
            // console.log(item)
            if ((item.isElectronic == 1 || item.name.indexOf(' SRL ') > -1) && item.markets[0]) {
            // if ((item.id == -10212211 || item.id == -10212212) && item.markets[0]) {

              if (item.id) {
                item.id = -(item.id);
                item.id = '17' + item.id;
                item.markets[0].marketId = '1.' + item.id;
              }
              // console.log(item)
              let elEvent = {
                "gameId": item.id,
                "marketId": item.markets[0].marketId,
                "eventName": item.name,
                "inPlay": item.isInPlay == 1 ? "True" : "False",
                "tv": item.streamingChannel ? "True" : "False",
                "back1": 0,
                "lay1": 0,
                "back11": 0,
                "lay11": 0,
                "back12": 0,
                "lay12": 0,
                "m1": item.hasBookMakerMarkets ? "True" : "False",
                "f": item.hasFancyBetMarkets ? "True" : "False",
                // "vir": 2,
                "vir": 1,
                "name": item.name,
                "eventDate": item.openDate.replace(' ', 'T'),
                "updatetime": new Date(),
                "competitionName": "T10 Cricket League",
                "competitionId": "2107191543"
                // "competitionName": "Virtual " + (req.params.eventTypeId == 4 ? 'Cricket' : 'Soccer') + " League",
                // "competitionId": (req.params.eventTypeId == 4 ? -610719 : -710719),
              }
              // elEvent.eventDate = moment(elEvent.eventDate).utc().format('YYYY-MM-DD h:mm:ss');
              // var time = moment.duration("01:30:00");
              // elEvent.eventDate =moment(elEvent.eventDate).subtract(time);
              elEvent.eventDate = moment(elEvent.eventDate).utc().format('MM/DD/YYYY h:mm:ss A') + " +00:00";

              diamondEvent.data.push(elEvent);
            }


          });
          // diamondEvent.data=[];
          res.send(diamondEvent);
        }
        else {
          res.send(diamondEvent);
          // res.send({ data: null, eventId: req.params.eventTypeId });
        }
      })
      // res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.eventTypeId });
    }
  })
});

express.get('/api/highlights2/:eventTypeId', function (req, res) {
  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  const data = fs.readFile('../../store_highlights/' + req.params.eventTypeId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.eventTypeId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      data = JSON.parse(data);
      // console.log(data.data.filter(IfBfMatch));

      data.data.forEach((item, index) => {
        if (item.vir == 1) {
          let dateSplit = item.eventDate.split('-');
          // console.log(item.openDate);
          if (dateSplit.length > 0) {
            if (item.gameId == "2107260553") {
              delete data.data[index];
              return false;
            }
            // item.eventDate = moment(item.eventDate).utc().format()
            item.eventDate = item.eventDate.replace('-1T', '-01T');
            item.eventDate = item.eventDate.replace('-2T', '-02T');
            item.eventDate = item.eventDate.replace('-3T', '-03T');
            item.eventDate = item.eventDate.replace('-4T', '-04T');
            item.eventDate = item.eventDate.replace('-5T', '-05T');
            item.eventDate = item.eventDate.replace('-6T', '-06T');
            item.eventDate = item.eventDate.replace('-7T', '-07T');
            item.eventDate = item.eventDate.replace('-8T', '-08T');
            item.eventDate = item.eventDate.replace('-9T', '-09T');

            item.eventName = item.eventName.replace(' vs ', ' v ');
            item.name = item.name.replace(' vs ', ' v ');



            item.eventDate = moment(item.eventDate).utc().format('MM/DD/YYYY h:mm:ss A') + " +00:00";
            // item.inPlay="True"
            // item.competitionName = "Tamil Nadu Premier League 2021";
            // item.competitionId = "2107191543";
          }

        }
      })
      data.data = data.data.filter(IfBfMatch);
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.eventTypeId });
    }
  })
});

express.get('/api/inplay/:eventTypeId', function (req, res) {
  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }

  const data = fs.readFile('../../store_highlights/' + req.params.eventTypeId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.eventTypeId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      data = JSON.parse(data);
      // console.log(data.data.filter(IfBfMatch));
      data.data.forEach((item) => {
        if (item.vir == 1) {
          item.competitionName = "Tamil Nadu Premier League 2021";
          item.competitionId = "2107191543";
        }
      })
      data.data = data.data.filter(IfInplayMatch);
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.eventTypeId });
    }
  })
});

function formatSkyMktData(marketData) {
  // console.log(marketData);
  let formattedData = {
    "success": true,
    "data": [],
    "status": 200,
    "updatetime": "",
    "eventTypeId": marketData.eventType,
    "eventTypeName": marketData.eventType == 4 ? 'Cricket' : marketData.eventType == 1 ? 'Soccer' : 'Tennis',
    "eventName": marketData.eventName,
    "gameId": marketData.eventId,
  };


  let market = {
    "sport": marketData.eventType == 4 ? 'Cricket' : marketData.eventType == 1 ? 'Soccer' : 'Tennis',
    "sportId": marketData.eventType,
    "eventId": marketData.eventId,
    "MarketId": marketData.market.marketId,
    "marketName": marketData.market.marketName,
    "marketType": marketData.market.marketType,
    "source": 1,
    "IsMarketDataDelayed": false,
    "Status": marketData.market.status == 1 ? 'OPEN' : 'SUSPENDED',
    "IsInplay": marketData.market.inPlay == 1 ? true : false,
    "inplay": marketData.market.inPlay == 1 ? true : false,
    "NumberOfRunners": marketData.market.selections.length,
    "NumberOfActiveRunners": marketData.market.selections.length,
    "TotalMatched": marketData.market.totalMatchedInUSD,
    "Runners": []
  };

  _.forEach(marketData.market.selections, (item2) => {
    // console.log(item2)

    let runner = {
      "SelectionId": item2.selectionId,
      "runnerName": item2.runnerName,
      "Status": item2.status == 1 ? 'ACTIVE' : 'ACTIVE',
      "LastPriceTraded": null,
      "TotalMatched": marketData.market.totalMatchedInUSD,
      "ExchangePrices": {
        "AvailableToBack": [
          {
            "price": item2.availableToBack[0] ? item2.availableToBack[0].price : 0,
            "size": item2.availableToBack[0] ? item2.availableToBack[0].size : 0
          },
          {
            "price": item2.availableToBack[1] ? item2.availableToBack[1].price : 0,
            "size": item2.availableToBack[1] ? item2.availableToBack[1].size : 0
          },
          {
            "price": item2.availableToBack[2] ? item2.availableToBack[2].price : 0,
            "size": item2.availableToBack[2] ? item2.availableToBack[2].size : 0
          }
        ],
        "AvailableToLay": [
          {
            "price": item2.availableToLay[0] ? item2.availableToLay[0].price : 0,
            "size": item2.availableToLay[0] ? item2.availableToLay[0].size : 0
          },
          {
            "price": item2.availableToLay[1] ? item2.availableToLay[1].price : 0,
            "size": item2.availableToLay[1] ? item2.availableToLay[1].size : 0
          },
          {
            "price": item2.availableToLay[2] ? item2.availableToLay[2].price : 0,
            "size": item2.availableToLay[2] ? item2.availableToLay[2].size : 0
          }
        ]
      }
    }

    market.Runners.push(runner);


  })

  formattedData.data.push(market);

  // console.log(formattedData)
  return formattedData;

}

express.get('/api/cup_odds/:gameId', function (req, res) {
  var clientIp = getCallerIP(req);
  if (hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  // if (hostNames.indexOf(req.get('origin')) == -1) {

  //     res.send({errMsg:"Invalid authentication"});
  //     // console.error(err)
  //     return null;
  // }
  // console.log(req.get('origin'));
  const data = fs.readFile('../../store_sky_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.gameId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      data = JSON.parse(data);
      data = formatSkyMktData(data);
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.gameId });
    }
  })
});

express.get('/api/sky_odds/:gameId', function (req, res) {
  var clientIp = getCallerIP(req);
  if (hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  // if (hostNames.indexOf(req.get('origin')) == -1) {

  //     res.send({errMsg:"Invalid authentication"});
  //     // console.error(err)
  //     return null;
  // }
  // console.log(req.get('origin'));
  const data = fs.readFile('../../store_sky_markets/' + req.params.gameId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.gameId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      data = JSON.parse(data);
      data = formatSkyMktData(data);
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.gameId });
    }
  })
});


express.get('/api/sky_eventlist/:eventType', function (req, res) {

  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  fs.readFile('../../store_sky_highlight/' + req.params.eventType + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.eventType });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.eventType });
    }
  })
});

express.get('/api/sky_odds/:eventId', function (req, res) {

  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  fs.readFile('../../store_sky_markets/' + req.params.eventId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.eventId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.eventId });
    }
  })
});

express.get('/api/sky_book/:eventId', function (req, res) {

  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  fs.readFile('../../store_sky_book/' + req.params.eventId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.eventId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.eventId });
    }
  })
});

express.get('/api/sky_fancy/:eventId', function (req, res) {

  var clientIp = getCallerIP(req);
  // console.log(clientIp)

  if (hostNames.indexOf(req.get('origin')) == -1 && hostNames.indexOf(clientIp[0]) == -1) {

    res.send({ errMsg: "Invalid authentication" });
    // console.error(err)
    return null;
  }
  fs.readFile('../../store_sky_fancy/' + req.params.eventId + '.json', 'utf8', (err, data) => {
    if (err) {
      res.send({ data: null, eventId: req.params.eventId });
      // console.error(err)
      return null;
    }
    // console.log(data)
    if (data) {
      res.send(data);
    }
    else {
      res.send({ data: null, eventId: req.params.eventId });
    }
  })
});

app.listen(3447, function () {
  console.log('listening on *:3447');
});

