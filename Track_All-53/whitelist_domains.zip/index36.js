var express = require('express')();
var https = require('https');
var axios = require('axios');
var fs = require('fs');
var _ = require('lodash');
var moment = require('moment');

var cors = require('cors')

var ssl_domain = require("./ssl/ssl_domain");
var whitelist_domain = require("./whitelist_domains/domains");

const { json } = require('express');

const redis = require('redis');
const redisPort = 6379;
const client = redis.createClient(redisPort);
let app = https.createServer(ssl_domain.options, express);

app.addContext('api1.streamingtv.fun', ssl_domain.options1);
app.addContext('api2.streamingtv.fun', ssl_domain.options2);
app.addContext('api3.streamingtv.fun', ssl_domain.options3);
app.addContext('access.vrnl.net', ssl_domain.options4);
app.addContext('access.streamtv247.fun', ssl_domain.options5);
app.addContext('api3.streamtv247.fun', ssl_domain.options6);
app.addContext('api.bfoddsapi.in', ssl_domain.options7);
app.addContext('access.vrnlapi.live', ssl_domain.options8);
app.addContext('api3.vrnlapi.live', ssl_domain.options9);


express.use(cors());
express.get('/', function (req, res) {
    res.send('VRNL.NET');
});

let hostNames = [
    "https://panel.betskyexch.com",
    "https://panel.play786.live",
    "https://panel.play123.live",
    "https://panel.bee25.live",
    "https://panel.bee25.site",
    "https://panel.cricbuzzer.io",
    "https://panel.ninewiickets.com",
    "https://panel.skyex247.pro",
    "https://panel.vellki.live",
    "https://panel.bdcrickeet.com",
    'https://panel.crickets.pro',
    'https://panel.criicket.live',
    'https://panel.crickeet.live',
    'https://panel.mybazzi.live',
    'https://panel.fairbd.live',
    'https://panel.bdplay.bet',
    'https://panel.9wicketspro.vip',
    'https://panel.bdbet21.pro',
    "http://localhost:4200",
    "http://localhost:4204",
    "https://dw.4six.com",
    "https://dw.4six.vip",
    "https://dw.4six.pro",
    'https://panel.velkil.live',
    "https://panel.seanscric247.club",
    "https://panel.baajifair.vip",
    "https://panel.9xbaji.pro"
];

let loginDetails = [
    { username: "supportyp1", run: "Yp1@4321", loginUserName: 'BDTquontumAG' },
    { username: "supportyp2", run: "Yp2@1234", loginUserName: 'BDTquontumAG' },
    { username: "supportyp3", run: "Yp3@9876", loginUserName: 'BDTquontumAG' },
    { username: "supportyp4", run: "Yp4@5674", loginUserName: 'AGQuonINR' },
    { username: "supportyp5", run: "Yp5@9084", loginUserName: 'AGQuonINR' },
    { username: "supportyp6", run: "Yp6@6084", loginUserName: 'AGQuonINR' },


    { username: "support1", run: "pPlay398@671", loginUserName: 'plabon' },
    { username: "support2", run: "pPlay611@134", loginUserName: 'plabon' },
    { username: "support3", run: "pPlay957@976", loginUserName: 'plabon' },
    { username: "support4", run: "pPlay094@564", loginUserName: 'plabon' },
    { username: "support5", run: "pPlay610@984", loginUserName: 'plabon' },

    { username: "supportb1", run: "Bee353@4321", loginUserName: 'CasinoWL' },
    { username: "supportb2", run: "Bee346@1234", loginUserName: 'CasinoWL' },
    { username: "supportb3", run: "Bee973@9876", loginUserName: 'CasinoWL' },
    { username: "supportb4", run: "Bee343@5674", loginUserName: 'CasinoWL' },
    { username: "supportb5", run: "Bee786@9084", loginUserName: 'CasinoWL' },

    { username: "supcb16", run: "Supp353@43211", loginUserName: 'playfoxmain' },
    { username: "supcb25", run: "Supp346@12342", loginUserName: 'playfoxmain' },
    { username: "supcb34", run: "Supp973@98763", loginUserName: 'playfoxmain' },
    { username: "supcb43", run: "Supp553@98764", loginUserName: 'playfoxmain' },
    { username: "supcb52", run: "Supp753@63535", loginUserName: 'playfoxmain' },
    { username: "supcb61", run: "Supp953@35336", loginUserName: 'playfoxmain' },

    { username: "supnine1", run: "Nine353@4321", loginUserName: 'MPnine' },
    { username: "supnine2", run: "Nine346@1234", loginUserName: 'MPnine' },
    { username: "supnine3", run: "Nine973@9876", loginUserName: 'MPnine' },
    { username: "supnine4", run: "Nine343@5674", loginUserName: 'MPnine' },
    { username: "supnine5", run: "Nine786@9084", loginUserName: 'MPnine' },

    { username: "supskyex1", run: "SkyEx353@4321", loginUserName: 'WLProexsky' },
    { username: "supskyex2", run: "SkyEx346@1234", loginUserName: 'WLProexsky' },
    { username: "supskyex3", run: "SkyEx973@9876", loginUserName: 'WLProexsky' },
    { username: "supskyex4", run: "SkyEx343@5674", loginUserName: 'WLProexsky' },
    { username: "supskyex5", run: "SkyEx786@9084", loginUserName: 'WLProexsky' },

    { username: "supvellki1", run: "Supvelki365@0053", loginUserName: 'vellkkiWL' },
    { username: "supvellki2", run: "Supvelki365@1699", loginUserName: 'vellkkiWL' },
    { username: "supvellki3", run: "Supvelki365@9777", loginUserName: 'vellkkiWL' },
    { username: "supvellki4", run: "Supvelki365@5027", loginUserName: 'vellkkiWL' },
    { username: "supvellki5", run: "Supvelki365@9444", loginUserName: 'vellkkiWL' },

    { username: "supwickpro9", run: "Supwickpro9@#799", loginUserName: 'Mp9wickpro' },

    { username: "supbdcrickeet1", run: "Supbdcrickeet365@4321", loginUserName: 'bdcrickeetAD' },

    { username: "supcrickeett1", run: "SupcrickeettAD786@4321", loginUserName: 'crickeettAD' },

    { username: "sup9xbet1", run: "Sup9xbet123@4321", loginUserName: '9xbetAD' },

    { username: "sup9mybazzi1", run: "Supmybazzi123@4321", loginUserName: 'mybazziAD' },

    { username: "supjara1123", run: "SupJARA1457@4321", loginUserName: 'ADJARA11' },

    { username: "supfairbd1123", run: "Supfairbd1237@4321", loginUserName: 'ADfairbd' },

    { username: "supluxkgamex121", run: "SupLuckgamex127@4321", loginUserName: 'LuckgamexAD' },

    { username: "supexpress141", run: "SupExpress143@4321", loginUserName: 'ADExpress' },

    { username: "supbdplay121", run: "BdplayB2C143@4321", loginUserName: 'BdplayB2C' },

    { username: "supsports247", run: "SportsB2C24@7722", loginUserName: 'ADsports' },

    { username: "supsupport123", run: "SupsearnB2C24@365", loginUserName: 'EarningbdtAD' },

    { username: "supvelkiSupport65", run: "Sup##sveiiB2C24@65", loginUserName: 'velkilAD' },

    { username: "sup4six247", run: "Supsix@64721", loginUserName: '4sixAD' },
    { username: "sup4six2471", run: "Supsix@64722", loginUserName: '4sixAD' },
    { username: "sup4six2472", run: "Supsix@64723", loginUserName: '4sixAD' },
    { username: "sup4six2473", run: "Supsix@64724", loginUserName: '4sixAD' },
    { username: "sup4six2474", run: "Supsix@64725", loginUserName: '4sixAD' },

    { username: "supseanscric247",  run: "Supseanscric@64721", loginUserName: 'MPseanscric247' },
    { username: "supseanscric2472", run: "Supseanscric@64722", loginUserName: 'MPseanscric247' },
    { username: "supseanscric2473", run: "Supseanscric@64723", loginUserName: 'MPseanscric247' },
    { username: "supseanscric2444", run: "Supseanscric@64724", loginUserName: 'MPseanscric247' },
    { username: "supseanscric2475", run: "Supseanscric@64725", loginUserName: 'MPseanscric247' },

    { username: "supbaaji431", run: "Sup##432Baji@@@", loginUserName: 'MpBaajifairvip' },

    { username: "supbaji91", run: "Sup#@9Baji#1@@", loginUserName: 'AD9xbaji' },

]


function getCallerIP(request) {
    var ip = request.headers['x-forwarded-for'] ||
        request.connection.remoteAddress ||
        request.socket.remoteAddress ||
        request.connection.socket.remoteAddress;
    ip = ip.split(',')[0];
    ip = ip.split(':').slice(-1); //in case the ip returned in a format: "::ffff:146.xxx.xxx.xxx"
    return ip;
}

function getDomainName(hostName) {
    if (!hostName) {
        return;
    }
    let formatedHost = "";
    let splithostName = hostName.split('.');
    if (splithostName.length > 2) {
        formatedHost = hostName.substring(hostName.lastIndexOf(".", hostName.lastIndexOf(".") - 1) + 1);
    } else {
        formatedHost = hostName.split('//')[1]
    }
    return formatedHost;
}


express.post('/api/login', json({ type: '*/*' }), function (req, res) {


    // console.log(req.body)
    var clientIp = getCallerIP(req);
    // console.log(clientIp)
    console.log(req.get('origin'))

    if (hostNames.indexOf(req.get('origin')) == -1) {

        res.send({
            "errorCode": 1,
            "errorDescription": "Not authorized",
            "result": []
        });
        return;
    }

    if (!req.body.userName) {
        res.send({
            "errorCode": 1,
            "errorDescription": "invalid username/password",
            "result": []
        });
        return;
    }
    if (!req.body.password) {
        res.send({
            "errorCode": 1,
            "errorDescription": "invalid username/password",
            "result": []
        });
        return;
    }
    if (!req.body.captcha) {
        res.send({
            "errorCode": 1,
            "errorDescription": "Incorrect Captcha",
            "result": []
        });
        return;
    }
    if (!req.body.log) {
        res.send({
            "errorCode": 1,
            "errorDescription": "Incorrect Captcha",
            "result": []
        });
        return;
    }

    let loginData = { username: req.body.userName.toLowerCase(), run: req.body.password };
    let result = _.find(loginDetails, loginData);
    console.log("result".result)
    if (result) {
        // res.send(result);

        let data = JSON.stringify({
            "userName": result.loginUserName,
            // "password": "THREE-2equal1",
            "password": "ONE-1equal0",
            "captcha": req.body.captcha,
            "log": req.body.log
        });

        let config = {
            method: 'post',
            url: 'https://111111.info/pad=81/login',
            headers: {
                'Origin': req.get('origin'),
                'Content-Type': 'application/json'
            },
            data: data
        };

        axios.request(config)
            .then((response) => {
                // console.log(JSON.stringify(response.data));
                if (response.data) {
                    if (response.data.errorCode == 0) {
                        if (response.data.result[0]) {
                            response.data.result[0].userName = req.body.userName;
                            response.data.result[0].balance = req.body.balance;
                        }
                        let content = "Login Successfull " + req.body.userName + " IP= " + clientIp[0];
                        storeLogs(content);
                        res.send(response.data);
                    } else {
                        let content = response.data.errorDescription + " coder " + req.body.userName + " IP= " + clientIp[0];
                        storeLogs(content);
                        res.send(response.data);
                    }
                }
            })
            .catch((error) => {
                console.log('error');
                let content = "Coder Api error " + req.body.userName + " IP= " + clientIp[0];
                storeLogs(content);
                res.send({
                    "errorCode": 1,
                    "errorDescription": "invalid username/password",
                    "result": []
                });
            });


    } else {
        let content = "invalid username/password " + req.body.userName + " IP= " + clientIp[0];
        storeLogs(content);
        res.send({
            "errorCode": 1,
            "errorDescription": "invalid username/password",
            "result": []
        });
    }
});

const format1 = "YYYY-MM-DD HH:mm:ss"
function storeLogs(content) {
    content = content + " time= " + moment(new Date()).format(format1);;

    content += "\n";
    fs.appendFile("StoreUser.txt", content, (err) => {
        // return console.log(err);
    });
}




app.listen(3476, function () {
    console.log('listening on *:3476');
});

