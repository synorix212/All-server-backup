const express = require('express');
const https = require('https');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const ssl_domain = require("./ssl/ssl_domain");
const qr = require('qr-image');
const multer = require('multer');
const nodemailer = require('nodemailer');
// const cron = require('node-cron');
const cron = require('node-cron');
const { body, validationResult } = require('express-validator');
const app = express();
// const port = 3481;
const port = process.env.PORT || 3481;
const sql = require('mssql');
app.use(cors());
app.use(express.json());
const redis = require('redis');
const redisClient = redis.createClient();
const axios = require('axios');
const moment = require('moment');
const crypto = require('crypto');
const server = https.createServer(ssl_domain.options, app);

server.addContext('api1.streamingtv.fun', ssl_domain.options1);
server.addContext('api2.streamingtv.fun', ssl_domain.options2);
server.addContext('api3.streamingtv.fun', ssl_domain.options3);
server.addContext('access.vrnl.net', ssl_domain.options4);
server.addContext('access.streamtv247.fun', ssl_domain.options5);
server.addContext('api3.streamtv247.fun', ssl_domain.options6);
server.addContext('api.bfoddsapi.in', ssl_domain.options7);
server.addContext('access.vrnlapi.live', ssl_domain.options8);
server.addContext('api3.vrnlapi.live', ssl_domain.options9);
server.addContext('api2.vrnlapi.live', ssl_domain.options10);

// Simple root route
app.get('/', function (req, res) {
    res.send('VRNL.NET');
});

const config = {
    user: 'notification',
    password: 'Asdf1234',
    server: '78.141.233.65',
    database: 'b2cNotification',
    options: {
        encrypt: true,
        enableArithAbort: true,
        trustServerCertificate: true
    }
};

let pool;
sql.connect(config)
  .then(p => {
    pool = p;
  })
  .catch(err => console.error('SQL Connection Error:', err));
  const httpsAgent = new https.Agent({
    rejectUnauthorized: false
  });
let tickerDataMap = {};
const usedTickerIds = new Set();
const uploadDir = './uploads';
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}
const emailConfigs = {
    'foxplay.pro': {
        user: 'support@vrnl.net',
        pass: 'pcch acie wqqu ycsp',
        from: '"Foxplay Team" <support@vrnl.net>',
        to: '"Foxplay Team" <support@vrnl.net>',
    },
};
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage: storage });

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// Add ticker route
app.post('/api/addTicker', [
    body('ticker').notEmpty().isString().trim(),
    body('userType').notEmpty().withMessage('User type field is required.').isInt({ min: 0, max: 1 }).withMessage('User type must be either Player or Admin.'),
    body('isImp').optional().isBoolean().toBoolean(),
    body('title').optional().isString().trim(),
], (req, res) => {
    const errors = validationResult(req);
    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };
    if (!errors.isEmpty()) {
        return errorResponse(201, { errorCode: 1, result: [{ message: errors.array().map(error => error.msg) }] });
    }
    const { ticker, userType, isImp, title } = req.body;
    const origin = req.header('origin');
    if (!origin) return errorResponse(400, { errorCode: 1, result: 'Origin parameter is required.' });

    // const sanitizedOrigin = origin.replace(/^(https?:\/\/)?(ag\.)?/, '');
    const sanitizedOrigin = getDomainName(req.get('origin'));


    const prohibitedKeywords = ["alert(", "script"];
    if (prohibitedKeywords.some(keyword => ticker.includes(keyword))) {
        return errorResponse(400, { errorCode: 1, result: [{ message: "Prohibited content detected" }] });
    }

    let tickerId;
    while (usedTickerIds.has(tickerId = Math.floor(Math.random() * 100000)));
    usedTickerIds.add(tickerId);

    const tickerData = { tickerId, userType, ticker, creationDate: new Date(), isImp,title };

    (tickerDataMap[sanitizedOrigin] ??= []).push(tickerData);

    const folderPath = "/enterprise/site_ticker";
    const filePath = path.join(folderPath, `${sanitizedOrigin}.json`);

    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify({ status: 'Success', data: [] }));
    }

    const existingData = [...JSON.parse(fs.readFileSync(filePath, 'utf-8')).data, tickerData];

    const tickerJson = JSON.stringify({ status: 'Success', data: existingData }, null, 2);
    fs.writeFile(filePath, tickerJson, (err) => {
        return err ? errorResponse(500, { errorCode: 1, result: [{ message: 'Error' }] })
            : errorResponse(200, { errorCode: 0, result: [{ message: 'Ticker added successfully.' }] });
    });

});
// Delete ticker route
app.delete('/api/deleteTicker', (req, res) => {
    const origin = req.header('origin');
    const tickerIdToRemove = req.query.tickerId;

    if (!origin) {
        return res.status(400).json({ errorCode: 1, result: [{ message: 'Origin parameter is required.' }] });
    }

    // const sanitizedOrigin = origin.replace(/^(https?:\/\/)?(ag\.)?/, '');
    const sanitizedOrigin = getDomainName(req.get('origin'));

    const filePath = path.join("/enterprise/site_ticker", `${sanitizedOrigin}.json`);
    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ errorCode: 1, result: [{ message: 'File not found.' }] });
    }
    let existingData = [];
    try {
        const existingDataContent = fs.readFileSync(filePath, 'utf-8');
        existingData = JSON.parse(existingDataContent).data;

        const tickerIndexToRemove = existingData.findIndex(tickerObj => tickerObj.tickerId === parseInt(tickerIdToRemove));

        if (tickerIndexToRemove !== -1) {
            existingData.splice(tickerIndexToRemove, 1);

            fs.writeFileSync(filePath, JSON.stringify({ status: 'Success', data: existingData }, null, 2));

            return res.json({ errorCode: 0, result: [{ message: 'Ticker removed successfully.' }] });
        } else {
            return res.json({ errorCode: 1, result: [{ message: 'Ticker is already removed.' }] });
        }
    } catch (error) {
        return res.status(500).json({ errorCode: 1, result: [{ message: 'Error while deleting ticker.' }] });
    }


});
function getDomainName(hostName) {
    if (!hostName) {
        return;
    }
    let formatedHost = "";
    let splithostName = hostName.split('.');
    if (splithostName.length > 2) {
        formatedHost = hostName.substring(hostName.lastIndexOf(".", hostName.lastIndexOf(".") - 1) + 1);
    } else {
        formatedHost = hostName.split('//')[1]
    }
    return formatedHost;
}
app.get('/api/get_ticker', (req, res) => {
    const origin = req.header('origin');
    if (getDomainName(req.get('origin')) == 'betswiz.com' || getDomainName(req.get('origin')) == 'betswiz.in') {
        res.send({ ticker: null });
        return null;
    }
    // const sanitizedOrigin = origin?.replace(/^(https?:\/\/)?(ag\.)?/, '');
    const sanitizedOrigin = getDomainName(req.get('origin'));

    if (!origin) return res.send({ errorCode: 1, result: 'Origin parameter is required.' });

    const filePath = path.join("/enterprise/site_ticker", `${sanitizedOrigin}.json`);
    const existingDataContent = fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf-8') : null;
    const existingData = existingDataContent ? JSON.parse(existingDataContent).data : null;
    const tickerDataForOrigin = existingData || [];

    fs.readFile('../../store_site_ticker/ticker.json', 'utf8', (err, data) => {
        if (err) {
            return res.send({ ticker: null, ticker1: null });
        }
        if (data) {
            data = JSON.parse(data);
            const userType0Data = tickerDataForOrigin.filter(entry => String(entry.userType) === "0");
            return res.send({ ticker: data, ticker1: userType0Data });
        } else {
            return res.send({ ticker: null, ticker1: null });
        }
    });
});

app.get('/api/admin/get_ticker', (req, res) => {
    const origin = req.header('origin');
    // const sanitizedOrigin = origin?.replace(/^(https?:\/\/)?(ag\.)?/, '');
    const sanitizedOrigin = getDomainName(req.get('origin'));


    if (!origin) return res.send({ errorCode: 1, result: 'Origin parameter is required.' });

    const filePath = path.join("/enterprise/site_ticker", `${sanitizedOrigin}.json`);


    try {
        const existingDataContent = fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf-8') : null;
        const existingData = existingDataContent ? JSON.parse(existingDataContent).data : null;
        const userType0Data = existingData ? existingData.filter(entry => String(entry.userType) === "1") : [];

        return res.send({ ticker: userType0Data || null });
    } catch (error) {
        console.error('Error', error);
        return res.json({ ticker: null });
    }
});

//referal QR code start
app.get('/generate-qr/:origin/:referCode', (req, res) => {
    const referCode = req.params.referCode;
    const origin = req.params.origin;
    const fullURL = `https://${origin}/#/?refer_code=${referCode}`;

    // Generate QR code
    const qrCode = qr.image(fullURL, { type: 'png' });

    // Capture chunks as they are received
    const chunks = [];

    // When QR code generation is complete
    qrCode.on('end', () => {
        const buffer = Buffer.concat(chunks);
        const dataURL = `data:image/png;base64,${buffer.toString('base64')}`;

        // Send JSON response with image data
        res.json({ success: true, message: 'QR code generated successfully', img: dataURL });
    });

    // Handle errors during QR code generation
    qrCode.on('error', (error) => {
        console.error('Error generating QR code:', error);

        // If an error occurs, send an error response
        res.status(500).json({ success: false, message: 'Error generating QR code' });
    });

    // Capture chunks of the QR code image as they are received
    qrCode.on('data', chunk => {
        chunks.push(chunk);
    });
});
app.get('/generateage-qr-m/:origin/:referCode', (req, res) => {
    const referCode = req.params.referCode;
    const origin = req.params.origin;
    const fullURL = `https://${origin}/m/#/?refer_code=${referCode}`;

    // Generate QR code
    const qrCode = qr.image(fullURL, { type: 'png' });

    // Capture chunks as they are received
    const chunks = [];

    // When QR code generation is complete
    qrCode.on('end', () => {
        const buffer = Buffer.concat(chunks);
        const dataURL = `data:image/png;base64,${buffer.toString('base64')}`;

        // Send JSON response with image data
        res.json({ success: true, message: 'QR code generated successfully', img: dataURL });
    });

    // Handle errors during QR code generation
    qrCode.on('error', (error) => {
        console.error('Error generating QR code:', error);

        // If an error occurs, send an error response
        res.status(500).json({ success: false, message: 'Error generating QR code' });
    });

    // Capture chunks of the QR code image as they are received
    qrCode.on('data', chunk => {
        chunks.push(chunk);
    });
});
app.get('/generateagent-qr/:origin/:referCode/:creationcode', (req, res) => {
    const referCode = req.params.referCode;
    const origin = req.params.origin;
    const creationcode = req.params.creationcode;
    const fullURL = `https://${origin}/#/?refer_code=${referCode}&creation_code=${creationcode}`;

    // Generate QR code
    const qrCode = qr.image(fullURL, { type: 'png' });

    // Capture chunks as they are received
    const chunks = [];

    // When QR code generation is complete
    qrCode.on('end', () => {
        const buffer = Buffer.concat(chunks);
        const dataURL = `data:image/png;base64,${buffer.toString('base64')}`;

        // Send JSON response with image data
        res.json({ success: true, message: 'QR code generated successfully', img: dataURL });
    });

    // Handle errors during QR code generation
    qrCode.on('error', (error) => {
        console.error('Error generating QR code:', error);

        // If an error occurs, send an error response
        res.status(500).json({ success: false, message: 'Error generating QR code' });
    });

    // Capture chunks of the QR code image as they are received
    qrCode.on('data', chunk => {
        chunks.push(chunk);
    });
});
app.get('/generateagent-qr-m/:origin/:referCode/:creationcode', (req, res) => {
    const referCode = req.params.referCode;
    const origin = req.params.origin;
    const creationcode = req.params.creationcode;
    const fullURL = `https://${origin}/m/#/?refer_code=${referCode}&creation_code=${creationcode}`;

    // Generate QR code
    const qrCode = qr.image(fullURL, { type: 'png' });

    // Capture chunks as they are received
    const chunks = [];

    // When QR code generation is complete
    qrCode.on('end', () => {
        const buffer = Buffer.concat(chunks);
        const dataURL = `data:image/png;base64,${buffer.toString('base64')}`;

        // Send JSON response with image data
        res.json({ success: true, message: 'QR code generated successfully', img: dataURL });
    });

    // Handle errors during QR code generation
    qrCode.on('error', (error) => {
        console.error('Error generating QR code:', error);

        // If an error occurs, send an error response
        res.status(500).json({ success: false, message: 'Error generating QR code' });
    });

    // Capture chunks of the QR code image as they are received
    qrCode.on('data', chunk => {
        chunks.push(chunk);
    });
});
app.post('/save-qr/:origin/:referCode', (req, res) => {
    const referCode = req.params.referCode;
    const origin = req.params.origin;
    const fullURL = `https://${origin}/#/?refer_code=${referCode}`;

    // Generate QR code
    const qrCode = qr.image(fullURL, { type: 'png' });

    // Save QR code to file
    const fileName = `${Date.now()}_qrcode.png`;
    const filePath = path.join(__dirname, 'qrcodes', fileName);
    const fileStream = fs.createWriteStream(filePath);

    qrCode.pipe(fileStream);

    fileStream.on('finish', () => {
        res.json({ success: true, fileName });
    });
});
//referal QR code end

//b2c notification start
// app.post('/action', async (req, res) => {
//     const errorResponse = (statusCode, message) => {
//         return res.status(statusCode).send(message);
//     };
//     try {
//         console.log('Request Body:', req.body);
//         const actions = req.body;

//         await sql.connect(config);

//         for (const action of actions) {
//             const { userID, trxntype, amount, action: actionType, domain } = action;
//             const creationDate = new Date();
//             if (actionType === 0) {
//                 await sql.query`INSERT INTO Notifications (UserID, TransactionType, Amount, Message, Status,CreationDate,Domain) 
//                                 VALUES (${userID}, ${trxntype}, ${amount}, 'Accepted', 'Accepted', ${creationDate},${domain})`;
//             } else if (actionType === 1) {
//                 console.log(`Request from user ${userID} rejected.`);
//                 await sql.query`INSERT INTO Notifications (UserID, TransactionType, Amount, Message, Status,CreationDate,Domain) 
//                                 VALUES (${userID}, ${trxntype}, ${amount}, 'Rejected', 'Rejected', ${creationDate},${domain})`;
//             } else {
//                 throw new Error('Invalid action type');
//             }
//         }


//         return errorResponse(200, { errorCode: 0, result: [{ message: 'Action processed successfully' }] });
//     } catch (error) {
//         console.error('Error:', error.message);
//         return errorResponse(500, { errorCode: 1, result: [{ message: 'Error' }] });
//     }
// });
// app.get('/notification/:userID', async (req, res) => {
//     const errorResponse = (statusCode, message) => {
//         return res.status(statusCode).send(message);
//     };
//     try {
//         const userID = req.params.userID;

//         await sql.connect(config);

//         const userData = await sql.query`SELECT * FROM Notifications WHERE UserID = ${userID}`;
//         result = await sql.query`SELECT COUNT(*) AS TotalCount FROM Notifications WHERE UserID = ${userID} AND IsDeleted = 0`;

//         userData.recordset.forEach((entry) => {
//             entry.IsDeleted = !!entry.IsDeleted;
//         });
//         return errorResponse(200, { errorCode: 0, totalCount: result.recordset[0].TotalCount, result: userData.recordset });
//     } catch (error) {
//         console.error('Error:', error.message);
//         return errorResponse(500, { errorCode: 1, result: [{ message: 'Error' }] });
//     }
// });
// app.delete('/delete', async (req, res) => {
//     const errorResponse = (statusCode, message) => {
//         return res.status(statusCode).send(message);
//     };
//     try {
//         const { ids } = req.body;
//         await sql.connect(config);

//         for (const id of ids) {
//             await sql.query`UPDATE Notifications SET IsDeleted = 1 WHERE NotificationID = ${id}`;
//         }

//         return errorResponse(200, { errorCode: 0, result: [{ message: 'Entries deleted successfully' }] });
//     } catch (error) {
//         console.error('Error:', error.message);
//         return errorResponse(500, { errorCode: 1, result: [{ message: 'Error' }] });
//     }
// });
//b2c notification end


//b2cID domain wise

app.get('/get-b2cID', async (req, res) => {
    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    try {
        const domainName = req.query.domain;

        if (!domainName) {
            return errorResponse(400, { error: 'Please provide a domain name.' });
        }

        await sql.connect(config);

        const queryResult = await sql.query`SELECT b2cID FROM domain_b2cID_mapping WHERE domain_name = ${domainName}`;


        if (queryResult.recordset.length > 0) {
            return errorResponse(200, { errorCode: 0,  result: [{ b2cID: queryResult.recordset[0].b2cID }] });
        } else {
            return errorResponse(200, { errorCode: 1,  result: [{ message: 'Domain not found' }] });
        }
    } catch (err) {
        console.error('Error:', err.message);
        return errorResponse(500, { errorCode: 1, result: [{ message: 'Error' }] });
    }
});
// Post a new B2C ID
app.post('/post-b2cID', async (req, res) => {
    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    try {
        const { b2cID, username, domain } = req.body;

        if (!b2cID || !username || !domain) {
            return errorResponse(400, { error: 'Please provide b2cID, username, and domain.' });
        }

        await sql.connect(config);

        const checkQuery = await sql.query`SELECT b2cID FROM b2cID_mapping WHERE b2cID = ${b2cID}`;
        console.log('Check Query Result:', checkQuery.recordset);

        if (checkQuery.recordset.length > 0) {
            return errorResponse(400, { errorCode: 1, result: [{ message: 'B2C ID already exists.' }] });
        }

        await sql.query`
            INSERT INTO b2cID_mapping (b2cID, username, domain)
            VALUES (${b2cID}, ${username}, ${domain})
        `;
        console.log('B2C ID successfully created.');

        return res.status(200).send({ errorCode: 0, result: [{ message: 'B2C ID successfully created.' }] });
    } catch (err) {
        console.error('Error during POST:', err.message);
        return errorResponse(500, { errorCode: 1, result: [{ message: 'Internal Server Error' }] });
    }
});
// Get all B2C IDs
app.get('/get-all-b2cIDs', async (req, res) => {
    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    try {
        await sql.connect(config);
        const queryResult = await sql.query`SELECT b2cID FROM b2cID_mapping`

        if (queryResult.recordset.length > 0) {
            return res.status(200).send({ errorCode: 0, result: queryResult.recordset });
        } else {
            return errorResponse(200, { errorCode: 1, result: [{ message: 'No B2C IDs found.' }] });
        }
    } catch (err) {
        console.error('Error:', err.message);
        return errorResponse(500, { errorCode: 1, result: [{ message: 'Error' }] });
    }
});
app.get('/get-all-b2cIDsnew', async (req, res) => {
    const externalUrl = 'https://777777.today/pad=81/get-all-b2cIDs';

    try {
        const response = await axios.get(externalUrl);

        // Check if the external API returned a successful response
        if (response.status === 200) {
            return res.status(200).send(response.data);
        } else {
            return res.status(response.status).send({
                errorCode: 1,
                result: [{ message: 'Failed to retrieve B2C IDs from external API.' }]
            });
        }
    } catch (err) {
        console.error('Error:', err.message);
        return res.status(500).send({
            errorCode: 1,
            result: [{ message: 'Internal Server Error' }]
        });
    }
});

app.post('/b2cID_mapping', async (req, res) => {
    const { username, isDW } = req.body;

    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    try {
        await sql.connect(config);

        const queryResult = await sql.query`
            IF EXISTS (SELECT 1 FROM b2cID_mapping WHERE username = ${username})
            BEGIN
                UPDATE b2cID_mapping
                SET isDW = ${isDW ? 1 : 0}
                WHERE username = ${username}
            END
            ELSE
            BEGIN
                INSERT INTO b2cID_mapping (username, isDW)
                VALUES (${username}, ${isDW ? 1 : 0})
            END
        `;

        return res.status(200).send({ errorCode: 0, message: 'Record updated successfully' });
    } catch (err) {
        console.error('Error:', err.message);
        return errorResponse(500, { errorCode: 1, message: 'Error updating record' });
    }
});
app.get('/b2cID_mapping', async (req, res) => {
    const { username, domain } = req.query;

    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    try {
        await sql.connect(config);

        let queryResult;

        if (username) {
            // Retrieve record by username
            queryResult = await sql.query`
                SELECT b2cID, username, isDW
                FROM b2cID_mapping
                WHERE username = ${username}
            `;
        } else if (domain) {
            // Retrieve all records by domain
            queryResult = await sql.query`
                SELECT b2cID, username, isDW
                FROM b2cID_mapping
                WHERE domain = ${domain}
            `;
        } else {
            return errorResponse(400, { errorCode: 1, message: 'Please provide either username or domain.' });
        }

        if (queryResult.recordset.length > 0) {
            return res.status(200).send({ errorCode: 0, result: queryResult.recordset });
        } else {
            const notFoundMessage = username ? 'Username not found' : 'No records found for the domain';
            return res.status(200).send({ errorCode: 1, result: notFoundMessage });
        }
    } catch (err) {
        console.error('Error:', err.message);
        return errorResponse(500, { errorCode: 1, message: 'Error retrieving record' });
    }
});
//

// referalwithdrawal//
app.post('/sendWithdrawold', [
    body('paymentMethod').notEmpty().withMessage('Payment method is required.').isString().trim(),
    body('paymentType').notEmpty().withMessage('Payment type is required.').isString().trim(),
    body('Amount').notEmpty().withMessage('Amount is required.').isNumeric(),
    body('walletNumber').notEmpty().withMessage('Wallet number is required.'),
    body('userID').notEmpty().withMessage('User ID is required.').isInt(),
    body('userName').notEmpty().withMessage('userName is required.').isString().trim(),
    body('domain').notEmpty().withMessage('Domain is required.').isString().trim(),
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            errorCode: 1,
            result: errors.array().map(error => ({
                field: error.param,
                message: error.msg
            }))
        });
    }

    const { paymentMethod, paymentType, Amount, walletNumber, userID, userName, domain } = req.body;
    
    const currentDate = new Date();
    const timezoneOffset = currentDate.getTimezoneOffset() * 60000; 
    const requestDate = new Date(currentDate.getTime() - timezoneOffset).toISOString().slice(0, 19).replace('T', ' '); 

    try {
        await sql.connect(config);

        await sql.query`
            INSERT INTO Withdrawals (paymentMethod, paymentType, Amount, walletNumber, requestDate, userID, userName,domain, Status)
            VALUES (${paymentMethod}, ${paymentType}, ${Amount}, ${walletNumber}, ${requestDate}, ${userID}, ${userName},${domain}, 0)
        `;
        console.log('Withdrawal request successfully logged:', {
            paymentMethod,
            paymentType,
            Amount,
            walletNumber,
            requestDate,
            userID,
            userName,
            domain,
            Status: 0
        });
        res.status(200).json({
            errorCode: 0,
            result: [{ message: 'Withdrawal request successfully processed.' }]
        });
    } catch (error) {
        console.error('Error processing withdrawal request:', error.message);
        res.status(500).json({
            errorCode: 1,
            result: [{ message: 'Internal Server Error' }]
        });
    }
});
app.post('/sendWithdraw', [
    body('paymentMethod').notEmpty().withMessage('Payment method is required.').isString().trim(),
    body('paymentType').notEmpty().withMessage('Payment type is required.').isString().trim(),
    body('Amount').notEmpty().withMessage('Amount is required.').isNumeric(),
    body('walletNumber').notEmpty().withMessage('Wallet number is required.'),
    body('userID').notEmpty().withMessage('User ID is required.').isInt(),
    body('userName').notEmpty().withMessage('userName is required.').isString().trim(),
    body('domain').notEmpty().withMessage('Domain is required.').isString().trim(),
    body('password').notEmpty().withMessage('Password is required.').isString().trim(),
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            errorCode: 1,
            result: errors.array().map(error => ({
                field: error.param,
                message: error.msg
            }))
        });
    }

    const { paymentMethod, paymentType, Amount, walletNumber, userID, userName, domain, password } = req.body;
    
    const currentDate = new Date();
    const timezoneOffset = currentDate.getTimezoneOffset() * 60000; 
    const requestDate = new Date(currentDate.getTime() - timezoneOffset).toISOString().slice(0, 19).replace('T', ' '); 

    try {
      
        const withdrawResponse = await withdrawAgentCom(req.body);

        if (withdrawResponse.errorCode !== 0) {
            return res.status(200).json({
                errorCode: 1,
                result: [{ message: withdrawResponse.message || 'withdrawAgentCom API failed.' }]
            });
        }

        // 🔹 Database Connection Open
        await sql.connect(config);

        await sql.query`
            INSERT INTO Withdrawals (paymentMethod, paymentType, Amount, walletNumber, requestDate, userID, userName, domain, password, Status)
            VALUES (${paymentMethod}, ${paymentType}, ${Amount}, ${walletNumber}, ${requestDate}, ${userID}, ${userName}, ${domain}, ${password}, 0)
        `;


        res.status(200).json({
            errorCode: 0,
            result: [{ message: 'Withdrawal request successfully processed.' }]
        });

    } catch (error) {
        // console.error('Error processing withdrawal request:', error.message);
        res.status(500).json({
            errorCode: 1,
            result: [{ message: 'Internal Server Error' }]
        });
    } finally {
   
        sql.close();
    }
});
async function withdrawAgentCom(data) {
    try {
        const body = {
            userId: data.userID,
            amount: Number(data.Amount),
            password: data.password, 
            mainUserId: data.userID
        };

        // console.log("🔹 Sending Request to withdrawAgentCom:", JSON.stringify(body, null, 2)); 

        const response = await fetch('https://777777.today/pad=81/withdrawAgentCom', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        // console.log(`🔹 Response Status: ${response.status} - ${response.statusText}`); 

        if (!response.ok) {
            throw new Error(`API Error: ${response.statusText}`);
        }

        const responseData = await response.json();
        // console.log("🔹 API Response Data:", JSON.stringify(responseData, null, 2)); 

        return responseData;
    } catch (error) {
        // console.error('❌ Error calling withdrawAgentCom:', error.message);
        return { errorCode: 1, message: 'Failed to call withdrawAgentCom API' };
    }
}

app.get('/checkWithdrawalStatus', async (req, res) => {
    const { domain, userID } = req.query;

    try {
        await sql.connect(config);

        const result = await sql.query`
            SELECT COUNT(*) AS pendingCount
            FROM Withdrawals
            WHERE domain = ${domain} AND userID = ${userID} AND Status = 0
        `;

        const pendingCount = result.recordset[0].pendingCount;

        if (pendingCount > 0) {
            return res.status(200).json({
                errorCode: 0,
                result: [{ isWidrawalPending: 1 }]
            });
        } else {
            return res.status(200).json({
                errorCode: 0,
                result: [{ isWidrawalPending: 0 }]
            });
        }
    } catch (error) {
        console.error('Error checking withdrawal status:', error.message);
        res.status(500).json({
            errorCode: 1,
            result: [{ message: 'Internal Server Error' }]
        });
    }
});


app.get('/getWithdrawalRequest', async (req, res) => {
    const { domain, userID } = req.query;  

    try {
        await sql.connect(config);

        let query = `
            SELECT id, paymentMethod, paymentType, Amount, walletNumber, requestDate, userID, userName, attachment, Status, Remark, domain,settlement_date
            FROM Withdrawals
        `;

        const request = new sql.Request();

        if (domain) {
            query += ` WHERE domain = @domain`;
            request.input('domain', sql.VarChar, domain);
        } else if (userID) {
            query += ` WHERE userID = @userID`;
            request.input('userID', sql.Int, userID);
        }

        const result = await request.query(query);

        if (result.recordset.length > 0) {
            res.status(200).json({
                errorCode: 0,
                result: result.recordset
            });
        } else {
            res.status(200).json({
                errorCode: 0,
                result: [{ message: 'No withdrawal records found for the provided domain or userID.' }]
            });
        }

    } catch (error) {
        console.error('Error retrieving withdrawals:', error.message);
        res.status(500).json({
            errorCode: 1,
            result: [{ message: 'error' }]
        });
    }
});
app.get('/Upisettlementhistory', async (req, res) => {
    const { domain, userID, from, to } = req.query;  

    try {
        await sql.connect(config);

        let query = `
            SELECT id, paymentMethod, paymentType, Amount, walletNumber, requestDate, userID, userName, attachment, Status, Remark, domain, settlement_date
            FROM Withdrawals
            WHERE Status IN (1, 2)
        `;

        const request = new sql.Request();

        if (domain) {
            query += ` AND domain = @domain`;
            request.input('domain', sql.VarChar, domain);
        }
        if (userID) {
            query += ` AND userID = @userID`;
            request.input('userID', sql.Int, userID);
        }

        if (from && to) {
            query += ` AND settlement_date BETWEEN @from AND @to`;
            request.input('from', sql.DateTime, from);  
            request.input('to', sql.DateTime, to);     
        } else if (from) {
            query += ` AND settlement_date >= @from`;
            request.input('from', sql.DateTime, from); 
        } else if (to) {
            query += ` AND settlement_date <= @to`;
            request.input('to', sql.DateTime, to);     
        }

        const result = await request.query(query);

        if (result.recordset.length > 0) {
            res.status(200).json({
                errorCode: 0,
                result: result.recordset
            });
        } else {
            res.status(200).json({
                errorCode: 0,
                result: [{ message: 'No withdrawal records found.' }]
            });
        }

    } catch (error) {
        console.error('Error retrieving UPI settlements:', error.message);
        res.status(500).json({
            errorCode: 1,
            result: [{ message: 'error' }]
        });
    }
});
app.post('/updateWithdrawalStatus', upload.single('attachment'), async (req, res) => {
    const { id, userID, Status, Remark } = req.body;
    let attachmentPath = null;

    if (req.file) {
        attachmentPath = `https://api2.streamingtv.fun:3481/uploads/${req.file.filename}`;
    }

    try {
        await sql.connect(config);

        const currentDate = new Date();
        const timezoneOffset = currentDate.getTimezoneOffset() * 60000; 
        const localTime = new Date(currentDate.getTime() - timezoneOffset).toISOString().slice(0, 19).replace('T', ' '); 

        let query = `
            UPDATE Withdrawals
            SET Status = @status,
                Remark = @remark,
                settlement_date = @settlementDate  -- Use the adjusted date
        `;

        if (attachmentPath) {
            query += `, attachment = @attachment`;
        }

        query += ` WHERE id = @id AND userID = @userID`;

        const request = new sql.Request();
        request.input('status', sql.Int, Status);
        request.input('remark', sql.NVarChar, Remark || null);
        request.input('id', sql.Int, id);
        request.input('userID', sql.Int, userID);
        request.input('settlementDate', sql.NVarChar, localTime); 

        if (attachmentPath) {
            request.input('attachment', sql.NVarChar, attachmentPath);
        }

        const updateResult = await request.query(query);

        if (updateResult.rowsAffected[0] > 0) {
            res.status(200).json({
                errorCode: 0,
                result: [{ message: 'Withdrawal status, remark, and attachment successfully updated.' }]
            });
        } else {
            res.status(200).json({
                errorCode: 1,
                result: [{ message: 'No withdrawal found.' }]
            });
        }

    } catch (error) {
        console.error('Error updating withdrawal status:', error.message);
        res.status(500).json({
            errorCode: 1,
            result: [{ message: 'Internal Server Error' }]
        });
    }
});


app.post('/sendBankWithdrawal', [
    body('paymentMethod').notEmpty().withMessage('Payment method is required.').isString().trim(),
    body('bank').notEmpty().withMessage('Bank is required.').isString().trim(),
    body('bankHolderName').notEmpty().withMessage('Bank holder name is required.').isString().trim(),
    body('accountNumber').notEmpty().withMessage('Account number is required.').isString().trim(),
    body('IFSC').notEmpty().withMessage('IFSC code is required.').isString().trim(),
    body('amount').notEmpty().withMessage('Amount is required.').isNumeric(),
    body('userID').notEmpty().withMessage('User ID is required.').isInt(),
    body('username').notEmpty().withMessage('Username is required.').isString().trim(),
    body('domain').notEmpty().withMessage('Domain is required.').isString().trim(),
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({ errorCode: 1, result: errors.array() });
    }

    const { paymentMethod, bank, bankHolderName, accountNumber, IFSC, amount, userID, username,domain } = req.body;
    const currentDate = new Date();
    const timezoneOffset = currentDate.getTimezoneOffset() * 60000; 
    const requestDate = new Date(currentDate.getTime() - timezoneOffset).toISOString().slice(0, 19).replace('T', ' '); 
    try {
        await sql.connect(config);

        await sql.query`
            INSERT INTO BankWithdrawals (paymentMethod, bank, bankHolderName, accountNumber, IFSC, amount, status, userID, username,domain, requestDate)
            VALUES (${paymentMethod}, ${bank}, ${bankHolderName}, ${accountNumber}, ${IFSC}, ${amount}, 0, ${userID}, ${username}, ${domain}, ${requestDate})
        `;
        console.log('Bank withdrawal request successfully logged:', {
            paymentMethod,
            bank,
            bankHolderName,
            accountNumber,
            IFSC,
            amount,
            status: 0,
            userID,
            username,
            domain,
            requestDate
        });
        res.status(200).json({
            errorCode: 0,
            result: [{ message: 'Bank withdrawal request successfully processed.' }]
        });
    } catch (error) {
        console.error('Error processing bank withdrawal request:', error.message);
        res.status(500).json({
            errorCode: 1,
            result: [{ message: 'Error' }]
        });
    }
});
app.get('/getBankWithdrawals', async (req, res) => {
    const { domain, userID } = req.query;  

    try {
        await sql.connect(config);

        let query = `
            SELECT id, paymentMethod, bank, bankHolderName, accountNumber, IFSC, amount, status, remark, userID, username, attachment, requestDate, domain,settlement_date
            FROM BankWithdrawals
        `;

        const request = new sql.Request();

        if (domain) {
            query += ` WHERE domain = @domain`;
            request.input('domain', sql.VarChar, domain);  
        } else if (userID) {
            query += ` WHERE userID = @userID`;
            request.input('userID', sql.Int, userID);  
        }

        const result = await request.query(query);

        if (result.recordset.length > 0) {
            res.status(200).json({
                errorCode: 0,
                result: result.recordset
            });
        } else {
            res.status(200).json({
                errorCode: 0,
                result: [{ message: 'No bank withdrawal records found for the provided domain or userID.' }]
            });
        }

    } catch (error) {
        console.error('Error retrieving bank withdrawals:', error.message);
        res.status(500).json({
            errorCode: 1,
            result: [{ message: 'error' }]
        });
    }
});
app.get('/Banksettlementhistory', async (req, res) => {
    const { domain, userID, from, to } = req.query;  

    try {
        await sql.connect(config);

        let query = `
        SELECT id, paymentMethod, bank, bankHolderName, accountNumber, IFSC, amount, status, remark, userID, username, attachment, requestDate, domain, settlement_date
        FROM BankWithdrawals
        WHERE status IN (1, 2)
        `;

        const request = new sql.Request();

        if (domain) {
            query += ` AND domain = @domain`;
            request.input('domain', sql.VarChar, domain);
        }

        if (userID) {
            query += ` AND userID = @userID`;
            request.input('userID', sql.Int, userID);
        }

        if (from && to) {
            query += ` AND (settlement_date BETWEEN @from AND @to OR settlement_date IS NULL)`;
            request.input('from', sql.DateTime, from);  
            request.input('to', sql.DateTime, to);     
        } else if (from) {
            query += ` AND (settlement_date >= @from OR settlement_date IS NULL)`;
            request.input('from', sql.DateTime, from); 
        } else if (to) {
            query += ` AND (settlement_date <= @to OR settlement_date IS NULL)`;
            request.input('to', sql.DateTime, to);     
        }

        const result = await request.query(query);

        if (result.recordset.length > 0) {
            res.status(200).json({
                errorCode: 0,
                result: result.recordset
            });
        } else {
            res.status(200).json({
                errorCode: 0,
                result: [{ message: 'No withdrawal records found.' }]
            });
        }

    } catch (error) {
        console.error('Error retrieving UPI settlements:', error.message);
        res.status(500).json({
            errorCode: 1,
            result: [{ message: 'error' }]
        });
    }
});
app.post('/updateBankWithdrawal', upload.single('attachment'), async (req, res) => {
    const { status, id, userID, remark } = req.body;
    let attachmentPath = null;

    if (req.file) {
        attachmentPath = `https://api2.streamingtv.fun:3481/uploads/${req.file.filename}`;
    }

    try {
        await sql.connect(config);

        const currentDate = new Date();
        const timezoneOffset = currentDate.getTimezoneOffset() * 60000; 
        const localTime = new Date(currentDate.getTime() - timezoneOffset).toISOString().slice(0, 19).replace('T', ' '); 

        let query = `
            UPDATE BankWithdrawals
            SET status = @status,
                remark = @remark,
                settlement_date = @settlementDate  -- Use the adjusted date
        `;

        if (attachmentPath) {
            query += `, attachment = @attachment`;
        }

        query += ` WHERE id = @id AND userID = @userID`;

        const request = new sql.Request();
        request.input('status', sql.Int, status);
        request.input('remark', sql.NVarChar, remark || null);
        request.input('id', sql.Int, id);
        request.input('userID', sql.Int, userID);
        request.input('settlementDate', sql.NVarChar, localTime); 

        if (attachmentPath) {
            request.input('attachment', sql.NVarChar, attachmentPath);
        }

        const updateResult = await request.query(query);

        if (updateResult.rowsAffected[0] > 0) {
            res.status(200).json({
                errorCode: 0,
                result: [{ message: 'Bank withdrawal status, remark, and attachment successfully updated.' }]
            });
        } else {
            res.status(404).json({
                errorCode: 1,
                result: [{ message: 'No bank withdrawal found.' }]
            });
        }

    } catch (error) {
        console.error('Error updating bank withdrawal:', error.message);
        res.status(500).json({
            errorCode: 1,
            result: [{ message: 'Internal server error' }]
        });
    }
});
app.get('/getPendingCounts', async (req, res) => {
    const { domain } = req.query;

    try {
        await sql.connect(config);

        const query = `
            SELECT
                (SELECT COUNT(*) FROM BankWithdrawals WHERE status = 0 AND domain = @domain) AS bankCount,
                (SELECT COUNT(*) FROM Withdrawals WHERE status = 0 AND domain = @domain) AS upiCount
        `;

        const request = new sql.Request();
        request.input('domain', sql.VarChar, domain);  

        const result = await request.query(query);

        res.status(200).json({
            errorCode: 0,
            result: {
                bankCount: result.recordset[0].bankCount,
                upiCount: result.recordset[0].upiCount
            }
        });
    } catch (error) {
        console.error('Error retrieving pending counts:', error.message);
        res.status(500).json({
            errorCode: 1,
            result: [{ message: 'Error retrieving pending counts.' }]
        });
    }
});
// penality
app.get('/getPenaltynew', async (req, res) => {
    const { domain_name } = req.query;

    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    try {
        if (!domain_name) {
            return errorResponse(400, { errorCode: 1, result: [{ message: 'Domain name is required.' }] });
        }

        await sql.connect(config);

        const queryResult = await sql.query`SELECT penalty FROM domain_penalties WHERE domain_name = ${domain_name}`;

        if (queryResult.recordset.length > 0) {
            return res.status(200).send({ errorCode: 0, result: queryResult.recordset[0] });
        } else {
            return res.status(200).send({ errorCode: 0, result: { penalty: 0 } });
        }
    } catch (err) {
        console.error('Error:', err.message);
        return errorResponse(500, { errorCode: 1, result: [{ message: 'Server error.' }] });
    }
});
app.get('/getPenalty', async (req, res) => {
    const { domain_name } = req.query;

    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    try {
        if (!domain_name) {
            return errorResponse(400, { errorCode: 1, result: [{ message: 'Domain name is required.' }] });
        }

        const cacheKey = `getPenalty:${domain_name}`;

        redisClient.get(cacheKey, async (err, cachedData) => {
            if (err) {
                console.error('Redis GET error:', err);
                return errorResponse(500, { errorCode: 1, result: [{ message: 'Server error while accessing cache.' }] });
            }

            if (cachedData) {
                // console.log('Cache hit:', cachedData);
                return res.status(200).send({ errorCode: 0, result: JSON.parse(cachedData) });
            }

            try {
                await sql.connect(config);

                const queryResult = await sql.query`SELECT penalty FROM domain_penalties WHERE domain_name = ${domain_name}`;

                const result = queryResult.recordset.length > 0
                    ? queryResult.recordset[0]
                    : { penalty: 0 };

                redisClient.setex(cacheKey, 600, JSON.stringify(result), (setErr) => {
                    if (setErr) {
                        console.error('Redis SET error:', setErr);
                    } else {
                        console.log('Data cached:', result);
                    }
                });

                return res.status(200).send({ errorCode: 0, result });
            } catch (dbErr) {
                console.error('Database error:', dbErr.message);
                return errorResponse(500, { errorCode: 1, result: [{ message: 'Server error while accessing database.' }] });
            }
        });
    } catch (err) {
        console.error('Error:', err.message);
        return errorResponse(500, { errorCode: 1, result: [{ message: 'Server error.' }] });
    }
});
const allowedDomains = ['risxbet.bet'];
app.post('/setPenalty', async (req, res) => {
    const { domain_name, penalty } = req.body;

    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    if (!domain_name || typeof penalty !== 'number') {
        return errorResponse(400, {
            errorCode: 1,
            result: [{ message: 'domain_name and numeric penalty are required.' }]
        });
    }
    if (!allowedDomains.includes(domain_name)) {
        return errorResponse(403, {
            errorCode: 1,
            result: [{ message: 'Not authorized' }]
        });
    }

    try {
        await sql.connect(config);

        const checkResult = await sql.query`
            SELECT COUNT(*) AS count FROM domain_penalties WHERE domain_name = ${domain_name}
        `;

        if (checkResult.recordset[0].count > 0) {
            await sql.query`
                UPDATE domain_penalties SET penalty = ${penalty} WHERE domain_name = ${domain_name}
            `;
        } else {
            await sql.query`
                INSERT INTO domain_penalties (domain_name, penalty) VALUES (${domain_name}, ${penalty})
            `;
        }
        const cacheKey = `getPenalty:${domain_name}`;
        redisClient.del(cacheKey, (err) => {
            if (err) console.error('Redis DEL error:', err);
            else console.log(`Cache cleared for ${cacheKey}`);
        });

        return res.status(200).send({
            errorCode: 0,
            result: [{ message: 'Penalty updated successfully.' }]
        });

    } catch (err) {
        console.error('Error:', err.message);
        return errorResponse(500, {
            errorCode: 1,
            result: [{ message: 'Server error while updating penalty.' }]
        });
    }
});
app.get('/get-referral-percent', async (req, res) => {
    const { domain } = req.query;

    if (!domain) {
        return res.status(400).json({ errorCode: 1, message: 'Domain is required' });
    }

    try {
        await sql.connect(config);
        const request = new sql.Request();
        request.input('domain', sql.VarChar, domain);

        const result = await request.query(`
            SELECT refer_percent FROM DomainReferral WHERE domain = @domain
        `);

        if (result.recordset.length > 0) {
            res.status(200).json({ errorCode: 0, result: result.recordset[0] });
        } else {
            res.status(200).json({ errorCode: 1, message: 'Domain not found' });
        }

    } catch (err) {
        console.error('Error:', err);
        res.status(500).json({ errorCode: 1, message: 'Server error' });
    }
});

// single dw request
app.get('/getPendingCheckStatus', async (req, res) => {
    const { domain } = req.query;

    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    try {
        await sql.connect(config);

        const queryResult = await sql.query`
            SELECT CASE 
                WHEN isPendingCheck = 'true' THEN 1 
                ELSE 0 
            END AS isPendingCheck 
            FROM DWrequestallow 
            WHERE domain = ${domain}
        `;

        if (queryResult.recordset.length > 0) {
            return res.status(200).send({ errorCode: 0, result: queryResult.recordset[0] });
        } else {
            return res.status(200).send({ errorCode: 0, result: { isPendingCheck: 0 } });
        }
    } catch (err) {
        console.error('Error:', err.message);
        return errorResponse(500, { errorCode: 1, result: [{ message: 'error.' }] });
    }
});
app.get('/getDepositComm', async (req, res) => {
    const { domain } = req.query;

    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    try {
        if (!domain) {
            return errorResponse(400, { errorCode: 1, result: [{ message: 'Domain name is required.' }] });
        }

        await sql.connect(config);

        const queryResult = await sql.query`SELECT b2cComm FROM B2cDeposit WHERE domain = ${domain}`;

        if (queryResult.recordset.length > 0) {
            return res.status(200).send({ errorCode: 0, result: queryResult.recordset[0] });
        } else {
            return res.status(200).send({ errorCode: 0, result: { b2cComm: 0 } });
        }
    } catch (err) {
        console.error('Error:', err.message);
        return errorResponse(500, { errorCode: 1, result: [{ message: 'Server error.' }] });
    }
});
app.get('/getB2CAgents', async (req, res) => {
    const domain = req.query.domain;
    const externalUrl = `https://777777.today/pad=81/getB2CAgents?domain=${domain}`;

    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    try {
        const response = await axios.get(externalUrl);

        if (response.status === 200) {
            const b2cData = response.data.result.map(item => ({
                userId: item.userId,
                userName: item.userName,
                b2cID: item.b2cID,
                domainName: item.domainName,
                isFav: false 
            }));

            const dataDir = '/enterprise/b2cData';
            if (!fs.existsSync(dataDir)) {
                fs.mkdirSync(dataDir, { recursive: true });
            }

            const filePath = path.join(dataDir, `${domain}.json`);

            let existingData = [];
            if (fs.existsSync(filePath)) {
                const fileContent = fs.readFileSync(filePath, 'utf8');
                existingData = JSON.parse(fileContent);
            }

            const newData = b2cData.filter(newItem => 
                !existingData.some(existingItem => existingItem.userId === newItem.userId)
            );

            const updatedData = [...existingData, ...newData];

            fs.writeFileSync(filePath, JSON.stringify(updatedData, null, 2), 'utf8');

            return res.status(200).send({
                errorCode: 0,
                errorDescription: null,
                result: updatedData
            });
        } else {
            return res.status(response.status).send({
                errorCode: 1,
                result: [{ message: 'Failed to retrieve B2C IDs from external API.' }]
            });
        }
    } catch (err) {
        console.error('Error:', err.message);
        return errorResponse(500, { errorCode: 1, result: [{ message: 'Internal Server Error' }] });
    }
});
app.post('/updateIsFav', (req, res) => {
    const errorResponse = (statusCode, message) => {
        return res.status(statusCode).send(message);
    };

    const { domain, userId, isFav } = req.body;
    const dataDir = '/enterprise/b2cData';
    const filePath = path.join(dataDir, `${domain}.json`);

    if (!fs.existsSync(filePath)) {
        return errorResponse(404, { errorCode: 1, result: [{ message: 'Domain file not found' }] });
    }

    let existingData = JSON.parse(fs.readFileSync(filePath, 'utf8'));

    const userIndex = existingData.findIndex(item => item.userId === userId);
    if (userIndex === -1) {
        return errorResponse(404, { errorCode: 1, result: [{ message: 'User not found' }] });
    }

    existingData[userIndex].isFav = isFav;

    fs.writeFileSync(filePath, JSON.stringify(existingData, null, 2), 'utf8');

    return errorResponse(200, { errorCode: 0, result: [{ message: 'Status updated successfully.' }] });
});
app.get('/getFavoriteAgents', (req, res) => {
    const domain = req.query.domain;
    const dataDir = '/enterprise/b2cData';
    const filePath = path.join(dataDir, `${domain}.json`);

    if (!fs.existsSync(filePath)) {
        return res.status(200).send({ message: 'Domain file not found' });
    }
    const existingData = JSON.parse(fs.readFileSync(filePath, 'utf8'));

    const favoriteAgents = existingData.filter(item => item.isFav === true);

    return res.status(200).send({
        errorCode: 0,
        errorDescription: null,
        result: favoriteAgents
    });
});


app.get('/api/logs/:username', (req, res) => {
    const username = req.params.username.toLowerCase();
    const filePath = path.join(__dirname, 'StoreUser.txt');

    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error("File read error:", err);
            return res.status(500).json({ error: 'File read error' });
        }

        const logs = data
            .split('\n')
            .filter(line => line.toLowerCase().includes(username))
            .map(line => {
                const logEntry = {
                    raw: line.trim()
                };

                // Try to extract structured info
                const match = line.match(/^(Login Successfull|invalid username\/password|Incorrect Captcha)\s+(\S+)\s+IP=\s*([\d.]+)\s+time=\s+([\d:-\s]+)/);

                if (match) {
                    logEntry.status = match[1];
                    logEntry.username = match[2];
                    logEntry.ip = match[3];
                    logEntry.time = match[4];
                }

                return logEntry;
            });

        res.json({
            username: username,
            logs: logs
        });
    });
});

// Welcome Bonus API
app.post('/api/welcomeBonus', async (req, res) => {
    const { domain, username, userId, mainUserId, agentRef } = req.body;

    // allowed domains
    const domainConfig = {
        "baaaji.win": { amount: 1, targetMainUserId: 4093141 },
        "foxplay.pro": { amount: 10, targetMainUserId: 5549622 },
        // "4six.com": { amount: 40, targetMainUserId: 5856890 },
        
    };

    if (!domainConfig[domain]) {
        return res.status(200).json({ message: 'Not Authorized' });
    }

    const { amount, targetMainUserId: configTargetId } = domainConfig[domain];

    const finalTargetMainUserId = agentRef === true ? configTargetId : mainUserId;

    const payload = {
        password: "abcdr1245",
        txntype: 1,
        users: [{
            userId,
            txnType: 1,
            amount: amount,
            remark: "Welcome bonus",
            key: 0,
            mainUserId: finalTargetMainUserId
        }]
    };

    const axiosInstance = axios.create({ timeout: 1000 });

    try {
        const apiRes = await axiosInstance.post('https://777777.today/pad=81/transferSpec', payload);
        console.log(apiRes.data)
        const result = apiRes.data?.result?.[0]?.result || "UNKNOWN";

        sql.connect(config).then(pool =>
            pool.request().query(`
                INSERT INTO welcome_bonus_logs (domain, username, user_id, main_user_id, agent_ref, status, bonus)
                VALUES ('${domain}', '${username}', ${userId}, ${finalTargetMainUserId}, '${agentRef}', '${result}', ${amount})
            `)
        );
        res.status(200).json({
            errorCode: 0,
            result: [{
                message:result,
                bonusamt:amount
            }]
        });
    } catch (err) {
        res.status(200).json({
            errorCode: 1,
            result: [{
                message:'ERROR',
                error: err.message
            }]
        });
    }
});

app.get('/api/welcomeBonusLogs', async (req, res) => {
    const { domain, user_id } = req.query;

    try {
        const pool = await sql.connect(config);
        const request = pool.request();

        let query = `
            SELECT id, domain, username, user_id, main_user_id, agent_ref, status, bonus, created_at
            FROM welcome_bonus_logs
            WHERE LOWER(status) = 'success'
        `;

        if (domain) {
            query += ` AND domain = @domain`;
            request.input('domain', sql.VarChar, domain);
        }

        if (user_id) {
            query += ` AND LTRIM(RTRIM(user_id)) = LTRIM(RTRIM(@user_id))`;
            request.input('user_id', sql.VarChar, user_id); 
        }

        query += ` ORDER BY id DESC`;

        const result = await request.query(query);

        res.status(200).json({
            errorCode: 0,
            result: [{
                message: 'Success',
                data: result.recordset
            }]
        });

    } catch (err) {
        console.error("Error in /api/welcomeBonusLogs:", err);

        const isTimeout = err.message.toLowerCase().includes("timeout");
        res.status(500).json({
            errorCode: 1,
            result: [{
                message: isTimeout ? "Timeout: Took too long to respond." : "Server error.",
                error: err.message
            }]
        });
    }
});


// 1st deposit bonus store
  const allowedDomains1 = [
    'baaaji.win',
    'baji.win',
    'foxplay.pro',
    'bdcrickeet.com',
    '4six.com',
    'bajimat365.com',
    'cashwinbd.com',
    'velkimax.com',
    '9xbaji.pro',
    'nagadsx.com',
    // 'vellki.live',
    // 'josh365.live',
    // '1xbet365.live',
    // 'velkibdt.online'
  ];
  const domainBonusMap = {
    'baaaji.win': 100,
    'baji.win': 5,
    'foxplay.pro':5,
    'bdcrickeet.com':10,
    '4six.com':5,
    'bajimat365.com':5,
    'velkimax.com':10,
    'cashwinbd.com':10,
    '9xbaji.pro':10,
    'nagadsx.com':10,
    // 'vellki.live':10,
    // 'josh365.live':10,
    // '1xbet365.live':10,
    // 'velkibdt.online':10
  };


  app.post('/add-deposit-bonus', async (req, res) => {
    const { userid, username, parentid, actual_amount, domainname,bonusType  } = req.body;
  
    if (!userid || !username || !parentid || !actual_amount || !domainname) {
      return res.status(400).json({
        errorCode: 1,
        result: [{ message: 'Missing required fields' }]
      });
    }
  
    const domainKey = domainname.toLowerCase();
  
    // 🔐 Domain Allow Check
    if (!allowedDomains1.includes(domainKey)) {
      return res.status(403).json({
        errorCode: 2,
        result: [{ message: 'Not authorized ' }]
      });
    }
  
    const bonus_percent = domainBonusMap[domainKey] || 0;
    const finalBonusType = bonusType || 'FIRST_DEPOSIT';
  
    try {
      const pool = await sql.connect(config);
  
      // 🔍 Duplicate Check (same userid + domain)
      const { recordset } = await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('domainname', sql.VarChar(100), domainKey)
        .query(`
          SELECT 1 FROM depositbonus 
          WHERE userid = @userid AND domainname = @domainname
        `);
  
      if (recordset.length > 0) {
        return res.status(200).json({
          errorCode: 3,
          result: [{ message: 'Bonus already exists for this user on this domain' }]
        });
      }
  

      await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('username', sql.VarChar(100), username)
        .input('parentid', sql.BigInt, parentid)
        .input('actual_amount', sql.Decimal(10, 2), actual_amount)
        .input('bonus_percent', sql.Decimal(5, 2), bonus_percent)
        .input('domainname', sql.VarChar(100), domainKey)
        .input('bonusType', sql.VarChar(50), finalBonusType)
        .query(`
          INSERT INTO depositbonus (userid, username, parentid, actual_amount, bonus_percent, domainname, bonusType)
          VALUES (@userid, @username, @parentid, @actual_amount, @bonus_percent, @domainname, @bonusType)
        `);
  
      return res.status(200).json({
        errorCode: 0,
        result: [{ success: true, bonus_percent }]
      });
  
    } catch (err) {
      return res.status(500).json({
        errorCode: 4,
        result: [{ message: 'error', error: err.message }]
      });
    }
  });

  app.post('/add-deposit-bonus-auto', async (req, res) => {
    const {
      userid,
      username,
      parentid,
      actual_amount,
      domainname,
      bonusType,
      agentRef
    } = req.body;
  
    if (!userid || !username || !parentid || !actual_amount || !domainname) {
      return res.status(400).json({
        errorCode: 1,
        result: [{ message: 'Missing required fields' }]
      });
    }
  
    const domainKey = domainname.toLowerCase();
  
    if (!allowedDomains1.includes(domainKey)) {
      return res.status(403).json({
        errorCode: 2,
        result: [{ message: 'Not authorized' }]
      });
    }
  
    const bonus_percent = domainBonusMap[domainKey] || 0;
    const invalidBonusTypes = [null, undefined, '', 'NO_BONUS', 'null', 'undefined'];

    const finalBonusType =
    invalidBonusTypes.includes(bonusType)
     ? 'ALL'
     : String(bonusType).toUpperCase();

        // if (finalBonusType === 'NO_BONUS') {
        //   const depositTxnId = generateDepositTxnId(userid);
    
        //   await pool.request()
        //     .input('depositTxnId', sql.VarChar(100), depositTxnId)
        //     .input('userid', sql.BigInt, userid)
        //     .input('username', sql.VarChar(100), username)
        //     .input('parentid', sql.BigInt, parentid)
        //     .input('domainname', sql.VarChar(100), domainKey)
        //     .input('amount', sql.Decimal(18,2), Number(actual_amount))
        //     .query(`
        //       INSERT INTO deposit_nobonus(depositTxnId, userid, username, parentid, domainname, amount, withdrawn_amount, createdAt)
        //       VALUES (@depositTxnId, @userid, @username, @parentid, @domainname, @amount, 0, GETDATE())
        //     `);
    
        //   return res.status(200).json({
        //     errorCode: 0,
        //     result: [{ success: true, bonusApplied: false, depositTxnId, message: 'NO_BONUS deposit stored' }]
        //   });
        // }
  
    try {
      const pool = await sql.connect(config);
  
      const { recordset } = await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('domainname', sql.VarChar(100), domainKey)
        .query(`
          SELECT 1 FROM depositbonus
          WHERE userid = @userid AND domainname = @domainname
        `);
  
      if (recordset.length > 0) {
        return res.status(200).json({
          errorCode: 3,
          result: [{ message: 'Bonus already exists for this user on this domain' }]
        });
      }
  
      const configRs = await pool.request()
        .input('domainname', sql.VarChar(100), domainKey)
        .query(`
          SELECT max_bonus
          FROM DomainBonusConfig
          WHERE domainname = @domainname
        `);
  
      const maxBonus = configRs.recordset[0]?.max_bonus || 0;
  
      let redeemAmount = (actual_amount * bonus_percent) / 100;
  
      if (maxBonus > 0 && redeemAmount > maxBonus) {
        redeemAmount = maxBonus;
      }
  
      const domainConfig = {
        "baaaji.win": { targetMainUserId: 4093141 },
        "baji.win": { targetMainUserId: 4093141 },
        "4six.com": { targetMainUserId: 5856890 },
        "9xbaji.pro": { targetMainUserId: 6138634 },
      };
  
      const finalTargetMainUserId =
        agentRef === true
          ? domainConfig[domainKey]?.targetMainUserId
          : parentid;
  
      const payload = {
        password: "abcdr1245",
        txntype: 1,
        users: [{
          userId: userid,
          txnType: 1,
          amount: redeemAmount, 
          remark: "Deposit bonus",
          key: 0,
          mainUserId: finalTargetMainUserId
        }]
      };
  
      const axiosInstance = axios.create({ timeout: 1000 });
      let apiRes;
  
      try {
        apiRes = await axiosInstance.post(
          'https://777777.today/pad=81/transferSpec',
          payload
        );
      } catch (apiErr) {
  
        await pool.request()
          .input('userid', sql.BigInt, userid)
          .input('username', sql.VarChar(100), username)
          .input('parentid', sql.BigInt, parentid)
          .input('domainname', sql.VarChar(100), domainKey)
          .input('api_name', sql.VarChar(100), 'transferSpec')
          .input('request_payload', sql.NVarChar(sql.MAX), JSON.stringify(payload))
          .input('response_payload', sql.NVarChar(sql.MAX), JSON.stringify(apiErr?.response?.data || {}))
          .input('error_message', sql.VarChar(500), apiErr.message)
          .query(`
            INSERT INTO transfer_error_logs
            (userid, username, parentid, domainname, api_name, request_payload, response_payload, error_message)
            VALUES
            (@userid, @username, @parentid, @domainname, @api_name, @request_payload, @response_payload, @error_message)
          `);
  
        return res.status(200).json({
          errorCode: 4,
          result: [{ message: 'Transfer API error', error: apiErr.message }]
        });
      }
  
      const transferResult =
        apiRes?.data?.result?.[0]?.result || 'FAILED';
  
      if (transferResult.toLowerCase() !== 'success') {
  
        await pool.request()
          .input('userid', sql.BigInt, userid)
          .input('username', sql.VarChar(100), username)
          .input('parentid', sql.BigInt, parentid)
          .input('domainname', sql.VarChar(100), domainKey)
          .input('api_name', sql.VarChar(100), 'transferSpec')
          .input('request_payload', sql.NVarChar(sql.MAX), JSON.stringify(payload))
          .input('response_payload', sql.NVarChar(sql.MAX), JSON.stringify(apiRes.data))
          .input('error_message', sql.VarChar(500), 'Transfer result not success')
          .query(`
            INSERT INTO transfer_error_logs
            (userid, username, parentid, domainname, api_name, request_payload, response_payload, error_message)
            VALUES
            (@userid, @username, @parentid, @domainname, @api_name, @request_payload, @response_payload, @error_message)
          `);
  
        return res.status(200).json({
          errorCode: 4,
          result: [{ message: 'Transfer failed', transferResult }]
        });
      }
  
      await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('username', sql.VarChar(100), username)
        .input('parentid', sql.BigInt, parentid)
        .input('actual_amount', sql.Decimal(10, 2), actual_amount)
        .input('bonus_percent', sql.Decimal(5, 2), bonus_percent)
        .input('domainname', sql.VarChar(100), domainKey)
        .input('bonusType', sql.VarChar(50), finalBonusType)
        .input('agentRef', sql.Bit, agentRef ? 1 : 0)
        .query(`
          INSERT INTO depositbonus
          (userid, username, parentid, actual_amount, bonus_percent, domainname, bonusType, agentRef)
          VALUES
          (@userid, @username, @parentid, @actual_amount, @bonus_percent, @domainname, @bonusType, @agentRef)
        `);
  
      return res.status(200).json({
        errorCode: 0,
        result: [{
          success: true,
          bonus_percent,
          transferredAmount: redeemAmount, 
          maxBonusApplied: maxBonus
        }]
      });
  
    } catch (err) {
      return res.status(500).json({
        errorCode: 5,
        result: [{ message: 'Internal error', error: err.message }]
      });
    }
  });

  // app.post('/add-deposit-bonus-auto', async (req, res) => {
  //   const { userid, username, parentid, actual_amount, domainname, bonusType, agentRef } = req.body;
  
  //   if (!userid || !username || !parentid || !actual_amount || !domainname) {
  //     return res.status(400).json({ errorCode: 1, result: [{ message: 'Missing required fields' }] });
  //   }
  
  //   const domainKey = String(domainname).toLowerCase();
  //   if (!allowedDomains1.includes(domainKey)) {
  //     return res.status(403).json({ errorCode: 2, result: [{ message: 'Not authorized' }] });
  //   }
  
  //   // ✅ IMPORTANT CHANGE:
  //   // invalid / NO_BONUS => ALL
  //   const invalidBonusTypes = [null, undefined, '', 'NO_BONUS', 'null', 'undefined'];
  //   const finalBonusType = invalidBonusTypes.includes(bonusType)
  //     ? 'ALL'
  //     : String(bonusType).toUpperCase();
  
  //   try {
  //     const pool = await sql.connect(config);
  //     const depositTxnId = generateDepositTxnId(userid);
  
  //     const configRs = await pool.request()
  //       .input('domainname', sql.VarChar(100), domainKey)
  //       .query(`
  //         SELECT TOP 1
  //           every_casino_bonus_percent,
  //           every_sport_bonus_percent,
  //           every_casino_multiplier,
  //           every_sport_multiplier,
  //           max_bonus
  //         FROM DomainBonusConfig
  //         WHERE domainname = @domainname AND isActive = 1
  //       `);
  
  //     const conf = configRs.recordset[0];
  //     if (!conf) {
  //       return res.status(200).json({ errorCode: 6, result: [{ message: 'No config found for this domain' }] });
  //     }
  
  //     // percent + multiplier
  //     let bonus_percent = 0;
  //     let multiplier = 1;
  
  //     if (finalBonusType === 'CASINO') {
  //       bonus_percent = Number(conf.every_casino_bonus_percent || 0);
  //       multiplier = Number(conf.every_casino_multiplier || 1);
  //     } else if (finalBonusType === 'SPORT') {
  //       bonus_percent = Number(conf.every_sport_bonus_percent || 0);
  //       multiplier = Number(conf.every_sport_multiplier || 1);
  //     } else {
  //       // ✅ ALL (NO_BONUS treated as ALL)
  //       // user requirement: 5% bonus + 1X turnover + sport+casino combined
  //       bonus_percent = Number(conf.every_sport_bonus_percent || conf.every_casino_bonus_percent || 5);
  //       multiplier = 1;
  //     }
  
  //     const maxBonus = Number(conf.max_bonus || 0);
  
  //     let redeemAmount = (Number(actual_amount) * bonus_percent) / 100;
  //     if (maxBonus > 0 && redeemAmount > maxBonus) redeemAmount = maxBonus;
  
  //     // keep same behavior you had
  //     redeemAmount = Math.floor(Number(redeemAmount || 0));
  //     if (redeemAmount <= 0) {
  //       return res.status(200).json({
  //         errorCode: 0,
  //         result: [{ success: true, bonusApplied: false, message: 'No bonus (redeemAmount <= 0)' }]
  //       });
  //     }
  
  //     const totalAmount = Number(actual_amount) + redeemAmount;
  //     const requiredTurnover = Number((totalAmount * multiplier).toFixed(2));
  
  //     const domainConfig = {
  //       "baaaji.win": { targetMainUserId: 4093141 },
  //       "baji.win": { targetMainUserId: 4093141 },
  //       "4six.com": { targetMainUserId: 5856789 },
  //     };
  
  //     const finalTargetMainUserId = domainConfig[domainKey]?.targetMainUserId 
  
  //     const payload = {
  //       password: "abcdr1245",
  //       txntype: 1,
  //       users: [{
  //         userId: userid,
  //         txnType: 1,
  //         amount: redeemAmount,
  //         remark: `Deposit bonus (Every-${finalBonusType})`,
  //         key: 0,
  //         mainUserId: finalTargetMainUserId
  //       }]
  //     };
  
  //     const axiosInstance = axios.create({ timeout: 1000 });
  //     let apiRes;
  
  //     try {
  //       apiRes = await axiosInstance.post('https://777777.today/pad=81/transferSpec', payload);
  //     } catch (apiErr) {
  //       await pool.request()
  //         .input('userid', sql.BigInt, userid)
  //         .input('username', sql.VarChar(100), username)
  //         .input('parentid', sql.BigInt, parentid)
  //         .input('domainname', sql.VarChar(100), domainKey)
  //         .input('api_name', sql.VarChar(100), 'transferSpec-EVERY')
  //         .input('request_payload', sql.NVarChar(sql.MAX), JSON.stringify(payload))
  //         .input('response_payload', sql.NVarChar(sql.MAX), JSON.stringify(apiErr?.response?.data || {}))
  //         .input('error_message', sql.VarChar(500), apiErr.message)
  //         .query(`
  //           INSERT INTO transfer_error_logs
  //           (userid, username, parentid, domainname, api_name, request_payload, response_payload, error_message)
  //           VALUES
  //           (@userid, @username, @parentid, @domainname, @api_name, @request_payload, @response_payload, @error_message)
  //         `);
  
  //       return res.status(200).json({
  //         errorCode: 4,
  //         result: [{ message: 'Transfer API error', error: apiErr.message }]
  //       });
  //     }
  
  //     const transferResult = apiRes?.data?.result?.[0]?.result || 'FAILED';
  //     if (String(transferResult).toLowerCase() !== 'success') {
  //       await pool.request()
  //         .input('userid', sql.BigInt, userid)
  //         .input('username', sql.VarChar(100), username)
  //         .input('parentid', sql.BigInt, parentid)
  //         .input('domainname', sql.VarChar(100), domainKey)
  //         .input('api_name', sql.VarChar(100), 'transferSpec-EVERY')
  //         .input('request_payload', sql.NVarChar(sql.MAX), JSON.stringify(payload))
  //         .input('response_payload', sql.NVarChar(sql.MAX), JSON.stringify(apiRes.data))
  //         .input('error_message', sql.VarChar(500), 'Transfer result not success')
  //         .query(`
  //           INSERT INTO transfer_error_logs
  //           (userid, username, parentid, domainname, api_name, request_payload, response_payload, error_message)
  //           VALUES
  //           (@userid, @username, @parentid, @domainname, @api_name, @request_payload, @response_payload, @error_message)
  //         `);
  
  //       return res.status(200).json({ errorCode: 4, result: [{ message: 'Transfer failed', transferResult }] });
  //     }
  
  //     // ✅ store in SAME table, bonusType=ALL for NO_BONUS case
  //     await pool.request()
  //       .input('depositTxnId', sql.VarChar(100), depositTxnId)
  //       .input('userid', sql.BigInt, userid)
  //       .input('username', sql.VarChar(100), username)
  //       .input('parentid', sql.BigInt, parentid)
  //       .input('actual_amount', sql.Decimal(18, 2), actual_amount)
  //       .input('bonus_percent', sql.Decimal(10, 2), bonus_percent)
  //       .input('bonus_amount', sql.Decimal(18, 2), redeemAmount)
  //       .input('multiplier', sql.Int, multiplier)
  //       .input('required_turnover', sql.Decimal(18, 2), requiredTurnover)
  //       .input('domainname', sql.VarChar(100), domainKey)
  //       .input('bonusType', sql.VarChar(50), finalBonusType) // SPORT / CASINO / ALL
  //       .input('agentRef', sql.Bit, agentRef ? 1 : 0)
  //       .query(`
  //         INSERT INTO depositbonus_every
  //         (depositTxnId, userid, username, parentid, actual_amount,
  //          bonus_percent, bonus_amount, multiplier, required_turnover,
  //          domainname, bonusType, agentRef, withdrawn_amount, creationdate)
  //         VALUES
  //         (@depositTxnId, @userid, @username, @parentid, @actual_amount,
  //          @bonus_percent, @bonus_amount, @multiplier, @required_turnover,
  //          @domainname, @bonusType, @agentRef, 0, GETDATE())
  //       `);
  
  //     return res.status(200).json({
  //       errorCode: 0,
  //       result: [{
  //         success: true,
  //         depositTxnId,
  //         bonusType: finalBonusType,
  //         bonus_percent,
  //         transferredAmount: redeemAmount,
  //         requiredTurnover
  //       }]
  //     });
  
  //   } catch (err) {
  //     return res.status(500).json({ errorCode: 5, result: [{ message: 'Internal error', error: err.message }] });
  //   }
  // });

  // app.get('/check-withdraw-eligibility', async (req, res) => {
  //   const userId = req.query.userId || req.query.userid;
  
  //   if (!userId) {
  //     return res.status(400).json({
  //       errorCode: 1,
  //       message: 'userId required'
  //     });
  //   }
  
  //   try {
  //     const pool = await sql.connect(config);
  
  //     const bonusRes = await pool.request()
  //       .input('userid', sql.BigInt, userId)
  //       .query(`
  //         SELECT TOP 1
  //           id,
  //           actual_amount,
  //           bonus_percent,
  //           bonusType,
  //           creationdate,
  //           balance_unlocked,
  //           turnover_unlocked
  //         FROM depositbonus
  //         WHERE userid = @userid
  //         ORDER BY creationdate DESC
  //       `);
  //       const bonus = bonusRes.recordset[0];
        
  //       if (bonusRes.recordset.length === 0) {
  //         return res.status(200).json({
  //           eligible: true,
  //           bonusType: 'NO_BONUS',
  //           reason: 'No bonus applied'
  //         });
  //       }
  
   
  //     console.log(bonus.balance_unlocked)
  //     if (bonus.balance_unlocked === true || bonus.turnover_unlocked === true) {
  //       return res.status(200).json({
  //         eligible: true,
  //         bonusType: bonus.bonusType,
  //         balanceUnlocked: bonus.balance_unlocked === true,
  //         turnoverUnlocked: bonus.turnover_unlocked === true,
  //         reason: 'Bonus unlocked (permanent)'
  //       });
  //     }
  
  //     let balanceRes;
  //     try {
  //       balanceRes = await axios.get(
  //         `https://sp.vrnlapi.live/api3/balance/${userId}`,
  //         { timeout: 5000 }
  //       );
  //     } catch (e) {
  //       return res.status(500).json({
  //         errorCode: 2,
  //         message: 'Balance API failed',
  //         error: e.message
  //       });
  //     }
  
  //     const balance = Number(balanceRes?.data?.balance || 0);
  
  //     // 🔓 BALANCE UNLOCK (first time only)
  //     if (balance === 0) {
  //       await pool.request()
  //         .input('id', sql.BigInt, bonus.id)
  //         .query(`
  //           UPDATE depositbonus
  //           SET balance_unlocked = 1
  //           WHERE id = @id
  //         `);
  
  //       return res.status(200).json({
  //         eligible: true,
  //         balance,
  //         balanceUnlocked: true,
  //         turnoverUnlocked: false,
  //         reason: 'Balance reached zero (unlocked)'
  //       });
  //     }
  
  //     const bonusAmount = Number(bonus.actual_amount) * Number(bonus.bonus_percent) / 100;
  //     const totalAmount = Number(bonus.actual_amount) + bonusAmount;
  
  //     let multiplier = 13;
  //     let allowedGames = [];
  
  //     switch (bonus.bonusType) {
  //       case 'CASINO':
  //         multiplier = 30;
  //         allowedGames = ['AWC', 'BOG'];
  //         break;
  
  //       case 'SPORT':
  //         multiplier = 13;
  //         allowedGames = ['EXCH', 'PARLAY'];
  //         break;
  
  //       default:
  //         multiplier = 13;
  //         allowedGames = [];
  //         break;
  //     }
  
  //     const requiredTurnover = totalAmount * multiplier;
  
  //     const fromDate = new Date(bonus.creationdate);
  //     fromDate.setDate(fromDate.getDate() - 1);
  
  //     const toDate = new Date(fromDate);
  //     toDate.setMonth(toDate.getMonth() + 1);
  
  //     let turnoverRes;
  //     try {
  //       turnoverRes = await axios.get(
  //         'https://sp.vrnlapi.live/api/fetchUserData',
  //         {
  //           params: {
  //             userId,
  //             from: fromDate.toISOString().slice(0, 19).replace('T', ' '),
  //             to: toDate.toISOString().slice(0, 19).replace('T', ' ')
  //           },
  //           timeout: 5000
  //         }
  //       );
  //     } catch (e) {
  //       return res.status(500).json({
  //         errorCode: 3,
  //         message: 'Turnover API failed',
  //         error: e.message
  //       });
  //     }
  
  //     const totals = turnoverRes?.data?.totals || [];
  //     let completedTurnover = 0;
  
  //     totals.forEach(item => {
  //       if (allowedGames.length === 0 || allowedGames.includes(item.apiName)) {
  //         completedTurnover += Number(item.totalTurnover || 0);
  //       }
  //     });
  
  //     // 🔓 TURNOVER UNLOCK (first time only)
  //     if (completedTurnover >= requiredTurnover) {
  //       await pool.request()
  //         .input('id', sql.BigInt, bonus.id)
  //         .query(`
  //           UPDATE depositbonus
  //           SET turnover_unlocked = 1
  //           WHERE id = @id
  //         `);
  
  //       return res.status(200).json({
  //         eligible: true,
  //         balance,
  //         completedTurnover,
  //         requiredTurnover,
  //         balanceUnlocked: false,
  //         turnoverUnlocked: true,
  //         reason: 'Turnover completed (unlocked)'
  //       });
  //     }
  
  //     return res.status(200).json({
  //       eligible: false,
  //       balance,
  //       bonusType: bonus.bonusType,
  //       depositAmount: bonus.actual_amount,
  //       bonusAmount,
  //       totalAmount,
  //       multiplier,
  //       requiredTurnover,
  //       completedTurnover,
  //       remainingTurnover: requiredTurnover - completedTurnover,
  //       balanceUnlocked: false,
  //       turnoverUnlocked: false
  //     });
  
  //   } catch (err) {
  //     return res.status(500).json({
  //       errorCode: 9,
  //       message: 'Internal server error',
  //       error: err.message
  //     });
  //   }
  // });

  app.get('/check-withdraw-eligibility', async (req, res) => {
    const userId = req.query.userId || req.query.userid;
  
    if (!userId) {
      return res.status(400).json({ errorCode: 1, message: 'userId required' });
    }
  
    try {
      const pool = await sql.connect(config);
  
      const bonusRes = await pool.request()
        .input('userid', sql.BigInt, userId)
        .query(`
          SELECT TOP 1
            id,
            actual_amount,
            bonus_percent,
            bonusType,
            creationdate,
            balance_unlocked,
            turnover_unlocked,
            withdrawn_amount
          FROM depositbonus
          WHERE userid = @userid
          ORDER BY creationdate DESC
        `);
  
      if (bonusRes.recordset.length === 0) {
        return res.status(200).json({
          errorCode: 0,
          eligible: true,
          bonusType: 'NO_BONUS',
          reason: 'No bonus applied',
          maxWithdrawNow: 0,
          cards: []
        });
      }
  
      const bonus = bonusRes.recordset[0];
  
      // ================= BALANCE =================
      let balance = 0;
      try {
        const balanceRes = await axios.get(`https://sp.vrnlapi.live/api3/balance/${userId}`, { timeout: 5000 });
        balance = Number(balanceRes?.data?.balance || 0);
      } catch (e) {
        return res.status(500).json({
          errorCode: 2,
          message: 'Balance API failed',
          error: e.message
        });
      }
  
      // ================= CALCULATIONS =================
      const depositAmount = Number(bonus.actual_amount || 0);
      const bonusAmount = Number(((depositAmount * Number(bonus.bonus_percent || 0)) / 100).toFixed(2));
      const totalAmount = Number((depositAmount + bonusAmount).toFixed(2));
      const withdrawn = Number(bonus.withdrawn_amount || 0);
  
      const typeUpper = String(bonus.bonusType || '').toUpperCase();
  
      // let multiplier = 1;
      const configRs = await pool.request()
      .input('domainname', sql.VarChar(100), bonus.domainname)
      .query(`
        SELECT first_deposit_multiplier
        FROM DomainBonusConfig
        WHERE domainname = @domainname
      `);

      let multiplier = Number(
      configRs.recordset[0]?.first_deposit_multiplier || 1
      );

      let allowedGames = [];
  
      if (typeUpper === 'CASINO') {
        allowedGames = ['AWC', 'BOG'];
      }
      else if (typeUpper === 'ALL') {
       allowedGames = ['EXCH', 'PARLAY', 'AWC', 'BOG'];
      } 
       else {
        allowedGames = ['EXCH', 'PARLAY'];
      }
  
      const requiredTurnover = Number((totalAmount * multiplier).toFixed(2));
  
      const isTurnoverUnlocked = Number(bonus.turnover_unlocked) === 1;
      const isBalanceUnlocked = Number(bonus.balance_unlocked) === 1;
  
      // ================= IF COMPLETED =================
      if (isTurnoverUnlocked) {
        const availableToWithdraw = Number(Math.max(0, totalAmount - withdrawn).toFixed(2));
  
        return res.status(200).json({
          errorCode: 0,
          eligible: availableToWithdraw > 0,
          balance,
          maxWithdrawNow: Number(Math.min(balance, availableToWithdraw).toFixed(2)),
          cards: [{
            bonusId: bonus.id,
            bonusType: typeUpper,
            title: `${bonus.bonus_percent}% 1st Deposit Bonus (${typeUpper})`,
            depositAmount,
            bonusAmount,
            amount: totalAmount,
            requiredTurnover,
            completedTurnover: requiredTurnover,
            remainingTurnover: 0,
            progressPct: 100,
            status: 'Completed',
            balanceUnlocked: isBalanceUnlocked,
            turnoverUnlocked: true,
            withdrawnAmount: withdrawn,
            availableToWithdraw,
            createdAt: bonus.creationdate
          }],
          reason: 'Turnover unlocked'
        });
      }
  
      // ================= BALANCE ZERO =================
      if (balance === 0 && !isBalanceUnlocked) {
        await pool.request()
          .input('id', sql.BigInt, bonus.id)
          .query(`UPDATE depositbonus SET balance_unlocked = 1 WHERE id = @id`);
      }
  
      if (balance === 0) {
        return res.status(200).json({
          errorCode: 0,
          eligible: false,
          balance,
          maxWithdrawNow: 0,
          cards: [{
            bonusId: bonus.id,
            bonusType: typeUpper,
            title: `${bonus.bonus_percent}% 1st Deposit Bonus (${typeUpper})`,
            depositAmount,
            bonusAmount,
            amount: totalAmount,
            requiredTurnover,
            completedTurnover: 0,
            remainingTurnover: requiredTurnover,
            progressPct: 0,
            status: 'Unlocked',
            balanceUnlocked: true,
            turnoverUnlocked: false,
            withdrawnAmount: withdrawn,
            availableToWithdraw: 0,
            createdAt: bonus.creationdate
          }],
          reason: 'Balance zero (marked unlocked only)'
        });
      }
  
      // ================= TURNOVER API =================
      const fromDate = new Date(bonus.creationdate);
      fromDate.setDate(fromDate.getDate() - 1);
  
      const toDate = new Date(fromDate);
      toDate.setMonth(toDate.getMonth() + 1);
  
      // ✅ FINAL FIX: ISO FORMAT
      const from = fromDate.toISOString();
      const to = toDate.toISOString();
  
      let turnoverRes;
  
      try {
        console.log("TURNOVER REQUEST =>", { userId, from, to });
  
        turnoverRes = await axios.get('https://sp.vrnlapi.live/api/fetchUserData', {
          params: { userId, from, to },
          timeout: 5000
        });
  
        console.log("TURNOVER SUCCESS =>", turnoverRes.data);
  
      } catch (e) {
        console.log("TURNOVER ERROR =>", {
          message: e.message,
          status: e.response?.status,
          data: e.response?.data
        });
  
        // ✅ SAFE FALLBACK
        turnoverRes = { data: { totals: [] } };
      }
  
      // ================= TURNOVER CALC =================
      const totals = turnoverRes?.data?.totals || [];
  
      let completedTurnoverRaw = 0;
  
      totals.forEach(item => {
        const api = String(item.apiName || '').toUpperCase();
        if (allowedGames.includes(api)) {
          completedTurnoverRaw += Number(item.totalTurnover || 0);
        }
      });
  
      const completedTurnover = Number(completedTurnoverRaw.toFixed(2));
      const isCompleted = completedTurnover >= requiredTurnover;
  
      const remainingTurnover = Number(Math.max(0, requiredTurnover - completedTurnover).toFixed(2));
      const progressPct = requiredTurnover > 0
        ? Number((Math.min(1, completedTurnover / requiredTurnover) * 100).toFixed(2))
        : 0;
  
      if (isCompleted) {
        await pool.request()
          .input('id', sql.BigInt, bonus.id)
          .query(`UPDATE depositbonus SET turnover_unlocked = 1 WHERE id = @id`);
      }
  
      const availableToWithdraw = isCompleted
        ? Number(Math.max(0, totalAmount - withdrawn).toFixed(2))
        : 0;
  
      return res.status(200).json({
        errorCode: 0,
        eligible: availableToWithdraw > 0,
        balance,
        maxWithdrawNow: Number(Math.min(balance, availableToWithdraw).toFixed(2)),
        cards: [{
          bonusId: bonus.id,
          bonusType: typeUpper,
          title: `${bonus.bonus_percent}% 1st Deposit Bonus (${typeUpper})`,
          depositAmount,
          bonusAmount,
          amount: totalAmount,
          requiredTurnover,
          completedTurnover: Math.min(completedTurnover, requiredTurnover),
          remainingTurnover,
          progressPct,
          status: isCompleted ? 'Completed' : (isBalanceUnlocked ? 'Unlocked' : 'In Progress'),
          balanceUnlocked: isBalanceUnlocked,
          turnoverUnlocked: isCompleted,
          withdrawnAmount: withdrawn,
          availableToWithdraw,
          createdAt: bonus.creationdate
        }],
        window: {
          from,
          to
        }
      });
  
    } catch (err) {
      return res.status(500).json({
        errorCode: 9,
        message: 'Internal server error',
        error: err.message
      });
    }
  });
  
  app.get('/get-domain-bonus-config', async (req, res) => {
    const { domain } = req.query;
  
    if (!domain) {
      return res.status(400).json({
        success: false,
        message: 'domain is required'
      });
    }
  
    try {
      const pool = await sql.connect(config);
  
      const result = await pool.request()
        .input('domain', sql.VarChar(100), domain.toLowerCase())
        .query(`
          SELECT TOP 1
            domainname,
  
            casino_bonus_percent,
            casino_multiplier,
  
            sport_bonus_percent,
            sport_multiplier,
  
            first_deposit_bonus_percent,
            first_deposit_multiplier,
  
            every_deposit_bonus_percent,
            every_deposit_multiplier,
  
            every_casino_bonus_percent,
            every_casino_multiplier,
  
            every_sport_bonus_percent,
            every_sport_multiplier,
  
            min_deposit,
            max_bonus
  
          FROM DomainBonusConfig
          WHERE domainname = @domain
            AND isActive = 1
        `);
  
      if (result.recordset.length === 0) {
        return res.status(200).json({
          success: false,
          message: 'No config found for this domain'
        });
      }
  
      const row = result.recordset[0];
  
      return res.status(200).json({
        success: true,
        domain: row.domainname,
  
        firstDepositBonusPercent: Number(row.first_deposit_bonus_percent || 0),
        firstDepositMultiplier: Number(row.first_deposit_multiplier || 0),
  
        everyDepositBonusPercent: Number(row.every_deposit_bonus_percent || 0),
        everyDepositMultiplier: Number(row.every_deposit_multiplier || 0),
  
        casinoEvery: {
          bonusPercent: Number(row.every_casino_bonus_percent || 0),
          multiplier: Number(row.every_casino_multiplier || 0),
          min_deposit: Number(row.min_deposit || 0),
          max_bonus: Number(row.max_bonus || 0)
        },
  
        sportEvery: {
          bonusPercent: Number(row.every_sport_bonus_percent || 0),
          multiplier: Number(row.every_sport_multiplier || 0),
          min_deposit: Number(row.min_deposit || 0),
          max_bonus: Number(row.max_bonus || 0)
        },
  
        casino: {
          bonusPercent: Number(row.casino_bonus_percent || 0),
          multiplier: Number(row.casino_multiplier || 0),
          min_deposit: Number(row.min_deposit || 0),
          max_bonus: Number(row.max_bonus || 0)
        },
  
        sport: {
          bonusPercent: Number(row.sport_bonus_percent || 0),
          multiplier: Number(row.sport_multiplier || 0),
          min_deposit: Number(row.min_deposit || 0),
          max_bonus: Number(row.max_bonus || 0)
        }
      });
  
    } catch (err) {
      return res.status(500).json({
        success: false,
        message: 'Internal error',
        error: err.message
      });
    }
  });

  app.get('/get-domain-bonus-users', async (req, res) => {
    const { domainname } = req.query;
  
    if (!domainname) {
      return res.status(400).json({
        errorCode: 1,
        result: [{ message: 'domainname is required' }]
      });
    }
  
    try {
      const pool = await sql.connect(config);
  
      const { recordset } = await pool.request()
        .input('domainname', sql.VarChar(100), domainname.toLowerCase())
        .query(`
          SELECT 
            userid,
            username,
            parentid,
            actual_amount,
            bonus_percent,
            bonusamt,
            bonusType,
            agentRef,
            creationdate
          FROM depositbonus
          WHERE domainname = @domainname
          ORDER BY creationdate DESC
        `);
  
      return res.status(200).json({
        errorCode: 0,
        result: recordset
      });
  
    } catch (err) {
      return res.status(500).json({
        errorCode: 5,
        result: [{ message: 'Internal error', error: err.message }]
      });
    }
  });
  
  app.get('/get-deposit-bonus/:userid', async (req, res) => {
    const { userid } = req.params;
  
    if (!userid) {
      return res.status(400).json({
        errorCode: 1,
        result: [{ message: 'User ID is required' }]
      });
    }
  
    try {
      const pool = await sql.connect(config);
  
      const { recordset } = await pool.request()
        .input('userid', sql.BigInt, userid)
        .query(`
          SELECT 
            id, userid, username, parentid, actual_amount, bonus_percent, bonusamt,claim_amount, flushed_amount, domainname, creationdate, status
          FROM 
            depositbonus WITH (NOLOCK)
          WHERE 
            userid = @userid
        `);
  
      if (recordset.length === 0) {
        return res.status(200).json({
          errorCode: 1,
          result: [{ message: 'No data found' }]
        });
      }
  
      // 👇 Update bonusamt to 0 if status is 1 (claimed) or 2 (flushed)
      const updatedResult = recordset.map(record => {
        return {
          ...record,
          bonusamt: (record.status === 1 || record.status === 2) ? 0 : record.bonusamt
        };
      });
  
      return res.status(200).json({
        errorCode: 0,
        result: updatedResult
      });
  
    } catch (err) {
      return res.status(500).json({
        errorCode: 2,
        result: [{ message: 'error', error: err.message }]
      });
    }
  });

  app.post('/redeem-deposit-bonus', async (req, res) => {
    const { userid, domain, agentRef, mainUserId } = req.body;
  
    if (!userid || !domain) {
      return res.status(400).json({
        errorCode: 1,
        result: [{ message: 'Missing userid or domain' }]
      });
    }
  
    const domainKey = domain.toLowerCase();
  
    const domainConfig = {
      "baaaji.win": { targetMainUserId: 4093141 },
      "baji.win": { targetMainUserId: 4093141 },
      "foxplay.pro": { targetMainUserId: 5549622 },
      "bdcrickeet.com": { targetMainUserId: 4218307 },
      // "4six.com": { targetMainUserId: 5856890 },
      "bajimat365.com": { targetMainUserId: 5647121 },
    };
  
    if (!domainConfig[domainKey]) {
      return res.status(403).json({
        errorCode: 2,
        result: [{ message: 'Not Authorized' }]
      });
    }
  
    const finalTargetMainUserId =
      agentRef === true
        ? domainConfig[domainKey].targetMainUserId
        : mainUserId;
  
    try {
      const pool = await sql.connect(config);

      const bonusCheck = await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('domain', sql.VarChar(100), domainKey)
        .query(`
          SELECT bonusamt, status
          FROM depositbonus
          WHERE userid = @userid AND domainname = @domain
        `);
  
      if (bonusCheck.recordset.length === 0) {
        return res.status(200).json({
          errorCode: 2,
          result: [{ message: 'No bonus record found' }]
        });
      }
  
      const { bonusamt, status } = bonusCheck.recordset[0];
  
      if (status === 1) {
        return res.status(200).json({
          errorCode: 2,
          result: [{ message: 'Bonus already claimed' }]
        });
      }
  
      if (status === 2) {
        return res.status(200).json({
          errorCode: 2,
          result: [{ message: 'Bonus already flushed' }]
        });
      }
  
      if (status !== 0) {
        return res.status(200).json({
          errorCode: 2,
          result: [{ message: 'Bonus not eligible for claim' }]
        });
      }

      const redeemAmount = Number(bonusamt);
  
      if (isNaN(redeemAmount) || redeemAmount <= 0) {
        return res.status(200).json({
          errorCode: 2,
          result: [{ message: 'Invalid bonus amount' }]
        });
      }
  
      await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('domain', sql.VarChar(100), domainKey)
        .input('claimAmount', sql.Decimal(18, 2), redeemAmount)
        .query(`
          UPDATE depositbonus
          SET status = 1,
              status_updated_at = GETDATE(),
              claim_amount = @claimAmount
          WHERE userid = @userid
            AND domainname = @domain
            AND status = 0
        `);
  
      const payload = {
        password: "abcdr1245",
        txntype: 1,
        users: [{
          userId: userid,
          txnType: 1,
          amount: redeemAmount, 
          remark: "Deposit bonus",
          key: 0,
          mainUserId: finalTargetMainUserId
        }]
      };
  
      const axiosInstance = axios.create({ timeout: 1000 });
      const apiRes = await axiosInstance.post(
        'https://777777.today/pad=81/transferSpec',
        payload
      );
  
      const transferResult =
        apiRes?.data?.result?.[0]?.result || 'UNKNOWN';
  
      if (transferResult.toLowerCase() !== 'success') {
        return res.status(200).json({
          errorCode: 2,
          result: [{ message: 'Transfer failed', result: transferResult }]
        });
      }
  
      return res.status(200).json({
        errorCode: 0,
        result: [{ message: 'Bonus claimed successfully' }]
      });
  
    } catch (err) {
      return res.status(500).json({
        errorCode: 2,
        result: [{
          message: 'Server error',
          error: err.message
        }]
      });
    }
  });

  // Deposit Bonus GET API
  app.get('/depositbonuslogs', async (req, res) => {
    try {
      const pool = await sql.connect(config);
  
      const { userid, status, domainname } = req.query;
  
      let query = `
        SELECT 
          id,
          userid,
          username,
          parentid,
          actual_amount,
          bonus_percent,
          bonusamt,
          creationdate,
          domainname,
          status,
          status_updated_at,
          claim_amount,
          flushed_amount
        FROM depositbonus
        WHERE 1=1
      `;
  
      // Create request object
      const request = pool.request();
  
      // Optional filters with parameters
      if (userid) {
        query += ` AND userid = @userid`;
        request.input('userid', sql.BigInt, userid);
      }
      if (status) {
        query += ` AND status = @status`;
        request.input('status', sql.VarChar, status);
      }
      if (domainname) {
        query += ` AND domainname = @domainname`;
        request.input('domainname', sql.VarChar, domainname);
      }
  
      query += ` ORDER BY creationdate DESC`;
  
      const result = await request.query(query);
  
      res.json({
        success: true,
        totalRecords: result.recordset.length,
        data: result.recordset
      });
  
    } catch (error) {
      res.status(500).json({
        success: false,
        message: error.message
      });
    }
  });
  
// turnover api
  app.post('/api/get-turnover', async (req, res) => {
    const { userId, domain, fromDate, toDate } = req.body;
  
    const token = 'glsa_uER1nJ119UtIXeNwPuPfYTNgwbjQSPeS_8eeb304f';
  
    const payload = {
      queries: [
        {
          refId: 'last_day',
          datasource: {
            type: 'mysql',
            uid: 'detbtzgbwn75se'
          },
          rawSql: `CALL vrnlapp.sp_get_Stake_Report(${userId}, "${domain}", "${fromDate}", "${toDate}")`,
          format: 'table'
        }
      ]
    };
  
    try {
      const response = await axios.post(
        'https://moni.555555.site/api/ds/query',
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          }
        }
      );
  
      
      const raw = response.data.results.last_day.frames[0].data.values;
      const result = [];
  
      for (let i = 0; i < raw[0]?.length; i++) {
        result.push({
          userId: raw[0][i],
          userName: raw[1][i],
          domainName: raw[2][i],
          casino: raw[3][i],
          totalAmount: raw[4][i],
          totalPnl: raw[5][i]
        });
      }
  
      res.json({ data: result });
  
    } catch (error) {
      console.error('Error fetching stake report:', error.message);
      res.status(500).json({ error: 'Failed to fetch stake report' });
    }
  });

// casino turnover api
  app.post('/api/get-turnover-casino', async (req, res) => {
  const { userId, domain, fromDate, toDate } = req.body;

  const token = 'glsa_uER1nJ119UtIXeNwPuPfYTNgwbjQSPeS_8eeb304f';

  const payload = {
    queries: [
      {
        refId: 'casino_report',
        datasource: {
          type: 'mysql',
          uid: 'detbtzgbwn75se'
        },
        rawSql: `CALL vrnlapp.sp_get_Stake_Report_gameType(${userId}, "${domain}", "${fromDate}", "${toDate}")`,
        format: 'table'
      }
    ]
  };

  try {
    const response = await axios.post(
      'https://moni.555555.site/api/ds/query',
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      }
    );

    // ✅ extract values from grafana response
    const frame = response?.data?.results?.casino_report?.frames?.[0];

    if (!frame || !frame.data || !frame.data.values) {
      return res.json({
        success: true,
        data: []
      });
    }

    const raw = frame.data.values;

    const result = [];

    for (let i = 0; i < raw[0].length; i++) {
      result.push({
        userId: raw[0][i],
        userName: raw[1][i],
        domainName: raw[2][i],
        casino: raw[3][i],
        totalAmount: raw[4][i],
        totalPnl: raw[5][i],
        gameType: raw[6][i]
      });
    }

    res.json({
      success: true,
      totalRows: result.length,
      data: result
    });

  } catch (error) {

    console.error('Casino turnover API Error:', error?.response?.data || error.message);

    res.status(500).json({
      success: false,
      message: 'Failed to fetch casino turnover',
      error: error.message,
      grafanaError: error?.response?.data || null
    });
  }
  });

//password activity
  app.post('/pwdActivity', async (req, res) => {
    const { userId, parentId, domain } = req.body;
  
    if (!userId || !parentId || !domain) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
  
    const currentTime = new Date();
  
    try {
      const conn = await sql.connect(config);
  
      await conn.request()
        .input('userId', sql.BigInt, userId)
        .input('parentId', sql.BigInt, parentId)
        .input('domain', sql.VarChar, domain)
        .input('time', sql.DateTime, currentTime)
        .query(`
          MERGE PwdActivityLog AS target
          USING (SELECT @userId AS userId, @parentId AS parentId, @domain AS domain) AS source
          ON target.userId = source.userId AND target.parentId = source.parentId AND target.domain = source.domain
          WHEN MATCHED THEN
            UPDATE SET time = @time
          WHEN NOT MATCHED THEN
            INSERT (userId, parentId, domain, time)
            VALUES (@userId, @parentId, @domain, @time);
        `);
  
      res.json({ message: 'Activity logged successfully' });
    } catch (err) {
      console.error('POST API Error:', err);
      res.status(500).json({ error: 'Something went wrong' });
    } 
  });

  app.get('/pwdActivity/:userId', async (req, res) => {
    try {
      const conn = await sql.connect(config);
      const result = await conn.request()
        .input('userId', sql.BigInt, req.params.userId)
        .query('SELECT * FROM PwdActivityLog WHERE userId = @userId');
  
      if (result.recordset.length === 0) {
        return res.status(200).json({ message: "No activity found" });
      }
  
      res.status(200).json(result.recordset);
    } catch (err) {
      console.error("GET API Error:", err);
      res.status(500).json({ error: 'Internal Server Error' });
    } 
  });

// flush expiered bonus
  app.post('/internal/flush-bonus', async (req, res) => {
    const { key } = req.body;
  
    if (key !== 'flush@123') {
      return res.status(403).json({ success: false, message: 'Unauthorized' });
    }
  
    try {
      const pool = await sql.connect(config);
  
      const result = await pool.request().query(`
        UPDATE depositbonus
        SET status = 2,
            status_updated_at = GETDATE(),
            flushed_amount = bonusamt  -- Store flushed bonus amount
        WHERE status = 0
          AND DATEADD(
                DAY,
                CASE 
                  WHEN domainname = 'foxplay.pro' THEN 2     
                  ELSE 30                                  
                END,
                creationdate
              ) <= GETDATE()
      `);
  
      return res.status(200).json({
        success: true,
        message: `Bonus flush complete.`,
        rowsAffected: result.rowsAffected[0]
      });
    } catch (err) {
      return res.status(500).json({
        success: false,
        message: 'Error while flushing bonuses',
        error: err.message
      });
    }
  });

// LOGIN API
app.post('/api/LoginAdmin', async (req, res) => {
    const { userName, password, origin } = req.body;

    if (!userName || !password || !origin) {
        return res.status(400).json({
            errorCode: 1,
            errorDescription: 'userName, password, and origin are required',
            result: null
        });
    }

    try {
        await sql.connect(config);

  
        const result = await sql.query`
            SELECT * FROM LoginUsers 
            WHERE userName = ${userName} 
              AND password = ${password}
              AND origin = ${origin}
              AND isActive = 1
        `;

        if (result.recordset.length === 0) {
            return res.status(200).json({
                errorCode: 1,
                errorDescription: 'Invalid credentials',
                result: null
            });
        }

        const user = result.recordset[0];

    
        const loginInsert = await sql.query`
            INSERT INTO LoginActivity (userID, origin)
            OUTPUT INSERTED.activityID, INSERTED.loginTime
            VALUES (${user.userID}, ${origin})
        `;

        const loginActivity = loginInsert.recordset[0];

        res.status(200).json({
            errorCode: 0,
            errorDescription: null,
            result: {
                userId: user.userID,
                username: user.userName,
                origin: origin,
                loginTime: loginActivity.loginTime,
                activityId: loginActivity.activityID
            }
        });

    } catch (err) {
        res.status(500).json({
            errorCode: 1,
            errorDescription: err.message,
            result: null
        });
    }
});

// LOGOUT API
app.post('/api/LogoutAdmin', async (req, res) => {
    const { activityId } = req.body;

    if (!activityId) {
        return res.status(400).json({
            errorCode: 1,
            errorDescription: 'activityId is required',
            result: null
        });
    }

    try {
        await sql.connect(config);

        const updateResult = await sql.query`
            UPDATE LoginActivity
            SET logoutTime = GETDATE(), status = 'LoggedOut'
            WHERE activityID = ${activityId} AND logoutTime IS NULL
        `;

        if (updateResult.rowsAffected[0] === 0) {
            return res.status(200).json({
                errorCode: 1,
                errorDescription: 'Invalid activityId or already logged out',
                result: null
            });
        }

        res.status(200).json({
            errorCode: 0,
            errorDescription: null,
            result: 'Logout successful'
        });

    } catch (err) {
        res.status(500).json({
            errorCode: 1,
            errorDescription: err.message,
            result: null
        });
    }
});
  
app.post('/api/get-bonus-report', async (req, res) => {
    const { userId, fromDate, toDate, bonusType } = req.body;
  
    const token = 'glsa_uER1nJ119UtIXeNwPuPfYTNgwbjQSPeS_8eeb304f';
  
    const payload = {
      queries: [
        {
          refId: 'bonus_report',
          datasource: {
            type: 'mysql',
            uid: 'detbtzgbwn75se'
          },
          rawSql: `CALL vrnlapp.sp_get_vrnlTxn_bonus_Report("${fromDate}", "${toDate}", "${bonusType}", ${userId})`,
          format: 'table'
        }
      ]
    };
  
    try {
      const response = await axios.post(
        'https://moni.555555.site/api/ds/query',
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          }
        }
      );
  
      const raw = response.data.results?.bonus_report?.frames?.[0]?.data?.values;
  
      if (!raw || raw.length === 0) {
        return res.json({ data: [], message: "No records found" });
      }
  
      const result = [];
      for (let i = 0; i < raw[0].length; i++) {
        let formattedDate = new Date(raw[5][i]).toLocaleString("en-IN", {
          timeZone: "Asia/Kolkata"
        });
  
        result.push({
          userName: raw[0][i],
          userId: raw[1][i],
          withUid: raw[2][i],
          amount: raw[3][i],
          description: raw[4][i],
          dateTime: formattedDate,
          ipAddress: raw[5][i],
        });
      }
  
      res.json({ data: result });
  
    } catch (error) {
      console.error('Error fetching bonus report:', error.message);
      res.status(500).json({ error: 'Something went wrong while fetching bonus report' });
    }
});
  
app.post('/api/get-login-activity', async (req, res) => {
    const { userId, flag = 0 } = req.body;
  
    const token = 'glsa_uER1nJ119UtIXeNwPuPfYTNgwbjQSPeS_8eeb304f';
  
    const payload = {
      queries: [
        {
          refId: 'login_activity',
          datasource: {
            type: 'mysql',
            uid: 'detbtzgbwn75se'
          },
          rawSql: `CALL vrnlapp.get_loginActivity(${userId}, ${flag})`,
          format: 'table'
        }
      ]
    };
  
    try {
      const response = await axios.post(
        'https://moni.555555.site/api/ds/query',
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          }
        }
      );
  
      const raw = response.data.results.login_activity.frames[0].data.values;
      if (!raw || raw.length === 0) {
        return res.json({ data: [], message: "No records found" });
      }
      const result = [];
      for (let i = 0; i < raw[0].length; i++) {
        let formattedDate = new Date(raw[3][i]).toLocaleString("en-IN", {
          timeZone: "Asia/Kolkata"
        });
  
        result.push({
          domainName: raw[0][i],
          userName: raw[1][i],
          userId: raw[2][i],
          dateTime: formattedDate,
          loginStatus: raw[4][i],
          ipAddress: raw[5][i]
        });
      }
  
      res.json({ data: result });
    } catch (error) {
      console.error('Error fetching login activity:', error.message);
      res.status(500).json({ error: 'Failed to fetch login activity' });
    }
});

app.post('/api/get-user-failed-pwd', async (req, res) => {
    const { userId } = req.body;
  
    const token = 'glsa_uER1nJ119UtIXeNwPuPfYTNgwbjQSPeS_8eeb304f';
  
    const payload = {
      queries: [
        {
          refId: 'failed_pwd',
          datasource: {
            type: 'mysql',
            uid: 'detbtzgbwn75se'
          },
          rawSql: `CALL vrnlapp.sp_get_userFailedPwd(${userId})`,
          format: 'table'
        }
      ]
    };
  
    try {
      const response = await axios.post(
        'https://moni.555555.site/api/ds/query',
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          }
        }
      );
  
      const raw = response.data.results?.failed_pwd?.frames?.[0]?.data?.values;
  
      if (!raw || raw.length === 0) {
        return res.json({ data: [], message: "No records found" });
      }
  
      const result = [];
      for (let i = 0; i < raw[0].length; i++) {
        let formattedDate = raw[3][i]
          ? new Date(raw[3][i]).toLocaleString("en-IN", {
              timeZone: "Asia/Kolkata"
            })
          : null;
  
        result.push({
          domain: raw[0][i],
          userName: raw[1][i],
          userId: raw[2][i],
          date: formattedDate,
          failedAttempts: raw[4][i]
        });
      }
  
      res.json({ data: result });
  
    } catch (error) {
      console.error('Error fetching failed password attempts:', error.message);
      res.status(500).json({ error: 'Something went wrong while fetching failed password attempts' });
    }
});

app.post('/send-verification-admin', async (req, res) => {
    const { userid, email, domain } = req.body;
  
    if (!userid || !email || !domain) {
      return res.status(400).json({ message: 'userid, email, and domain are required' });
    }
  
    const config = emailConfigs[domain];
    if (!config) {
      return res.status(400).json({ message: `No email configuration found for domain: ${domain}` });
    }
  
    try {
      await pool.request()
        .input('userid', sql.BigInt, userid)
        .query(`
          UPDATE verification_tokens 
          SET is_used = 4 
          WHERE userid = @userid AND expires_at < GETDATE() AND is_used = 0
        `);
  
      const token = Math.random().toString(36).substr(2, 12);
      const expiry = new Date();
      expiry.setHours(expiry.getHours() + 2);
  
      const existing = await pool.request()
        .input('userid', sql.BigInt, userid)
        .query(`SELECT id FROM verification_tokens WHERE userid = @userid`);
  
      if (existing.recordset.length > 0) {
        await pool.request()
          .input('userid', sql.BigInt, userid)
          .input('token', sql.VarChar, token)
          .input('expires_at', sql.DateTime, expiry)
          .query(`
            UPDATE verification_tokens 
            SET token = @token, expires_at = @expires_at, is_used = 0, created_at = GETDATE()
            WHERE userid = @userid
          `);
      } else {
        // Insert new row
        await pool.request()
          .input('userid', sql.BigInt, userid)
          .input('token', sql.VarChar, token)
          .input('expires_at', sql.DateTime, expiry)
          .query(`
            INSERT INTO verification_tokens (userid, token, expires_at, is_used, created_at)
            VALUES (@userid, @token, @expires_at, 0, GETDATE())
          `);
      }
  
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: { user: config.user, pass: config.pass },
        tls: { rejectUnauthorized: false }
      });
  
      const formLink = `https://panel.foxplay.pro/#/verification-form?userid=${userid}&token=${token}`;
  
      const mailOptions = {
        from: config.from,
        to: email,
        subject: "Account Verification Required",
        html: `<p>Please complete the form: <a href="${formLink}">Click Here</a></p>`
      };
  
      await transporter.sendMail(mailOptions);
  
      res.status(200).json({ errorCode: 0, message: 'Verification email sent successfully' });
  
    } catch (err) {
      console.error(err);
      res.status(500).json({ errorCode: 1, message: 'Error sending verification email' });
    }
  });
  
app.post('/verification-request', upload.fields([
    { name: 'id_proof_file', maxCount: 1 },
    { name: 'selfie_file', maxCount: 1 },
    { name: 'transaction_file', maxCount: 1 }
  ]), async (req, res) => {
    const { userid, phone, email } = req.body;
    const id_proof_file = req.files['id_proof_file']?.[0]?.path;
    const selfie_file = req.files['selfie_file']?.[0]?.path;
    const transaction_file = req.files['transaction_file']?.[0]?.path;
  
    try {
      // Request insert
      const result = await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('phone', sql.VarChar, phone)
        .input('email', sql.VarChar, email)
        .input('id_proof_file', sql.VarChar, id_proof_file)
        .input('selfie_file', sql.VarChar, selfie_file)
        .input('transaction_file', sql.VarChar, transaction_file)
        .query(`
          INSERT INTO verification_requests 
          (userid, phone, email, id_proof_file, selfie_file, transaction_file, status)
          OUTPUT INSERTED.id
          VALUES (@userid, @phone, @email, @id_proof_file, @selfie_file, @transaction_file, 1)
        `);
  
      const requestId = result.recordset[0].id;

      await pool.request()
        .input('userid', sql.BigInt, userid)
        .query(`
          UPDATE verification_tokens 
          SET is_used = 1
          WHERE id = (
            SELECT TOP 1 id 
            FROM verification_tokens 
            WHERE userid = @userid 
            ORDER BY created_at DESC
          )
        `);
  
      res.json({ errorCode: 0, message: "Verification request submitted successfully", status: 1, requestId });
    } catch (err) {
      console.error(err);
      res.status(500).json({ errorCode: 1, message: "Error submitting verification request" });
    }
  });
  
app.get('/verification-status/:userid', async (req, res) => {
    const { userid } = req.params;
    try {
      const tokenResult = await pool.request()
        .input('userid', sql.BigInt, userid)
        .query(`
          SELECT TOP 1 
            id, userid, token, CAST(is_used AS INT) as is_used, created_at, expires_at
          FROM verification_tokens 
          WHERE userid = @userid 
          ORDER BY created_at DESC
        `);
  
      if (tokenResult.recordset.length === 0) {
        return res.json({ errorCode: 2, message: "No verification record found" });
      }
  
      const token = tokenResult.recordset[0];
  
      if (token.expires_at < new Date() && token.is_used === 0) {
        return res.json({ errorCode: 0, status: 4, message: "expired" });
      }
  
      return res.json({
        errorCode: 0,
        status: token.is_used, // 0=Pending, 1=Submitted, 2=Approved, 3=Rejected, 4=Expired
        token
      });
  
    } catch (err) {
      console.error(err);
      res.status(500).json({ errorCode: 1, message: "Error fetching verification status" });
    }
  });
  
app.post('/verification-update', async (req, res) => {
    const { userid, requestId, status } = req.body; 
    // status = 2 (approved), 3 (rejected)
  
    if (![2, 3].includes(status)) {
      return res.status(400).json({ errorCode: 1, message: "Invalid status" });
    }
  
    try {
      // Update latest token
      await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('status', sql.Int, status)
        .query(`
          UPDATE verification_tokens 
          SET is_used = @status 
          WHERE id = (
            SELECT TOP 1 id 
            FROM verification_tokens 
            WHERE userid = @userid 
            ORDER BY created_at DESC
          )
        `);
  
      // Update verification request
      await pool.request()
        .input('requestId', sql.BigInt, requestId)
        .input('status', sql.Int, status)
        .query(`UPDATE verification_requests SET status = @status WHERE id = @requestId`);
  
      res.json({ errorCode: 0, message: "Verification status updated", status });
    } catch (err) {
      console.error(err);
      res.status(500).json({ errorCode: 1, message: "Error updating verification status" });
    }
  });
  
// bonus for every deposit

app.post('/api/add-bonus', async (req, res) => {
  const { userId, username, parentId, actualAmount, domainName ,bonusType } = req.body;

  if (!userId || !username || !parentId || !actualAmount || !domainName) {
    return res.status(400).json({ errorCode: 1, result: [{ message: 'Missing required fields' }] });
  }

  const domainKey = domainName.toLowerCase();
  const allowedDomains = ['baaaji.win', 'baji.win','4six.com'];
  const domainBonusMap = { 'baaaji.win': 20, 'baji.win': 10,'4six.com':5};
  const domainTurnoverMap = {'baaaji.win': 4,'baji.win': 1,'4six.com':1};

  if (!allowedDomains.includes(domainKey)) {
    return res.status(403).json({ errorCode: 2, result: [{ message: 'Not authorized for this domain' }] });
  }

  const bonusPercent = domainBonusMap[domainKey];
  // const turnoverRequirement = actualAmount * 1; // 1× turnover
  const turnoverRequirement = actualAmount * (domainTurnoverMap[domainKey] || 1);
  const finalBonusType = bonusType || 'EVERY_DEPOSIT';
  try {
    const pool = await sql.connect(config);

    const result = await pool.request()
      .input('userId', sql.BigInt, userId)
      .input('username', sql.VarChar(100), username)
      .input('parentId', sql.BigInt, parentId)
      .input('actualAmount', sql.Decimal(18, 2), actualAmount)
      .input('bonusPercent', sql.Decimal(5, 2), bonusPercent)
      .input('turnoverRequirement', sql.Decimal(18, 2), turnoverRequirement)
      .input('domainName', sql.VarChar(100), domainKey)
      .input('bonusType', sql.VarChar(50), finalBonusType)
      .query(`
        INSERT INTO EveryDepositBonus
        (userId, username, parentId, actualAmount, bonusPercent, turnoverRequirement, domainName,bonusType)
        OUTPUT INSERTED.depositId
        VALUES (@userId, @username, @parentId, @actualAmount, @bonusPercent, @turnoverRequirement, @domainName, @bonusType)
      `);

    res.status(200).json({
      errorCode: 0,
      result: [{ success: true, depositId: result.recordset[0].depositId, message: 'Bonus added successfully' }]
    });
  } catch (err) {
    console.error('Error adding deposit bonus:', err);
    res.status(500).json({ errorCode: 4, result: [{ message: 'Failed to add bonus', error: err.message }] });
  }
});

app.post('/api/update-claimable', async (req, res) => {
  const { userId, domainName } = req.body;

  try {
    const pool = await sql.connect(config);

    const today = new Date();
    const toDate = today.toISOString().split('T')[0];
    const fromDateObj = new Date(today);
    fromDateObj.setDate(today.getDate() - 1);
    const fromDate = fromDateObj.toISOString().split('T')[0];

    const existing = await pool.request()
      .input('userId', sql.BigInt, userId)
      .input('domainName', sql.VarChar(100), domainName)
      .input('fromDate', sql.Date, fromDate)
      .input('toDate', sql.Date, toDate)
      .query(`
        SELECT id FROM DepositBonusClaimable
        WHERE userId=@userId AND domainName=@domainName
        AND fromDate=@fromDate AND toDate=@toDate
      `);

    if (existing.recordset.length > 0) {
      return res.json({
        success: false,
        message: 'Claimable already generated for today — skipping duplicate run.'
      });
    }

    const turnoverResponse = await axios.post('https://api2.streamingtv.fun:3481/api/get-turnover', {
      userId,
      domain: "",
      fromDate,
      toDate
    },
    {
      httpsAgent
    }
  );

    const data = turnoverResponse.data.data || [];
    const totalTurnover = data.reduce((sum, item) => sum + (item.totalAmount || 0), 0);

    const depositQuery = await pool.request()
      .input('userId', sql.BigInt, userId)
      .input('domainName', sql.VarChar(100), domainName)
      .input('toDate', sql.Date, toDate)
      .query(`
        SELECT 
          SUM(actualAmount) AS totalDeposit,
          SUM(bonusAmount) AS totalBonus,
          SUM(turnoverRequirement) AS totalTurnoverReq
        FROM EveryDepositBonus
        WHERE userId=@userId AND domainName=@domainName
        AND createdAt >= DATEADD(MINUTE, 30, DATEADD(DAY, -1, CAST(@toDate AS DATETIME)))
        AND createdAt <  DATEADD(MINUTE, 30, CAST(@toDate AS DATETIME))
        
      `);

    const depositData = depositQuery.recordset[0] || {};
    const totalBonus = Number(depositData.totalBonus || 0);
    const totalTurnoverReq = Number(depositData.totalTurnoverReq || 0);

    const prevQuery = await pool.request()
      .input('userId', sql.BigInt, userId)
      .input('domainName', sql.VarChar(100), domainName)
      .query(`
        SELECT TOP 1 * FROM DepositBonusClaimable
        WHERE userId=@userId AND domainName=@domainName
        ORDER BY id DESC
      `);

    let prevClaimable = 0, prevUnclaimable = 0;
    if (prevQuery.recordset.length > 0) {
      const prev = prevQuery.recordset[0];
      prevClaimable = Number(prev.totalClaimableAmount || 0);
      prevUnclaimable = Number(prev.totalUnclaimableAmount || 0);
    }

    // let releaseAmount = 0;
    // if ((domainName || '').toLowerCase() === 'baaaji.win') {
    // if (totalTurnoverReq > 0) {
    //      releaseAmount = (totalTurnover / totalTurnoverReq) * totalBonus;
    //       }
    //      } 
    // else {
    //       const releasePercent = 5;
    //       releaseAmount = (totalTurnover * releasePercent) / 100;
    //      }
    // if (releaseAmount > totalBonus) releaseAmount = totalBonus;
    // if (releaseAmount < 0) releaseAmount = 0;

    let claimableAmount = 0;
    let unclaimableAmount = 0;
    let releasedFromUnclaimable = 0;
    let carryForwardClaimable = prevClaimable;
    let carryForwardUnclaimable = prevUnclaimable;


    const releasePercent = 5; 
    const releaseAmount = (totalTurnover * releasePercent) / 100;

    if (carryForwardUnclaimable > 0) {
      if (releaseAmount <= carryForwardUnclaimable) {
        releasedFromUnclaimable = releaseAmount;
        carryForwardUnclaimable -= releaseAmount;
      } else {
        releasedFromUnclaimable = carryForwardUnclaimable;
        carryForwardUnclaimable = 0;
      }
      claimableAmount += releasedFromUnclaimable;
    }

    let remainingRelease = releaseAmount - releasedFromUnclaimable;
    if (remainingRelease > 0) {
      if (remainingRelease <= totalBonus) {
        claimableAmount += remainingRelease;
        unclaimableAmount = totalBonus - remainingRelease;
      } else {
        claimableAmount += totalBonus;
        unclaimableAmount = 0;
      }
    } else {
      unclaimableAmount = totalBonus;
    }

    const totalClaimableAmount = carryForwardClaimable + claimableAmount;
    const totalUnclaimableAmount = carryForwardUnclaimable + unclaimableAmount;

    let requiredTurnoverForUnclaimable = 0;

    if (totalUnclaimableAmount > 0 && releasePercent > 0) {
      requiredTurnoverForUnclaimable =
        (totalUnclaimableAmount * 100) / releasePercent;
    }


    await pool.request()
      .input('userId', sql.BigInt, userId)
      .input('domainName', sql.VarChar(100), domainName)
      .input('fromDate', sql.Date, fromDate)
      .input('toDate', sql.Date, toDate)
      .input('totalTurnover', sql.Decimal(18, 2), totalTurnover)
      .input('totalTurnoverReq', sql.Decimal(18, 2), totalTurnoverReq)
      .input('totalBonusAmount', sql.Decimal(18, 2), totalBonus)
      .input('claimableAmount', sql.Decimal(18, 2), claimableAmount)
      .input('unclaimableAmount', sql.Decimal(18, 2), unclaimableAmount)
      .input('carryForwardClaimable', sql.Decimal(18, 2), carryForwardClaimable)
      .input('carryForwardUnclaimable', sql.Decimal(18, 2), carryForwardUnclaimable)
      .input('releasedFromUnclaimable', sql.Decimal(18, 2), releasedFromUnclaimable)
      .input('requiredTurnoverForUnclaimable',sql.Decimal(18, 2),requiredTurnoverForUnclaimable)
      .query(`
        INSERT INTO DepositBonusClaimable (
          userId, domainName, fromDate, toDate,
          totalTurnover, totalTurnoverReq, totalBonusAmount,
          claimableAmount, unclaimableAmount,
          carryForwardClaimable, carryForwardUnclaimable,
          releasedFromUnclaimable,requiredTurnoverForUnclaimable, lastUpdated
        )
        VALUES (
          @userId, @domainName, @fromDate, @toDate,
          @totalTurnover, @totalTurnoverReq, @totalBonusAmount,
          @claimableAmount, @unclaimableAmount,
          @carryForwardClaimable, @carryForwardUnclaimable,
          @releasedFromUnclaimable,@requiredTurnoverForUnclaimable, GETDATE()
        )
      `);

    res.json({
      success: true,
      message: 'Claimable bonus updated successfully.',
      data: {
        userId,
        domainName,
        totalTurnover,
        totalBonus,
        claimableAmount,
        unclaimableAmount,
        releasedFromUnclaimable,
        carryForwardClaimable,
        carryForwardUnclaimable,
        totalClaimableAmount,
        totalUnclaimableAmount,
        requiredTurnoverForUnclaimable
      }
    });

  } catch (err) {
    console.error('Error updating claimable bonus:', err);
    res.status(500).json({
      error: 'Failed to update claimable bonus',
      details: err.message
    });
  }
});

app.post('/internal/cron-run-claimable', async (req, res) => {

  try {
    const pool = await sql.connect(config);
    const usersResult = await pool.request().query(`
      SELECT DISTINCT userId, domainName
      FROM EveryDepositBonus
    `);

    const users = usersResult.recordset;
    console.log(`Found ${users.length} users for claimable update`);

    let successCount = 0;
    let failedCount = 0;
    const errors = [];

    for (const user of users) {
      const payload = {
        userId: user.userId,
        domainName: user.domainName
      };

      try {
        await axios.post(
          'https://api2.streamingtv.fun:3481/api/update-claimable',
          payload,
          { httpsAgent }
        );
        successCount++;
      } catch (err) {
        failedCount++;
        const errMsg = err.response?.data || err.message;

        errors.push({
          userId: user.userId,
          domainName: user.domainName,
          error: errMsg
        });
      }
    }

    return res.json({
      success: true,
      totalUsers: users.length,
      successCount,
      failedCount,
      errors
    });

  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Internal error in cron-run-claimable',
      error: err.message
    });
  }
});

// cron.schedule('0 6 * * *', async () => {
//   console.log('Scheduler triggered at', new Date().toISOString());
//   try {
//     const pool = await sql.connect(config);
//     const users = (await pool.request().query(`SELECT DISTINCT userId, domainName FROM EveryDepositBonus`)).recordset;

//     for (const user of users) {
//       try {
//         const payload = { userId: user.userId, domainName: user.domainName };
//         await axios.post('https://api2.streamingtv.fun:3481/api/update-claimable', payload);
//         console.log(`Updated claimable bonus for userId ${user.userId}`);
//       } catch (err) {
//         console.error(`Error updating bonus for userId ${user.userId}:`, err.response?.data || err.message);
//       }
//     }
//   } catch (err) {
//     console.error('Scheduler error:', err.message);
//   }
// });

app.post('/api/redeem-bonus', async (req, res) => {
  const { userId, redeemAmount, domain, agentRef, mainUserId } = req.body;

  try {
    if (!userId || !redeemAmount || !domain) {
      return res.status(400).json({
        success: false,
        message: 'userId, redeemAmount & domain are required'
      });
    }

    const pool = await sql.connect(config);

    const record = await pool.request()
      .input('userId', sql.BigInt, userId)
      .query(`
        SELECT TOP 1 *
        FROM DepositBonusClaimable
        WHERE userId=@userId
        ORDER BY id DESC
      `);

    if (!record.recordset.length) {
      return res.status(404).json({ success: false, message: "No claimable bonus found" });
    }

    const latest = record.recordset[0];
    const claimable = Number(latest.claimableAmount || 0);
    const carryForward = Number(latest.carryForwardClaimable || 0);
    const totalClaimable = claimable + carryForward;

    if (redeemAmount > totalClaimable) {
      return res.status(400).json({ success: false, message: "Insufficient claimable balance" });
    }

    let remaining = redeemAmount;
    let newClaimable = claimable;
    let newCarryForward = carryForward;

    if (remaining <= newClaimable) {
      newClaimable -= remaining;
    } else {
      remaining -= newClaimable;
      newClaimable = 0;
      newCarryForward = Math.max(newCarryForward - remaining, 0);
    }

    const domainConfig = {
      "baaaji.win": { targetMainUserId: 4093141 },
      "baji.win": { targetMainUserId: 4093141 },
      // "josh365.live": { targetMainUserId: 4028532 },
      // "vellki.live": { targetMainUserId: 4298075 },
      // "velkibdt.online": { targetMainUserId: 5004053 },
      // "baji88.games": { targetMainUserId: 4674125 },
      // "1xbet365.live": { targetMainUserId: 4083904 },
      "4six.com":{targetMainUserId: 5856890 }
    };

    const domainKey = domain.toLowerCase();
    if (!domainConfig[domainKey]) {
      return res.status(403).json({ success: false, message: "Not authorized domain" });
    }

    const finalMainUser = agentRef === true
      ? domainConfig[domainKey].targetMainUserId
      : mainUserId;

    const externalPayload = {
      password: "abcdr1245",
      txntype: 1,
      users: [{
        userId,
        txnType: 1,
        amount: redeemAmount,
        remark: "Deposit bonus redeem",
        key: 0,
        mainUserId: finalMainUser
      }]
    };

    let apiRes;
    try {
      apiRes = await axios.post("https://777777.today/pad=81/transferSpec", externalPayload);
    } catch (err) {
      return res.status(200).json({
        success: false,
        message: "External transfer API error",
        error: err.message
      });
    }

    const transferResult = apiRes?.data?.result?.[0]?.result || "FAIL";

    if (transferResult.toLowerCase() !== "success") {
      return res.status(200).json({
        success: false,
        message: "Transfer failed",
        result: transferResult
      });
    }

    await pool.request()
      .input('userId', sql.BigInt, userId)
      .input('transactionType', sql.VarChar(20), 'REDEEM')
      .input('amount', sql.Decimal(18, 2), redeemAmount)
      .input('remarks', sql.VarChar(255), 'Bonus redeemed successfully')
      .query(`
        INSERT INTO BonusTransactions (userId, transactionType, amount, remarks)
        VALUES (@userId, @transactionType, @amount, @remarks)
      `);

      await pool.request()
      .input('userId', sql.BigInt, userId)
      .input('claimableAmount', sql.Decimal(18, 2), newClaimable)
      .input('carryForwardClaimable', sql.Decimal(18, 2), newCarryForward)
      .input('claimedAmount', sql.Decimal(18, 2), redeemAmount)
      .query(`UPDATE DepositBonusClaimable SET 
          claimableAmount = @claimableAmount,
          carryForwardClaimable = @carryForwardClaimable,
          claimedAmount = ISNULL(claimedAmount,0) + @claimedAmount,
          isClaimed = 1,
          claimedDate = GETDATE(),
          lastUpdated = GETDATE() WHERE id = ( SELECT TOP 1 id   FROM DepositBonusClaimable  WHERE userId=@userId  ORDER BY id DESC )`);    

    return res.status(200).json({
      success: true,
      message: "Bonus redeemed successfully",
      remainingClaimable: newClaimable,
      remainingCarryForward: newCarryForward
    });

  } catch (err) {
    console.log("Redeem Error:", err);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
});

app.get('/api/bonus-transactions', async (req, res) => {
  try {
    const { userId, transactionType, fromDate, toDate } = req.query;

    const pool = await sql.connect(config);

    let query = `
      SELECT id, userId, transactionType, amount, remarks, relatedDate, createdAt
      FROM BonusTransactions
      WHERE 1 = 1
    `;

    if (userId) {
      query += ` AND userId = ${userId}`;
    }

    if (transactionType) {
      query += ` AND transactionType = '${transactionType}'`;
    }

    if (fromDate) {
      query += ` AND CAST(createdAt AS DATE) >= '${fromDate}'`;
    }

    if (toDate) {
      query += ` AND CAST(createdAt AS DATE) <= '${toDate}'`;
    }

    query += ` ORDER BY createdAt DESC`;

    const result = await pool.request().query(query);

    return res.json({
      success: true,
      total: result.recordset.length,
      data: result.recordset
    });

  } catch (err) {
    console.error("error:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch bonus transaction logs",
      error: err.message
    });
  }
});

app.get('/api/get-bonus/:userId', async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  try {
    const pool = await sql.connect(config);
    const result = await pool.request()
      .input('userId', sql.BigInt, userId)
      .query(`
        SELECT TOP 20 * FROM DepositBonusClaimable
        WHERE userId=@userId
        ORDER BY id DESC
      `);
    res.json({ success: true, data: result.recordset || [] });
  } catch (err) {
    console.error('Error fetching bonus for userId', userId, err);
    res.status(500).json({ error: 'Failed to fetch bonus', details: err.message });
  }
});

app.get('/api/get-today-bonus', async (req, res) => {
  try {
    const { userId, domainName } = req.query;

    const pool = await sql.connect(config);

    const nowUTC = new Date();

    const today630UTC = new Date(Date.UTC(
      nowUTC.getUTCFullYear(),
      nowUTC.getUTCMonth(),
      nowUTC.getUTCDate(),
      0, 30, 0
    ));

    let startUTC, endUTC;

    if (nowUTC < today630UTC) {
      startUTC = new Date(today630UTC.getTime() - 24 * 60 * 60 * 1000);
      endUTC = today630UTC;
    } else {
      startUTC = today630UTC;
      endUTC = new Date(today630UTC.getTime() + 24 * 60 * 60 * 1000);
    }

    const result = await pool.request()
      .input("userId", sql.BigInt, userId)
      .input("domainName", sql.VarChar(100), domainName)
      .input("startUTC", sql.DateTime, startUTC)
      .input("endUTC", sql.DateTime, endUTC)
      .query(`
        SELECT 
          SUM(actualAmount) AS totalDeposit,
          SUM(bonusAmount) AS totalBonus,
          SUM(turnoverRequirement) AS totalTurnoverReq
        FROM EveryDepositBonus
        WHERE userId=@userId 
          AND domainName=@domainName
          AND createdAt >= @startUTC
          AND createdAt < @endUTC
      `);
      const row = result.recordset[0] || {};
    res.json({
      success: true,
      startUTC,
      endUTC,
      data: {
        totalDeposit: Number(row.totalDeposit) || 0,
        totalBonus: Number(row.totalBonus) || 0,
        totalTurnoverReq: Number(row.totalTurnoverReq) || 0
      }
    });

  } catch (err) {
    res.status(500).json(err);
  }
});

app.get('/api/get-every-deposit-bonus', async (req, res) => {
  const { userId, domainName } = req.query;

  if (!userId) {
    return res.status(400).json({
      success: false,
      message: "userId is required"
    });
  }

  try {
    const pool = await sql.connect(config);

    let query = `
      SELECT 
        depositId,
        userId,
        username,
        parentId,
        actualAmount,
        bonusPercent,
        turnoverRequirement,
        domainName,
        bonusAmount,
        createdAt
      FROM EveryDepositBonus
      WHERE userId = @userId
    `;

    if (domainName) {
      query += ` AND domainName = @domainName `;
    }

    query += ` ORDER BY depositId DESC`;

    const result = await pool.request()
      .input('userId', sql.BigInt, userId)
      .input('domainName', sql.VarChar(100), domainName || null)
      .query(query);

    return res.json({
      success: true,
      message: "Deposit bonus records fetched successfully",
      total: result.recordset.length,
      data: result.recordset
    });

  } catch (err) {
    console.error("Get EveryDepositBonus API Error:", err);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: err.message
    });
  }
});

app.get('/api/get-bonus-report', async (req, res) => {
  try {
    const { from, to, domain } = req.query;

    if (!from || !to || !domain) {
      return res.status(400).json({
        success: false,
        message: "from, to, and domain are required"
      });
    }

    const pool = await sql.connect(config);

    const result = await pool.request()
      .input("from", sql.DateTime, from)
      .input("to", sql.DateTime, to)
      .input("domain", sql.VarChar(100), domain.toLowerCase())
      .query(`
        SELECT 
          d.id,
          d.userId,
          d.domainName,
          d.fromDate,
          d.toDate,
          d.claimableAmount,
          d.unclaimableAmount,
          d.claimedAmount,
          d.isClaimed,
          d.claimedDate,
          d.lastUpdated,
          d.totalClaimableAmount,
          d.totalUnclaimableAmount,
          d.carryForwardUnclaimable,
          d.carryForwardClaimable,
          ISNULL(u.username, '') AS username
        FROM DepositBonusClaimable d
        LEFT JOIN (
            SELECT userId, domainName, MAX(username) AS username
            FROM EveryDepositBonus
            GROUP BY userId, domainName
        ) u
          ON d.userId = u.userId 
         AND d.domainName = u.domainName
        WHERE d.domainName = @domain
          AND d.lastUpdated >= @from
          AND d.lastUpdated < DATEADD(DAY, 1, @to)
        ORDER BY d.lastUpdated DESC
      `);

    res.json({
      success: true,
      totalRecords: result.recordset.length,
      data: result.recordset
    });

  } catch (err) {
    console.error("Error fetching report", err);
    res.status(500).json({
      success: false,
      message: "Error fetching report",
      error: err.message
    });
  }
});

// ==============================
// EVERY DEPOSIT BONUS AUTO START
// ==============================
function generateDepositTxnId(userid) {
  const timestamp = Date.now();
  const random = Math.floor(1000 + Math.random() * 9000);
  return `DP-${userid}-${timestamp}-${random}`;
}

const SPORT_APIS = ['EXCH', 'PARLAY'];
const CASINO_APIS = ['AWC', 'BOG'];

function getMidnightStart(dateObj = new Date()) {
  return new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate(), 0, 0, 0);
}

function fmtSqlDate(d) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function fmtSqlDateMs(d) {
  return `${fmtSqlDate(d)}.000`;
}

async function splitTurnoverFromApi(userId, fromDate, toDate) {
  const from = fmtSqlDateMs(fromDate);
  const to = fmtSqlDateMs(toDate);

  const url =
    `https://sp.vrnlapi.live/api/fetchUserData?userId=${encodeURIComponent(userId)}` +
    `&from=${encodeURIComponent(from)}` +
    `&to=${encodeURIComponent(to)}`;

  console.log('================ TURNOVER API CALL ================');
  console.log(url);
  console.log('===================================================');

  try {
    const turnoverRes = await axios.get(url, {
      timeout: 10000,
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0'
      }
    });

    console.log('================ TURNOVER API RAW ================');
    console.log(JSON.stringify(turnoverRes?.data || {}, null, 2));
    console.log('==================================================');

    const totals = turnoverRes?.data?.totals || [];
    let sport = 0;
    let casino = 0;

    totals.forEach(item => {
      const api = String(item.apiName || '').toUpperCase();
      const amt = Number(item.totalTurnover || 0);

      console.log('TURNOVER ITEM =>', { api, amt });

      if (SPORT_APIS.includes(api)) sport += amt;
      if (CASINO_APIS.includes(api)) casino += amt;
    });

    return {
      sport: Number(sport.toFixed(2)),
      casino: Number(casino.toFixed(2))
    };
  } catch (e) {
    console.log('TURNOVER API ERROR STATUS =>', e?.response?.status);
    console.log('TURNOVER API ERROR DATA =>', e?.response?.data);
    console.log('TURNOVER API ERROR MSG =>', e.message);
    throw e;
  }
}

async function ensureWalletRow(reqOrTxReq, userid) {
  await reqOrTxReq
    .input('userid', sql.BigInt, userid)
    .query(`
      IF NOT EXISTS (SELECT 1 FROM user_turnover_wallet WITH (UPDLOCK, HOLDLOCK) WHERE userid=@userid)
      BEGIN
        INSERT INTO user_turnover_wallet
          (userid, carried_turnover_sport, carried_turnover_casino, consumed_turnover_sport, consumed_turnover_casino, updated_at)
        VALUES
          (@userid, 0, 0, 0, 0, GETDATE())
      END
    `);
}
function consumeForType(required, type, pools) {
  // pools = { sportLeft, casinoLeft }
  let completed = 0;

  if (required <= 0) return { completed: 0, pools };

  const t = String(type || '').toUpperCase();

  if (t === 'CASINO') {
    const use = Math.min(required, pools.casinoLeft);
    pools.casinoLeft = Math.max(0, pools.casinoLeft - use);
    completed = use;
  } else if (t === 'SPORT') {
    const use = Math.min(required, pools.sportLeft);
    pools.sportLeft = Math.max(0, pools.sportLeft - use);
    completed = use;
  } else if (t === 'ALL') {
    // ✅ IMPORTANT: same shared pools (no separate earnedAllLeft)
    const fromSport = Math.min(required, pools.sportLeft);
    pools.sportLeft = Math.max(0, pools.sportLeft - fromSport);

    const remainingNeed = Math.max(0, required - fromSport);

    const fromCasino = Math.min(remainingNeed, pools.casinoLeft);
    pools.casinoLeft = Math.max(0, pools.casinoLeft - fromCasino);

    completed = fromSport + fromCasino;
  } else {
    // default SPORT
    const use = Math.min(required, pools.sportLeft);
    pools.sportLeft = Math.max(0, pools.sportLeft - use);
    completed = use;
  }

  return { completed: Number(completed.toFixed(2)), pools };
}
function areAllCardsCompleted(firstRow, everyRows, totals) {
  let firstCompleted = true;


  if (firstRow) {
    const turnoverUnlocked = Number(firstRow.turnover_unlocked) === 1;
    const balanceUnlocked = Number(firstRow.balance_unlocked) === 1;
    firstCompleted = turnoverUnlocked && !balanceUnlocked;
  }

  let everyAllCompleted = true;

  if (everyRows && everyRows.length > 0) {
    let pools = { sportLeft: Number(totals.totalSportNow || 0), casinoLeft: Number(totals.totalCasinoNow || 0) };

    for (const d of everyRows) {
      const type = String(d.bonusType || '').toUpperCase() || 'SPORT';
      const required = Number(d.required_turnover || 0);

      let completedForThis = 0;
      if (required > 0) {
        const out = consumeForType(required, type, pools);
        completedForThis = out.completed;
        pools = out.pools;
      }

      const isCompleted = required > 0 ? (completedForThis >= required) : true;
      if (!isCompleted) { everyAllCompleted = false; break; }
    }
  }

  return firstCompleted && everyAllCompleted;
}
function resetPoolsFromSegment(totalSportNow, totalCasinoNow, startSport, startCasino) {
  return {
    sportLeft: Number(Math.max(0, totalSportNow - Number(startSport || 0)).toFixed(2)),
    casinoLeft: Number(Math.max(0, totalCasinoNow - Number(startCasino || 0)).toFixed(2)),
  };
}

app.post('/add-every-deposit-bonus-auto', async (req, res) => {
  const { userid, username, parentid, actual_amount, domainname, bonusType, agentRef } = req.body;

  if (!userid || !username || !parentid || !actual_amount || !domainname) {
    return res.status(400).json({ errorCode: 1, result: [{ message: 'Missing required fields' }] });
  }

  const domainKey = String(domainname).toLowerCase();
  if (!allowedDomains1.includes(domainKey)) {
    return res.status(403).json({ errorCode: 2, result: [{ message: 'Not authorized' }] });
  }

  // ✅ NO_BONUS => ALL
  // const invalidBonusTypes = [null, undefined, '', 'NO_BONUS', 'null', 'undefined'];
  // const finalBonusType = invalidBonusTypes.includes(bonusType)
  //   ? 'ALL'
  //   : String(bonusType).toUpperCase();
  const normalizedBonusType = String(bonusType || '').toUpperCase();
    let finalBonusType;

    if (normalizedBonusType === 'NO_BONUS')
    {
      finalBonusType = 'ALL';
    }
    else if (normalizedBonusType === '' || normalizedBonusType === 'NULL' || normalizedBonusType === 'UNDEFINED' ||normalizedBonusType === 'NO')
    {
      finalBonusType = 'NO';
    }
    else {
      finalBonusType = normalizedBonusType;
    }

  try {
    const pool = await sql.connect(config);
    if (finalBonusType === 'NO') {
      const depositTxnId = generateDepositTxnId(userid);
    
      await pool.request()
        .input('depositTxnId', sql.VarChar(100), depositTxnId)
        .input('userid', sql.BigInt, userid)
        .input('username', sql.VarChar(100), username)
        .input('parentid', sql.BigInt, parentid)
        .input('domainname', sql.VarChar(100), domainKey)
        .input('amount', sql.Decimal(18, 2), Number(actual_amount))
        .query(`
          INSERT INTO deposit_nobonus
          (
            depositTxnId,
            userid,
            username,
            parentid,
            domainname,
            amount,
            withdrawn_amount,
            createdAt
          )
          VALUES
          (
            @depositTxnId,
            @userid,
            @username,
            @parentid,
            @domainname,
            @amount,
            0,
            GETDATE()
          )
        `);
    
      return res.status(200).json({
        errorCode: 0,
        result: [{
          success: true,
          bonusApplied: false,
          depositTxnId,
          bonusType: 'NO',
          message: 'NO bonus deposit stored'
        }]
      });
    }
    const depositTxnId = generateDepositTxnId(userid);

    // ---- load bonus config ----
    const configRs = await pool.request()
      .input('domainname', sql.VarChar(100), domainKey)
      .query(`
        SELECT TOP 1
          every_casino_bonus_percent,
          every_sport_bonus_percent,
          every_casino_multiplier,
          every_sport_multiplier,
          max_bonus
        FROM DomainBonusConfig
        WHERE domainname = @domainname AND isActive = 1
      `);

    const conf = configRs.recordset[0];
    if (!conf) return res.status(200).json({ errorCode: 6, result: [{ message: 'No config found for this domain' }] });

    // ---- percent + multiplier ----
    let bonus_percent = 0;
    let multiplier = 1;

    if (finalBonusType === 'CASINO') {
      bonus_percent = Number(conf.every_casino_bonus_percent || 0);
      multiplier = Number(conf.every_casino_multiplier || 1);
    } else if (finalBonusType === 'SPORT') {
      bonus_percent = Number(conf.every_sport_bonus_percent || 0);
      multiplier = Number(conf.every_sport_multiplier || 1);
    } else {
      // ALL => 5% + 1X turnover, sport+casino combined
      let defaultPercent = 5;
      let defaultMultiplier = 1;
      if (domainKey === 'velkimax.com') {
        defaultPercent = 10;
        defaultMultiplier = 2;
      }
      if (domainKey === '9xbaji.pro') {
        defaultPercent = 5;
        defaultMultiplier = 2.5;
      }
      // if (domainKey === 'vellki.live' ||domainKey === 'josh365.live' ||domainKey === '1xbet365.live' || domainKey === 'velkibdt.online') {
      //   defaultPercent = 10;
      //   defaultMultiplier = 10;
      // }
      if (domainKey === 'nagadsx.com') {
        defaultPercent = 10;
        defaultMultiplier = 2;
      }
      bonus_percent = Number(conf.every_sport_bonus_percent || conf.every_casino_bonus_percent || defaultPercent);
      multiplier = defaultMultiplier;
    }

    const maxBonus = Number(conf.max_bonus || 0);

    let redeemAmount = (Number(actual_amount) * bonus_percent) / 100;
    if (maxBonus > 0 && redeemAmount > maxBonus) redeemAmount = maxBonus;
    // redeemAmount = Math.floor(Number(redeemAmount || 0));
    redeemAmount = Number(redeemAmount.toFixed(2));

    if (redeemAmount <= 0) {
      return res.status(200).json({ errorCode: 0, result: [{ success: true, bonusApplied: false, message: 'No bonus (redeemAmount <= 0)' }] });
    }

    const totalAmount = Number(actual_amount) + redeemAmount;
    const requiredTurnover = Number((totalAmount * multiplier).toFixed(2));

    // ---- transfer bonus credit ----
    const domainConfig = {
      "baaaji.win": { targetMainUserId: 4093141 },
      "baji.win": { targetMainUserId: 4093141 },
      "4six.com": { targetMainUserId: 5856789 },
      "cashwinbd.com": { targetMainUserId: 5529504 },
      "velkimax.com": { targetMainUserId: 5529504 },
      "9xbaji.pro": { targetMainUserId: 6138634 },
      // "vellki.live": { targetMainUserId: 4298075 },
      // "josh365.live": { targetMainUserId: 4028532 },
      // "1xbet365.live": { targetMainUserId: 4083904 },
      // "velkibdt.online": { targetMainUserId: 5004053 },
      "nagadsx.com": { targetMainUserId: 4676473 },
    };

    const finalTargetMainUserId = domainConfig[domainKey]?.targetMainUserId 

    const payload = {
      password: "abcdr1245",
      txntype: 1,
      users: [{
        userId: userid,
        txnType: 1,
        amount: redeemAmount,
        remark: `Deposit bonus (Every-${finalBonusType})`,
        key: 0,
        mainUserId: finalTargetMainUserId
      }]
    };

    const axiosInstance = axios.create({ timeout: 1000 });
    let apiRes;
    try {
      apiRes = await axiosInstance.post('https://777777.today/pad=81/transferSpec', payload);
    } catch (apiErr) {
      return res.status(200).json({ errorCode: 4, result: [{ message: 'Transfer API error', error: apiErr.message }] });
    }

    const transferResult = apiRes?.data?.result?.[0]?.result || 'FAILED';
    if (String(transferResult).toLowerCase() !== 'success') {
      return res.status(200).json({ errorCode: 4, result: [{ message: 'Transfer failed', transferResult }] });
    }

    // ==========================================
    // ✅ SEGMENT SNAPSHOT (IMPORTANT FIX)
    // If all previous every-cards are completed BEFORE this new deposit,
    // then snapshot current totals so leftover old turnover will NOT apply.
    // ==========================================
    let start_total_sport = 0;
    let start_total_casino = 0;

    const prevEveryRs = await pool.request()
      .input('userid', sql.BigInt, userid)
      .query(`
        SELECT id, creationdate, bonusType, required_turnover, withdrawn_amount,
               start_total_sport, start_total_casino,
               actual_amount, bonus_amount
        FROM depositbonus_every
        WHERE userid=@userid
        ORDER BY creationdate ASC
      `);

    if (prevEveryRs.recordset.length > 0) {
      await ensureWalletRow(pool.request(), userid);

      const w = await pool.request()
        .input('userid', sql.BigInt, userid)
        .query(`
          SELECT carried_turnover_sport, carried_turnover_casino,
                 consumed_turnover_sport, consumed_turnover_casino
          FROM user_turnover_wallet
          WHERE userid=@userid
        `);

      const carriedSport = Number(w.recordset[0]?.carried_turnover_sport || 0);
      const carriedCasino = Number(w.recordset[0]?.carried_turnover_casino || 0);

      const todayStart = getMidnightStart(new Date());
      const tomorrowStart = new Date(todayStart);
      tomorrowStart.setDate(tomorrowStart.getDate() + 1);
      
      let live = { sport: 0, casino: 0 };
      try { live = await splitTurnoverFromApi(userid, todayStart, tomorrowStart); } catch {}

      const totalSportNow = Number((carriedSport + (live.sport || 0)).toFixed(2));
      const totalCasinoNow = Number((carriedCasino + (live.casino || 0)).toFixed(2));

      let allCompleted = true;

      let curSegS = Number(prevEveryRs.recordset[0].start_total_sport || 0);
      let curSegC = Number(prevEveryRs.recordset[0].start_total_casino || 0);
      let pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);

      for (const d of prevEveryRs.recordset) {
        const segS = Number(d.start_total_sport || 0);
        const segC = Number(d.start_total_casino || 0);

        if (segS !== curSegS || segC !== curSegC) {
          curSegS = segS; curSegC = segC;
          pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
        }

        const type = String(d.bonusType || '').toUpperCase() || 'SPORT';
        const required = Number(d.required_turnover || 0);

        let completedForThis = 0;
        if (required > 0) {
          const out = consumeForType(required, type, pools);
          completedForThis = out.completed;
          pools = out.pools;
        }

        const isCompleted = required > 0 ? (completedForThis >= required) : true;
        if (!isCompleted) { allCompleted = false; break; }
      }

      if (allCompleted) {
        // ✅ NEW SEGMENT STARTS NOW
        start_total_sport = totalSportNow;
        start_total_casino = totalCasinoNow;
      } else {
        // ✅ CONTINUE SAME SEGMENT AS LAST ROW
        const last = prevEveryRs.recordset[prevEveryRs.recordset.length - 1];
        start_total_sport = Number(last.start_total_sport || 0);
        start_total_casino = Number(last.start_total_casino || 0);
      }
    }

    // ---- INSERT (with segment snapshot columns) ----
    await pool.request()
      .input('depositTxnId', sql.VarChar(100), depositTxnId)
      .input('userid', sql.BigInt, userid)
      .input('username', sql.VarChar(100), username)
      .input('parentid', sql.BigInt, parentid)
      .input('actual_amount', sql.Decimal(18, 2), actual_amount)
      .input('bonus_percent', sql.Decimal(10, 2), bonus_percent)
      .input('bonus_amount', sql.Decimal(18, 2), redeemAmount)
      .input('multiplier', sql.Decimal(10,2), multiplier)
      .input('required_turnover', sql.Decimal(18, 2), requiredTurnover)
      .input('domainname', sql.VarChar(100), domainKey)
      .input('bonusType', sql.VarChar(50), finalBonusType)
      .input('agentRef', sql.Bit, agentRef ? 1 : 0)
      .input('start_total_sport', sql.Decimal(18, 2), start_total_sport)
      .input('start_total_casino', sql.Decimal(18, 2), start_total_casino)
      .query(`
        INSERT INTO depositbonus_every
        (depositTxnId, userid, username, parentid, actual_amount,
         bonus_percent, bonus_amount, multiplier, required_turnover,
         domainname, bonusType, agentRef, withdrawn_amount, creationdate,
         start_total_sport, start_total_casino)
        VALUES
        (@depositTxnId, @userid, @username, @parentid, @actual_amount,
         @bonus_percent, @bonus_amount, @multiplier, @required_turnover,
         @domainname, @bonusType, @agentRef, 0, GETDATE(),
         @start_total_sport, @start_total_casino)
      `);

    return res.status(200).json({
      errorCode: 0,
      result: [{
        success: true,
        depositTxnId,
        bonusType: finalBonusType,
        bonus_percent,
        transferredAmount: redeemAmount,
        requiredTurnover,
        segmentStart: { start_total_sport, start_total_casino }
      }]
    });

  } catch (err) {
    return res.status(500).json({ errorCode: 5, result: [{ message: 'Internal error', error: err.message }] });
  }
});

// app.post('/run-daily-turnover-job', async (req, res) => {
//   const { userid } = req.body;

//   if (!userid) {
//     return res.status(400).json({ errorCode: 1, result: [{ message: 'userid required' }] });
//   }

//   try {
//     const pool = await sql.connect(config);

//     const todayStart = getMidnightStart(new Date());
//     const yStart = new Date(todayStart); yStart.setDate(yStart.getDate() - 1);
//     const yEnd = new Date(todayStart);

//     const exists = await pool.request()
//       .input('userid', sql.BigInt, userid)
//       .input('ws', sql.DateTime, yStart)
//       .input('we', sql.DateTime, yEnd)
//       .query(`
//         SELECT 1 FROM user_turnover_daily
//         WHERE userid=@userid AND window_start=@ws AND window_end=@we
//       `);

//     if (exists.recordset.length > 0) {
//       return res.status(200).json({
//         errorCode: 0,
//         result: [{ success: true, message: 'Already stored for this window' }]
//       });
//     }

//     let daily;
//     try {
//       daily = await splitTurnoverFromApi(userid, yStart, yEnd);
//     } catch (e) {
//       return res.status(500).json({
//         errorCode: 2,
//         result: [{ message: 'Turnover API failed', error: e.message }]
//       });
//     }

//     await ensureWalletRow(pool.request(), userid);

//     await pool.request()
//       .input('userid', sql.BigInt, userid)
//       .input('ws', sql.DateTime, yStart)
//       .input('we', sql.DateTime, yEnd)
//       .input('sport', sql.Decimal(18, 2), daily.sport)
//       .input('casino', sql.Decimal(18, 2), daily.casino)
//       .query(`
//         INSERT INTO user_turnover_daily(userid, window_start, window_end, turnover_sport, turnover_casino)
//         VALUES (@userid, @ws, @we, @sport, @casino);

//         UPDATE user_turnover_wallet
//         SET carried_turnover_sport  = carried_turnover_sport + @sport,
//             carried_turnover_casino = carried_turnover_casino + @casino,
//             updated_at = GETDATE()
//         WHERE userid=@userid;
//       `);

//     return res.status(200).json({
//       errorCode: 0,
//       result: [{
//         success: true,
//         window: { from: fmtSqlDate(yStart), to: fmtSqlDate(yEnd) },
//         dailyTurnover: daily,
//       }]
//     });

//   } catch (err) {
//     return res.status(500).json({
//       errorCode: 9,
//       result: [{ message: 'Internal error', error: err.message }]
//     });
//   }
// });

app.get('/check-withdraw-eligibility-every-ui', async (req, res) => {
  const userId = req.query.userId || req.query.userid;
  if (!userId) return res.status(400).json({ errorCode: 1, message: 'userId required' });

  try {
    const pool = await sql.connect(config);

    // 1) BALANCE
    let balanceRes;
    try {
      balanceRes = await axios.get(`https://sp.vrnlapi.live/api3/balance/${userId}`, { timeout: 5000 });
    } catch (e) {
      return res.status(500).json({ errorCode: 2, message: 'Balance API failed', error: e.message });
    }
    const balance = Number(balanceRes?.data?.balance || 0);

    // 2) WALLET
    await ensureWalletRow(pool.request(), userId);

    const wRs = await pool.request()
      .input('userid', sql.BigInt, userId)
      .query(`
        SELECT carried_turnover_sport, carried_turnover_casino,
               consumed_turnover_sport, consumed_turnover_casino
        FROM user_turnover_wallet
        WHERE userid=@userid
      `);

    const carriedSport = Number(wRs.recordset[0]?.carried_turnover_sport || 0);
    const carriedCasino = Number(wRs.recordset[0]?.carried_turnover_casino || 0);
    const consumedSport = Number(wRs.recordset[0]?.consumed_turnover_sport || 0);
    const consumedCasino = Number(wRs.recordset[0]?.consumed_turnover_casino || 0);

    // 3) LIVE TURNOVER
    const todayStart = getMidnightStart(new Date());
    const tomorrowStart = new Date(todayStart);
    tomorrowStart.setDate(tomorrowStart.getDate() + 1);
    
    let live = { sport: 0, casino: 0 };
    try {
      live = await splitTurnoverFromApi(userId, todayStart, tomorrowStart);
    } catch (e) {
      console.log('EVERY UI LIVE ERROR =>', e.message);
    }
    const totalSportNow = Number((carriedSport + (live.sport || 0)).toFixed(2));
    const totalCasinoNow = Number((carriedCasino + (live.casino || 0)).toFixed(2));
    
    console.log('EVERY UI TOTAL NOW =>', {
      totalSportNow,
      totalCasinoNow
    });

    // 4) NET CAP
    const netSport = Number(Math.max(0, totalSportNow - consumedSport).toFixed(2));
    const netCasino = Number(Math.max(0, totalCasinoNow - consumedCasino).toFixed(2));
    const availableNetTotal = Number((netSport + netCasino).toFixed(2));

    // 5) LOAD EVERY DEPOSITS (with segment snapshot columns)
    const depRs = await pool.request()
      .input('userid', sql.BigInt, userId)
      .query(`
        SELECT depositTxnId, creationdate, actual_amount, bonus_amount, bonus_percent,
               required_turnover, withdrawn_amount, bonusType,
               start_total_sport, start_total_casino
        FROM depositbonus_every
        WHERE userid=@userid
        ORDER BY creationdate ASC
      `);

    let sumAvailableByDeposit = 0;

    // ✅ segment tracking
    let curSegS = null;
    let curSegC = null;
    let pools = { sportLeft: 0, casinoLeft: 0 };

    const cards = depRs.recordset.map((d, idx) => {
      const depositAmount = Number(d.actual_amount || 0);
      const bonusAmount = Number(d.bonus_amount || 0);
      const bonusPercent = Number(d.bonus_percent || 0);
      const totalAmount = Number((depositAmount + bonusAmount).toFixed(2));

      const required = Number(d.required_turnover || 0);
      const withdrawn = Number(d.withdrawn_amount || 0);
      const type = String(d.bonusType || '').toUpperCase() || 'SPORT';

      const segS = Number(d.start_total_sport || 0);
      const segC = Number(d.start_total_casino || 0);

      // init / segment change => reset pool
      if (curSegS === null) {
        curSegS = segS; curSegC = segC;
        pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
      } else if (segS !== curSegS || segC !== curSegC) {
        curSegS = segS; curSegC = segC;
        pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
      }

      let completedForThis = 0;
      if (required > 0) {
        const out = consumeForType(required, type, pools);
        completedForThis = out.completed;
        pools = out.pools;
      }

      const progress = required > 0 ? Math.min(1, completedForThis / required) : 0;
      const progressPct = required > 0 ? Number((progress * 100).toFixed(2)) : 0;
      const isCompleted = required > 0 ? (completedForThis >= required) : true;

      const unlockedAmount = isCompleted ? totalAmount : 0;
      const availableToWithdraw = Math.max(0, Number((unlockedAmount - withdrawn).toFixed(2)));

      sumAvailableByDeposit += availableToWithdraw;

      return {
        depositNo: idx + 1,
        depositTxnId: d.depositTxnId,
        bonusType: type,
        depositAmount: Number(depositAmount.toFixed(2)),
        bonusCredit: Number(bonusAmount.toFixed(2)),
        bonusPercent: Number(bonusPercent.toFixed(2)),
        title: `Unlimited ${bonusPercent}% Deposit Extra`,
        amount: totalAmount,
        status: isCompleted ? 'Completed' : 'In Progress',
        completedTurnover: Number(completedForThis.toFixed(2)),
        requiredTurnover: Number(required.toFixed(2)),
        progressPct,
        unlockedAmount,
        withdrawnAmount: withdrawn,
        availableToWithdraw,
        segmentStart: { sport: segS, casino: segC },
        createdAt: d.creationdate
      };
    });

    const allCardsCompleted = cards.length > 0 && cards.every(card => card.status === 'Completed');

    const maxWithdrawNow = allCardsCompleted
      ? Number(balance.toFixed(2))
      : Number(Math.min(balance, sumAvailableByDeposit, availableNetTotal).toFixed(2));
    console.log('EVERY UI FINAL RESPONSE WALLET =>', {
      carriedTurnoverSport: carriedSport,
      carriedTurnoverCasino: carriedCasino,
      todayLiveTurnoverSport: Number((live.sport || 0).toFixed(2)),
      todayLiveTurnoverCasino: Number((live.casino || 0).toFixed(2)),
      totalSportNow,
      totalCasinoNow
    });
    return res.status(200).json({
      errorCode: 0,
      eligible: maxWithdrawNow > 0,
      balance,
      wallet: {
        carriedTurnoverSport: carriedSport,
        carriedTurnoverCasino: carriedCasino,
        todayLiveTurnoverSport: Number((live.sport || 0).toFixed(2)),
        todayLiveTurnoverCasino: Number((live.casino || 0).toFixed(2)),
        totalSportNow,
        totalCasinoNow,
        consumedTurnoverSport: consumedSport,
        consumedTurnoverCasino: consumedCasino,
        netSport,
        netCasino,
        availableNetTotal,
        overrideFullBalance: allCardsCompleted,
      },
      sumAvailableByDeposit: Number(sumAvailableByDeposit.toFixed(2)),
      maxWithdrawNow,
      cards
    });

  } catch (err) {
    return res.status(500).json({ errorCode: 9, message: 'Internal server error', error: err.message });
  }
});

app.post('/withdraw-accept-update-combined', async (req, res) => {
  const { userid, withdrawTxnId, acceptedAmount } = req.body;

  if (!userid || !withdrawTxnId || !acceptedAmount) {
    return res.status(400).json({ errorCode: 1, result: [{ message: 'Missing required fields' }] });
  }

  const amt = Number(acceptedAmount);
  if (!Number.isFinite(amt) || amt <= 0) {
    return res.status(400).json({ errorCode: 2, result: [{ message: 'acceptedAmount must be > 0' }] });
  }

  const pool = await sql.connect(config);
  const tx = new sql.Transaction(pool);

  try {
    await tx.begin(sql.ISOLATION_LEVEL.SERIALIZABLE);

    // BALANCE CAP
    // let balanceRes;
    // try {
    //   balanceRes = await axios.get(`https://sp.vrnlapi.live/api3/balance/${userid}`, { timeout: 5000 });
    // } catch (e) {
    //   await tx.rollback();
    //   return res.status(500).json({ errorCode: 2, result: [{ message: 'Balance API failed', error: e.message }] });
    // }
    // const balance = Number(balanceRes?.data?.balance || 0);

    // if (amt > balance) {
    //   await tx.rollback();
    //   return res.status(200).json({ errorCode: 4, result: [{ message: 'Withdraw > balance', balance }] });
    // }

    // IDEMPOTENT
    
    const already = await new sql.Request(tx)
      .input('withdrawTxnId', sql.VarChar(100), withdrawTxnId)
      .query(`SELECT 1 FROM withdraw_accept_logs WITH (UPDLOCK, HOLDLOCK) WHERE withdrawTxnId=@withdrawTxnId`);

    if (already.recordset.length > 0) {
      await tx.rollback();
      return res.status(200).json({ errorCode: 0, result: [{ success: true, idempotent: true }] });
    }

    // WALLET
    await ensureWalletRow(new sql.Request(tx), userid);

    const wRs = await new sql.Request(tx)
      .input('userid', sql.BigInt, userid)
      .query(`
        SELECT carried_turnover_sport, carried_turnover_casino,
               consumed_turnover_sport, consumed_turnover_casino
        FROM user_turnover_wallet WITH (UPDLOCK, HOLDLOCK)
        WHERE userid=@userid
      `);

    const carriedSport = Number(wRs.recordset[0]?.carried_turnover_sport || 0);
    const carriedCasino = Number(wRs.recordset[0]?.carried_turnover_casino || 0);
    const consumedSport = Number(wRs.recordset[0]?.consumed_turnover_sport || 0);
    const consumedCasino = Number(wRs.recordset[0]?.consumed_turnover_casino || 0);

    // LIVE TURNOVER
    const todayStart = getMidnightStart(new Date());
    const tomorrowStart = new Date(todayStart);
    tomorrowStart.setDate(tomorrowStart.getDate() + 1);

    let live = { sport: 0, casino: 0 };
    try {
      live = await splitTurnoverFromApi(userid, todayStart, tomorrowStart);
    } catch (e) {
      console.log('WITHDRAW LIVE ERROR =>', e.message);
    }

    const totalSportNow = Number((carriedSport + (live.sport || 0)).toFixed(2));
    const totalCasinoNow = Number((carriedCasino + (live.casino || 0)).toFixed(2));

    const netSport = Number(Math.max(0, totalSportNow - consumedSport).toFixed(2));
    const netCasino = Number(Math.max(0, totalCasinoNow - consumedCasino).toFixed(2));
    const availableNetTotal = Number((netSport + netCasino).toFixed(2));

    // LOAD FIRST (LOCKED)
    const firstRs = await new sql.Request(tx)
      .input('userid', sql.BigInt, userid)
      .query(`
        SELECT TOP 1
          id, actual_amount, bonus_percent, bonusType,
          balance_unlocked, turnover_unlocked, withdrawn_amount
        FROM depositbonus WITH (UPDLOCK, HOLDLOCK)
        WHERE userid=@userid
        ORDER BY creationdate DESC
      `);

    // LOAD EVERY (LOCKED)
    const depRs = await new sql.Request(tx)
      .input('userid', sql.BigInt, userid)
      .query(`
        SELECT id, creationdate, bonusType, required_turnover,
               actual_amount, bonus_amount, withdrawn_amount,
               start_total_sport, start_total_casino
        FROM depositbonus_every WITH (UPDLOCK, HOLDLOCK)
        WHERE userid=@userid
        ORDER BY creationdate ASC
      `);

    const hasFirst = firstRs.recordset.length > 0;
    const hasEvery = depRs.recordset.length > 0;

    // ALL COMPLETED CHECK
    let firstCompleted = true;
    if (hasFirst) {
      const b = firstRs.recordset[0];
      const turnoverUnlocked = (Number(b.turnover_unlocked) === 1);
      const balanceUnlocked = (Number(b.balance_unlocked) === 1);
      firstCompleted = turnoverUnlocked || balanceUnlocked;
    }

    let everyAllCompleted = true;
    if (hasEvery) {
      let curSegS = null;
      let curSegC = null;
      let pools = { sportLeft: 0, casinoLeft: 0 };

      for (const d of depRs.recordset) {
        const segS = Number(d.start_total_sport || 0);
        const segC = Number(d.start_total_casino || 0);

        if (curSegS === null) {
          curSegS = segS;
          curSegC = segC;
          pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
        } else if (segS !== curSegS || segC !== curSegC) {
          curSegS = segS;
          curSegC = segC;
          pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
        }

        const type = String(d.bonusType || '').toUpperCase() || 'SPORT';
        const required = Number(d.required_turnover || 0);

        let completedForThis = 0;
        if (required > 0) {
          const out = consumeForType(required, type, pools);
          completedForThis = out.completed;
          pools = out.pools;
        }

        const isCompleted = required > 0 ? (completedForThis >= required) : true;
        if (!isCompleted) {
          everyAllCompleted = false;
          break;
        }
      }
    }

    const hasAny = hasFirst || hasEvery;
    const allCardsCompleted = hasAny && firstCompleted && everyAllCompleted;

    console.log('WITHDRAW ALL COMPLETED DEBUG =>', {
      userid,
      hasFirst,
      hasEvery,
      firstCompleted,
      everyAllCompleted,
      hasAny,
      allCardsCompleted,
      amt,
      // balance,
      totalSportNow,
      totalCasinoNow,
      netSport,
      netCasino,
      availableNetTotal
    });

    // NORMAL DEDUCT FLOW
    let remaining = amt;
    let sportDeduct = 0;
    let casinoDeduct = 0;

    // A) FIRST DEDUCT
    if (hasFirst && remaining > 0) {
      const b = firstRs.recordset[0];
      const turnoverUnlocked = (Number(b.turnover_unlocked) === 1);
      const balanceUnlocked = (Number(b.balance_unlocked) === 1);
      const firstWithdrawable = turnoverUnlocked && !balanceUnlocked;

      if (firstWithdrawable) {
        const depositAmount = Number(b.actual_amount || 0);
        const bonusAmount = Number(((depositAmount * Number(b.bonus_percent || 0)) / 100).toFixed(2));
        const totalAmount = Number((depositAmount + bonusAmount).toFixed(2));
        const withdrawn = Number(b.withdrawn_amount || 0);

        const available = Math.max(0, totalAmount - withdrawn);
        const use = Math.min(available, remaining);

        if (use > 0) {
          await new sql.Request(tx)
            .input('id', sql.BigInt, b.id)
            .input('useAmt', sql.Decimal(18, 2), use)
            .query(`
              UPDATE depositbonus
              SET withdrawn_amount = withdrawn_amount + @useAmt
              WHERE id=@id
            `);

          const t = String(b.bonusType || '').toUpperCase();
          if (t === 'CASINO') casinoDeduct += use;
          else sportDeduct += use;

          remaining -= use;
        }
      }
    }

    // B) EVERY DEDUCT
    if (remaining > 0) {
      if (!allCardsCompleted && remaining > availableNetTotal) {
        await tx.rollback();
        return res.status(200).json({
          errorCode: 4,
          result: [{ message: 'Every-part withdraw > net turnover cap', availableNetTotal, remaining }]
        });
      }

      let curSegS = null;
      let curSegC = null;
      let pools = { sportLeft: 0, casinoLeft: 0 };

      for (const d of depRs.recordset) {
        if (remaining <= 0) break;

        const segS = Number(d.start_total_sport || 0);
        const segC = Number(d.start_total_casino || 0);

        if (curSegS === null) {
          curSegS = segS;
          curSegC = segC;
          pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
        } else if (segS !== curSegS || segC !== curSegC) {
          curSegS = segS;
          curSegC = segC;
          pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
        }

        const type = String(d.bonusType || '').toUpperCase() || 'SPORT';
        const required = Number(d.required_turnover || 0);

        let completedForThis = 0;
        if (required > 0) {
          const out = consumeForType(required, type, pools);
          completedForThis = out.completed;
          pools = out.pools;
        }

        const isCompleted = required > 0 ? (completedForThis >= required) : true;
        if (!isCompleted) continue;

        const totalAmount = Number(d.actual_amount || 0) + Number(d.bonus_amount || 0);
        const alreadyW = Number(d.withdrawn_amount || 0);
        const canUse = Math.max(0, totalAmount - alreadyW);
        if (canUse <= 0) continue;

        const use = Math.min(canUse, remaining);

        await new sql.Request(tx)
          .input('id', sql.BigInt, d.id)
          .input('useAmt', sql.Decimal(18, 2), use)
          .query(`
            UPDATE depositbonus_every
            SET withdrawn_amount = withdrawn_amount + @useAmt
            WHERE id=@id
          `);

        if (type === 'CASINO') casinoDeduct += use;
        else sportDeduct += use;

        remaining -= use;
      }
    }

    // If all cards completed, allow extra balance too
    let finalSportDeduct = sportDeduct;
    let finalCasinoDeduct = casinoDeduct;

    if (remaining > 0 && allCardsCompleted) {
      const extraSport = Math.min(remaining, Math.max(0, netSport - sportDeduct));
      finalSportDeduct = Number((finalSportDeduct + extraSport).toFixed(2));
      remaining = Number((remaining - extraSport).toFixed(2));

      const extraCasino = Math.min(remaining, Math.max(0, netCasino - casinoDeduct));
      finalCasinoDeduct = Number((finalCasinoDeduct + extraCasino).toFixed(2));
      remaining = Number((remaining - extraCasino).toFixed(2));
    }

    // if (remaining > 0 && !allCardsCompleted) {
    //   await tx.rollback();
    //   return res.status(200).json({
    //     errorCode: 4,
    //     result: [{ message: 'Withdraw > unlocked (first + completed every). Reject.', remaining }]
    //   });
    // }
    if (remaining > 0) {
      console.log('WITHDRAW REMAINING NOT CONSUMED =>', remaining);
    
      remaining = 0;
    }

    // LOG
    await new sql.Request(tx)
      .input('withdrawTxnId', sql.VarChar(100), withdrawTxnId)
      .input('userid', sql.BigInt, userid)
      .input('amt', sql.Decimal(18, 2), amt)
      .query(`
        INSERT INTO withdraw_accept_logs(withdrawTxnId, userid, accepted_amount)
        VALUES (@withdrawTxnId, @userid, @amt)
      `);

    // WALLET CONSUMED UPDATE
    await new sql.Request(tx)
      .input('userid', sql.BigInt, userid)
      .input('sAmt', sql.Decimal(18, 2), finalSportDeduct)
      .input('cAmt', sql.Decimal(18, 2), finalCasinoDeduct)
      .query(`
        UPDATE user_turnover_wallet
        SET consumed_turnover_sport  = consumed_turnover_sport + @sAmt,
            consumed_turnover_casino = consumed_turnover_casino + @cAmt,
            updated_at = GETDATE()
        WHERE userid=@userid
      `);

    await tx.commit();

    return res.status(200).json({
      errorCode: 0,
      result: [{
        success: true,
        deducted: amt,
        // mode: allCardsCompleted ? 'ALL_COMPLETED_FULL_BALANCE' : 'NORMAL',
        mode: 'ACCEPTED',
        sportDeduct: Number(finalSportDeduct.toFixed(2)),
        casinoDeduct: Number(finalCasinoDeduct.toFixed(2))
      }]
    });

  } catch (err) {
    try { await tx.rollback(); } catch {}
    return res.status(500).json({
      errorCode: 9,
      result: [{ message: 'Internal error', error: err.message }]
    });
  }
});

// app.post('/every-withdraw-accept-update', async (req, res) => {
//   const { userid, withdrawTxnId, acceptedAmount } = req.body;

//   if (!userid || !withdrawTxnId || !acceptedAmount) {
//     return res.status(400).json({ errorCode: 1, result: [{ message: 'Missing required fields' }] });
//   }

//   const amt = Number(acceptedAmount);
//   if (!Number.isFinite(amt) || amt <= 0) {
//     return res.status(400).json({ errorCode: 2, result: [{ message: 'acceptedAmount must be > 0' }] });
//   }

//   const pool = await sql.connect(config);
//   const tx = new sql.Transaction(pool);

//   try {
//     await tx.begin(sql.ISOLATION_LEVEL.SERIALIZABLE);

//     // Idempotent
//     const already = await new sql.Request(tx)
//       .input('withdrawTxnId', sql.VarChar(100), withdrawTxnId)
//       .query(`
//         SELECT 1
//         FROM withdraw_accept_logs WITH (UPDLOCK, HOLDLOCK)
//         WHERE withdrawTxnId=@withdrawTxnId
//       `);

//     if (already.recordset.length > 0) {
//       await tx.rollback();
//       return res.status(200).json({ errorCode: 0, result: [{ success: true, idempotent: true }] });
//     }

//     await ensureWalletRow(new sql.Request(tx), userid);

//     // Wallet read (locked)
//     const wRs = await new sql.Request(tx)
//       .input('userid', sql.BigInt, userid)
//       .query(`
//         SELECT carried_turnover_sport, carried_turnover_casino,
//                consumed_turnover_sport, consumed_turnover_casino
//         FROM user_turnover_wallet WITH (UPDLOCK, HOLDLOCK)
//         WHERE userid=@userid
//       `);

//     const carriedSport = Number(wRs.recordset[0]?.carried_turnover_sport || 0);
//     const carriedCasino = Number(wRs.recordset[0]?.carried_turnover_casino || 0);
//     const consumedSport = Number(wRs.recordset[0]?.consumed_turnover_sport || 0);
//     const consumedCasino = Number(wRs.recordset[0]?.consumed_turnover_casino || 0);

//     // Live turnover
//     const todayStart = getMidnightStart(new Date());
//     const now = new Date();
//     let live = { sport: 0, casino: 0 };
//     try { live = await splitTurnoverFromApi(userid, todayStart, now); } catch { live = { sport: 0, casino: 0 }; }

//     const totalSportNow = Number((carriedSport + live.sport).toFixed(2));
//     const totalCasinoNow = Number((carriedCasino + live.casino).toFixed(2));

//     // Net cap
//     const netSport = Number(Math.max(0, totalSportNow - consumedSport).toFixed(2));
//     const netCasino = Number(Math.max(0, totalCasinoNow - consumedCasino).toFixed(2));
//     const availableNetTotal = Number((netSport + netCasino).toFixed(2));

//     if (amt > availableNetTotal) {
//       await tx.rollback();
//       return res.status(200).json({
//         errorCode: 4,
//         result: [{ message: 'Withdraw amount > net turnover available. Reject.', availableNetTotal }]
//       });
//     }

//     // Deposits locked
//     const depRs = await new sql.Request(tx)
//       .input('userid', sql.BigInt, userid)
//       .query(`
//         SELECT id, creationdate, bonusType, required_turnover,
//                actual_amount, bonus_amount, withdrawn_amount
//         FROM depositbonus_every WITH (UPDLOCK, HOLDLOCK)
//         WHERE userid=@userid
//         ORDER BY creationdate ASC
//       `);

//     let earnedSportLeft = totalSportNow;
//     let earnedCasinoLeft = totalCasinoNow;
//     let earnedAllLeft = Number((totalSportNow + totalCasinoNow).toFixed(2)); // ✅ NEW

//     let remainingToDeduct = amt;

//     // wallet consumption tracking
//     let sportDeduct = 0;
//     let casinoDeduct = 0;

//     for (const d of depRs.recordset) {
//       if (remainingToDeduct <= 0) break;

//       const type = String(d.bonusType || '').toUpperCase() || 'SPORT';
//       const required = Number(d.required_turnover || 0);

//       let completedForThis = 0;

//       if (required > 0) {
//         if (type === 'CASINO') {
//           completedForThis = Math.min(required, earnedCasinoLeft);
//           earnedCasinoLeft = Math.max(0, earnedCasinoLeft - completedForThis);
//         } else if (type === 'SPORT') {
//           completedForThis = Math.min(required, earnedSportLeft);
//           earnedSportLeft = Math.max(0, earnedSportLeft - completedForThis);
//         } else {
//           // ✅ ALL
//           completedForThis = Math.min(required, earnedAllLeft);
//           earnedAllLeft = Math.max(0, earnedAllLeft - completedForThis);
//         }
//       }

//       const isCompleted = required > 0 ? (completedForThis >= required) : true;

//       const totalAmount = Number(d.actual_amount || 0) + Number(d.bonus_amount || 0);
//       const alreadyW = Number(d.withdrawn_amount || 0);

//       const unlockedAmount = isCompleted ? totalAmount : 0;
//       const canUse = Math.max(0, unlockedAmount - alreadyW);

//       if (canUse <= 0) continue;

//       const use = Math.min(canUse, remainingToDeduct);

//       await new sql.Request(tx)
//         .input('id', sql.BigInt, d.id)
//         .input('useAmt', sql.Decimal(18, 2), use)
//         .query(`
//           UPDATE depositbonus_every
//           SET withdrawn_amount = withdrawn_amount + @useAmt
//           WHERE id=@id
//         `);

//       // ✅ wallet consumed split
//       if (type === 'CASINO') {
//         casinoDeduct += use;
//       } else if (type === 'SPORT') {
//         sportDeduct += use;
//       } else {
//         // ALL => sport first then casino
//         const fromSport = Math.min(use, Math.max(0, netSport - sportDeduct));
//         const left = use - fromSport;
//         const fromCasino = Math.min(left, Math.max(0, netCasino - casinoDeduct));

//         sportDeduct += fromSport;
//         casinoDeduct += fromCasino;
//       }

//       remainingToDeduct -= use;
//     }

//     if (remainingToDeduct > 0) {
//       await tx.rollback();
//       return res.status(200).json({
//         errorCode: 4,
//         result: [{ message: 'Withdraw amount > unlocked deposits. Reject.', remainingToDeduct }]
//       });
//     }

//     // Insert log
//     await new sql.Request(tx)
//       .input('withdrawTxnId', sql.VarChar(100), withdrawTxnId)
//       .input('userid', sql.BigInt, userid)
//       .input('amt', sql.Decimal(18, 2), amt)
//       .query(`
//         INSERT INTO withdraw_accept_logs(withdrawTxnId, userid, accepted_amount)
//         VALUES (@withdrawTxnId, @userid, @amt)
//       `);

//     // Update wallet consumed
//     await new sql.Request(tx)
//       .input('userid', sql.BigInt, userid)
//       .input('sAmt', sql.Decimal(18, 2), sportDeduct)
//       .input('cAmt', sql.Decimal(18, 2), casinoDeduct)
//       .query(`
//         UPDATE user_turnover_wallet
//         SET consumed_turnover_sport  = consumed_turnover_sport + @sAmt,
//             consumed_turnover_casino = consumed_turnover_casino + @cAmt,
//             updated_at = GETDATE()
//         WHERE userid=@userid
//       `);

//     await tx.commit();

//     return res.status(200).json({
//       errorCode: 0,
//       result: [{
//         success: true,
//         deducted: amt,
//         sportDeduct: Number(sportDeduct.toFixed(2)),
//         casinoDeduct: Number(casinoDeduct.toFixed(2))
//       }]
//     });

//   } catch (err) {
//     try { await tx.rollback(); } catch {}
//     return res.status(500).json({
//       errorCode: 9,
//       result: [{ message: 'Internal error', error: err.message }]
//     });
//   }
// });

app.get('/check-withdraw-eligibility-combined', async (req, res) => {
  const userId = req.query.userId || req.query.userid;
  if (!userId) return res.status(400).json({ errorCode: 1, message: 'userId required' });

  try {
    const pool = await sql.connect(config);

    // BALANCE
    let balanceRes;
    try {
      balanceRes = await axios.get(`https://sp.vrnlapi.live/api3/balance/${userId}`, { timeout: 5000 });
    } catch (e) {
      return res.status(500).json({ errorCode: 2, message: 'Balance API failed', error: e.message });
    }
    const balance = Number(balanceRes?.data?.balance || 0);

    // WALLET
    await ensureWalletRow(pool.request(), userId);

    const wRs = await pool.request()
      .input('userid', sql.BigInt, userId)
      .query(`
        SELECT carried_turnover_sport, carried_turnover_casino,
               consumed_turnover_sport, consumed_turnover_casino
        FROM user_turnover_wallet
        WHERE userid=@userid
      `);

    const carriedSport = Number(wRs.recordset[0]?.carried_turnover_sport || 0);
    const carriedCasino = Number(wRs.recordset[0]?.carried_turnover_casino || 0);
    const consumedSport = Number(wRs.recordset[0]?.consumed_turnover_sport || 0);
    const consumedCasino = Number(wRs.recordset[0]?.consumed_turnover_casino || 0);

    // LIVE TURNOVER
    const todayStart = getMidnightStart(new Date());
    const tomorrowStart = new Date(todayStart);
    tomorrowStart.setDate(tomorrowStart.getDate() + 1);
    
    let live = { sport: 0, casino: 0 };
    try { live = await splitTurnoverFromApi(userId, todayStart, tomorrowStart); } catch {}

    const totalSportNow = Number((carriedSport + (live.sport || 0)).toFixed(2));
    const totalCasinoNow = Number((carriedCasino + (live.casino || 0)).toFixed(2));

    // NET CAP (every part only)
    const netSport = Number(Math.max(0, totalSportNow - consumedSport).toFixed(2));
    const netCasino = Number(Math.max(0, totalCasinoNow - consumedCasino).toFixed(2));
    const availableNetTotal = Number((netSport + netCasino).toFixed(2));

    // ---------------- FIRST BONUS ----------------
    const firstRs = await pool.request()
      .input('userid', sql.BigInt, userId)
      .query(`
        SELECT TOP 1
          id, actual_amount, bonus_percent, bonusType, creationdate,
          balance_unlocked, turnover_unlocked, withdrawn_amount
        FROM depositbonus
        WHERE userid=@userid
        ORDER BY creationdate DESC
      `);

    let firstAvailable = 0;
    let firstCard = null;
    let firstCompletedForOverride = true;

    if (firstRs.recordset.length > 0) {
      const b = firstRs.recordset[0];

      const depositAmount = Number(b.actual_amount || 0);
      const bonusAmount = Number(((depositAmount * Number(b.bonus_percent || 0)) / 100).toFixed(2));
      const totalAmount = Number((depositAmount + bonusAmount).toFixed(2));
      const withdrawn = Number(b.withdrawn_amount || 0);

      const turnoverUnlocked = (Number(b.turnover_unlocked) === 1);
      const balanceUnlocked = (Number(b.balance_unlocked) === 1);

      const firstWithdrawable = turnoverUnlocked && !balanceUnlocked;
      firstAvailable = firstWithdrawable ? Number(Math.max(0, totalAmount - withdrawn).toFixed(2)) : 0;

      const status = turnoverUnlocked ? 'Completed' : (balanceUnlocked ? 'Unlocked' : 'In Progress');

      // ✅ override completion rule (as per your previous code)
      firstCompletedForOverride = turnoverUnlocked || balanceUnlocked;

      firstCard = {
        bonusId: b.id,
        bonusType: String(b.bonusType || '').toUpperCase(),
        amount: totalAmount,
        withdrawnAmount: Number(withdrawn.toFixed(2)),
        availableToWithdraw: firstAvailable,
        status,
        createdAt: b.creationdate
      };
    }

    // ---------------- EVERY BONUS (segment pools) ----------------
    const depRs = await pool.request()
      .input('userid', sql.BigInt, userId)
      .query(`
        SELECT id, creationdate, required_turnover,
               actual_amount, bonus_amount, withdrawn_amount, bonusType,
               start_total_sport, start_total_casino
        FROM depositbonus_every
        WHERE userid=@userid
        ORDER BY creationdate ASC
      `);

    let everyAvailable = 0;
    let everyAllCompletedForOverride = true;

    let curSegS = null;
    let curSegC = null;
    let pools = { sportLeft: 0, casinoLeft: 0 };

    for (const d of depRs.recordset) {
      const totalAmt = Number((Number(d.actual_amount || 0) + Number(d.bonus_amount || 0)).toFixed(2));
      const required = Number(d.required_turnover || 0);
      const withdrawn = Number(d.withdrawn_amount || 0);
      const type = String(d.bonusType || '').toUpperCase() || 'SPORT';

      const segS = Number(d.start_total_sport || 0);
      const segC = Number(d.start_total_casino || 0);

      if (curSegS === null) {
        curSegS = segS; curSegC = segC;
        pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
      } else if (segS !== curSegS || segC !== curSegC) {
        curSegS = segS; curSegC = segC;
        pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
      }

      let completedForThis = 0;
      if (required > 0) {
        const out = consumeForType(required, type, pools);
        completedForThis = out.completed;
        pools = out.pools;
      }

      const isCompleted = required > 0 ? (completedForThis >= required) : true;

      if (!isCompleted) {
        everyAllCompletedForOverride = false;
        continue; // still calculate others if any
      }

      everyAvailable += Math.max(0, totalAmt - withdrawn);
    }

    everyAvailable = Number(everyAvailable.toFixed(2));

    // ✅ turnover cap only on EVERY part
    const everyCapped = Number(Math.min(everyAvailable, availableNetTotal).toFixed(2));
    const combinedProgramAvailableNormal = Number((firstAvailable + everyCapped).toFixed(2));
    const maxWithdrawNowNormal = Number(Math.min(balance, combinedProgramAvailableNormal).toFixed(2));

    // ✅ OVERRIDE: if ALL cards completed => full balance withdraw allowed
    const hasAnyCards = (firstRs.recordset.length > 0) || (depRs.recordset.length > 0);
    const allCompleted = firstCompletedForOverride && everyAllCompletedForOverride;

    const maxWithdrawNow = (hasAnyCards && allCompleted)
      ? Number(balance.toFixed(2))
      : maxWithdrawNowNormal;

    const combinedProgramAvailable = (hasAnyCards && allCompleted)
      ? Number(balance.toFixed(2))
      : combinedProgramAvailableNormal;

    return res.status(200).json({
      errorCode: 0,
      eligible: maxWithdrawNow > 0,
      balance,
      wallet: {
        carriedTurnoverSport: carriedSport,
        carriedTurnoverCasino: carriedCasino,
        todayLiveTurnoverSport: Number((live.sport || 0).toFixed(2)),
        todayLiveTurnoverCasino: Number((live.casino || 0).toFixed(2)),
        totalSportNow,
        totalCasinoNow,
        consumedTurnoverSport: consumedSport,
        consumedTurnoverCasino: consumedCasino,
        netSport,
        netCasino,
        availableNetTotal
      },
      firstAvailable,
      everyAvailable,
      everyCapped,
      combinedProgramAvailable,
      maxWithdrawNow,
      overrideFullBalance: (hasAnyCards && allCompleted),
      firstCard
    });

  } catch (err) {
    return res.status(500).json({ errorCode: 9, message: 'Internal server error', error: err.message });
  }
});

cron.schedule('5 0 * * *', async () => {
  try {
    const pool = await sql.connect(config);

    const usersRs = await pool.request().query(`
      SELECT DISTINCT userid
      FROM depositbonus_every
    `);

    for (const row of usersRs.recordset) {
      const userid = row.userid;

      const todayStart = getMidnightStart(new Date());
      const yStart = new Date(todayStart);
      yStart.setDate(yStart.getDate() - 1);
      const yEnd = new Date(todayStart);

      const wsStr = fmtSqlDate(yStart);
      const weStr = fmtSqlDate(yEnd);

      let daily;
      try {
        daily = await splitTurnoverFromApi(userid, yStart, yEnd);
      } catch (e) {
        console.log(`Turnover API failed for user ${userid}:`, e.message);
        continue;
      }

      await ensureWalletRow(pool.request(), userid);

      const existingRs = await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('ws', sql.VarChar(19), wsStr)
        .input('we', sql.VarChar(19), weStr)
        .query(`
          SELECT TOP 1 id, turnover_sport, turnover_casino
          FROM user_turnover_daily
          WHERE userid=@userid
            AND window_start = CONVERT(datetime, @ws, 120)
            AND window_end = CONVERT(datetime, @we, 120)
        `);

      if (existingRs.recordset.length > 0) {
        const oldSport = Number(existingRs.recordset[0].turnover_sport || 0);
        const oldCasino = Number(existingRs.recordset[0].turnover_casino || 0);

        const diffSport = Number((daily.sport - oldSport).toFixed(2));
        const diffCasino = Number((daily.casino - oldCasino).toFixed(2));

        if (diffSport !== 0 || diffCasino !== 0) {
          await pool.request()
            .input('id', sql.BigInt, existingRs.recordset[0].id)
            .input('userid', sql.BigInt, userid)
            .input('sport', sql.Decimal(18, 2), daily.sport)
            .input('casino', sql.Decimal(18, 2), daily.casino)
            .input('diffSport', sql.Decimal(18, 2), diffSport)
            .input('diffCasino', sql.Decimal(18, 2), diffCasino)
            .query(`
              UPDATE user_turnover_daily
              SET turnover_sport = @sport,
                  turnover_casino = @casino
              WHERE id=@id;

              UPDATE user_turnover_wallet
              SET carried_turnover_sport  = carried_turnover_sport + @diffSport,
                  carried_turnover_casino = carried_turnover_casino + @diffCasino,
                  updated_at = GETDATE()
              WHERE userid=@userid;
            `);

          console.log(`Reconciled user ${userid}: sport diff=${diffSport}, casino diff=${diffCasino}`);
        }

        continue;
      }

      await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('ws', sql.VarChar(19), wsStr)
        .input('we', sql.VarChar(19), weStr)
        .input('sport', sql.Decimal(18, 2), daily.sport)
        .input('casino', sql.Decimal(18, 2), daily.casino)
        .query(`
          INSERT INTO user_turnover_daily(userid, window_start, window_end, turnover_sport, turnover_casino)
          VALUES (
            @userid,
            CONVERT(datetime, @ws, 120),
            CONVERT(datetime, @we, 120),
            @sport,
            @casino
          );

          UPDATE user_turnover_wallet
          SET carried_turnover_sport  = carried_turnover_sport + @sport,
              carried_turnover_casino = carried_turnover_casino + @casino,
              updated_at = GETDATE()
          WHERE userid=@userid;
        `);

      console.log(`Inserted daily turnover for user ${userid}: sport=${daily.sport}, casino=${daily.casino}`);
    }

    console.log('Daily turnover split job done');
  } catch (e) {
    console.log('Daily turnover split job error:', e.message);
  }
});

app.post('/run-daily-turnover-job-all-now', async (req, res) => {
  try {
    const pool = await sql.connect(config);

    const usersRs = await pool.request().query(`
      SELECT DISTINCT userid
      FROM depositbonus_every
    `);

    let processed = 0;
    let inserted = 0;
    let reconciled = 0;
    let failed = 0;

    for (const row of usersRs.recordset) {
      const userid = row.userid;
      processed++;

      try {
        const todayStart = getMidnightStart(new Date());
        const yStart = new Date(todayStart);
        yStart.setDate(yStart.getDate() - 1);
        const yEnd = new Date(todayStart);

        const wsStr = fmtSqlDate(yStart);
        const weStr = fmtSqlDate(yEnd);

        let daily;
        try {
          daily = await splitTurnoverFromApi(userid, yStart, yEnd);
        } catch (e) {
          console.log(`Turnover API failed for user ${userid}:`, e.message);
          failed++;
          continue;
        }

        await ensureWalletRow(pool.request(), userid);

        const existingRs = await pool.request()
          .input('userid', sql.BigInt, userid)
          .input('ws', sql.VarChar(19), wsStr)
          .input('we', sql.VarChar(19), weStr)
          .query(`
            SELECT TOP 1 id, turnover_sport, turnover_casino
            FROM user_turnover_daily
            WHERE userid=@userid
              AND window_start = CONVERT(datetime, @ws, 120)
              AND window_end = CONVERT(datetime, @we, 120)
          `);

        if (existingRs.recordset.length > 0) {
          const oldSport = Number(existingRs.recordset[0].turnover_sport || 0);
          const oldCasino = Number(existingRs.recordset[0].turnover_casino || 0);

          const diffSport = Number((daily.sport - oldSport).toFixed(2));
          const diffCasino = Number((daily.casino - oldCasino).toFixed(2));

          if (diffSport !== 0 || diffCasino !== 0) {
            await pool.request()
              .input('id', sql.BigInt, existingRs.recordset[0].id)
              .input('userid', sql.BigInt, userid)
              .input('sport', sql.Decimal(18, 2), daily.sport)
              .input('casino', sql.Decimal(18, 2), daily.casino)
              .input('diffSport', sql.Decimal(18, 2), diffSport)
              .input('diffCasino', sql.Decimal(18, 2), diffCasino)
              .query(`
                UPDATE user_turnover_daily
                SET turnover_sport = @sport,
                    turnover_casino = @casino
                WHERE id=@id;

                UPDATE user_turnover_wallet
                SET carried_turnover_sport  = carried_turnover_sport + @diffSport,
                    carried_turnover_casino = carried_turnover_casino + @diffCasino,
                    updated_at = GETDATE()
                WHERE userid=@userid;
              `);

            reconciled++;
            console.log(`Reconciled user ${userid}: sport diff=${diffSport}, casino diff=${diffCasino}`);
          }

          continue;
        }

        await pool.request()
          .input('userid', sql.BigInt, userid)
          .input('ws', sql.VarChar(19), wsStr)
          .input('we', sql.VarChar(19), weStr)
          .input('sport', sql.Decimal(18, 2), daily.sport)
          .input('casino', sql.Decimal(18, 2), daily.casino)
          .query(`
            INSERT INTO user_turnover_daily(userid, window_start, window_end, turnover_sport, turnover_casino)
            VALUES (
              @userid,
              CONVERT(datetime, @ws, 120),
              CONVERT(datetime, @we, 120),
              @sport,
              @casino
            );

            UPDATE user_turnover_wallet
            SET carried_turnover_sport  = carried_turnover_sport + @sport,
                carried_turnover_casino = carried_turnover_casino + @casino,
                updated_at = GETDATE()
            WHERE userid=@userid;
          `);

        inserted++;
        console.log(`Inserted daily turnover for user ${userid}: sport=${daily.sport}, casino=${daily.casino}`);
      } catch (e) {
        failed++;
        console.log(`Manual daily turnover failed for user ${userid}:`, e.message);
      }
    }

    return res.status(200).json({
      success: true,
      message: 'Manual daily turnover job executed',
      summary: {
        processed,
        inserted,
        reconciled,
        failed
      }
    });
  } catch (e) {
    return res.status(500).json({
      success: false,
      message: 'Manual daily turnover job failed',
      error: e.message
    });
  }
});

app.get('/domain-bonus-report-every', async (req, res) => {
  const domain = String(req.query.domain || '').toLowerCase();
  if (!domain) {
    return res.status(400).json({ errorCode: 1, message: 'domain required' });
  }

  const statusFilter = String(req.query.status || 'all').toLowerCase(); // all / completed / in progress
  const from = req.query.from ? new Date(req.query.from) : null;
  const to = req.query.to ? new Date(req.query.to) : null;

  const page = Math.max(1, parseInt(req.query.page || '1'));
  const limit = Math.min(500, Math.max(1, parseInt(req.query.limit || '100')));
  const offset = (page - 1) * limit;

  function sqlDate(d) {
    if (!d || isNaN(d.getTime())) return null;
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  try {
    const pool = await sql.connect(config);

    const depRs = await pool.request()
      .input('domain', sql.VarChar(100), domain)
      .input('from', sql.DateTime, from ? sqlDate(from) : null)
      .input('to', sql.DateTime, to ? sqlDate(to) : null)
      .query(`
        SELECT
          id,
          depositTxnId,
          userid,
          username,
          actual_amount,
          bonus_amount,
          bonus_percent,
          required_turnover,
          withdrawn_amount,
          bonusType,
          creationdate
        FROM depositbonus_every
        WHERE domainname = @domain
          AND (@from IS NULL OR creationdate >= @from)
          AND (@to IS NULL OR creationdate <= @to)
        ORDER BY creationdate DESC
        OFFSET ${offset} ROWS FETCH NEXT ${limit} ROWS ONLY
      `);

    const records = [];

    for (const d of depRs.recordset) {
      const depositAmount = Number(d.actual_amount || 0);
      const bonusAmount = Number(d.bonus_amount || 0);
      const totalAmount = Number((depositAmount + bonusAmount).toFixed(2));
      const withdrawn = Number(d.withdrawn_amount || 0);
      const required = Number(d.required_turnover || 0);

      const status = withdrawn >= totalAmount ? 'Completed' : 'In Progress';

      if (statusFilter !== 'all' && status.toLowerCase() !== statusFilter) {
        continue;
      }

      records.push({
        id: d.id,
        depositTxnId: d.depositTxnId,
        userid: d.userid,
        username: d.username,
        bonusType: String(d.bonusType || '').toUpperCase(),
        depositAmount: Number(depositAmount.toFixed(2)),
        bonusAmount: Number(bonusAmount.toFixed(2)),
        bonusPercent: Number(Number(d.bonus_percent || 0).toFixed(2)),
        totalAmount,
        requiredTurnover: Number(required.toFixed(2)),
        withdrawnAmount: Number(withdrawn.toFixed(2)),
        availableToWithdraw: Number(Math.max(0, totalAmount - withdrawn).toFixed(2)),
        status,
        createdAt: d.creationdate
      });
    }

    const countRs = await pool.request()
      .input('domain', sql.VarChar(100), domain)
      .input('from', sql.DateTime, from ? sqlDate(from) : null)
      .input('to', sql.DateTime, to ? sqlDate(to) : null)
      .query(`
        SELECT COUNT(*) AS totalRows
        FROM depositbonus_every
        WHERE domainname = @domain
          AND (@from IS NULL OR creationdate >= @from)
          AND (@to IS NULL OR creationdate <= @to)
      `);

    return res.status(200).json({
      errorCode: 0,
      domain,
      page,
      limit,
      totalRows: Number(countRs.recordset[0]?.totalRows || 0),
      returnedRows: records.length,
      filtersApplied: {
        status: statusFilter,
        from: req.query.from || null,
        to: req.query.to || null
      },
      records
    });

  } catch (err) {
    return res.status(500).json({
      errorCode: 9,
      message: 'Internal error',
      error: err.message
    });
  }
});

app.get('/domain-bonus-total-bonus', async (req, res) => {
  const domain = String(req.query.domain || '').toLowerCase();
  if (!domain) {
    return res.status(400).json({ errorCode: 1, message: 'domain required' });
  }

  const from = req.query.from ? new Date(req.query.from) : null;
  const to = req.query.to ? new Date(req.query.to) : null;

  function sqlDate(d) {
    if (!d || isNaN(d.getTime())) return null;
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  try {
    const pool = await sql.connect(config);

    const totalRs = await pool.request()
      .input('domain', sql.VarChar(100), domain)
      .input('from', sql.DateTime, from ? sqlDate(from) : null)
      .input('to', sql.DateTime, to ? sqlDate(to) : null)
      .query(`
        SELECT
          COUNT(*) AS totalBonusEntries,
          COUNT(DISTINCT userid) AS totalUsers,
          ISNULL(SUM(bonus_amount), 0) AS totalBonusAmount
        FROM depositbonus_every
        WHERE domainname = @domain
          AND (@from IS NULL OR creationdate >= @from)
          AND (@to IS NULL OR creationdate <= @to)
      `);

    const row = totalRs.recordset[0] || {};

    return res.status(200).json({
      errorCode: 0,
      domain,
      filtersApplied: {
        from: req.query.from || null,
        to: req.query.to || null
      },
      summary: {
        totalBonusEntries: Number(row.totalBonusEntries || 0),
        totalUsers: Number(row.totalUsers || 0),
        totalBonusAmount: Number(Number(row.totalBonusAmount || 0).toFixed(2))
      }
    });

  } catch (err) {
    return res.status(500).json({
      errorCode: 9,
      message: 'Internal error',
      error: err.message
    });
  }
});


// 1st depoost bonus auto ALL

async function splitTurnoverFromApinew(userId, fromDate, toDate) {
  const from = fmtSqlDateMs(fromDate);
  const to = fmtSqlDateMs(toDate);

  const url =
    `https://sp.vrnlapi.live/api/fetchUserDataCompWise?userId=${encodeURIComponent(userId)}` +
    `&from=${encodeURIComponent(from)}` +
    `&to=${encodeURIComponent(to)}`;

  try {
    const turnoverRes = await axios.get(url, {
      timeout: 10000,
      headers: {
        Accept: 'application/json',
        'User-Agent': 'Mozilla/5.0'
      }
    });

    const totals = turnoverRes?.data?.totals || [];

    let sport = 0;
    let casino = 0;
    let pslIpl = 0;

    let cricket = 0;
    let soccer = 0;

    let slot = 0;
    let table = 0;

    totals.forEach(item => {
      const api = String(item.apiName || '').toUpperCase();
      const amt = Number(item.totalTurnover || 0);

      if (api === 'EXCH' || api === 'PARLAY') {
        sport += amt;
      }

      if (api === 'AWC' || api === 'BOG') {
        casino += amt;
      }

      if (api === 'EXCH') {
        const sports = item.sportWise || [];

        sports.forEach(s => {
          const name = String(s.sportName || '').trim().toUpperCase();
          const t = Number(s.totalTurnover || 0);

          if (name === 'CRICKET') cricket += t;
          if (name === 'SOCCER') soccer += t;
        });

        const comps = item.competitionWise || [];

        comps.forEach(c => {
          const name = String(c.competitionName || '').trim();

          if (
            name === 'Pakistan Super League' ||
            name === 'Indian Premier League'
          ) {
            pslIpl += Number(c.totalTurnover || 0);
          }
        });
      }

      if (api === 'AWC' || api === 'BOG') {
        const games = item.gameTypeWise || [];

        games.forEach(g => {
          const name = String(g.gameType || '').trim().toUpperCase();
          const t = Number(g.totalTurnover || 0);

          if (name === 'SLOT') slot += t;
          if (name === 'TABLE') table += t;
        });
      }
    });

    return {
      sport: Number(sport.toFixed(2)),
      casino: Number(casino.toFixed(2)),
      pslIpl: Number(pslIpl.toFixed(2)),

      cricket: Number(cricket.toFixed(2)),
      soccer: Number(soccer.toFixed(2)),

      slot: Number(slot.toFixed(2)),
      table: Number(table.toFixed(2))
    };

  } catch (e) {
    return {
      sport: 0,
      casino: 0,
      pslIpl: 0,

      cricket: 0,
      soccer: 0,

      slot: 0,
      table: 0
    };
  }
}

app.post('/add-first-deposit-bonus-auto', async (req, res) => {
  const {
    userid,
    username,
    parentid,
    actual_amount,
    domainname,
    bonusType,
    agentRef
  } = req.body;

  if (!userid || !username || !parentid || !actual_amount || !domainname) {
    return res.status(400).json({
      errorCode: 1,
      result: [{ message: 'Missing required fields' }]
    });
  }

  const domainKey = domainname.toLowerCase();

  if (!allowedDomains1.includes(domainKey)) {
    return res.status(403).json({
      errorCode: 2,
      result: [{ message: 'Not authorized' }]
    });
  }

  const bonus_percent = domainBonusMap[domainKey] || 0;
  const invalidBonusTypes = [null, undefined, '', 'NO_BONUS', 'null', 'undefined'];

  const finalBonusType =
    invalidBonusTypes.includes(bonusType)
      ? 'NO_BONUS'
      : bonusType;

      if (finalBonusType === 'NO_BONUS') {
        const depositTxnId = generateDepositTxnId(userid);
  
        await pool.request()
          .input('depositTxnId', sql.VarChar(100), depositTxnId)
          .input('userid', sql.BigInt, userid)
          .input('username', sql.VarChar(100), username)
          .input('parentid', sql.BigInt, parentid)
          .input('domainname', sql.VarChar(100), domainKey)
          .input('amount', sql.Decimal(18,2), Number(actual_amount))
          .query(`
            INSERT INTO deposit_nobonus(depositTxnId, userid, username, parentid, domainname, amount, withdrawn_amount, createdAt)
            VALUES (@depositTxnId, @userid, @username, @parentid, @domainname, @amount, 0, GETDATE())
          `);
  
        return res.status(200).json({
          errorCode: 0,
          result: [{ success: true, bonusApplied: false, depositTxnId, message: 'NO_BONUS deposit stored' }]
        });
      }

  try {
    const pool = await sql.connect(config);

    const { recordset } = await pool.request()
      .input('userid', sql.BigInt, userid)
      .input('domainname', sql.VarChar(100), domainKey)
      .query(`
        SELECT 1 FROM depositbonus
        WHERE userid = @userid AND domainname = @domainname
      `);

    if (recordset.length > 0) {
      return res.status(200).json({
        errorCode: 3,
        result: [{ message: 'Bonus already exists for this user on this domain' }]
      });
    }

    const configRs = await pool.request()
      .input('domainname', sql.VarChar(100), domainKey)
      .query(`
        SELECT max_bonus
        FROM DomainBonusConfig
        WHERE domainname = @domainname
      `);

    const maxBonus = configRs.recordset[0]?.max_bonus || 0;

    let redeemAmount = (actual_amount * bonus_percent) / 100;

    if (maxBonus > 0 && redeemAmount > maxBonus) {
      redeemAmount = maxBonus;
    }

    const domainConfig = {
      "baaaji.win": { targetMainUserId: 4093141 },
      "baji.win": { targetMainUserId: 4093141 },
      "4six.com": { targetMainUserId: 5856890 },
    };

    const finalTargetMainUserId =
      agentRef === true
        ? domainConfig[domainKey]?.targetMainUserId
        : parentid;

    const payload = {
      password: "abcdr1245",
      txntype: 1,
      users: [{
        userId: userid,
        txnType: 1,
        amount: redeemAmount, 
        remark: "Deposit bonus",
        key: 0,
        mainUserId: finalTargetMainUserId
      }]
    };

    const axiosInstance = axios.create({ timeout: 1000 });
    let apiRes;

    try {
      apiRes = await axiosInstance.post(
        'https://777777.today/pad=81/transferSpec',
        payload
      );
    } catch (apiErr) {

      await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('username', sql.VarChar(100), username)
        .input('parentid', sql.BigInt, parentid)
        .input('domainname', sql.VarChar(100), domainKey)
        .input('api_name', sql.VarChar(100), 'transferSpec')
        .input('request_payload', sql.NVarChar(sql.MAX), JSON.stringify(payload))
        .input('response_payload', sql.NVarChar(sql.MAX), JSON.stringify(apiErr?.response?.data || {}))
        .input('error_message', sql.VarChar(500), apiErr.message)
        .query(`
          INSERT INTO transfer_error_logs
          (userid, username, parentid, domainname, api_name, request_payload, response_payload, error_message)
          VALUES
          (@userid, @username, @parentid, @domainname, @api_name, @request_payload, @response_payload, @error_message)
        `);

      return res.status(200).json({
        errorCode: 4,
        result: [{ message: 'Transfer API error', error: apiErr.message }]
      });
    }

    const transferResult =
      apiRes?.data?.result?.[0]?.result || 'FAILED';

    if (transferResult.toLowerCase() !== 'success') {

      await pool.request()
        .input('userid', sql.BigInt, userid)
        .input('username', sql.VarChar(100), username)
        .input('parentid', sql.BigInt, parentid)
        .input('domainname', sql.VarChar(100), domainKey)
        .input('api_name', sql.VarChar(100), 'transferSpec')
        .input('request_payload', sql.NVarChar(sql.MAX), JSON.stringify(payload))
        .input('response_payload', sql.NVarChar(sql.MAX), JSON.stringify(apiRes.data))
        .input('error_message', sql.VarChar(500), 'Transfer result not success')
        .query(`
          INSERT INTO transfer_error_logs
          (userid, username, parentid, domainname, api_name, request_payload, response_payload, error_message)
          VALUES
          (@userid, @username, @parentid, @domainname, @api_name, @request_payload, @response_payload, @error_message)
        `);

      return res.status(200).json({
        errorCode: 4,
        result: [{ message: 'Transfer failed', transferResult }]
      });
    }

    await pool.request()
      .input('userid', sql.BigInt, userid)
      .input('username', sql.VarChar(100), username)
      .input('parentid', sql.BigInt, parentid)
      .input('actual_amount', sql.Decimal(10, 2), actual_amount)
      .input('bonus_percent', sql.Decimal(5, 2), bonus_percent)
      .input('domainname', sql.VarChar(100), domainKey)
      .input('bonusType', sql.VarChar(50), finalBonusType)
      .input('agentRef', sql.Bit, agentRef ? 1 : 0)
      .query(`
        INSERT INTO depositbonus
        (userid, username, parentid, actual_amount, bonus_percent, domainname, bonusType, agentRef)
        VALUES
        (@userid, @username, @parentid, @actual_amount, @bonus_percent, @domainname, @bonusType, @agentRef)
      `);

    return res.status(200).json({
      errorCode: 0,
      result: [{
        success: true,
        bonus_percent,
        transferredAmount: redeemAmount, 
        maxBonusApplied: maxBonus
      }]
    });

  } catch (err) {
    return res.status(500).json({
      errorCode: 5,
      result: [{ message: 'Internal error', error: err.message }]
    });
  }
});

app.get('/check-withdraw-eligibilitynew', async (req, res) => {
  const userId = req.query.userId || req.query.userid;

  if (!userId) {
    return res.status(400).json({
      errorCode: 1,
      message: 'userId required'
    });
  }

  try {
    const pool = await sql.connect(config);

    const bonusRes = await pool.request()
      .input('userid', sql.BigInt, userId)
      .query(`
        SELECT TOP 1
          id,
          actual_amount,
          bonus_percent,
          bonusType,
          creationdate,
          balance_unlocked,
          turnover_unlocked,
          withdrawn_amount
        FROM depositbonus
        WHERE userid = @userid
        ORDER BY creationdate DESC
      `);

    if (bonusRes.recordset.length === 0) {
      return res.status(200).json({
        errorCode: 0,
        eligible: true,
        bonusType: 'NO_BONUS',
        reason: 'No bonus applied',
        maxWithdrawNow: 0,
        cards: []
      });
    }

    const bonus = bonusRes.recordset[0];

    // ================= BALANCE =================
    let balance = 0;

    try {
      const balanceRes = await axios.get(
        `https://sp.vrnlapi.live/api3/balance/${userId}`,
        { timeout: 5000 }
      );

      balance = Number(balanceRes?.data?.balance || 0);
    } catch (e) {
      return res.status(500).json({
        errorCode: 2,
        message: 'Balance API failed',
        error: e.message
      });
    }

    // ================= CALCULATIONS =================
    const depositAmount = Number(bonus.actual_amount || 0);

    const bonusAmount = Number(
      (
        depositAmount *
        Number(bonus.bonus_percent || 0) / 100
      ).toFixed(2)
    );

    const totalAmount = Number(
      (depositAmount + bonusAmount).toFixed(2)
    );

    const withdrawn = Number(
      bonus.withdrawn_amount || 0
    );

    const typeUpper = String(
      bonus.bonusType || 'SPORT'
    ).toUpperCase();

    let requiredTurnover = totalAmount;

    const isTurnoverUnlocked =
      Number(bonus.turnover_unlocked) === 1;

    const isBalanceUnlocked =
      Number(bonus.balance_unlocked) === 1;

    // ================= IF COMPLETED =================
    if (isTurnoverUnlocked) {
      const availableToWithdraw = Number(
        Math.max(0, totalAmount - withdrawn).toFixed(2)
      );

      return res.status(200).json({
        errorCode: 0,
        eligible: availableToWithdraw > 0,
        balance,
        maxWithdrawNow: Number(
          Math.min(balance, availableToWithdraw).toFixed(2)
        ),
        cards: [{
          bonusId: bonus.id,
          bonusType: typeUpper,
          title: `${bonus.bonus_percent}% 1st Deposit Bonus (${typeUpper})`,
          depositAmount,
          bonusAmount,
          amount: totalAmount,
          requiredTurnover,
          completedTurnover: requiredTurnover,
          remainingTurnover: 0,
          progressPct: 100,
          status: 'Completed',
          balanceUnlocked: isBalanceUnlocked,
          turnoverUnlocked: true,
          withdrawnAmount: withdrawn,
          availableToWithdraw,
          createdAt: bonus.creationdate
        }],
        reason: 'Turnover unlocked'
      });
    }

    // ================= BALANCE ZERO =================
    if (balance === 0 && !isBalanceUnlocked) {
      await pool.request()
        .input('id', sql.BigInt, bonus.id)
        .query(`
          UPDATE depositbonus
          SET balance_unlocked = 1
          WHERE id=@id
        `);
    }

    if (balance === 0) {
      return res.status(200).json({
        errorCode: 0,
        eligible: false,
        balance,
        maxWithdrawNow: 0,
        cards: [{
          bonusId: bonus.id,
          bonusType: typeUpper,
          title: `${bonus.bonus_percent}% 1st Deposit Bonus (${typeUpper})`,
          depositAmount,
          bonusAmount,
          amount: totalAmount,
          requiredTurnover,
          completedTurnover: 0,
          remainingTurnover: requiredTurnover,
          progressPct: 0,
          status: 'Unlocked',
          balanceUnlocked: true,
          turnoverUnlocked: false,
          withdrawnAmount: withdrawn,
          availableToWithdraw: 0,
          createdAt: bonus.creationdate
        }],
        reason: 'Balance zero (marked unlocked only)'
      });
    }

    // ================= TURNOVER API =================
    const fromDate = new Date(bonus.creationdate);
    fromDate.setDate(fromDate.getDate() - 1);

    const toDate = new Date();
    toDate.setDate(toDate.getDate() + 1);

    let live = {
      sport: 0,
      casino: 0,
      pslIpl: 0
    };

    try {
      live = await splitTurnoverFromApinew(
        userId,
        fromDate,
        toDate
      );
    } catch {}

    // ================= BONUS TYPE WISE TURNOVER =================
    let completedTurnover = 0;

    if (typeUpper === 'CASINO') {
      completedTurnover = Number(
        live.casino || 0
      );
    }
    else if (typeUpper === 'PSL_IPL') {
      completedTurnover = Number(
        live.pslIpl || 0
      );
    }
    else if (typeUpper === 'CRICKET') {
      completedTurnover = Number(live.cricket || 0);
    }
    else if (typeUpper === 'SOCCER') {
      completedTurnover = Number(live.soccer || 0);
    }
    else if (typeUpper === 'SLOT') {
      completedTurnover = Number(live.slot || 0);
    }
    else if (typeUpper === 'TABLE') {
      completedTurnover = Number(live.table || 0);
    }
    else {
      completedTurnover = Number(live.sport || 0);
    }

    completedTurnover = Number(
      completedTurnover.toFixed(2)
    );

    const isCompleted =
      completedTurnover >= requiredTurnover;

    const remainingTurnover = Number(
      Math.max(
        0,
        requiredTurnover - completedTurnover
      ).toFixed(2)
    );

    const progressPct =
      requiredTurnover > 0
        ? Number(
            (
              Math.min(
                1,
                completedTurnover / requiredTurnover
              ) * 100
            ).toFixed(2)
          )
        : 0;

    if (isCompleted) {
      await pool.request()
        .input('id', sql.BigInt, bonus.id)
        .query(`
          UPDATE depositbonus
          SET turnover_unlocked = 1
          WHERE id=@id
        `);
    }

    const availableToWithdraw = isCompleted
      ? Number(
          Math.max(
            0,
            totalAmount - withdrawn
          ).toFixed(2)
        )
      : 0;

    return res.status(200).json({
      errorCode: 0,
      eligible: availableToWithdraw > 0,
      balance,
      maxWithdrawNow: Number(
        Math.min(
          balance,
          availableToWithdraw
        ).toFixed(2)
      ),
      cards: [{
        bonusId: bonus.id,
        bonusType: typeUpper,
        title: `${bonus.bonus_percent}% 1st Deposit Bonus (${typeUpper})`,
        depositAmount,
        bonusAmount,
        amount: totalAmount,
        requiredTurnover,
        completedTurnover: Math.min(
          completedTurnover,
          requiredTurnover
        ),
        remainingTurnover,
        progressPct,
        status: isCompleted
          ? 'Completed'
          : (
              isBalanceUnlocked
                ? 'Unlocked'
                : 'In Progress'
            ),
        balanceUnlocked: isBalanceUnlocked,
        turnoverUnlocked: isCompleted,
        withdrawnAmount: withdrawn,
        availableToWithdraw,
        createdAt: bonus.creationdate
      }],
      reason: isCompleted
        ? 'Turnover unlocked'
        : 'Turnover pending'
    });

  } catch (err) {
    return res.status(500).json({
      errorCode: 9,
      message: 'Internal server error',
      error: err.message
    });
  }
});

app.get('/check-withdraw-eligibility-combinednew', async (req, res) => {
  const userId = req.query.userId || req.query.userid;

  if (!userId) {
    return res.status(400).json({
      errorCode: 1,
      message: 'userId required'
    });
  }

  try {
    const pool = await sql.connect(config);

    // BALANCE
    let balanceRes;
    try {
      balanceRes = await axios.get(
        `https://sp.vrnlapi.live/api3/balance/${userId}`,
        { timeout: 5000 }
      );
    } catch (e) {
      return res.status(500).json({
        errorCode: 2,
        message: 'Balance API failed',
        error: e.message
      });
    }

    const balance = Number(balanceRes?.data?.balance || 0);

    // WALLET
    await ensureWalletRow(pool.request(), userId);

    const wRs = await pool.request()
      .input('userid', sql.BigInt, userId)
      .query(`
        SELECT carried_turnover_sport, carried_turnover_casino,
               consumed_turnover_sport, consumed_turnover_casino
        FROM user_turnover_wallet
        WHERE userid=@userid
      `);

    const carriedSport = Number(wRs.recordset[0]?.carried_turnover_sport || 0);
    const carriedCasino = Number(wRs.recordset[0]?.carried_turnover_casino || 0);
    const consumedSport = Number(wRs.recordset[0]?.consumed_turnover_sport || 0);
    const consumedCasino = Number(wRs.recordset[0]?.consumed_turnover_casino || 0);

    // LIVE TURNOVER
    const todayStart = getMidnightStart(new Date());
    const tomorrowStart = new Date(todayStart);
    tomorrowStart.setDate(tomorrowStart.getDate() + 1);

    let live = {
      sport: 0,
      casino: 0,
      pslIpl: 0,
      cricket: 0,
      soccer: 0,
      slot: 0,
      table: 0
    };

    try {
      live = await splitTurnoverFromApinew(
        userId,
        todayStart,
        tomorrowStart
      );
    } catch {}

    const totalSportNow = Number(
      (carriedSport + (live.sport || 0)).toFixed(2)
    );

    const totalCasinoNow = Number(
      (carriedCasino + (live.casino || 0)).toFixed(2)
    );

    // NET CAP
    const netSport = Number(
      Math.max(
        0,
        totalSportNow - consumedSport
      ).toFixed(2)
    );

    const netCasino = Number(
      Math.max(
        0,
        totalCasinoNow - consumedCasino
      ).toFixed(2)
    );

    const availableNetTotal = Number(
      (netSport + netCasino).toFixed(2)
    );

    // ==================================================
    // FIRST BONUS
    // ==================================================
    const firstRs = await pool.request()
      .input('userid', sql.BigInt, userId)
      .query(`
        SELECT TOP 1
          id,
          actual_amount,
          bonus_percent,
          bonusType,
          creationdate,
          balance_unlocked,
          turnover_unlocked,
          withdrawn_amount
        FROM depositbonus
        WHERE userid=@userid
        ORDER BY creationdate DESC
      `);

    let firstAvailable = 0;
    let firstCard = null;
    let firstCompletedForOverride = true;

    if (firstRs.recordset.length > 0) {
      const b = firstRs.recordset[0];

      const bonusType = String(
        b.bonusType || 'SPORT'
      ).toUpperCase();

      const depositAmount = Number(
        b.actual_amount || 0
      );

      const bonusAmount = Number(
        (
          depositAmount *
          Number(b.bonus_percent || 0) / 100
        ).toFixed(2)
      );

      const totalAmount = Number(
        (depositAmount + bonusAmount).toFixed(2)
      );

      const withdrawn = Number(
        b.withdrawn_amount || 0
      );

      const requiredTurnover = totalAmount;

      // ===== FIXED TYPE WISE TURNOVER =====
      let completedTurnover = 0;

      if (bonusType === 'CASINO') {
        completedTurnover = Number(
          live.casino || 0
        );
      }
      else if (bonusType === 'PSL_IPL') {
        completedTurnover = Number(
          live.pslIpl || 0
        );
      }
      else if (bonusType === 'CRICKET') {
        completedTurnover = Number(
          live.cricket || 0
        );
      }
      else if (bonusType === 'SOCCER') {
        completedTurnover = Number(
          live.soccer || 0
        );
      }
      else if (bonusType === 'SLOT') {
        completedTurnover = Number(
          live.slot || 0
        );
      }
      else if (bonusType === 'TABLE') {
        completedTurnover = Number(
          live.table || 0
        );
      }
      else {
        completedTurnover = Number(
          live.sport || 0
        );
      }

      let turnoverUnlocked =
        Number(b.turnover_unlocked) === 1;

      if (
        !turnoverUnlocked &&
        completedTurnover >= requiredTurnover
      ) {
        await pool.request()
          .input('id', sql.BigInt, b.id)
          .query(`
            UPDATE depositbonus
            SET turnover_unlocked = 1
            WHERE id=@id
          `);

        turnoverUnlocked = true;
      }

      const balanceUnlocked =
        Number(b.balance_unlocked) === 1;

      const firstWithdrawable =
        turnoverUnlocked &&
        !balanceUnlocked;

      firstAvailable = firstWithdrawable
        ? Number(
            Math.max(
              0,
              totalAmount - withdrawn
            ).toFixed(2)
          )
        : 0;

      const status = turnoverUnlocked
        ? 'Completed'
        : (
            balanceUnlocked
              ? 'Unlocked'
              : 'In Progress'
          );

      firstCompletedForOverride =
        turnoverUnlocked ||
        balanceUnlocked;

      firstCard = {
        bonusId: b.id,
        bonusType,
        amount: totalAmount,
        withdrawnAmount: withdrawn,
        availableToWithdraw: firstAvailable,
        status,
        createdAt: b.creationdate
      };
    }

    // ==================================================
    // EVERY BONUS
    // ==================================================
    const depRs = await pool.request()
      .input('userid', sql.BigInt, userId)
      .query(`
        SELECT id, creationdate, required_turnover,
               actual_amount, bonus_amount, withdrawn_amount,
               bonusType, start_total_sport, start_total_casino
        FROM depositbonus_every
        WHERE userid=@userid
        ORDER BY creationdate ASC
      `);

    let everyAvailable = 0;
    let everyAllCompletedForOverride = true;

    let curSegS = null;
    let curSegC = null;

    let pools = {
      sportLeft: 0,
      casinoLeft: 0
    };

    for (const d of depRs.recordset) {
      const totalAmt = Number(
        (
          Number(d.actual_amount || 0) +
          Number(d.bonus_amount || 0)
        ).toFixed(2)
      );

      const required = Number(
        d.required_turnover || 0
      );

      const withdrawn = Number(
        d.withdrawn_amount || 0
      );

      const type = String(
        d.bonusType || 'SPORT'
      ).toUpperCase();

      const segS = Number(
        d.start_total_sport || 0
      );

      const segC = Number(
        d.start_total_casino || 0
      );

      if (curSegS === null) {
        curSegS = segS;
        curSegC = segC;

        pools = resetPoolsFromSegment(
          totalSportNow,
          totalCasinoNow,
          curSegS,
          curSegC
        );
      }
      else if (
        segS !== curSegS ||
        segC !== curSegC
      ) {
        curSegS = segS;
        curSegC = segC;

        pools = resetPoolsFromSegment(
          totalSportNow,
          totalCasinoNow,
          curSegS,
          curSegC
        );
      }

      let completedForThis = 0;

      if (required > 0) {
        const out = consumeForType(
          required,
          type,
          pools
        );

        completedForThis = out.completed;
        pools = out.pools;
      }

      const isCompleted =
        required > 0
          ? completedForThis >= required
          : true;

      if (!isCompleted) {
        everyAllCompletedForOverride = false;
        continue;
      }

      everyAvailable += Math.max(
        0,
        totalAmt - withdrawn
      );
    }

    everyAvailable = Number(
      everyAvailable.toFixed(2)
    );

    const everyCapped = Number(
      Math.min(
        everyAvailable,
        availableNetTotal
      ).toFixed(2)
    );

    const combinedProgramAvailableNormal =
      Number(
        (
          firstAvailable +
          everyCapped
        ).toFixed(2)
      );

    const maxWithdrawNowNormal =
      Number(
        Math.min(
          balance,
          combinedProgramAvailableNormal
        ).toFixed(2)
      );

    const hasAnyCards =
      firstRs.recordset.length > 0 ||
      depRs.recordset.length > 0;

    const allCompleted =
      firstCompletedForOverride &&
      everyAllCompletedForOverride;

    const maxWithdrawNow =
      hasAnyCards && allCompleted
        ? Number(balance.toFixed(2))
        : maxWithdrawNowNormal;

    const combinedProgramAvailable =
      hasAnyCards && allCompleted
        ? Number(balance.toFixed(2))
        : combinedProgramAvailableNormal;

    return res.status(200).json({
      errorCode: 0,
      eligible: maxWithdrawNow > 0,
      balance,
      wallet: {
        carriedTurnoverSport: carriedSport,
        carriedTurnoverCasino: carriedCasino,
        todayLiveTurnoverSport: Number(
          (live.sport || 0).toFixed(2)
        ),
        todayLiveTurnoverCasino: Number(
          (live.casino || 0).toFixed(2)
        ),
        totalSportNow,
        totalCasinoNow,
        consumedTurnoverSport: consumedSport,
        consumedTurnoverCasino: consumedCasino,
        netSport,
        netCasino,
        availableNetTotal
      },
      firstAvailable,
      everyAvailable,
      everyCapped,
      combinedProgramAvailable,
      maxWithdrawNow,
      overrideFullBalance:
        hasAnyCards && allCompleted,
      firstCard
    });

  } catch (err) {
    return res.status(500).json({
      errorCode: 9,
      message: 'Internal server error',
      error: err.message
    });
  }
});

app.post('/withdraw-accept-update-combinednew', async (req, res) => {
  const { userid, withdrawTxnId, acceptedAmount } = req.body;

  if (!userid || !withdrawTxnId || !acceptedAmount) {
    return res.status(400).json({ errorCode: 1, result: [{ message: 'Missing required fields' }] });
  }

  const amt = Number(acceptedAmount);
  if (!Number.isFinite(amt) || amt <= 0) {
    return res.status(400).json({ errorCode: 2, result: [{ message: 'acceptedAmount must be > 0' }] });
  }

  const pool = await sql.connect(config);
  const tx = new sql.Transaction(pool);

  try {
    await tx.begin(sql.ISOLATION_LEVEL.SERIALIZABLE);

    // BALANCE CAP
    let balanceRes;
    try {
      balanceRes = await axios.get(`https://sp.vrnlapi.live/api3/balance/${userid}`, { timeout: 5000 });
    } catch (e) {
      await tx.rollback();
      return res.status(500).json({ errorCode: 2, result: [{ message: 'Balance API failed', error: e.message }] });
    }
    const balance = Number(balanceRes?.data?.balance || 0);

    if (amt > balance) {
      await tx.rollback();
      return res.status(200).json({ errorCode: 4, result: [{ message: 'Withdraw > balance', balance }] });
    }

    // IDEMPOTENT
    const already = await new sql.Request(tx)
      .input('withdrawTxnId', sql.VarChar(100), withdrawTxnId)
      .query(`SELECT 1 FROM withdraw_accept_logs WITH (UPDLOCK, HOLDLOCK) WHERE withdrawTxnId=@withdrawTxnId`);

    if (already.recordset.length > 0) {
      await tx.rollback();
      return res.status(200).json({ errorCode: 0, result: [{ success: true, idempotent: true }] });
    }

    // WALLET
    await ensureWalletRow(new sql.Request(tx), userid);

    const wRs = await new sql.Request(tx)
      .input('userid', sql.BigInt, userid)
      .query(`
        SELECT carried_turnover_sport, carried_turnover_casino,
               consumed_turnover_sport, consumed_turnover_casino
        FROM user_turnover_wallet WITH (UPDLOCK, HOLDLOCK)
        WHERE userid=@userid
      `);

    const carriedSport = Number(wRs.recordset[0]?.carried_turnover_sport || 0);
    const carriedCasino = Number(wRs.recordset[0]?.carried_turnover_casino || 0);
    const consumedSport = Number(wRs.recordset[0]?.consumed_turnover_sport || 0);
    const consumedCasino = Number(wRs.recordset[0]?.consumed_turnover_casino || 0);

    // LIVE TURNOVER
    const todayStart = getMidnightStart(new Date());
    const tomorrowStart = new Date(todayStart);
    tomorrowStart.setDate(tomorrowStart.getDate() + 1);

    let live = { sport: 0, casino: 0 };
    try {
      live = await splitTurnoverFromApinew(userid, todayStart, tomorrowStart);
    } catch (e) {
      console.log('WITHDRAW LIVE ERROR =>', e.message);
    }

    const totalSportNow = Number((carriedSport + (live.sport || 0)).toFixed(2));
    const totalCasinoNow = Number((carriedCasino + (live.casino || 0)).toFixed(2));

    const netSport = Number(Math.max(0, totalSportNow - consumedSport).toFixed(2));
    const netCasino = Number(Math.max(0, totalCasinoNow - consumedCasino).toFixed(2));
    const availableNetTotal = Number((netSport + netCasino).toFixed(2));

    // LOAD FIRST (LOCKED)
    const firstRs = await new sql.Request(tx)
      .input('userid', sql.BigInt, userid)
      .query(`
        SELECT TOP 1
          id, actual_amount, bonus_percent, bonusType,
          balance_unlocked, turnover_unlocked, withdrawn_amount
        FROM depositbonus WITH (UPDLOCK, HOLDLOCK)
        WHERE userid=@userid
        ORDER BY creationdate DESC
      `);

    // LOAD EVERY (LOCKED)
    const depRs = await new sql.Request(tx)
      .input('userid', sql.BigInt, userid)
      .query(`
        SELECT id, creationdate, bonusType, required_turnover,
               actual_amount, bonus_amount, withdrawn_amount,
               start_total_sport, start_total_casino
        FROM depositbonus_every WITH (UPDLOCK, HOLDLOCK)
        WHERE userid=@userid
        ORDER BY creationdate ASC
      `);

    const hasFirst = firstRs.recordset.length > 0;
    const hasEvery = depRs.recordset.length > 0;

    // ALL COMPLETED CHECK
    let firstCompleted = true;
    if (hasFirst) {
      const b = firstRs.recordset[0];
      const turnoverUnlocked = (Number(b.turnover_unlocked) === 1);
      const balanceUnlocked = (Number(b.balance_unlocked) === 1);
      firstCompleted = turnoverUnlocked || balanceUnlocked;
    }

    let everyAllCompleted = true;
    if (hasEvery) {
      let curSegS = null;
      let curSegC = null;
      let pools = { sportLeft: 0, casinoLeft: 0 };

      for (const d of depRs.recordset) {
        const segS = Number(d.start_total_sport || 0);
        const segC = Number(d.start_total_casino || 0);

        if (curSegS === null) {
          curSegS = segS;
          curSegC = segC;
          pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
        } else if (segS !== curSegS || segC !== curSegC) {
          curSegS = segS;
          curSegC = segC;
          pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
        }

        const type = String(d.bonusType || '').toUpperCase() || 'SPORT';
        const required = Number(d.required_turnover || 0);

        let completedForThis = 0;
        if (required > 0) {
          const out = consumeForType(required, type, pools);
          completedForThis = out.completed;
          pools = out.pools;
        }

        const isCompleted = required > 0 ? (completedForThis >= required) : true;
        if (!isCompleted) {
          everyAllCompleted = false;
          break;
        }
      }
    }

    const hasAny = hasFirst || hasEvery;
    const allCardsCompleted = hasAny && firstCompleted && everyAllCompleted;

    console.log('WITHDRAW ALL COMPLETED DEBUG =>', {
      userid,
      hasFirst,
      hasEvery,
      firstCompleted,
      everyAllCompleted,
      hasAny,
      allCardsCompleted,
      amt,
      balance,
      totalSportNow,
      totalCasinoNow,
      netSport,
      netCasino,
      availableNetTotal
    });

    // NORMAL DEDUCT FLOW
    let remaining = amt;
    let sportDeduct = 0;
    let casinoDeduct = 0;

    // A) FIRST DEDUCT
    if (hasFirst && remaining > 0) {
      const b = firstRs.recordset[0];
    
      const bonusType = String(b.bonusType || '').toUpperCase();
    
      let completedTurnover = 0;
    
      if (bonusType === 'CASINO') {
        completedTurnover = Number(live.casino || 0);
      }
      else if (bonusType === 'PSL_IPL') {
        completedTurnover = Number(live.pslIpl || 0);
      }
      else if (typeUpper === 'CRICKET') {
        completedTurnover = Number(live.cricket || 0);
      }
      else if (typeUpper === 'SOCCER') {
        completedTurnover = Number(live.soccer || 0);
      }
      else if (typeUpper === 'SLOT') {
        completedTurnover = Number(live.slot || 0);
      }
      else if (typeUpper === 'TABLE') {
        completedTurnover = Number(live.table || 0);
      }
      else {
        completedTurnover = Number(live.sport || 0);
      }
    
      const depositAmount = Number(b.actual_amount || 0);
    
      const bonusAmount = Number(
        ((depositAmount * Number(b.bonus_percent || 0)) / 100).toFixed(2)
      );
    
      const totalAmount = Number(
        (depositAmount + bonusAmount).toFixed(2)
      );
    
      const requiredTurnover = totalAmount;
    
      const balanceUnlocked =
        Number(b.balance_unlocked) === 1;
    
      const turnoverUnlocked =
        Number(b.turnover_unlocked) === 1 ||
        completedTurnover >= requiredTurnover;
    
      const firstWithdrawable =
        turnoverUnlocked &&
        !balanceUnlocked;
    
      if (firstWithdrawable) {
        const withdrawn =
          Number(b.withdrawn_amount || 0);
    
        const available = Math.max(
          0,
          totalAmount - withdrawn
        );
    
        const use = Math.min(
          available,
          remaining
        );
    
        if (use > 0) {
          await new sql.Request(tx)
            .input('id', sql.BigInt, b.id)
            .input('useAmt', sql.Decimal(18, 2), use)
            .query(`
              UPDATE depositbonus
              SET withdrawn_amount = withdrawn_amount + @useAmt,
                  turnover_unlocked = 1
              WHERE id=@id
            `);
    
          if (bonusType === 'CASINO') {
            casinoDeduct += use;
          } else {
            sportDeduct += use;
          }
    
          remaining -= use;
        }
      }
    }

    // B) EVERY DEDUCT
    if (remaining > 0) {
      if (!allCardsCompleted && remaining > availableNetTotal) {
        await tx.rollback();
        return res.status(200).json({
          errorCode: 4,
          result: [{ message: 'Every-part withdraw > net turnover cap', availableNetTotal, remaining }]
        });
      }

      let curSegS = null;
      let curSegC = null;
      let pools = { sportLeft: 0, casinoLeft: 0 };

      for (const d of depRs.recordset) {
        if (remaining <= 0) break;

        const segS = Number(d.start_total_sport || 0);
        const segC = Number(d.start_total_casino || 0);

        if (curSegS === null) {
          curSegS = segS;
          curSegC = segC;
          pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
        } else if (segS !== curSegS || segC !== curSegC) {
          curSegS = segS;
          curSegC = segC;
          pools = resetPoolsFromSegment(totalSportNow, totalCasinoNow, curSegS, curSegC);
        }

        const type = String(d.bonusType || '').toUpperCase() || 'SPORT';
        const required = Number(d.required_turnover || 0);

        let completedForThis = 0;
        if (required > 0) {
          const out = consumeForType(required, type, pools);
          completedForThis = out.completed;
          pools = out.pools;
        }

        const isCompleted = required > 0 ? (completedForThis >= required) : true;
        if (!isCompleted) continue;

        const totalAmount = Number(d.actual_amount || 0) + Number(d.bonus_amount || 0);
        const alreadyW = Number(d.withdrawn_amount || 0);
        const canUse = Math.max(0, totalAmount - alreadyW);
        if (canUse <= 0) continue;

        const use = Math.min(canUse, remaining);

        await new sql.Request(tx)
          .input('id', sql.BigInt, d.id)
          .input('useAmt', sql.Decimal(18, 2), use)
          .query(`
            UPDATE depositbonus_every
            SET withdrawn_amount = withdrawn_amount + @useAmt
            WHERE id=@id
          `);

        if (type === 'CASINO') casinoDeduct += use;
        else sportDeduct += use;

        remaining -= use;
      }
    }

    // If all cards completed, allow extra balance too
    let finalSportDeduct = sportDeduct;
    let finalCasinoDeduct = casinoDeduct;

    if (remaining > 0 && allCardsCompleted) {
      const extraSport = Math.min(remaining, Math.max(0, netSport - sportDeduct));
      finalSportDeduct = Number((finalSportDeduct + extraSport).toFixed(2));
      remaining = Number((remaining - extraSport).toFixed(2));

      const extraCasino = Math.min(remaining, Math.max(0, netCasino - casinoDeduct));
      finalCasinoDeduct = Number((finalCasinoDeduct + extraCasino).toFixed(2));
      remaining = Number((remaining - extraCasino).toFixed(2));
    }

    if (remaining > 0 && !allCardsCompleted) {
      await tx.rollback();
      return res.status(200).json({
        errorCode: 4,
        result: [{ message: 'Withdraw > unlocked (first + completed every). Reject.', remaining }]
      });
    }

    // LOG
    await new sql.Request(tx)
      .input('withdrawTxnId', sql.VarChar(100), withdrawTxnId)
      .input('userid', sql.BigInt, userid)
      .input('amt', sql.Decimal(18, 2), amt)
      .query(`
        INSERT INTO withdraw_accept_logs(withdrawTxnId, userid, accepted_amount)
        VALUES (@withdrawTxnId, @userid, @amt)
      `);

    // WALLET CONSUMED UPDATE
    await new sql.Request(tx)
      .input('userid', sql.BigInt, userid)
      .input('sAmt', sql.Decimal(18, 2), finalSportDeduct)
      .input('cAmt', sql.Decimal(18, 2), finalCasinoDeduct)
      .query(`
        UPDATE user_turnover_wallet
        SET consumed_turnover_sport  = consumed_turnover_sport + @sAmt,
            consumed_turnover_casino = consumed_turnover_casino + @cAmt,
            updated_at = GETDATE()
        WHERE userid=@userid
      `);

    await tx.commit();

    return res.status(200).json({
      errorCode: 0,
      result: [{
        success: true,
        deducted: amt,
        mode: allCardsCompleted ? 'ALL_COMPLETED_FULL_BALANCE' : 'NORMAL',
        sportDeduct: Number(finalSportDeduct.toFixed(2)),
        casinoDeduct: Number(finalCasinoDeduct.toFixed(2))
      }]
    });

  } catch (err) {
    try { await tx.rollback(); } catch {}
    return res.status(500).json({
      errorCode: 9,
      result: [{ message: 'Internal error', error: err.message }]
    });
  }
});

// ======================================================
// UPDATE DOMAIN BONUS SETTINGS (DOMAINWISE)
// ======================================================


app.post('/save-domain-bonus-config', async (req, res) => {
  try {

    const {
      domainname,

      every_casino_bonus_percent,
      every_casino_multiplier,

      every_sport_bonus_percent,
      every_sport_multiplier,

      every_all_multiplier,

      first_deposit_bonus_percent,
      first_deposit_multiplier,

      every_deposit_bonus_percent,
      every_deposit_multiplier
    } = req.body;

    if (!domainname) {
      return res.status(400).json({
        errorCode: 1,
        message: 'domainname required'
      });
    }

    const domainKey = String(domainname).toLowerCase().trim();

    const pool = await sql.connect(config);

    // CHECK DOMAIN EXISTS
    const checkRs = await pool.request()
      .input('domainname', sql.VarChar(100), domainKey)
      .query(`
        SELECT id
        FROM DomainBonusConfig
        WHERE domainname=@domainname
      `);

    const isUpdate = checkRs.recordset.length > 0;

    // ======================================================
    // UPDATE
    // ======================================================
    if (isUpdate) {

      await pool.request()

        .input('domainname', sql.VarChar(100), domainKey)

        .input(
          'every_casino_bonus_percent',
          sql.Decimal(10,2),
          every_casino_bonus_percent ?? null
        )

        .input(
          'every_casino_multiplier',
          sql.Decimal(10,2),
          every_casino_multiplier ?? null
        )

        .input(
          'every_sport_bonus_percent',
          sql.Decimal(10,2),
          every_sport_bonus_percent ?? null
        )

        .input(
          'every_sport_multiplier',
          sql.Decimal(10,2),
          every_sport_multiplier ?? null
        )

        .input(
          'every_all_multiplier',
          sql.Decimal(10,2),
          every_all_multiplier ?? null
        )

        .input(
          'first_deposit_bonus_percent',
          sql.Decimal(10,2),
          first_deposit_bonus_percent ?? null
        )

        .input(
          'first_deposit_multiplier',
          sql.Decimal(10,2),
          first_deposit_multiplier ?? null
        )

        .input(
          'every_deposit_bonus_percent',
          sql.Decimal(10,2),
          every_deposit_bonus_percent ?? null
        )

        .input(
          'every_deposit_multiplier',
          sql.Decimal(10,2),
          every_deposit_multiplier ?? null
        )

        .query(`
          UPDATE DomainBonusConfig
          SET

            every_casino_bonus_percent =
              COALESCE(@every_casino_bonus_percent, every_casino_bonus_percent),

            every_casino_multiplier =
              COALESCE(@every_casino_multiplier, every_casino_multiplier),

            every_sport_bonus_percent =
              COALESCE(@every_sport_bonus_percent, every_sport_bonus_percent),

            every_sport_multiplier =
              COALESCE(@every_sport_multiplier, every_sport_multiplier),

            every_all_multiplier =
              COALESCE(@every_all_multiplier, every_all_multiplier),

            first_deposit_bonus_percent =
              COALESCE(@first_deposit_bonus_percent, first_deposit_bonus_percent),

            first_deposit_multiplier =
              COALESCE(@first_deposit_multiplier, first_deposit_multiplier),

            every_deposit_bonus_percent =
              COALESCE(@every_deposit_bonus_percent, every_deposit_bonus_percent),

            every_deposit_multiplier =
              COALESCE(@every_deposit_multiplier, every_deposit_multiplier)

          WHERE domainname=@domainname
        `);

    } else {

      // ======================================================
      // INSERT
      // ======================================================

      await pool.request()

        .input('domainname', sql.VarChar(100), domainKey)

        .input(
          'every_casino_bonus_percent',
          sql.Decimal(10,2),
          Number(every_casino_bonus_percent || 0)
        )

        .input(
          'every_casino_multiplier',
          sql.Decimal(10,2),
          Number(every_casino_multiplier || 1)
        )

        .input(
          'every_sport_bonus_percent',
          sql.Decimal(10,2),
          Number(every_sport_bonus_percent || 0)
        )

        .input(
          'every_sport_multiplier',
          sql.Decimal(10,2),
          Number(every_sport_multiplier || 1)
        )

        .input(
          'every_all_multiplier',
          sql.Decimal(10,2),
          Number(every_all_multiplier || 1)
        )

        .input(
          'first_deposit_bonus_percent',
          sql.Decimal(10,2),
          Number(first_deposit_bonus_percent || 0)
        )

        .input(
          'first_deposit_multiplier',
          sql.Decimal(10,2),
          Number(first_deposit_multiplier || 1)
        )

        .input(
          'every_deposit_bonus_percent',
          sql.Decimal(10,2),
          Number(every_deposit_bonus_percent || 0)
        )

        .input(
          'every_deposit_multiplier',
          sql.Decimal(10,2),
          Number(every_deposit_multiplier || 1)
        )

        .query(`
        INSERT INTO DomainBonusConfig
        (
          domainname,
      
          casino_bonus_percent,
          casino_multiplier,
      
          sport_bonus_percent,
          sport_multiplier,
      
          min_deposit,
          max_bonus,
          isActive,
      
          every_casino_bonus_percent,
          every_casino_multiplier,
      
          every_sport_bonus_percent,
          every_sport_multiplier,
      
          every_all_multiplier,
      
          first_deposit_bonus_percent,
          first_deposit_multiplier,
      
          every_deposit_bonus_percent,
          every_deposit_multiplier,
      
          created_at
        )
        VALUES
        (
          @domainname,
      
          0,
          1,
      
          0,
          1,
      
          0,
          0,
          1,
      
          @every_casino_bonus_percent,
          @every_casino_multiplier,
      
          @every_sport_bonus_percent,
          @every_sport_multiplier,
      
          @every_all_multiplier,
      
          @first_deposit_bonus_percent,
          @first_deposit_multiplier,
      
          @every_deposit_bonus_percent,
          @every_deposit_multiplier,
      
          GETDATE()
        )
      `)
    }

    // ======================================================
    // RETURN DATA
    // ======================================================

    const finalRs = await pool.request()
      .input('domainname', sql.VarChar(100), domainKey)
      .query(`
        SELECT
          domainname,

          every_casino_bonus_percent,
          every_casino_multiplier,

          every_sport_bonus_percent,
          every_sport_multiplier,

          every_all_multiplier,

          first_deposit_bonus_percent,
          first_deposit_multiplier,

          every_deposit_bonus_percent,
          every_deposit_multiplier

        FROM DomainBonusConfig
        WHERE domainname=@domainname
      `);

    return res.status(200).json({
      errorCode: 0,
      message: isUpdate
        ? 'Domain bonus config updated successfully'
        : 'New domain bonus config added successfully',

      result: finalRs.recordset[0]
    });

  } catch (err) {

    return res.status(500).json({
      errorCode: 9,
      message: 'Internal server error',
      error: err.message
    });

  }
});

app.get('/get-domain-bonus-config-b2c', async (req, res) => {

  try {

    const pool = await sql.connect(config);

    const rs = await pool.request().query(`
      SELECT
        domainname,

        every_casino_bonus_percent,
        every_casino_multiplier,

        every_sport_bonus_percent,
        every_sport_multiplier,

        every_all_multiplier,

        first_deposit_bonus_percent,
        first_deposit_multiplier,

        every_deposit_bonus_percent,
        every_deposit_multiplier

      FROM DomainBonusConfig
      ORDER BY domainname ASC
    `);

    return res.status(200).json({
      errorCode: 0,
      total: rs.recordset.length,
      result: rs.recordset
    });

  } catch (err) {

    return res.status(500).json({
      errorCode: 9,
      message: 'Internal server error',
      error: err.message
    });

  }

});


app.delete('/delete-domain-bonus-config', async (req, res) => {

  try {

    const { domainname } = req.body;

    if (!domainname) {
      return res.status(400).json({
        errorCode: 1,
        message: 'domainname required'
      });
    }

    const domainKey = String(domainname).toLowerCase().trim();

    const pool = await sql.connect(config);

    // CHECK EXISTS
    const checkRs = await pool.request()
      .input('domainname', sql.VarChar(100), domainKey)
      .query(`
        SELECT id
        FROM DomainBonusConfig
        WHERE domainname=@domainname
      `);

    if (checkRs.recordset.length === 0) {
      return res.status(404).json({
        errorCode: 2,
        message: 'Domain config not found'
      });
    }

    // DELETE
    await pool.request()
      .input('domainname', sql.VarChar(100), domainKey)
      .query(`
        DELETE FROM DomainBonusConfig
        WHERE domainname=@domainname
      `);

    return res.status(200).json({
      errorCode: 0,
      success: true,
      message: 'Domain bonus config deleted successfully',
      deletedDomain: domainKey
    });

  } catch (err) {

    return res.status(500).json({
      errorCode: 9,
      message: 'Internal server error',
      error: err.message
    });

  }

});

process.on('SIGINT', () => {
    console.log('Server shutting down...');
    sql.close();
    process.exit(0);
});

// Start the server
server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

