
var express = require('express')();
var https = require('https');
var axios = require('axios');
var fs = require('fs');

var ssl_domain = require("./ssl/ssl_domain");

const { json } = require('express');

const redis = require('redis');
const redisPort = 6379;
const client = redis.createClient(redisPort);


var app = https.createServer(ssl_domain.options, express);

app.addContext('api1.streamingtv.fun', ssl_domain.options1);
app.addContext('api2.streamingtv.fun', ssl_domain.options2);
app.addContext('api3.streamingtv.fun', ssl_domain.options3);
app.addContext('access.vrnl.net', ssl_domain.options4);
app.addContext('access.streamtv247.fun', ssl_domain.options5);
app.addContext('api3.streamtv247.fun', ssl_domain.options6);
app.addContext('api.bfoddsapi.in', ssl_domain.options7);
app.addContext('access.vrnlapi.live', ssl_domain.options8);
app.addContext('api3.vrnlapi.live', ssl_domain.options9);

var _ = require('lodash');

var cors = require('cors')

express.use(cors());
express.get('/', function (req, res) {
    res.send('Hello world');
});

let TimerIntevalFancy = 0;
let TimerIntevalListGames = 0;
let storeMatches = [];
let eventTypeId = 4;

function startIntevalFancy() {
    if (TimerIntevalFancy) {
        clearInterval(TimerInteval);
    }
    if (TimerIntevalListGames) {
        clearInterval(TimerIntevalListGames);
    }
    getFancyEventList(eventTypeId);

    TimerIntevalFancy = setInterval(() => {
        // for all matches
        let eventIdss = [];
        storeMatches.forEach(element => {
            eventIdss.push(element.gameId);
        });
        eventIdss = eventIdss.join(',');
        if (eventIdss) {
            getFancyDataAll(eventIdss, eventTypeId);
        }
        // for all matches

        // storeMatches.forEach(element => {
        //     getFancyData(element.gameId);
        // });
    }, 1000);

    TimerIntevalListGames = setInterval(() => {
        getFancyEventList(eventTypeId);
    }, 10000);
}
// startIntevalFancy();

function getFancyEventList(eventTypeId) {

    let config = {
        method: 'get',
        maxBodyLength: Infinity,
        url: 'https://streamingtv.fun:3447/api/highlights/' + eventTypeId,
        headers: {}
    };

    axios.request(config)
        .then((response) => {
            if (response.data) {
                storeMatches = response.data.data;

                // for all matches
                let eventIdss = [];
                storeMatches.forEach(element => {
                    eventIdss.push(element.gameId);
                });
                eventIdss = eventIdss.join(',');
                if (eventIdss) {
                    getFancyDataAll(eventIdss, eventTypeId);
                }
                // for all matches

                // storeMatches.forEach(element => {
                //     getFancyData(element.gameId);
                // });
            }
            // console.log(JSON.stringify(response.data));
        })
        .catch((error) => {
            console.log(error);
        });

}




function getFancyDataAll(eventIds, eventTypeId) {

    let config = {
        method: 'get',
        url: 'https://streamingtv.fun:3447/api/bm_fancy_multi/' + eventIds,
        headers: {}
    };

    axios.request(config)
        .then((response) => {
            if (response.data) {
                var keys = Object.keys(response.data);
                // console.log(keys)
                keys.forEach((gameId) => {
                    // console.log(gameId)
                    content = JSON.stringify(response.data[gameId]);
                    // console.log(content)
                    client.set('store_markets' + gameId, content);
                });

            }
        })
        .catch((error) => {
            console.log(error)
            if (error.code === 'ECONNABORTED') {
                console.log('Request timed out');
            } else {
                console.log(error.message);
            }
        });

}



app.listen(3472, function () {
    console.log('listening on *:3472');
});

