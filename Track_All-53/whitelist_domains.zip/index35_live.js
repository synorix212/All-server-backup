var express = require('express')();
var https = require('https');
var axios = require('axios');
var fs = require('fs');
var _ = require('lodash');
var cors = require('cors')

var ssl_domain = require("./ssl/ssl_domain");
var whitelist_domain = require("./whitelist_domains/domains");

const { json } = require('express');

const redis = require('redis');
const redisPort = 6379;
const client = redis.createClient(redisPort);
let app = https.createServer(ssl_domain.options, express);

app.addContext('api1.streamingtv.fun', ssl_domain.options1);
app.addContext('api2.streamingtv.fun', ssl_domain.options2);
app.addContext('api3.streamingtv.fun', ssl_domain.options3);


express.use(cors());
express.get('/', function (req, res) {
    res.send('VRNL.NET');
});

let hostNames = [
    "betpro.bet",
    "bsf444.net",
    "nice7777.fun",
    "nice9999.fun",
    "nice0000.fun",
    "nice5555.fun",
    "nice24.fun",
    "nice1010.fun",
    "nicebihar.fun",
    "sky7777.fun",
    "goodbet7777.fun",
    "nicess.fun",
    "bsfbet7777.com",
    "bsfbet7777.net",
    "nice8888.fun",
    "mywbt999.com",
    "bsf999.in",
    "bsf444.net",
    "baaji365.site",
    "velkii365.live",
    "vellkiex123.live",
    "velki.bet",
    "cloudexch.in",
    "bwinbd.com",
    "lc247.vip",
    "lc247.click",
    "6wickets.live",
    "velkiex123.biz",
    "lc247.live",
    "lc247.bet",
    "lc247.xyz",
    "lcbuzz.bet",
    "9ex365.bet",
    "bajimat.win",
    "bajimat.site",
    "baaji7.com",
    "betbuzz365.fun",
    "diamond4.live",
    "lcexch.in",
    "9wiicket.win",
    "velkiex.live",
    "maza247.bet",
    "jeesky7.com",
    "mash247.live",
    "betskyexch.com",
    "betwinners.live",
    "cricbuzzer.io",
    "velkii.co",
    "lc247.co",
    "baaji365.org",
    "vellki365.live",
    "xpgexch.com",
    "xpgexch.io",
    "winplus99.com",
    "winplus247.com",
    "sky-exch.com",
    "cricexch.xyz",
    "betx365.asia",
    "runexch.co",
    "neyaludis.live",
    "velkiex123.bet",
    "1wicket.vip",
    "4wickets.com",
    "3wickets.bet",
    "skyexch.win",
    "bett365.live",
    "sports365.pro",
    "runexch.live",
    "betbuzz369.live",
    "baaji24.live",
    "maza246.live",
    "magic365.live",
    "winbet365.win",
    "betswiz.in",
    "betfair365.bet",
    "playbet365.live",
    "dreamcric247.com",
    "fiarsky.com",
    "baajii365.live",
    "six6r.com",
    "10sports.bet",
    "bwin365.site",
    "bazi9.live",
    "mpk.live",
    "velkibaji.live",
    "bdbaji365.live",
    "jmdexchange.in",
    "betgame247.live",
    "9wicketbd.com",
    "citybett.com",
    "velkiex365.com",
    "agun365.win",
    "playbdt.live",
    "betguru.win",
    "kingxchange.com",
    "9wicketbdt.com",
    "velkiex123.win",
    "betx123.live",
    "24xbets.com",
    "velkiex.com",
    "sat-sport.live",
    "vellkiex123.com",
    "velkie247.live",
    "maza246.live",
    "betbuzz247.bet",
    "winbdt.bet",
    "velki365.pro",
    "masti247.live",
    "betx365.in",
];
let hostNames2 = [
];
let hostNames3 = [
];

function getCallerIP(request) {
    var ip = request.headers['x-forwarded-for'] ||
        request.connection.remoteAddress ||
        request.socket.remoteAddress ||
        request.connection.socket.remoteAddress;
    ip = ip.split(',')[0];
    ip = ip.split(':').slice(-1); //in case the ip returned in a format: "::ffff:146.xxx.xxx.xxx"
    return ip;
}

function getDomainName(hostName) {
    if (!hostName) {
        return;
    }
    let formatedHost = "";
    let splithostName = hostName.split('.');
    if (splithostName.length > 2) {
        formatedHost = hostName.substring(hostName.lastIndexOf(".", hostName.lastIndexOf(".") - 1) + 1);
    } else {
        formatedHost = hostName.split('//')[1]
    }
    return formatedHost;
}

let token;
let TimerInteval;
let TimerInteval2;


function startInteval() {
    if (TimerInteval) {
        clearInterval(TimerInteval);
    }
    if (TimerInteval2) {
        clearInterval(TimerInteval2);
    }

    getstreaminfo();
    TimerInteval = setInterval(getstreaminfo, 20000);
    TimerInteval2 = setInterval(getlistGames, 20000);

    // get_access_token();

    // TimerInteval = setInterval(get_access_token, 900000);

    // TimerInteval2 = setInterval(getlistGames, 600000);

}
startInteval();



function get_access_token() {
    var axios = require('axios');
    var data = JSON.stringify({
        "agentcode": "laserbook247",
        "secretkey": "e779a4142f87679a4a2e4fafe6de5f9809389c7b4e2d9a869b2d2b60786db11f"
    });

    var config = {
        method: 'post',
        url: 'https://bfrates.com/api/get_access_token',
        headers: {
            'Content-Type': 'application/json',
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            if (response.data) {
                token = response.data.token;
                getlistGames();

            }
        })
        .catch(function (error) {
            console.log(error);
        });

}
function get_scoreurl_by_centralid(match) {
    var axios = require('axios');
    var data = JSON.stringify({
        "access_token": token,
        "match_id": match.eventId,
        "domain_name": "ss247.com"
    });

    var config = {
        method: 'post',
        url: 'https://bfrates.com/api/get_scoreurl_by_centralid',
        headers: {
            'Content-Type': 'application/json',
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            if (response.data) {
                if (response.data.data) {
                    if (response.data.data.streamingUrl) {
                        // response.data.data.streamingUrl="https://555555.services/live_tv/index.html?eventId="+match.eventId
                        // console.log(response.data.data.streamingUrl);
                        content = JSON.stringify(response.data.data);

                        client.set('tvstream_' + match.eventId, content);
                    }
                }
            }
            // console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
            console.log(error);
        });

}

function getstreaminfo() {
    var config = {
        method: 'get',
        url: 'https://ss247.life/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/streaminfo.php',
    };
    axios(config)
        .then(function (response) {
            if (response.data.data) {
                response.data.data.getMatches.forEach((match, index) => {

                    let tvData = {
                        "scoreUrl": "",
                        "NowPlaying": match.NowPlaying == 1 ? true : false,
                        "streamingUrl": "https://ss247.life/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/Nstreamapi.php?chid=" + match.Channel + "&ip="
                    };
                    if (match.MatchID < 0) {
                        let gameId = -(match.MatchID);
                        match.MatchID = '17' + gameId;
                    }
                    content = JSON.stringify(tvData);
                    client.set('tvstream_' + match.MatchID, content);

                    // if (match.Type != "CRICKET" && match.IsLive == 1) {
                    if (match.IsLive == 1) {
                        let url = "https://access.vrnlapi.live/VRN/v1/api/LiveTv/post";

                        let tvDatas = {
                            "channelIp": "",
                            "channelNo": "",
                            "hdmi": "",
                            "link": "",
                            "matchId": "",
                            "program": "p1",
                            "type": 6,
                            "SportId": 0
                        };
                        var lastDigit = index.toString().slice(-1);
                        let tvdomain = [
                              
                               
                             
                               "rajbet.win"]
                        // console.log(lastDigit,match.MatchID)
                        tvDatas.link = "https://www." + tvdomain[lastDigit] + "/livetv/index.html?eventId=" + match.MatchID;
                        // tvDatas.link = "https://runx.bet/livetv/index.html?eventId=" + match.MatchID;

                        tvDatas.link2 = tvDatas.link;
                        // console.log(tvDatas.link)
                        tvDatas.matchId = match.MatchID;
                        tvDatas.SportId = 1;
                        // tvDatas.channelNo = data.streamingChannel;
                        tvDatas.type = 6;
                        SaveLiveTv(tvDatas, url);
                    }



                });
            }

        })
        .catch(function (error) {
            // console.log(error);
        });
}

function getlistGames() {

    var config = {
        method: 'get',
        // url: 'https://121212.digital/pad=82/listGames',
        // url: 'https://444444.club/pad=82/listGames',
        url: "https://555555.today/pad=82/listAllGames",


    };
    axios(config)
        .then(function (response) {
            // console.log(response)
            if (response.data.result.length > 0) {
                response.data.result.forEach((match, index) => {
                    // console.log(match.eventId)
                    getScoreId(match.eventId);
                    getLiveTv(match.eventId);
                });
            }

        })
        .catch(function (error) {
            console.log(error);
        });

}

function getScoreId(eventId) {

    var config = {
        method: 'get',
        url: 'https://access.vrnlapi.live/VRN/v1/api/scoreid/get?eventid=' + eventId,
    };
    axios(config)
        .then(function (response) {
            // console.log(response.data);

            if (response.data.result.length > 0) {
                content = JSON.stringify(response.data.result[0]);
                client.set('scoreAvailbale_' + eventId, content);
            }




        })
        .catch(function (error) {
            console.log(error);
        });

}

function getLiveTv(eventId) {

    var config = {
        method: 'get',
        url: 'https://access.vrnlapi.live/VRN/v1/api/livetv/get?matchid=' + eventId,
    };
    axios(config)
        .then(function (response) {

            if (response.data.result.length > 0) {
                content = JSON.stringify(response.data.result[0]);
                client.set('tvAvailbale_' + eventId, content);
            }

        })
        .catch(function (error) {
            console.log(error);
        });

}

function SaveLiveTv(data, url) {

    // console.log(JSON.stringify(data))
    var config = {
        method: 'post',
        data: JSON.stringify(data),
        headers: {
            'Content-Type': 'application/json'
        },
        // url: url,
        url: "https://access.vrnlapi.live/VRN/v1/api/LiveTv/post"
    };
    axios(config)
        .then(function (response) {

            // console.log(response.data)


        })
        .catch(function (error) {
            console.log(error);
        });


    // $.ajax({
    //   url: url,
    //   method: 'POST',
    //   data: JSON.stringify(data),
    //   headers: {
    //     'content-type': 'application/json'
    //   },
    //   success: function (data) {
    //     console.log(data)
    //   },
    //   error: function (err) {
    //     console.log(err)
    //   }
    // });
}


express.get('/api/get_live_tv_url/:eventId', function (req, res) {
    var clientIp = getCallerIP(req);
    let scoreTvData = {
        "scoreUrl": "",
        "NowPlaying": false,
        "streamingUrl": ""
    };
    client.get('scoreAvailbale_' + req.params.eventId, (err, scoreData) => {
        if (scoreData) {
            scoreData = JSON.parse(scoreData);
            scoreTvData.scoreUrl = 'https://www.satsports.net/score_widget/index.html?id=' + scoreData.score_id + '&aC=bGFzZXJib29rMjQ3';
        } else {

        }
        client.get('tvAvailbale_' + req.params.eventId, (err, tvData) => {
            if (tvData) {
                tvData = JSON.parse(tvData);
                scoreTvData.NowPlaying = true;
                scoreTvData.streamingUrl = "https://streamingtv.fun/live_tv/index.html?eventId=" + req.params.eventId;
            }

            if (hostNames2.indexOf(getDomainName(req.get('origin'))) > -1) {
                if (tvData) {
                    scoreTvData.NowPlaying = true;
                    scoreTvData.streamingUrl = "https://sportbet.id/live_tv/index.html?eventId=" + req.params.eventId;
                }
                // let tvData = {
                //   "scoreUrl": "",
                //   "streamingUrl": "https:///yorkerclub.xyz/live_tv/index.html?eventId=" + req.params.eventId
                // };
                res.send(scoreTvData);
            }
            else if (hostNames3.indexOf(getDomainName(req.get('origin'))) > -1) {
                if (tvData) {
                    scoreTvData.NowPlaying = true;
                    scoreTvData.streamingUrl = "https://sportbet.id/live_tv/index.html?eventId=" + req.params.eventId;
                }
                // let tvData = {
                //   "scoreUrl": "",
                //   "streamingUrl": "https://sportbet.id/live_tv/index.html?eventId=" + req.params.eventId
                // };
                res.send(scoreTvData);
            }
            else if (hostNames.indexOf(getDomainName(req.get('origin'))) == -1) {
                if (tvData) {
                    scoreTvData.NowPlaying = true;
                    scoreTvData.streamingUrl = "https://streamingtv.fun/live_tv/index.html?eventId=" + req.params.eventId;
                }
                // let tvData = {
                //   "scoreUrl": "",
                //   "streamingUrl": "https://access.streamingtv.fun/live_tv/index.html?eventId=" + req.params.eventId
                // };
                res.send(scoreTvData);


            }
            else {
                client.get('tvstream_' + req.params.eventId, (err, data) => {
                    // console.log(data)
                    if (data) {
                        data = JSON.parse(data);
                        scoreTvData.NowPlaying = data.NowPlaying;
                        scoreTvData.streamingUrl = data.streamingUrl + clientIp[0];
                        if (getDomainName(req.get('origin')) == 'betgame.live' || getDomainName(req.get('origin')) == 'lc247.live') {
                            // scoreTvData.streamingUrl = "https://www.lc247.live/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653_staging/?eventId=" + req.params.eventId;
                            scoreTvData.streamingUrl = "https://www.lc247.live/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/?eventId=" + req.params.eventId;
                        }
                        // scoreTvData.streamingUrl = "https://www.lc247.live/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653_staging/?eventId="+ req.params.eventId;

                        // data.streamingUrl = data.streamingUrl + clientIp[0];
                    } else {
                        // scoreTvData.streamingUrl = null;
                    }
                    res.send(scoreTvData);

                })
            }
        })
    })


});

express.get('/api/get_live_tv_score_url/:eventId', function (req, res) {
    var clientIp = getCallerIP(req);
    // console.log(clientIp[0])
    let scoreTvData = {
        "scoreUrl": "",
        "streamingUrl": ""
    };
    client.get('scoreAvailbale_' + req.params.eventId, (err, scoreData) => {
        if (scoreData) {
            scoreData = JSON.parse(scoreData);
            scoreTvData.scoreUrl = 'https://www.satsports.net/score_widget/index.html?id=' + scoreData.score_id + '&aC=bGFzZXJib29rMjQ3';
        } else {

        }

        client.get('tvstream_' + req.params.eventId, (err, data) => {
            // console.log(data)
            if (data) {
                data = JSON.parse(data);
                scoreTvData.streamingUrl = data.streamingUrl + clientIp[0];
                // data.streamingUrl = data.streamingUrl + clientIp[0];
            }
            res.send(scoreTvData);

        })
    })


});


app.listen(3475, function () {
    console.log('listening on *:3475');
});

