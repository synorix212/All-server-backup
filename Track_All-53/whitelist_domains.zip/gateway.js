const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const qr = require('qrcode');
const crypto = require('crypto');
const speakeasy = require('speakeasy');
const sql = require('mssql')
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const nodemailer = require('nodemailer');
const redis = require('redis');
const redisClient = redis.createClient();
const TelegramBot = require('node-telegram-bot-api');
const cron = require('node-cron');
const admin = require("firebase-admin");
const serviceAccount = require("./serviceAccountKey.json");

const app = express();
app.use(cors());
const PORT = process.env.PORT || 3480;

const ssl_domain = require("./ssl/ssl_domain");
const server = https.createServer(ssl_domain.options, app);
server.addContext('api1.streamingtv.fun', ssl_domain.options1);
server.addContext('api2.streamingtv.fun', ssl_domain.options2);
server.addContext('api3.streamingtv.fun', ssl_domain.options3);
server.addContext('access.vrnl.net', ssl_domain.options4);
server.addContext('access.streamtv247.fun', ssl_domain.options5);
server.addContext('api3.streamtv247.fun', ssl_domain.options6);
server.addContext('api.bfoddsapi.in', ssl_domain.options7);
server.addContext('access.vrnlapi.live', ssl_domain.options8);
server.addContext('api3.vrnlapi.live', ssl_domain.options9);
server.addContext('api2.vrnlapi.live', ssl_domain.options10);


// callback start
app.post('/api/payment-Gateway-history/', (req, res) => {
    const { approved_on, rejected_on, trn_date, trn_desc, trn_id, trn_type, status, coins, ref_no, payment_method, uid, parentId, username, type, isAgentStatus, UpiDetails, isDW, currencyCode, remark, orderId, domain, penalty, actual_coins, responseProvider, responseCoder } = req.body;
    const request = new sql.Request();
    request.input('approved_on', sql.VarChar, approved_on);
    request.input('coins', sql.VarChar, coins.toString());
    request.input('payment_method', sql.VarChar, payment_method);
    request.input('ref_no', sql.VarChar, ref_no);
    request.input('rejected_on', sql.VarChar, rejected_on);
    request.input('status', sql.Int, status);
    request.input('trn_date', sql.VarChar, trn_date);
    request.input('trn_desc', sql.VarChar, trn_desc);
    request.input('trn_id', sql.VarChar, trn_id);
    request.input('trn_type', sql.VarChar, trn_type);
    request.input('uid', sql.VarChar, uid);
    request.input('parentId', sql.VarChar, parentId);
    request.input('username', sql.VarChar, username);
    request.input('type', sql.VarChar, type);
    request.input('isAgentStatus', sql.TinyInt, isAgentStatus);
    request.input('isDW', sql.VarChar, isDW);
    request.input('currencyCode', sql.VarChar, currencyCode);
    request.input('UpiDetails', sql.NVarChar, UpiDetails);
    request.input('remark', sql.VarChar, remark);
    request.input('orderId', sql.VarChar, orderId);
    request.input('domain', sql.VarChar, domain);
    request.input('penalty', sql.VarChar, penalty);
    request.input('actual_coins', sql.VarChar, actual_coins?.toString());
    request.input('responseProvider', sql.NVarChar, responseProvider);
    request.input('responseCoder', sql.NVarChar, responseCoder);


    request.query(`
        IF EXISTS (SELECT 1 FROM ReportGateway WHERE orderId = @orderId)
        BEGIN
            UPDATE ReportGateway
            SET 
                approved_on = @approved_on,
                coins = @coins,
                payment_method = @payment_method,
                rejected_on = @rejected_on,
                status = @status,
                trn_date = @trn_date,
                trn_desc = @trn_desc,
                trn_id = @trn_id,
                trn_type = @trn_type,
                uid = @uid,
                parentId = @parentId,
                username = @username,
                type = @type,
                isAgentStatus = @isAgentStatus,
                UpiDetails = @UpiDetails,
                isDW = @isDW,
                currencyCode = @currencyCode,
                remark = @remark,
                domain = @domain,
                penalty = @penalty,
                actual_coins = @actual_coins,
                responseProvider = @responseProvider,
                responseCoder = @responseCoder,
                ref_no = @ref_no
            WHERE orderId = @orderId
        END
        ELSE
        BEGIN
            INSERT INTO ReportGateway (approved_on ,coins ,payment_method ,ref_no ,rejected_on,status , trn_date ,trn_desc , trn_id , trn_type, uid ,parentId ,username , type , isAgentStatus , UpiDetails , isDW ,currencyCode, remark ,orderId , domain , penalty , actual_coins ,responseProvider , responseCoder) 
            VALUES (@approved_on ,@coins ,@payment_method ,@ref_no ,@rejected_on,@status , @trn_date ,@trn_desc , @trn_id , @trn_type, @uid ,@parentId ,@username, @type , @isAgentStatus , @UpiDetails , @isDW , @currencyCode , @remark , @orderId , @domain , @penalty ,@actual_coins , @responseProvider , @responseCoder)
        END
    `)
        .then(result => {
            console.log('History Log Updated successfully:', result);
            res.status(200).json({ errorCode: 0, errorDescription: null, message: 'History Log Updated successfully' });
        })
        .catch(error => {
            console.error('Error inserting History:', error);
            res.status(500).json({ errorCode: 1, errorDescription: null, error: 'Error inserting History' });
        });
});
app.get('/api/getClientPaymentReport/', async (req, res) => {
    const { uid, status, type, from, to } = req.query;
    if (!uid || !status || !type || !from || !to) {
        return res.status(400).json({
            status: "Error",
            errorDescription: 'All query parameters are required',
            data: []
        });
    }
    try {
        const fromDate = new Date(from);
        const toDate = new Date(to);

        if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime())) {
            return res.status(400).json({
                status: "Error",
                errorDescription: 'Invalid date format',
                data: []
            });
        }

        // console.log(`Fetching records from ${fromDate.toISOString()} to ${toDate.toISOString()}`);

        await sql.connect(config);
        if (status == '5') {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE uid = ${uid}
                AND type = ${type}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        } else {
            // Filter by status if status is not 5
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE uid = ${uid}
                AND status = ${status}
                AND type = ${type}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        }
        // console.log(result);
        if (result.recordset.length === 0) {
            res.status(200).json({
                status: "Success",
                data: []
            });
        } else {
            res.status(200).json({
                status: "Success",
                data: result.recordset
            });
        }

    } catch (err) {
        console.error('Error fetching client payment report:', err);
        res.status(500).json({
            status: "Error",
            errorDescription: err.message,
            data: []
        });
    }
});
app.get('/api/getalltrnrequest/', async (req, res) => {
    const { uid, status, type, from, to, domain } = req.query;
    if (!uid || !status || !type || !from || !to || !domain) {
        return res.status(400).json({
            status: "Error",
            errorDescription: 'All query parameters are required',
            data: []
        });
    }

    try {
        const fromDate = new Date(from);
        const toDate = new Date(to);

        if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime())) {
            return res.status(400).json({
                status: "Error",
                errorDescription: 'Invalid date format',
                data: []
            });
        }

        await sql.connect(config);

        let result;

        // 🔁 specific check first
        if (uid === '0' && type === '0') {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE domain = ${domain}
                AND status = ${status}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        } else if (uid === '0') {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE domain = ${domain}
                AND type = ${type}
                AND status = ${status}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        } else if (status === '5') {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE parentId = ${uid}
                AND type = ${type}
                AND domain = ${domain}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        } else if (type === '0') {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE parentId = ${uid}
                AND status = ${status}
                AND domain = ${domain}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        } else {
            result = await sql.query`
                SELECT * FROM ReportGateway
                WHERE parentId = ${uid}
                AND status = ${status}
                AND domain = ${domain}
                AND type = ${type}
                AND trn_date BETWEEN ${fromDate.toISOString()} AND ${toDate.toISOString()}
            `;
        }

        res.status(200).json({
            status: "Success",
            data: result.recordset || []
        });

    } catch (err) {
        console.error('Error fetching client payment report:', err);
        res.status(500).json({
            status: "Error",
            errorDescription: err.message,
            data: []
        });
    }
});
app.post('/api/deposit-Gateway/create-payment', async (req, res) => {
    try {
        const {
            currency,
            amount,
            actual_amount,
            buttons,
            payment_system,
            custom_transaction_id,
            custom_user_id,
            return_url,
            language,
            isPendingCheck,
            data,
            domain
        } = req.body;
        if (
            !currency ||
            !amount ||
            !actual_amount ||
            !buttons ||
            !payment_system ||
            !custom_transaction_id ||
            !return_url ||
            !language ||
            !domain ||
            !data
        ) {
            return res.status(201).json({ message: "All fields are required" });
        }

        if (!custom_transaction_id || custom_transaction_id.split("-").length !== 3) {
            return res.status(400).json({ message: "Invalid custom_transaction_id format" });
        }

        const parts = custom_transaction_id.split("-");
        const uid = parts[1];
        if (isPendingCheck === 1) {
            const pendingCheckRequest = new sql.Request();
            pendingCheckRequest.input('uid', sql.VarChar, uid);
            const result = await pendingCheckRequest.query(`
                SELECT TOP 1 * FROM ReportGateway 
                WHERE uid = @uid AND status = 0 AND trn_type = 'Deposit'
            `);
            if (result.recordset.length > 0) {
                return res.status(201).json({ message: "Previous Deposit Request Is Pending..." });
            }
        }
        const payload = {
            currency,
            amount,
            buttons,
            payment_system,
            custom_transaction_id,
            custom_user_id,
            return_url,
            language,
            data
        };

        const response = await axios.post('https://pay-crm.com/Remotes/create-payment-page', payload, {
            headers: {
                'Content-Type': 'application/json',
                'apikey': 'ef22332fe042f0fcaecdaa500e542be8'
            }
        });

        const externalResp = response.data;
        const logPayload = {
            approved_on: null,
            rejected_on: null,
            trn_date: new Date().toISOString(),
            trn_desc: 'Deposit',
            trn_id: null,
            trn_type: 'Deposit',
            ref_no: 'DW-' + Date.now(),
            isAgentStatus: 10,
            status: 0,
            coins: amount.toString(),
            actual_coins: actual_amount.toString(),
            orderId: externalResp?.order_id,
            payment_method: payment_system?.[0],
            isDW: parts[0],
            uid: parts[1],
            parentId: parts[2],
            username: custom_user_id,
            currencyCode: currency,
            domain: domain,
            type: "1"
        };

        // ⏳ Wait for log to complete
        await new Promise((resolve) => {
            depositToLogs((resp) => {
                console.log("Deposit log response:", resp);
                resolve();
            }, logPayload);
        });

        return res.status(200).json(externalResp);

    } catch (error) {
        console.error("❌ Error:", error.message);
        return res.status(error?.response?.status || 500).json({
            message: 'Failed to initiate payment',
            error: error?.response?.data || error.message
        });
    }
});
app.post('/api/withdrawal-Gateway/create-withdrawal', async (req, res) => {
    try {
        const {
            amount,
            actual_amount,
            currency,
            payment_system,
            custom_transaction_id,
            custom_user_id,
            isPendingCheck,
            data,
            domain,
            penalty,
        } = req.body;

        if (
            !amount ||
            !actual_amount ||
            !currency ||
            !payment_system ||
            !custom_transaction_id ||
            !custom_user_id ||
            penalty == undefined ||
            !data) {
            return res.status(400).json({ message: "All fields are required" });
        }
        if (!custom_transaction_id || custom_transaction_id.split("-").length !== 3) {
            return res.status(400).json({ message: "Invalid custom_transaction_id format" });
        }
        const parts = custom_transaction_id.split("-");
        const uid = parts[1];
        if (isPendingCheck === 1) {
            const pendingCheckRequest = new sql.Request();
            pendingCheckRequest.input('uid', sql.VarChar, uid);
            const result = await pendingCheckRequest.query(`
                SELECT TOP 1 * FROM ReportGateway 
                WHERE uid = @uid AND status = 0 AND trn_type = 'withdrawal'
            `);
            if (result.recordset.length > 0) {
                return res.status(201).json({ message: "Previous withdrawal Request Is Pending..." });
            }
        }
        const logPayload = {
            approved_on: null,
            rejected_on: null,
            orderId: null,
            trn_date: new Date().toISOString(),
            trn_desc: 'withdrawal',
            trn_id: null,
            trn_type: 'withdrawal',
            isAgentStatus: 0,
            status: 0,
            coins: amount.toString(),
            actual_coins: actual_amount.toString(),
            ref_no: 'DW-' + Date.now(),
            payment_method: payment_system,
            isDW: parts[0],
            uid: parts[1],
            parentId: parts[2],
            username: custom_user_id,
            currencyCode: currency,
            penalty: penalty.toString(),
            type: "2",
            domain: domain,
            UpiDetails: JSON.stringify({
                account_number: data?.account_number || '',
                payment_system: payment_system || '',
                currency: currency || ''
            })
        };

        // console.log(logPayload);

        await new Promise((resolve) => {
            depositToLogs((resp) => {
                // console.log("Withdrawal log response:", resp);
                resolve();
            }, logPayload);
        });

        res.status(200).json({ errorCode: 0, errorDescription: null, result: "Withrawal Submit Successfully" });
    } catch (error) {
        res.status(201).json({ errorCode: 1, errorDescription: error.message, result: "Error" });
    }
});
app.post('/api/deposit-callback-test/', async (req, res) => {
    if (req.body && Array.isArray(req.body.transactions)) {
        const results = [];

        for (const txn of req.body.transactions) {
            try {
                const parts = txn.custom_transaction_id.split("-");
                if (parts.length !== 3) {
                    throw new Error("Invalid custom_transaction_id format");
                }

                // console.log(parts);
                const isDW = parts[0];
                const user_id = parts[1];
                const parentId = parts[2];
                const username = txn.custom_user_id;
                const status = txn.status;
                const currencyCode = txn.currency;
                const trn_id = txn.transaction_id;
                const transaction_amount = txn.amount.toString();
                const orderId = txn.order_id;
                const payment_method = txn.payment_system;
                const approved_on = status === "Success" ? new Date().toISOString() : null;
                const rejected_on = status === "Failed" ? new Date().toISOString() : null;
                const trn_date = new Date().toISOString();

                const existingTransaction = await sql.query`
                    SELECT * FROM ReportGateway WHERE orderId = ${orderId}
                `;

                // console.log(existingTransaction);


                if (existingTransaction.recordset.length > 0) {
                    let depositLog = {
                        ref_no: existingTransaction.recordset[0]?.ref_no,
                        approved_on,
                        coins: transaction_amount,
                        payment_method,
                        orderId: orderId,
                        rejected_on,
                        status,
                        isAgentStatus: 10,
                        trn_date,
                        trn_desc: "Deposit",
                        trn_id,
                        trn_type: "Deposit",
                        uid: user_id,
                        parentId,
                        currencyCode,
                        isDW,
                        username,
                        type: "1",
                        domain: existingTransaction.recordset[0]?.domain,

                    };
                    console.log(depositLog, "depositLog");
                    if (status === 'Success' && existingTransaction.recordset[0]?.status === 0) {
                        depositLog.status = 1;
                        let depositReq = {
                            password: "abcdr1245",
                            txntype: 1,
                            users: [
                                {
                                    userId: user_id,
                                    txnType: 1,
                                    amount: transaction_amount,
                                    remark: "Payment-Gateway-Testing",
                                    key: 0,
                                    mainUserId: isDW === "1" ? parentId : 5117212
                                }
                            ]
                        };
                        console.log(depositReq, "depositReq");
                        await new Promise((resolve) => {
                            depositAmount((resp) => {
                                console.log(resp, "resp or success");
                                if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                                    depositToLogs((respLog) => {
                                        if (respLog.errorCode === 0) {
                                            results.push({ user_id, message: "Payment successful", code: 0 });
                                        } else {
                                            results.push({ user_id, message: "Failed to log deposit", code: 1, error: respLog });
                                        }
                                        resolve();
                                    }, depositLog);
                                } else {
                                    results.push({ user_id, message: "Payment failed", code: 1, error: resp.result?.[0] || resp });
                                    resolve();
                                }
                            }, depositReq);
                        });

                    } else {
                        depositLog.status = 2;
                        await new Promise((resolve) => {
                            depositToLogs((respLog) => {
                                if (respLog.status === "Success") {
                                    results.push({ user_id, message: "Transaction failed", code: 1 });
                                } else {
                                    results.push({ user_id, message: "Failed to log failed deposit", code: 1, error: respLog });
                                }
                                resolve();
                            }, depositLog);
                        });
                    }
                } else {
                    results.push({ user_id, message: "Transaction already completed", code: 0 });
                }
            } catch (err) {
                console.error("❌ Error parsing transaction:", err);
                results.push({ error: "Exception", details: err.message });
            }
        }
        return res.status(200).send({ status: "OK" });
    }
    return res.status(400).send({ error: "Invalid payload or no transactions found" });
});
app.post('/api/deposit-callback/', async (req, res) => {
    if (req.body && Array.isArray(req.body.transactions)) {
        const results = [];

        for (const txn of req.body.transactions) {
            try {
                const parts = txn.custom_transaction_id.split("-");
                if (parts.length !== 3) {
                    throw new Error("Invalid custom_transaction_id format");
                }

                // console.log(parts);
                const isDW = parts[0];
                const user_id = parts[1];
                const parentId = parts[2];
                const username = txn.custom_user_id;
                const status = txn.status;
                const currencyCode = txn.currency;
                const trn_id = txn.transaction_id;
                const transaction_amount = txn.amount.toString();
                const orderId = txn.order_id;
                const payment_method = txn.payment_system;
                const approved_on = status === "Success" ? new Date().toISOString() : null;
                const rejected_on = status === "Failed" ? new Date().toISOString() : null;
                const trn_date = new Date().toISOString();

                const existingTransaction = await sql.query`
                    SELECT * FROM ReportGateway WHERE orderId = ${orderId}
                `;

                // console.log(existingTransaction);


                if (existingTransaction.recordset.length > 0) {
                    let depositLog = {
                        ref_no: existingTransaction.recordset[0]?.ref_no,
                        approved_on,
                        coins: transaction_amount,
                        actual_coins: transaction_amount,
                        payment_method,
                        orderId: orderId,
                        rejected_on,
                        status,
                        isAgentStatus: 10,
                        trn_date,
                        trn_desc: "Deposit",
                        trn_id,
                        trn_type: "Deposit",
                        uid: user_id,
                        parentId,
                        currencyCode,
                        isDW,
                        username,
                        type: "1",
                        domain: existingTransaction.recordset[0]?.domain,
                        responseProvider: JSON.stringify(req.body),
                    };
                    console.log(depositLog, "depositLog");

                    if (status === 'Success' && existingTransaction.recordset[0]?.status === 0) {
                        depositLog.status = 1;
                        let depositReq = {
                            password: "abcdr1245",
                            txntype: 1,
                            users: [
                                {
                                    userId: user_id,
                                    txnType: 1,
                                    amount: transaction_amount,
                                    remark: "Payment-Gateway",
                                    key: 0,
                                    mainUserId: isDW === "1" ? parentId : 5117212
                                }
                            ]
                        };
                        console.log(depositReq, "depositReq");
                        await new Promise((resolve) => {
                            depositAmount((resp) => {
                                console.log(resp, "resp or success");
                                if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                                    depositToLogs((respLog) => {
                                        if (respLog.errorCode === 0) {
                                            results.push({ user_id, message: "Payment successful", code: 0 });
                                        } else {
                                            results.push({ user_id, message: "Failed to log deposit", code: 1, error: respLog });
                                        }
                                        resolve();
                                    }, depositLog);
                                } else {
                                    results.push({ user_id, message: "Payment failed", code: 1, error: resp.result?.[0] || resp });
                                    resolve();
                                }
                            }, depositReq);
                        });

                    } else {
                        depositLog.status = 2;
                        await new Promise((resolve) => {
                            depositToLogs((respLog) => {
                                if (respLog.status === "Success") {
                                    results.push({ user_id, message: "Transaction failed", code: 1 });
                                } else {
                                    results.push({ user_id, message: "Failed to log failed deposit", code: 1, error: respLog });
                                }
                                resolve();
                            }, depositLog);
                        });
                    }
                } else {
                    results.push({ user_id, message: "Transaction already completed", code: 0 });
                }
            } catch (err) {
                console.error("❌ Error parsing transaction:", err);
                results.push({ error: "Exception", details: err.message });
            }
        }
        return res.status(200).send({ status: "OK" });
    }
    return res.status(400).send({ error: "Invalid payload or no transactions found" });
});
app.post('/api/trasaction/SettleTrasaction', async (req, res) => {
    try {
        const {
            amount,
            currency,
            payment_system,
            custom_transaction_id,
            custom_user_id,
            ref_no,
            isAgentStatus,
            remark,
            penalty,
            data,
        } = req.body;
        if (
            !amount ||
            !currency ||
            !payment_system ||
            !custom_transaction_id ||
            !custom_user_id ||
            !ref_no ||
            penalty == undefined ||
            !isAgentStatus ||
            !data
        ) {
            return res.status(201).json({ message: "All fields are required" });
        }
        if (!custom_transaction_id || custom_transaction_id.split("-").length !== 3) {
            return res.status(400).json({ message: "Invalid custom_transaction_id format" });
        }
        const parts = custom_transaction_id.split("-");
        const isDW = parts[0];

        const originalAmount = parseFloat(amount);
        const penaltyFloat = parseFloat(penalty);
        const penaltyAmount = Math.round(originalAmount * (penaltyFloat / 100));
        const finalAmount = originalAmount - penaltyAmount;


        const payload = {
            amount: finalAmount,
            currency,
            payment_system,
            custom_transaction_id,
            custom_user_id,
            data
        };
        console.log(payload, "payload");
        if (isAgentStatus === 1) {
            let callbackResp;
            try {
                const callback = await axios.post(
                    'https://pay-crm.com/Remotes/create-withdrawal?project_id=5234239',
                    payload,
                    {
                        headers: {
                            'Content-Type': 'application/json',
                            'apikey': 'ef22332fe042f0fcaecdaa500e542be8'
                        }
                    }
                );
                callbackResp = callback.data;
                console.log(callbackResp, "callbackResp");
            } catch (error) {
                console.error("Callback API failed:", error.response?.data);
                return res.status(201).json({
                    errorCode: 1,
                    errorDescription: null,
                    result: error.response?.data.message
                });
            }
            if (callbackResp?.success && callbackResp?.status === "Pending") {
                const withdrawReq = {
                    password: "abcdr1245",
                    txntype: 2,
                    users: [
                        {
                            userId: parts[1],
                            txnType: 2,
                            amount: amount,
                            remark: "Payment-Gateway",
                            key: 0,
                            mainUserId: isDW === "1" ? parts[2] : 5117212
                        }
                    ]
                };
                console.log(callbackResp);
                console.log("✅ Callback successful. Proceeding with withdraw:", withdrawReq);
                let depositResp = null;
                await new Promise((resolve, reject) => {
                    depositAmount((resp) => {
                        depositResp = resp;
                        resolve();
                    }, withdrawReq);
                });
                if (depositResp?.errorCode === 0 && depositResp.result?.[0]?.result === "SUCCESS") {
                    const updateRequest = new sql.Request();
                    updateRequest.input('ref_no', sql.VarChar, ref_no);
                    updateRequest.input('remark', sql.VarChar, remark);
                    updateRequest.input('orderId', sql.VarChar, callbackResp.order_id);
                    updateRequest.input('coins', sql.VarChar, finalAmount.toString());
                    updateRequest.input('penalty', sql.VarChar, penaltyAmount.toString());

                    await updateRequest.query(`
                        UPDATE ReportGateway SET isAgentStatus = 1, orderId = @orderId,remark = @remark,  coins = @coins,penalty = @penalty, approved_on = GETDATE() WHERE ref_no = @ref_no
                    `);
                    return res.status(200).json({
                        errorCode: 0,
                        errorDescription: null,
                        result: "Transaction Settled Successfully"
                    });
                } else {
                    return res.status(201).json({
                        errorCode: 1,
                        errorDescription: "Deposit failed or insufficient funds",
                        result: depositResp?.result?.[0]?.result
                    });
                }
            } else {
                return res.status(400).json({
                    errorCode: 2,
                    errorDescription: "Callback response invalid",
                    callbackResponse: callbackResp
                });
            }
        }
        if (isAgentStatus === 2) {
            const updateRequest = new sql.Request();
            updateRequest.input('ref_no', sql.VarChar, ref_no);
            updateRequest.input('remark', sql.VarChar, remark);
            updateRequest.input('coins', sql.VarChar, finalAmount.toString());
            updateRequest.input('penalty', sql.VarChar, penaltyAmount.toString());

            await updateRequest.query(`
            UPDATE ReportGateway 
            SET isAgentStatus = 2, status = 2, remark = @remark,  coins = @coins, penalty = @penalty, approved_on = GETDATE() 
            WHERE ref_no = @ref_no
        `);
            return res.status(200).json({
                errorCode: 0,
                errorDescription: null,
                result: "Withdrawal Rejected Successfully"
            });
        }

    } catch (error) {
        console.error("❌ Error in /Settle:", error.message);
        return res.status(error?.response?.status || 500).json({
            message: 'Failed to initiate Withdrawal',
            error: error?.response?.data || error.message
        });
    }
});
app.post('/api/withdrawal-callback-test/', async (req, res) => {
    console.log(req.body, "withdrawal callback");

    if (!req.body || !Array.isArray(req.body.transactions)) {
        return res.status(400).send({ error: "Invalid payload or no transactions found" });
    }

    const results = [];

    for (const txn of req.body.transactions) {
        try {
            const parts = txn.custom_transaction_id?.split("-") || [];
            if (parts.length !== 3) {
                throw new Error("Invalid custom_transaction_id format");
            }

            const isDW = parts[0];
            const user_id = parts[1];
            const parentId = parts[2];
            const username = txn.custom_user_id;
            const currencyCode = txn.currency;
            const status = txn.status;
            const trn_id = txn.transaction_id;
            const transaction_amount = txn.amount.toString();
            const orderId = txn.order_id;
            const payment_method = txn.payment_system;
            const approved_on = status === "Success" ? new Date().toISOString() : null;
            const rejected_on = status === "Failed" ? new Date().toISOString() : null;
            const trn_date = new Date().toISOString();

            const existingTransaction = await sql.query`
                SELECT * FROM ReportGateway WHERE orderId = ${orderId}
            `;

            if (existingTransaction.recordset.length > 0) {
                let withdrawalLog = {
                    ref_no: existingTransaction.recordset[0]?.ref_no,
                    approved_on,
                    coins: transaction_amount,
                    payment_method,
                    isAgentStatus: existingTransaction.recordset[0]?.isAgentStatus,
                    orderId,
                    rejected_on,
                    status: status === "Success" ? 1 : 2,
                    trn_date,
                    trn_desc: "withdrawal",
                    trn_id,
                    trn_type: "withdrawal",
                    currencyCode,
                    uid: user_id,
                    UpiDetails: existingTransaction.recordset[0]?.UpiDetails,
                    remark: existingTransaction.recordset[0]?.remark,
                    parentId,
                    isDW,
                    username,
                    type: "2"
                };

                if (status === 'Success') {
                    await new Promise((resolve) => {
                        depositToLogs((respLog) => {
                            if (respLog.errorCode === 0) {
                                results.push({ user_id, message: "Payment successful", code: 0 });
                            } else {
                                results.push({ user_id, message: "Failed to log withdrawal", code: 1, error: respLog });
                            }
                            resolve();
                        }, withdrawalLog);
                    });
                }

                else if (status === 'Failed') {
                    const withdrawalReq = {
                        password: "abcdr1245",
                        txntype: 1,
                        users: [
                            {
                                userId: user_id,
                                txnType: 1,
                                amount: transaction_amount,
                                remark: "Payment-Gateway-Testing",
                                key: 0,
                                mainUserId: isDW === "1" && parentId ? parentId : 5117212
                            }
                        ]
                    };

                    await new Promise((resolve) => {
                        depositAmount((resp) => {
                            if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                                depositToLogs((respLog) => {
                                    if (respLog.errorCode === 0) {
                                        results.push({ user_id, message: "Reversed successfully", code: 0 });
                                    } else {
                                        results.push({ user_id, message: "Reverse success but log failed", code: 1, error: respLog });
                                    }
                                    resolve();
                                }, withdrawalLog);
                            } else {
                                results.push({ user_id, message: "Payment failed", code: 1, error: resp.result?.[0] || resp });
                                resolve();
                            }
                        }, withdrawalReq);
                    });
                }
            } else {
                results.push({ user_id, message: "Transaction already processed or not found in ReportGateway", code: 0 });
            }

        } catch (err) {
            console.error("❌ Error in transaction:", err.message);
            results.push({
                user_id: txn?.custom_user_id || 'unknown',
                message: "Exception occurred",
                code: 1,
                error: err.message
            });
        }
    }

    return res.status(200).send({ status: "OK", results });
});
app.post('/api/withdrawal-callback/', async (req, res) => {
    console.log(req.body, "withdrawal callback");

    if (!req.body || !Array.isArray(req.body.transactions)) {
        return res.status(400).send({ error: "Invalid payload or no transactions found" });
    }

    const results = [];

    for (const txn of req.body.transactions) {
        try {
            const parts = txn.custom_transaction_id?.split("-") || [];
            if (parts.length !== 3) {
                throw new Error("Invalid custom_transaction_id format");
            }

            const isDW = parts[0];
            const user_id = parts[1];
            const parentId = parts[2];
            const username = txn.custom_user_id;
            const currencyCode = txn.currency;
            const status = txn.status;
            const trn_id = txn.transaction_id;
            const transaction_amount = txn.amount.toString();
            const orderId = txn.order_id;
            const payment_method = txn.payment_system;
            const approved_on = status === "Success" ? new Date().toISOString() : null;
            const rejected_on = status === "Failed" ? new Date().toISOString() : null;
            const trn_date = new Date().toISOString();

            const existingTransaction = await sql.query`
                SELECT * FROM ReportGateway WHERE orderId = ${orderId}
            `;

            if (existingTransaction.recordset.length > 0) {
                let withdrawalLog = {
                    ref_no: existingTransaction.recordset[0]?.ref_no,
                    approved_on,
                    coins: transaction_amount,
                    actual_coins: existingTransaction.recordset[0]?.actual_coins,
                    payment_method,
                    isAgentStatus: existingTransaction.recordset[0]?.isAgentStatus,
                    orderId,
                    rejected_on,
                    status: status === "Success" ? 1 : 2,
                    trn_date,
                    trn_desc: "withdrawal",
                    trn_id,
                    trn_type: "withdrawal",
                    currencyCode,
                    uid: user_id,
                    UpiDetails: existingTransaction.recordset[0]?.UpiDetails,
                    remark: existingTransaction.recordset[0]?.remark,
                    parentId,
                    isDW,
                    username,
                    domain: existingTransaction.recordset[0]?.domain,
                    penalty: existingTransaction.recordset[0]?.penalty,
                    type: "2",
                    responseProvider: JSON.stringify(req.body),
                };

                if (status === 'Success') {
                    await new Promise((resolve) => {
                        depositToLogs((respLog) => {
                            if (respLog.errorCode === 0) {
                                results.push({ user_id, message: "Payment successful", code: 0 });
                            } else {
                                results.push({ user_id, message: "Failed to log withdrawal", code: 1, error: respLog });
                            }
                            resolve();
                        }, withdrawalLog);
                    });
                }

                else if (status === 'Failed') {
                    const withdrawalReq = {
                        password: "abcdr1245",
                        txntype: 1,
                        users: [
                            {
                                userId: user_id,
                                txnType: 1,
                                amount: existingTransaction.recordset[0]?.actual_coins,
                                remark: "Payment-Gateway",
                                key: 0,
                                mainUserId: isDW === "1" && parentId ? parentId : 5117212
                            }
                        ]
                    };

                    await new Promise((resolve) => {
                        depositAmount((resp) => {
                            if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                                depositToLogs((respLog) => {
                                    if (respLog.errorCode === 0) {
                                        results.push({ user_id, message: "Reversed successfully", code: 0 });
                                    } else {
                                        results.push({ user_id, message: "Reverse success but log failed", code: 1, error: respLog });
                                    }
                                    resolve();
                                }, withdrawalLog);
                            } else {
                                results.push({ user_id, message: "Payment failed", code: 1, error: resp.result?.[0] || resp });
                                resolve();
                            }
                        }, withdrawalReq);
                    });
                }
            } else {
                results.push({ user_id, message: "Transaction already processed or not found in ReportGateway", code: 0 });
            }

        } catch (err) {
            console.error("❌ Error in transaction:", err.message);
            results.push({
                user_id: txn?.custom_user_id || 'unknown',
                message: "Exception occurred",
                code: 1,
                error: err.message
            });
        }
    }

    return res.status(200).send({ status: "OK" });
});
app.get('/api/getPendingCount', async (req, res) => {
    const { uid, domain } = req.query;

    if (!uid || !domain) {
        return res.status(400).json({ status: "Failed", message: "uid and domain are required" });
    }

    try {
        await sql.connect(config);

        let depositResult, withdrawalResult;

        if (uid == 0) {
            depositResult = await sql.query`
                SELECT COUNT(*) AS deposit_count 
                FROM reportGateway 
                WHERE type = 1 AND status = 0 AND isDW = 0 AND domain = ${domain}
            `;
            withdrawalResult = await sql.query`
                SELECT COUNT(*) AS withdrawal_count 
                FROM reportGateway 
                WHERE type = 2 AND status = 0 AND isDW = 0 AND domain = ${domain}
            `;
        } else {
            depositResult = await sql.query`
                SELECT COUNT(*) AS deposit_count 
                FROM reportGateway 
                WHERE type = 1 AND status = 0 AND isDW = 1 AND parentId = ${uid} AND domain = ${domain}
            `;
            withdrawalResult = await sql.query`
                SELECT COUNT(*) AS withdrawal_count 
                FROM reportGateway 
                WHERE type = 2 AND status = 0 AND isDW = 1  AND parentId = ${uid} AND domain = ${domain}
            `;
        }

        return res.json({
            status: "Success",
            data: {
                deposit_count: depositResult.recordset[0].deposit_count.toString(),
                withdrawal_count: withdrawalResult.recordset[0].withdrawal_count.toString()
            }
        });

    } catch (err) {
        console.error("Error in getPendingCount:", err);
        return res.status(500).json({ status: "Failed", message: "Failed to Load Count" });
    }
});
async function recheckPendingDeposits() {
    try {
        await sql.connect(config);

        const pendingTxns = await sql.query`
            SELECT * FROM ReportGateway WHERE status = 0 AND type = 1
        `;
        pendingTxns.recordset.forEach(async txn => {
            try {
                const providerResp = await axios.get(`https://pay-crm.com/Remotes/deposit-info`, {
                    params: {
                        project_id: '5234239',
                        order_id: txn.orderId
                    },
                    headers: {
                        apikey: 'ef22332fe042f0fcaecdaa500e542be8'
                    }
                });
                const data = providerResp.data;
                if (data.success && data.status === 'Success' && txn.type === '1') {
                    console.log(`Provider shows success for txn ${txn.orderId}, re-attempting deposit...`);
                    const depositReq = {
                        password: "abcdr1245",
                        txntype: 1,
                        users: [{
                            userId: txn.uid,
                            txnType: 1,
                            amount: txn.coins,
                            remark: "Retry-Deposit",
                            key: 0,
                            mainUserId: txn.isDW === "1" && txn.parentId ? txn.parentId : 5117212
                        }]
                    };

                    await new Promise((resolve) => {
                        depositAmount((resp) => {
                            console.log(resp);
                            if (resp.errorCode === 0 && resp.result?.[0]?.result === "SUCCESS") {
                                const updateRequest = new sql.Request();
                                updateRequest.input('orderId', sql.VarChar, txn.orderId);
                                updateRequest.query(`
                                UPDATE ReportGateway SET status = 1, approved_on = GETDATE() WHERE orderId = @orderId
                            `).then(() => {
                                    console.log(`Deposit success re-logged for ${txn.orderId}`);
                                });
                            } else {
                                console.warn(`Deposit retry failed for ${txn.orderId}`);
                            }
                            resolve();
                        }, depositReq);
                    });
                } else {
                    console.log(`Still pending or failed on provider for txn ${txn.orderId}`);
                }
            }
            catch (err) {
                if (
                    err.response &&
                    err.response.status === 400 &&
                    err.response.data?.message === 'invalid order'
                ) {
                    const updateRequest = new sql.Request();
                    updateRequest.input('orderId', sql.VarChar, txn.orderId);
                    await updateRequest.query(`UPDATE ReportGateway SET status = 2, approved_on = GETDATE() WHERE orderId = @orderId`);
                    console.log(`Marked order ${txn.orderId} as status 2 due to invalid order.`);
                } else {
                    console.error(`Error checking txn ${txn.orderId}:`, err.message);
                }
            }
        });
    } catch (err) {
        console.error("Recheck error:", err.message);
    }
}
function depositAmount(handleData, data) {

    var data = JSON.stringify(data);

    var config = {
        method: 'post',
        url: 'https://777777.today/pad=81/transferSpec',
        headers: {
            // 'authorization': authorization,
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            handleData(response.data);
            // console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
            // console.log(error);
            handleData(error.message)
        });

}
function depositToLogs(handleData, data) {
    console.log(data, "deposit log");
    console.log(`[depositToLogs] Sending deposit log request for transaction ID: ${data.trn_id}`);
    var config = {
        method: 'post',
        url: 'https://api2.streamingtv.fun:3479/api/payment-Gateway-history',
        httpsAgent,
        headers: { 'Content-Type': 'application/json' },
        data: JSON.stringify(data),
        timeout: 15000 // 15 seconds timeout
    };

    axios(config)
        .then(function (response) {
            console.log(`[depositToLogs] Response Status: ${response.status}`);
            handleData(response.data);
        })
        .catch(function (error) {
            const errorMsg = error.response ? error.response.data : error.message;
            console.error(`[depositToLogs] Error for transaction ID: ${data.trn_id} - ${error}`);
            handleData(errorMsg);
        });
}
app.get('/api/getDWSummary/', async (req, res) => {
    const { uid, from, to, domain } = req.query;

    if (!uid || !from || !to || !domain) {
        return res.status(400).json({
            status: "Error",
            errorDescription: 'All query parameters are required',
            data: []
        });
    }

    try {
        const fromDate = new Date(from);
        const toDate = new Date(to);

        if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime())) {
            return res.status(400).json({
                status: "Error",
                errorDescription: 'Invalid date format',
                data: []
            });
        }

        await sql.connect(config);

        const resultdeposit = await sql.query(`
            SELECT 
                SUM(CASE WHEN status = 1 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalSuccessfulDeposit,
                SUM(CASE WHEN status = 2 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalRejectedDeposit,
                SUM(CASE WHEN status = 0 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalPendingDeposit
            FROM ReportGateway
            WHERE parentId = '${uid}'
            AND domain = '${domain}'
            AND type = 1
            AND trn_date BETWEEN '${fromDate.toISOString()}' AND '${toDate.toISOString()}'
        `);

        const resultwithdrawal = await sql.query(`
            SELECT 
                SUM(CASE WHEN status = 1 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalSuccessfulWithdraw,
                SUM(CASE WHEN status = 2 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalRejectedWithdraw,
                SUM(CASE WHEN status = 0 THEN CAST(coins AS FLOAT) ELSE 0 END) AS totalPendingWithdraw
            FROM ReportGateway
            WHERE parentId = '${uid}'
            AND domain = '${domain}'
            AND type = 2
            AND trn_date BETWEEN '${fromDate.toISOString()}' AND '${toDate.toISOString()}'
        `);

        const summarydeposit = resultdeposit.recordset[0];
        const summarywithdrawal = resultwithdrawal.recordset[0];

        res.status(200).json({
            status: "Success",
            data: {
                totalSuccessfulDeposit: (summarydeposit.totalSuccessfulDeposit || 0).toFixed(2),
                totalRejectedDeposit: (summarydeposit.totalRejectedDeposit || 0).toFixed(2),
                totalPendingDeposit: (summarydeposit.totalPendingDeposit || 0).toFixed(2),
                totalSuccessfulWithdraw: (summarywithdrawal.totalSuccessfulWithdraw || 0).toFixed(2),
                totalRejectedWithdraw: (summarywithdrawal.totalRejectedWithdraw || 0).toFixed(2),
                totalPendingWithdraw: (summarywithdrawal.totalPendingWithdraw || 0).toFixed(2),
            }
        });

    } catch (err) {
        console.error('Error fetching client payment report:', err);
        res.status(500).json({
            status: "Error",
            errorDescription: err.message,
            data: []
        });
    }
});
app.post('/api/updateDWstatus/', async (req, res) => {
    const { parentId, status } = req.body;
    if (!parentId || status === undefined) {
        return res.status(400).json({ status: 'Error', message: 'All fields are required' });
    }
    try {
        await sql.connect(config);
        const result = await sql.query`
            UPDATE ReportGateway 
            SET isDW = ${status} 
            WHERE parentId = ${parentId}
        `;
        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ status: 'Error', message: 'No matching records found to update.' });
        }
        return res.status(200).json({ status: 'Success', message: 'DW status updated Successfully...' });
    } catch (err) {
        return res.status(500).json({ errorCode: 1, errorDescription: err.message, result: null });
    }
});

// setInterval(() => {
//     console.log("🔄 Rechecking pending deposits...");
//     recheckPendingDeposits();
// }, 3 * 60 * 1000); // 3 minutes

process.on('SIGINT', () => {
    console.log('Server shutting down...');
    sql.close();
    process.exit(0);
});


//agentlist end///////////////

// Start server
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
