

var express = require('express')();
var fs = require('fs');
var https = require('https');
var axios = require('axios');

var _ = require('lodash');

var cors = require('cors')

var ssl_domain = require("./ssl/ssl_domain");

const { json } = require('express');

let app = https.createServer(ssl_domain.options, express);

app.addContext('api1.streamingtv.fun', ssl_domain.options1);
app.addContext('api2.streamingtv.fun', ssl_domain.options2);
app.addContext('api3.streamingtv.fun', ssl_domain.options3);
app.addContext('access.vrnl.net', ssl_domain.options4);
app.addContext('access.streamtv247.fun', ssl_domain.options5);
app.addContext('api3.streamtv247.fun', ssl_domain.options6);
app.addContext('api.bfoddsapi.in', ssl_domain.options7);
app.addContext('access.vrnlapi.live', ssl_domain.options8);
app.addContext('api3.vrnlapi.live', ssl_domain.options9);

express.use(cors());

express.get('/', function (req, res) {
  res.send('VRNL.NET');
});

//database
var mysql = require('mysql')

const mysql_username = process.env.mysqlUsername || 'vrnlappusr';
const mysql_password = process.env.mysqlPassword || 'okDU6i8csmqdb121!';
const mysql_host = process.env.mysqlHost || 'vrnl-db-readonly.c2fyyveua9jg.eu-west-2.rds.amazonaws.com';
const mysql_db = process.env.mysqlDb || 'vrnlapp';

// const mysql_username = process.env.mysqlUsername || 'vrnlappusr';
// const mysql_password = process.env.mysqlPassword || 'okDU6i8csmqdb121!';
// const mysql_host = process.env.mysqlHost || '185.237.252.87';
// const mysql_db = process.env.mysqlDb || 'vrnlapp';


var mysql_port = 3306

var POLLING_INTERVAL = 30000
var pollingTimer
var connection, session

var db_config = {
  host: mysql_host,
  user: mysql_username,
  password: mysql_password,
  database: mysql_db,
  port: mysql_port,
};

function handleDisconnect() {
  connection = mysql.createConnection(db_config);
  connection.connect(function (err) {
    if (err) {
      console.log('error when connecting to db:', err);
      // setTimeout(handleDisconnect, 2000);
    }
  });
  connection.on('error', function (err) {
    console.log('db error', err);
    if (err.code === 'PROTOCOL_CONNECTION_LOST') {
      // handleDisconnect();
    } else {
      console.log("gotcha !!! data base connection terminating the nodejs");
      throw err;
    }
  });
}
handleDisconnect();


var getLiveBets = async function () {
  connection = mysql.createConnection(db_config);

  var queryString = "SELECT * from vrnlapp.liveBets where sportid=-1 or isFancy=1";
  connection.query(queryString, function (err, gameDetail, fields) {
    connection.end();
    if (err) {
      console.log(err);
      return err;
    } else {

      return gameDetail;
    }
  });
}
// getLiveBets();

express.get('/api/userbets/:status', async function (req, res, next) {

  connection = mysql.createConnection(db_config);

  var queryString = "SELECT * from vrnlapp.userBetsSky where WL=148994 and status=" + req.params.status;
  connection.query(queryString, function (err, betDetails, fields) {
    connection.end();
    if (err) {
      console.log(err);
      // return err;
      res.json(err);

    } else {

      res.json(betDetails);
    }
  });
});

express.get('/api/userbets/:status/:eventId', async function (req, res, next) {

  connection = mysql.createConnection(db_config);

  var queryString = "SELECT * from vrnlapp.userBetsSky where WL=148994 and status=" + req.params.status + " and eventId=" + req.params.eventId;
  connection.query(queryString, function (err, betDetails, fields) {
    connection.end();
    if (err) {
      console.log(err);
      // return err;
      res.json(err);

    } else {

      res.json(betDetails);
    }
  });
});

express.get('/api/bookmaker_result/:eventId', async function (req, res, next) {

  connection = mysql.createConnection(db_config);

  var queryString = "SELECT eventId,eventName,marketName,winnerSelId FROM vrnlapp.vrnlGames where open=0 and oddSource=0 and marketName='Bookmaker' and eventId=" + req.params.eventId;
  connection.query(queryString, function (err, betDetails, fields) {
    connection.end();
    if (err) {
      console.log(err);
      // return err;
      res.json(err);

    } else {

      res.json(betDetails);
    }
  });
});


app.listen(3450, function () {
  console.log('listening on *:3450');
});

