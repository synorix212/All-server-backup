var fs = require('fs');
var options = {
    key: fs.readFileSync('./ssl/access.streamingtv.fun/access.streamingtv.fun-key.pem'),
    cert: fs.readFileSync('./ssl/access.streamingtv.fun/access.streamingtv.fun-crt.pem'),
    ca: fs.readFileSync('./ssl/access.streamingtv.fun/access.streamingtv.fun-chain.pem'),
}

var options1 = {
    key: fs.readFileSync('./ssl/api1.streamingtv.fun/api1.streamingtv.fun-key.pem'),
    cert: fs.readFileSync('./ssl/api1.streamingtv.fun/api1.streamingtv.fun-crt.pem'),
    ca: fs.readFileSync('./ssl/api1.streamingtv.fun/api1.streamingtv.fun-chain.pem'),
}
var options2 = {
    key: fs.readFileSync('./ssl/api2.streamingtv.fun/api2.streamingtv.fun-key.pem'),
    cert: fs.readFileSync('./ssl/api2.streamingtv.fun/api2.streamingtv.fun-crt.pem'),
    ca: fs.readFileSync('./ssl/api2.streamingtv.fun/api2.streamingtv.fun-chain.pem'),
}
var options3 = {
    key: fs.readFileSync('./ssl/api3.streamingtv.fun/api3.streamingtv.fun-key.pem'),
    cert: fs.readFileSync('./ssl/api3.streamingtv.fun/api3.streamingtv.fun-crt.pem'),
    ca: fs.readFileSync('./ssl/api3.streamingtv.fun/api3.streamingtv.fun-chain.pem'),
}

var options4 = {
    key: fs.readFileSync('./ssl/access.vrnl.net/access.vrnl.net-key.pem'),
    cert: fs.readFileSync('./ssl/access.vrnl.net/access.vrnl.net-crt.pem'),
    ca: fs.readFileSync('./ssl/access.vrnl.net/access.vrnl.net-chain.pem'),
}
var options5 = {
    key: fs.readFileSync('./ssl/access.streamtv247.fun/access.streamtv247.fun-key.pem'),
    cert: fs.readFileSync('./ssl/access.streamtv247.fun/access.streamtv247.fun-crt.pem'),
    ca: fs.readFileSync('./ssl/access.streamtv247.fun/access.streamtv247.fun-chain.pem'),
}
var options6 = {
    key: fs.readFileSync('./ssl/api3.streamtv247.fun/api3.streamtv247.fun-key.pem'),
    cert: fs.readFileSync('./ssl/api3.streamtv247.fun/api3.streamtv247.fun-crt.pem'),
    ca: fs.readFileSync('./ssl/api3.streamtv247.fun/api3.streamtv247.fun-chain.pem'),
}

var options7 = {
    key: fs.readFileSync('./ssl/api.bfoddsapi.in/api.bfoddsapi.in-key.pem'),
    cert: fs.readFileSync('./ssl/api.bfoddsapi.in/api.bfoddsapi.in-crt.pem'),
    ca: fs.readFileSync('./ssl/api.bfoddsapi.in/api.bfoddsapi.in-chain.pem'),
}

var options8 = {
    key: fs.readFileSync('./ssl/access.vrnlapi.live/access.vrnlapi.live-key.pem'),
    cert: fs.readFileSync('./ssl/access.vrnlapi.live/access.vrnlapi.live-crt.pem'),
    ca: fs.readFileSync('./ssl/access.vrnlapi.live/access.vrnlapi.live-chain.pem'),
}

var options9 = {
    key: fs.readFileSync('./ssl/api3.vrnlapi.live/api3.vrnlapi.live-key.pem'),
    cert: fs.readFileSync('./ssl/api3.vrnlapi.live/api3.vrnlapi.live-crt.pem'),
    ca: fs.readFileSync('./ssl/api3.vrnlapi.live/api3.vrnlapi.live-chain.pem'),
}

var options10 = {
    key: fs.readFileSync('./ssl/api2.vrnlapi.live/api2.vrnlapi.live-key.pem'),
    cert: fs.readFileSync('./ssl/api2.vrnlapi.live/api2.vrnlapi.live-crt.pem'),
    ca: fs.readFileSync('./ssl/api2.vrnlapi.live/api2.vrnlapi.live-chain.pem'),
}

var options11= {
    key: fs.readFileSync('./ssl/api2.vrnlapi.xyz/api2.vrnlapi.xyz-key.pem'),
    cert: fs.readFileSync('./ssl/api2.vrnlapi.xyz/api2.vrnlapi.xyz-crt.pem'),
    ca: fs.readFileSync('./ssl/api2.vrnlapi.xyz/api2.vrnlapi.xyz-chain.pem'),
}

exports.options = options;
exports.options1 = options1;
exports.options2 = options2;
exports.options3 = options3;
exports.options4 = options4;
exports.options5 = options5;
exports.options6 = options6;
exports.options7 = options7;
exports.options8 = options8;
exports.options9 = options9;
exports.options10 = options10;
exports.options11 = options11;





