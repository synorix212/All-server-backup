const express = require('express');
const admin = require('firebase-admin');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

// Initialize Firebase Admin SDK
const serviceAccount = require('./serviceAccountKey.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://fir-demo-9cbf0-default-rtdb.firebaseio.com',
});

app.use(bodyParser.json());
app.use(cors());

// Endpoint to send login code
app.post('/sendLoginCode', (req, res) => {
  const { phoneNumber, recaptchaVerifier } = req.body;

  admin
    .auth()
    .signInWithPhoneNumber(phoneNumber, recaptchaVerifier)
    .then((result) => {
      // Store the verification ID for later use (e.g., during code verification)
      const verificationId = result.verificationId;

      res.json({ success: true, verificationId });
    })
    .catch((error) => {
      console.error(error);
      res.status(500).json({ success: false, error: 'Failed to send login code.' });
    });
});

// ... (other endpoints)

const PORT = process.env.PORT || 3479;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
