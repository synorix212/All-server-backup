const sql = require("mssql");
const express = require("express");
const app = express();
const multer = require("multer");
const path = require("path");
const fs = require("fs");


const config = {
    user: "cricapi",
    password: "Asdf1234",
    server: "5.189.187.132",
    database: "cricbuzzer_prod",
    port: 1433,
    options: {
        encrypt: true,
        enableArithAbort: true,
        trustServerCertificate: true
    },
    connectionTimeout: 30000,
    requestTimeout: 30000
};
const PORT = process.env.PORT || 15552;
app.use(express.json());
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, "assets/images/qr_images");
    },
    filename: function (req, file, cb) {
        const uniqueName = Date.now() + path.extname(file.originalname);
        cb(null, uniqueName);
    }
});
const upload = multer({ storage: storage });


// UPI Detail 

// admin start
app.post("/api/AddAdminupidetails", async (req, res) => {
    const { value, type, name, isOwn, uid, domain } = req.body;

    if (!value || !type || !name || !isOwn || uid === undefined || !domain) {
        return res.json({
            status: "Error",
            message: "All fields are required"
        });
    }

    try {
        let pool = await sql.connect(config);

        await pool.request()
            .input("value", sql.VarChar, value)
            .input("type", sql.VarChar, type)
            .input("name", sql.VarChar, name)
            .input("isOwn", sql.Int, isOwn)
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .query(`
                INSERT INTO Adminupidetails 
                (value, type, name, isOwn, uid, domain, isPreferred)
                VALUES 
                (@value, @type, @name, @isOwn, @uid, @domain, NULL)
            `);

        return res.json({
            status: "Success",
            message: "UPI Added Successfully..."
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.get("/api/GetAdminUpiList", async (req, res) => {
    const uid = parseInt(req.query.uid);
    const domain = req.query.domain;

    if (!domain) {
        return res.json({ status: "Error", message: "domain is required" });
    }

    try {
        let pool = await sql.connect(config);

        let result = await pool.request()
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .query(`
                SELECT *
                FROM Adminupidetails
                WHERE 
                    (@uid = 0 AND domain = @domain)
                    OR
                    (@uid <> 0 AND uid = @uid AND domain = @domain);
            `);

        if (result.recordset.length > 0) {
            return res.json({ status: "Success", data: result.recordset });
        } else {
            return res.json({ status: "Error", message: "No UPI Found" });
        }

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.patch('/api/UpdateAdminupi', async (req, res) => {
    try {
        const { upi_id, value, type, name } = req.body;

        if (!upi_id) return res.json({ status: "Error", message: "upi_id is required" });

        const query = `
            UPDATE AdminUpiDetails
            SET 
                value = @value,
                type = @type,
                name = @name
            WHERE upi_id = @upi_id
        `;

        const pool = await sql.connect(config);
        await pool.request()
            .input("upi_id", sql.Int, upi_id)
            .input("value", sql.VarChar, value)
            .input("type", sql.VarChar, type)
            .input("name", sql.VarChar, name)
            .query(query);

        return res.json({ status: "Success", message: "UPI Updated Successfully..." });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.patch('/api/UpdateAdminupipreferred', async (req, res) => {
    try {
        const { uid, upi_id, isPreferred } = req.body;

        if (!uid || !upi_id)
            return res.json({ status: "Error", message: "uid and upi_id required" });

        const query = `
            UPDATE AdminUpiDetails
            SET isPreferred = @isPreferred
            WHERE uid = @uid AND upi_id = @upi_id
        `;

        const pool = await sql.connect(config);
        await pool.request()
            .input("uid", sql.Int, uid)
            .input("upi_id", sql.Int, upi_id)
            .input("isPreferred", sql.Int, isPreferred)
            .query(query);

        return res.json({ status: "Success", message: "Upi Updated Successfully..." });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.delete("/api/DeleteAdminupi", async (req, res) => {
    const upi_id = parseInt(req.query.upi_id);

    if (!upi_id) {
        return res.json({ status: "Error", message: "upi_id is required" });
    }

    try {
        let pool = await sql.connect(config);

        await pool.request()
            .input("upi_id", sql.Int, upi_id)
            .query(`DELETE FROM AdminUpidetails WHERE upi_id = @upi_id`);

        return res.json({
            status: "Success",
            message: "Upi Deleted Successfully..."
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.get("/api/GetAdminUpi", async (req, res) => {
    const uid = parseInt(req.query.uid);
    const domain = req.query.domain;

    if (uid === undefined || !domain) {
        return res.json({
            status: "Error",
            message: "uid and domain are required"
        });
    }

    try {
        const pool = await sql.connect(config);
        const statusResult = await pool.request()
            .input("parentId", sql.Int, uid)
            .query(`
                SELECT status
                FROM parentDWstatus
                WHERE parentId = @parentId
            `);

        let parentStatus = 0;
        if (statusResult.recordset.length > 0) {
            parentStatus = statusResult.recordset[0].status;
        }
        let query = `
            SELECT *
            FROM Adminupidetails
            WHERE domain = @domain
        `;

        if (parentStatus === 1) {
            query += ` AND uid = @uid`;
        } else {
            query += ` AND uid = 0`;
        }

        const result = await pool.request()
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .query(query);

        if (result.recordset.length > 0) {
            return res.json({
                status: "Success",
                data: result.recordset
            });
        } else {
            return res.json({
                status: "Error",
                message: "No UPI Found"
            });
        }

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});


// admin end

// user start
app.post("/api/Addupidetails", async (req, res) => {
    const { value, type, name, uid } = req.body;

    if (!value || !type || !name || !uid) {
        return res.json({
            status: "Error",
            message: "All fields are required"
        });
    }

    try {
        let pool = await sql.connect(config);
        await pool.request()
            .input("value", sql.VarChar, value)
            .input("type", sql.VarChar, type)
            .input("name", sql.VarChar, name)
            .input("uid", sql.Int, uid)
            .query(`
                INSERT INTO Upidetails 
                (value, type, name, uid)
                VALUES 
                (@value, @type, @name, @uid )
            `);

        return res.json({
            status: "Success",
            message: "UPI Added Successfully..."
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.get("/api/GetUpiList", async (req, res) => {
    const uid = parseInt(req.query.uid);

    if (!uid) {
        return res.json({ status: "Error", message: "uid is required" });
    }

    try {
        let pool = await sql.connect(config);

        let result = await pool.request()
            .input("uid", sql.Int, uid)
            .query(`
                SELECT * 
                FROM UpiDetails
                WHERE uid = @uid;
            `);

        if (result.recordset.length > 0) {
            return res.json({ status: "Success", data: result.recordset });
        } else {
            return res.json({ status: "Error", message: "No UPI Found" });
        }

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.delete("/api/Deleteupi", async (req, res) => {
    const upi_id = parseInt(req.query.upi_id);

    if (!upi_id) {
        return res.json({ status: "Error", message: "upi_id is required" });
    }

    try {
        let pool = await sql.connect(config);

        await pool.request()
            .input("upi_id", sql.Int, upi_id)
            .query(`DELETE FROM Upidetails WHERE upi_id = @upi_id`);

        return res.json({
            status: "Success",
            message: "Upi Deleted Successfully..."
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.patch('/api/Updateupi', async (req, res) => {
    try {
        const { upi_id, value, type, name } = req.body;

        if (!upi_id) return res.json({ status: "Error", message: "upi_id is required" });

        const query = `
            UPDATE Upidetails
            SET 
                value = @value,
                type = @type,
                name = @name
            WHERE upi_id = @upi_id
        `;

        const pool = await sql.connect(config);
        await pool.request()
            .input("upi_id", sql.Int, upi_id)
            .input("value", sql.VarChar, value)
            .input("type", sql.VarChar, type)
            .input("name", sql.VarChar, name)
            .query(query);

        return res.json({ status: "Success", message: "UPI Updated Successfully..." });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.patch('/api/Updateupipreferred', async (req, res) => {
    try {
        const { uid, upi_id, isPreferred } = req.body;

        if (!uid || !upi_id)
            return res.json({
                status: "Error",
                message: "uid and upi_id required"
            });

        const pool = await sql.connect(config);

        await pool.request()
            .input("uid", sql.Int, uid)
            .input("upi_id", sql.Int, upi_id)
            .input("isPreferred", sql.Int, isPreferred)
            .query(`
                UPDATE UpiDetails
                SET isPreferred = CASE 
                    WHEN upi_id = @upi_id THEN @isPreferred
                    ELSE NULL
                END
                WHERE uid = @uid
            `);

        return res.json({
            status: "Success",
            message: "Upi Updated Successfully..."
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
// user end







// Bank Detail 
// admin start
app.post("/api/AddAdminbankdetails", async (req, res) => {
    const { account_holder, account_number, bank_name, ifsc_code, uid, domain } = req.body;

    if (!account_holder || !account_number || !bank_name || !ifsc_code || uid === undefined || !domain) {
        return res.json({
            status: "Error",
            message: "All fields are required"
        });
    }
    try {
        let pool = await sql.connect(config);

        await pool.request()
            .input("account_holder", sql.VarChar, account_holder)
            .input("account_number", sql.VarChar, String(account_number))
            .input("bank_name", sql.VarChar, bank_name)
            .input("ifsc_code", sql.VarChar, ifsc_code)
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .query(`
                INSERT INTO AdminBankDetails 
                (account_holder, account_number, bank_name, ifsc_code, status, uid, domain)
                VALUES 
                (@account_holder, @account_number, @bank_name, @ifsc_code, 1, @uid, @domain)
            `);

        return res.json({
            status: "Success",
            message: "Bank Account Added Successfully..."
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.get("/api/GetAdminbankaccountsList", async (req, res) => {
    const uid = parseInt(req.query.uid);
    const domain = req.query.domain;

    if (!domain) {
        return res.json({ status: "Error", message: "domain is required" });
    }

    try {
        let pool = await sql.connect(config);

        let result = await pool.request()
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .query(`
                SELECT *
                FROM AdminBankDetails
                WHERE 
                    (@uid = 0 AND domain = @domain)
                    OR
                    (@uid <> 0 AND uid = @uid AND domain = @domain);
            `);

        if (result.recordset.length > 0) {
            return res.json({ status: "Success", data: result.recordset });
        } else {
            return res.json({ status: "Error", message: "No Bank Account Found" });
        }

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.patch('/api/UpdateAdminbankdetails', async (req, res) => {
    try {
        const { bank_id, account_holder, account_number, bank_name, ifsc_code } = req.body;

        if (!bank_id) {
            return res.json({ status: "Error", message: "bank_id is required" });
        }

        const query = `
            UPDATE AdminBankDetails
            SET 
                account_holder = @account_holder,
                account_number = @account_number,
                bank_name = @bank_name,
                ifsc_code = @ifsc_code
            WHERE bank_id = @bank_id
        `;

        const pool = await sql.connect(config);
        await pool.request()
            .input("bank_id", sql.Int, bank_id)
            .input("account_holder", sql.VarChar, account_holder)
            .input("account_number", sql.VarChar(50), account_number.toString())
            .input("bank_name", sql.VarChar, bank_name)
            .input("ifsc_code", sql.VarChar, ifsc_code)
            .query(query);

        return res.json({ status: "Success", message: "Bank Details Updated Successfully..." });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.patch('/api/UpdateAdminbankdetailpreferred', async (req, res) => {
    try {
        const { uid, bank_id } = req.body;

        if (uid === undefined || !bank_id) {
            return res.json({ status: "Error", message: "uid and bank_id required" });
        }

        const pool = await sql.connect(config);

        if (uid != 0) {
            await pool.request()
                .input("uid", sql.Int, uid)
                .query(`
                    UPDATE AdminBankDetails
                    SET isPreferred = NULL
                    WHERE uid = @uid
                `);
        }

        await pool.request()
            .input("uid", sql.Int, uid)
            .input("bank_id", sql.Int, bank_id)
            .query(`
                UPDATE AdminBankDetails
                SET isPreferred = 1
                WHERE bank_id = @bank_id
            `);

        return res.json({
            status: "Success",
            message: "Bank preferred updated successfully"
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.delete("/api/DeleteAdminbankdetails", async (req, res) => {
    const bank_id = parseInt(req.query.bank_id);

    if (!bank_id) {
        return res.json({ status: "Error", message: "bank_id is required" });
    }

    try {
        let pool = await sql.connect(config);

        const result = await pool.request()
            .input("bank_id", sql.Int, bank_id)
            .query(`DELETE FROM AdminBankDetails WHERE bank_id = @bank_id`);

        return res.json({
            status: "Success",
            message: "Bank Detail Deleted Successfully..."
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.get("/api/GetAdminbankaccounts", async (req, res) => {
    const uid = parseInt(req.query.uid);
    const domain = req.query.domain;

    if (!domain) {
        return res.json({ status: "Error", message: "domain is required" });
    }

    try {
        const pool = await sql.connect(config);
        const statusResult = await pool.request()
            .input("parentId", sql.Int, uid)
            .query(`
                SELECT status
                FROM parentDWstatus
                WHERE parentId = @parentId
            `);

        let parentStatus = 0;
        if (statusResult.recordset.length > 0) {
            parentStatus = statusResult.recordset[0].status;
        }
        let query = `
            SELECT *
            FROM AdminBankdetails
            WHERE domain = @domain AND isPreferred = 1
        `;

        if (parentStatus === 1) {
            query += ` AND uid = @uid`;
        } else {
            query += ` AND uid = 0`;
        }

        const result = await pool.request()
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .query(query);

        if (result.recordset.length > 0) {
            return res.json({
                status: "Success",
                data: result.recordset
            });
        } else {
            return res.json({
                status: "Error",
                message: "No Bank Details Found"
            });
        }

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
// admin end
// user start
app.post("/api/Addbankdetails", async (req, res) => {
    const { account_holder, account_number, bank_name, ifsc_code, uid } = req.body;

    if (!account_holder || !account_number || !bank_name || !ifsc_code || !uid) {
        return res.json({
            status: "Error",
            message: "All fields are required"
        });
    }

    try {
        let pool = await sql.connect(config);

        await pool.request()
            .input("account_holder", sql.VarChar, account_holder)
            .input("account_number", sql.VarChar, account_number)
            .input("bank_name", sql.VarChar, bank_name)
            .input("ifsc_code", sql.VarChar, ifsc_code)
            .input("uid", sql.Int, uid)
            .input("status", sql.Int, 1)
            .input("isPreferred", sql.Int, 1)
            .query(`
                INSERT INTO Bankdetails 
                (account_holder, account_number, bank_name, ifsc_code, uid, status, isPreferred)
                VALUES 
                (@account_holder, @account_number, @bank_name, @ifsc_code, @uid, @status, @isPreferred)
            `);

        return res.json({
            status: "Success",
            message: "Bank Account Added Successfully..."
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.get("/api/Getbankaccountslist", async (req, res) => {
    const uid = parseInt(req.query.uid);

    if (!uid) {
        return res.json({ status: "Error", message: "uid is required" });
    }

    try {
        let pool = await sql.connect(config);

        let result = await pool.request()
            .input("uid", sql.Int, uid)
            .query(`
                SELECT * 
                FROM Bankdetails
                WHERE uid = @uid;
            `);

        if (result.recordset.length > 0) {
            return res.json({ status: "Success", data: result.recordset });
        } else {
            return res.json({ status: "Error", message: "No Bank Account Found" });
        }

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.delete("/api/Deletebankdetails", async (req, res) => {
    const bank_id = parseInt(req.query.bank_id);

    if (!bank_id) {
        return res.json({ status: "Error", message: "bank_id is required" });
    }

    try {
        let pool = await sql.connect(config);

        await pool.request()
            .input("bank_id", sql.Int, bank_id)
            .query(`DELETE FROM Bankdetails WHERE bank_id = @bank_id`);

        return res.json({
            status: "Success",
            message: "Bank Detail Deleted Successfully..."
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.patch('/api/Updatebankdetails', async (req, res) => {
    try {
        const { bank_id, account_holder, account_number, bank_name, ifsc_code } = req.body;

        if (!bank_id) return res.json({ status: "Error", message: "bank_id is required" });

        const query = `
            UPDATE BankDetails
            SET 
                account_holder = @account_holder,
                account_number = @account_number,
                bank_name = @bank_name,
                ifsc_code = @ifsc_code
            WHERE bank_id = @bank_id
        `;

        const pool = await sql.connect(config);
        await pool.request()
            .input("bank_id", sql.Int, bank_id)
            .input("account_holder", sql.VarChar, account_holder)
            .input("account_number", sql.VarChar, account_number)
            .input("bank_name", sql.VarChar, bank_name)
            .input("ifsc_code", sql.VarChar, ifsc_code)
            .query(query);

        return res.json({ status: "Success", message: "Bank Details Updated Successfully..." });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.patch('/api/Updatebankdetailpreferred', async (req, res) => {
    try {
        const { uid, bank_id, isPreferred } = req.body;

        if (!uid || !bank_id)
            return res.json({ status: "Error", message: "uid and bank_id required" });

        const query = `
            UPDATE BankDetails
            SET isPreferred = CASE 
            WHEN bank_id = @bank_id THEN @isPreferred
            ELSE NULL
        END
        WHERE uid = @uid
        `;

        const pool = await sql.connect(config);
        await pool.request()
            .input("uid", sql.Int, uid)
            .input("bank_id", sql.Int, bank_id)
            .input("isPreferred", sql.Int, isPreferred)
            .query(query);

        return res.json({ status: "Success", message: "Bank Details Updated Successfully..." });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
// user end


// QR Detail
// admin start
app.post("/api/AddAdminQrCode", upload.single("qr_img"), async (req, res) => {
    const { uid, display_name, type, domain } = req.body;

    if (!uid || !display_name || !type || !domain || !req.file) {
        return res.json({
            status: "Error",
            message: "All fields including qr_img are required"
        });
    }

    try {
        let pool = await sql.connect(config);
        const qrImagePath = "assets/images/qr_images/" + req.file.filename;
        await pool.request()
            .input("display_name", sql.VarChar, display_name)
            .input("type", sql.VarChar, type)
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .input("img", sql.VarChar, qrImagePath)
            .query(`
                INSERT INTO AdminQRdetails
                (display_name, type, uid, domain, img)
                VALUES 
                (@display_name, @type, @uid, @domain, @img)
            `);

        return res.json({
            status: "Success",
            message: "QR Added Successfully..."
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.get("/api/GetAdminQrList", async (req, res) => {
    const uid = parseInt(req.query.uid);
    const domain = req.query.domain;

    if (!domain) {
        return res.json({ status: "Error", message: "domain is required" });
    }

    try {
        let pool = await sql.connect(config);

        let result = await pool.request()
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .query(`
                SELECT *
                FROM AdminQRdetails
                WHERE 
                    (@uid = 0 AND domain = @domain)
                    OR
                    (@uid <> 0 AND uid = @uid AND domain = @domain);
            `);

        if (result.recordset.length > 0) {
            return res.json({ status: "Success", data: result.recordset });
        } else {
            return res.json({ status: "Error", message: "No QR Found" });
        }

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.delete("/api/DeleteAdminQr", async (req, res) => {
    const qr_id = parseInt(req.query.qr_id);

    if (!qr_id) {
        return res.json({ status: "Error", message: "qr_id is required" });
    }

    try {
        let pool = await sql.connect(config);

        await pool.request()
            .input("qr_id", sql.Int, qr_id)
            .query(`DELETE FROM AdminQRdetails WHERE qr_id = @qr_id`);

        return res.json({
            status: "Success",
            message: "QR Code Deleted Successfully..."
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
// admin end

// user start
app.get("/api/GetAdminQr", async (req, res) => {
    const uid = parseInt(req.query.uid);
    const domain = req.query.domain;

    if (!domain) {
        return res.json({ status: "Error", message: "domain is required" });
    }

    try {
        const pool = await sql.connect(config);
        const statusResult = await pool.request()
            .input("parentId", sql.Int, uid)
            .query(`
                SELECT status
                FROM parentDWstatus
                WHERE parentId = @parentId
            `);

        let parentStatus = 0;
        if (statusResult.recordset.length > 0) {
            parentStatus = statusResult.recordset[0].status;
        }
        let query = `
            SELECT *
            FROM AdminQRdetails
            WHERE domain = @domain
        `;

        if (parentStatus === 1) {
            query += ` AND uid = @uid`;
        } else {
            query += ` AND uid = 0`;
        }

        const result = await pool.request()
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .query(query);

        if (result.recordset.length > 0) {
            return res.json({
                status: "Success",
                data: result.recordset
            });
        } else {
            return res.json({
                status: "Error",
                message: "No QR Details Found"
            });
        }

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
// user end


// Wallet Detail 
// admin start
app.post("/api/AddWalletdetails", async (req, res) => {
    try {
        const {
            wallet_type,
            blockchain,
            wallet_address,
            rate,
            uid,
            domain,
            isOwn
        } = req.body;

        if (!wallet_type || !blockchain || !wallet_address || !domain) {
            return res.json({
                status: "Error",
                message: "Required fields missing"
            });
        }

        const pool = await sql.connect(config);

        const checkResult = await pool.request()
            .input("wallet_address", sql.VarChar, wallet_address.trim())
            .input("domain", sql.VarChar, domain)
            .query(`
        SELECT id
        FROM AdminWalletdetails
        WHERE wallet_address = @wallet_address
          AND domain = @domain
    `);

        if (checkResult.recordset.length > 0) {
            return res.json({
                status: "Error",
                message: "Wallet Address Already Exist in this Domain"
            });
        }


        // ✅ INSERT
        await pool.request()
            .input("wallet_type", sql.VarChar, wallet_type)
            .input("blockchain", sql.VarChar, blockchain)
            .input("wallet_address", sql.VarChar, wallet_address.trim())
            .input("rate", sql.Decimal(10, 2), rate)
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .input("isOwn", sql.Int, isOwn)
            .query(`
                INSERT INTO AdminWalletdetails
                (wallet_type, blockchain, wallet_address, rate, uid, domain, isOwn)
                VALUES
                (@wallet_type, @blockchain, @wallet_address, @rate, @uid, @domain, @isOwn)
            `);

        return res.json({
            status: "Success",
            message: "Wallet Added Successfully..."
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.get("/api/GetAdminWalletlist", async (req, res) => {
    const uid = req.query.uid;
    const domain = req.query.domain;

    if (!uid) {
        return res.json({ status: "Error", message: "uid is required" });
    }

    try {
        let pool = await sql.connect(config);

        let result = await pool.request()
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .query(`
                SELECT *
                FROM AdminWalletdetails
                WHERE uid = @uid
                AND (@domain IS NULL OR domain = @domain)
            `);

        return res.json({ status: "Success", data: result.recordset });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.delete("/api/DeleteWallet", async (req, res) => {
    const wallet_id = parseInt(req.query.wallet_id);
    if (!wallet_id) {
        return res.json({
            status: "Error",
            message: "wallet_id is required"
        });
    }
    try {
        const pool = await sql.connect(config);
        const checkResult = await pool.request()
            .input("id", sql.Int, wallet_id)
            .query(`
                SELECT isPreferred
                FROM AdminWalletdetails
                WHERE id = @id
            `);

        if (checkResult.recordset.length === 0) {
            return res.json({
                status: "Error",
                message: "Wallet not found"
            });
        }

        if (checkResult.recordset[0].isPreferred === 1) {
            return res.json({
                status: "Error",
                message: "You cannot Delete a Preferred Wallet Address."
            });
        }
        await pool.request()
            .input("id", sql.Int, wallet_id)
            .query(`
                DELETE FROM AdminWalletdetails
                WHERE id = @id
            `);

        return res.json({
            status: "Success",
            message: "Wallet Deleted Successfully..."
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.patch("/api/UpdateWallet", async (req, res) => {
    try {
        const {
            id,
            wallet_type,
            blockchain,
            wallet_address,
            rate
        } = req.body;

        if (!id || !wallet_address) {
            return res.json({
                status: "Error",
                message: "id and wallet_address required"
            });
        }

        const pool = await sql.connect(config);

        // 🔎 1️⃣ get domain of this wallet
        const domainResult = await pool.request()
            .input("id", sql.Int, id)
            .query(`
                SELECT domain
                FROM AdminWalletdetails
                WHERE id = @id
            `);

        if (domainResult.recordset.length === 0) {
            return res.json({
                status: "Error",
                message: "Wallet not found"
            });
        }

        const domain = domainResult.recordset[0].domain;

        // 🔁 2️⃣ duplicate check (same domain, different id)
        const checkResult = await pool.request()
            .input("wallet_address", sql.VarChar, wallet_address.trim())
            .input("domain", sql.VarChar, domain)
            .input("id", sql.Int, id)
            .query(`
                SELECT id
                FROM AdminWalletdetails
                WHERE wallet_address = @wallet_address
                  AND domain = @domain
                  AND id <> @id
            `);

        if (checkResult.recordset.length > 0) {
            return res.json({
                status: "Error",
                message: "Wallet Address Already Exist in this Domain"
            });
        }

        // ✏️ 3️⃣ update wallet
        await pool.request()
            .input("id", sql.Int, id)
            .input("wallet_type", sql.VarChar, wallet_type)
            .input("blockchain", sql.VarChar, blockchain)
            .input("wallet_address", sql.VarChar, wallet_address.trim())
            .input("rate", sql.Int, rate)
            .query(`
                UPDATE AdminWalletdetails
                SET
                    wallet_type = @wallet_type,
                    blockchain = @blockchain,
                    wallet_address = @wallet_address,
                    rate = @rate
                WHERE id = @id
            `);

        return res.json({
            status: "Success",
            message: "Wallet Updated Successfully..."
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.patch('/api/UpdateWalletpreferred', async (req, res) => {
    try {
        const { uid, id } = req.body;

        if (uid === undefined || !id) {
            return res.json({ status: "Error", message: "uid and id required" });
        }

        const pool = await sql.connect(config);

        if (uid != 0) {
            await pool.request()
                .input("uid", sql.Int, uid)
                .query(`
                    UPDATE AdminWalletdetails
                    SET isPreferred = NULL
                    WHERE uid = @uid
                `);
        }

        await pool.request()
            .input("uid", sql.Int, uid)
            .input("id", sql.Int, id)
            .query(`
                UPDATE AdminWalletdetails
                SET isPreferred = 1
                WHERE id = @id
            `);

        return res.json({
            status: "Success",
            message: "Bank preferred updated successfully"
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
// admin end
// user start
app.get("/api/GetWalletlist", async (req, res) => {
    const uid = parseInt(req.query.uid);
    const domain = req.query.domain;

    if (!domain) {
        return res.json({ status: "Error", message: "domain is required" });
    }

    try {
        const pool = await sql.connect(config);
        const statusResult = await pool.request()
            .input("parentId", sql.Int, uid)
            .query(`
                SELECT status
                FROM parentDWstatus
                WHERE parentId = @parentId
            `);

        let parentStatus = 0;
        if (statusResult.recordset.length > 0) {
            parentStatus = statusResult.recordset[0].status;
        }
        let query = `
            SELECT *
            FROM AdminWalletdetails
            WHERE domain = @domain AND isPreferred = 1
        `;

        if (parentStatus === 1) {
            query += ` AND uid = @uid`;
        } else {
            query += ` AND uid = 0`;
        }

        const result = await pool.request()
            .input("uid", sql.Int, uid)
            .input("domain", sql.VarChar, domain)
            .query(query);

        if (result.recordset.length > 0) {
            return res.json({
                status: "Success",
                data: result.recordset
            });
        } else {
            return res.json({
                status: "Error",
                message: "No Wallet Found"
            });
        }

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
// user end

// Upline whastapp
app.post("/api/AddUplineWhatsapp", async (req, res) => {
    try {
        const { number, parentId } = req.body;

        if (!number || !parentId) {
            return res.json({ status: "Error", message: "number and parentId required" });
        }

        let pool = await sql.connect(config);
        await pool.request()
            .input("number", sql.VarChar, number)
            .input("uid", sql.Int, parentId)
            .query(`
                INSERT INTO UplineWhatsappNumber (number, uid)
                VALUES (@number, @uid)
            `);

        return res.json({
            status: "Success",
            message: "Whatsapp Number Added Successfully..."
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.patch("/api/UpdateUplineWhatsapp", async (req, res) => {
    try {
        const { id, number } = req.body;

        if (!id || !number) {
            return res.json({ status: "Error", message: "id and number required" });
        }

        let pool = await sql.connect(config);
        await pool.request()
            .input("id", sql.Int, id)
            .input("number", sql.VarChar, number)
            .query(`
                UPDATE UplineWhatsappNumber
                SET number = @number
                WHERE id = @id
            `);

        return res.json({
            status: "Success",
            message: "Whatsapp Number Updated Successfully..."
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.patch("/api/UpdateUplineWhatsapppreferred", async (req, res) => {
    try {
        const { uid, id } = req.body;

        if (!uid || !id) {
            return res.json({ status: "Error", message: "uid and id required" });
        }

        const pool = await sql.connect(config);

        // Step 1: sab ko un-preferred karo
        await pool.request()
            .input("uid", sql.Int, uid)
            .query(`
                UPDATE UplineWhatsappNumber
                SET isPreferred = 0
                WHERE uid = @uid
            `);

        // Step 2: sirf ek ko preferred karo
        await pool.request()
            .input("id", sql.Int, id)
            .query(`
                UPDATE UplineWhatsappNumber
                SET isPreferred = 1
                WHERE id = @id
            `);

        return res.json({
            status: "Success",
            message: "Whatsapp Updated Successfully..."
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.get("/api/GetUplineWhatsappAll", async (req, res) => {
    try {
        const uid = parseInt(req.query.uid);

        if (!uid) {
            return res.json({ status: "Error", message: "uid required" });
        }

        let pool = await sql.connect(config);
        const result = await pool.request()
            .input("uid", sql.Int, uid)
            .query(`
                SELECT *
                FROM UplineWhatsappNumber
                WHERE uid = @uid
            `);

        return res.json({
            status: "Success",
            data: result.recordset
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});
app.get("/api/GetUplineWhatsapp", async (req, res) => {
    try {
        const uid = parseInt(req.query.uid);

        if (!uid) {
            return res.json({ status: "Error", message: "uid required" });
        }

        let pool = await sql.connect(config);
        const result = await pool.request()
            .input("uid", sql.Int, uid)
            .query(`
                SELECT *
                FROM UplineWhatsappNumber
                WHERE uid = @uid AND isPreferred = 1
            `);

        return res.json({
            status: "Success",
            data: result.recordset
        });

    } catch (err) {
        return res.json({ status: "Error", message: err.message });
    }
});

// profile and kyc 
app.get("/api/getAvatars", async (req, res) => {
    try {
        let pool = await sql.connect(config);
        let result = await pool.request()
            .query("SELECT * FROM AvatarDetails");

        res.json({
            status: "Success",
            data: result.recordset
        });
    } catch (err) {
        res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.get("/api/getProfileDetails/:uid", async (req, res) => {
    try {
        const uid = parseInt(req.params.uid);

        if (!uid) {
            return res.json({
                status: "Error",
                message: "uid is required"
            });
        }

        const pool = await sql.connect(config);

        const result = await pool.request()
            .input("uid", sql.Int, uid)
            .query(`
                SELECT 
                    uid,
                    whatsapp,
                    telegram,
                    twitter,
                    dob,
                    gender,
                    profile_pic,
                    email,
                    phoneNo
                FROM UserProfile
                WHERE uid = @uid
            `);

        if (result.recordset.length === 0) {
            return res.json({
                status: "Error",
                message: "No Deatils Found"
            });
        }

        return res.json({
            status: "Success",
            data: result.recordset[0]
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.post("/api/updateProfileDetails", async (req, res) => {
    try {
        const {
            whatsapp,
            telegram,
            phoneNo,
            email,
            twitter,
            dob,
            uid,
            parentId
        } = req.body;

        if (!uid || !parentId) {
            return res.json({
                status: "Error",
                message: "uid and parentId are required"
            });
        }

        const pool = await sql.connect(config);

        // check if profile already exists
        const check = await pool.request()
            .input("uid", sql.Int, uid)
            .query(`
                SELECT uid
                FROM UserProfile
                WHERE uid = @uid
            `);

        if (check.recordset.length > 0) {
            // UPDATE
            await pool.request()
                .input("whatsapp", sql.VarChar, whatsapp || null)
                .input("telegram", sql.VarChar, telegram || null)
                .input("phoneNo", sql.VarChar, phoneNo || null)
                .input("email", sql.VarChar, email || null)
                .input("twitter", sql.VarChar, twitter || null)
                .input(
                    "dob",
                    sql.Date,
                    dob && dob !== "" ? dob : null
                )
                .input("parentId", sql.Int, parentId)
                .input("uid", sql.Int, uid)
                .query(`
                    UPDATE UserProfile
                    SET 
                        whatsapp = @whatsapp,
                        telegram = @telegram,
                        phoneNo = @phoneNo,
                        email = @email,
                        twitter = @twitter,
                        dob = @dob,
                        parentId = @parentId
                    WHERE uid = @uid
                `);

        } else {
            // INSERT
            await pool.request()
                .input("uid", sql.Int, uid)
                .input("parentId", sql.Int, parentId)
                .input("whatsapp", sql.VarChar, whatsapp || null)
                .input("telegram", sql.VarChar, telegram || null)
                .input("phoneNo", sql.VarChar, phoneNo || null)
                .input("email", sql.VarChar, email || null)
                .input("twitter", sql.VarChar, twitter || null)
                .input(
                    "dob",
                    sql.Date,
                    dob && dob !== "" ? dob : null
                )
                .query(`
                    INSERT INTO UserProfile
                    (uid, parentId, whatsapp, telegram, phoneNo, email, twitter, dob)
                    VALUES
                    (@uid, @parentId, @whatsapp, @telegram, @phoneNo, @email, @twitter, @dob)
                `);
        }

        return res.json({
            status: "Success",
            message: "Profile Updated Successfully..."
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.post("/api/updateProfileSetup", async (req, res) => {
    try {
        const { gender, avt_id, uid, parentId } = req.body;

        if (!gender || !uid || !parentId || !avt_id) {
            return res.json({
                status: "Error",
                message: "Required fields missing"
            });
        }

        const pool = await sql.connect(config);

        // 1️⃣ Get avatar path from AvatarDetails table
        const avatarResult = await pool.request()
            .input("avt_id", sql.Int, avt_id)
            .input("gender", sql.VarChar(10), gender)
            .query(`
                SELECT avt_path
                FROM AvatarDetails
                WHERE avt_id = @avt_id
                  AND avt_type = @gender
            `);

        if (!avatarResult.recordset.length) {
            return res.json({
                status: "Error",
                message: "Invalid avatar selected"
            });
        }

        // normalize path
        const profilePic = avatarResult.recordset[0].avt_path.replace(/\\/g, '/');

        // 2️⃣ Check profile exists
        const exists = await pool.request()
            .input("uid", sql.Int, uid)
            .query(`SELECT uid FROM UserProfile WHERE uid = @uid`);

        // 3️⃣ UPDATE
        if (exists.recordset.length) {
            await pool.request()
                .input("uid", sql.Int, uid)
                .input("gender", sql.VarChar(10), gender)
                .input("profile_pic", sql.VarChar(255), profilePic)
                .query(`
                    UPDATE UserProfile
                    SET 
                        gender = @gender,
                        profile_pic = @profile_pic,
                        profileCollected = 1
                    WHERE uid = @uid
                `);

            return res.json({
                status: "Success",
                message: "Personal information modified successfully"
            });
        }

        // 4️⃣ INSERT
        await pool.request()
            .input("uid", sql.Int, uid)
            .input("parentId", sql.Int, parentId)
            .input("gender", sql.VarChar(10), gender)
            .input("profile_pic", sql.VarChar(255), profilePic)
            .query(`
                INSERT INTO UserProfile (
                    uid,
                    parentId,
                    gender,
                    profile_pic,
                    profileCollected
                ) VALUES (
                    @uid,
                    @parentId,
                    @gender,
                    @profile_pic,
                    1
                )
            `);

        return res.json({
            status: "Success",
            message: "Personal information modified successfully"
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});



app.get("/api/getKYCstatus", async (req, res) => {
    try {
        const userId = parseInt(req.query.userId);

        if (!userId) {
            return res.json({
                status: "Error",
                message: "userId is required"
            });
        }

        const pool = await sql.connect(config);

        const result = await pool.request()
            .input("uid", sql.Int, userId)
            .query(`
                SELECT TOP 1
                    dateTime,
                    remark,
                    reason,
                    uid
                FROM statusKYCdetails
                WHERE uid = @uid
                ORDER BY dateTime DESC
            `);

        if (result.recordset.length === 0) {
            return res.json({
                status: "Error",
                message: "No Details Found"
            });
        }

        return res.json({
            status: "Success",
            data: {
                dateTime: result.recordset[0].dateTime,
                remark: result.recordset[0].remark,
                reason: result.recordset[0].reason,
                uid: result.recordset[0].uid
            }
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.get("/api/getKYCdetails", async (req, res) => {
    try {
        const userId = req.query.userId;

        if (!userId) {
            return res.json({
                status: "Error",
                message: "userId is required"
            });
        }

        const pool = await sql.connect(config);

        const result = await pool.request()
            .input("userId", sql.VarChar, userId)
            .query(`
                SELECT TOP 1 *
                FROM updatKYC
                WHERE userId = @userId
                ORDER BY uId DESC
            `);

        if (result.recordset.length === 0) {
            return res.json({
                status: "Error",
                message: "No Deatils Found"
            });
        }

        return res.json({
            status: "Success",
            data: result.recordset[0]
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.post("/api/updateKYCdetails", upload.single("docImg"), async (req, res) => {
    let transaction;

    try {
        const {
            userId,
            phoneNumber,
            email,
            surName,
            userName,
            firstName,
            dob,
            pob,
            docType,
            docNumber,
            docIssueDate,
            address,
            country,
            domain,
            status = 0,
            rejectReason // only for status = 2
        } = req.body;

        if (!userId || !docType || !docNumber) {
            return res.json({
                status: "Error",
                message: "Required fields missing"
            });
        }

        /* =========================
           STATUS → TEXT MAP
        ========================== */
        const STATUS_MAP = {
            0: { remark: "Pending", reason: "KYC Under Review" },
            1: { remark: "Approved", reason: "Approved" },
            2: { remark: "Rejected", reason: rejectReason || "Rejected by Admin" }
        };

        const currentStatus = STATUS_MAP[status] || STATUS_MAP[0];

        const docImgPath = req.file
            ? `assets/images/kycStorage/${req.file.filename}`.replace(/\\/g, "/")
            : null;

        const pool = await sql.connect(config);

        // 🔹 Check user exists
        const checkUser = await pool.request()
            .input("userId", sql.VarChar, userId)
            .query(`SELECT 1 FROM updatKYC WHERE userId = @userId`);

        if (!checkUser.recordset.length) {
            return res.json({
                status: "Error",
                message: "No Details Found"
            });
        }

        // 🔹 Start Transaction
        transaction = new sql.Transaction(pool);
        await transaction.begin();

        /* =========================
           1️⃣ Update updatKYC
        ========================== */
        await new sql.Request(transaction)
            .input("userId", sql.VarChar, userId)
            .input("phoneNumber", sql.VarChar, phoneNumber)
            .input("email", sql.VarChar, email)
            .input("surName", sql.VarChar, surName)
            .input("userName", sql.VarChar, userName)
            .input("firstName", sql.VarChar, firstName)
            .input("dob", sql.DateTime, dob)
            .input("pob", sql.VarChar, pob)
            .input("docImg", sql.VarChar, docImgPath)
            .input("docType", sql.Int, docType)
            .input("docNumber", sql.VarChar, docNumber)
            .input("docIssueDate", sql.DateTime, docIssueDate)
            .input("address", sql.VarChar, address)
            .input("country", sql.VarChar, country)
            .input("domain", sql.VarChar, domain)
            .input("status", sql.Int, status)
            .query(`
                UPDATE updatKYC
                SET 
                    phoneNumber = @phoneNumber,
                    email = @email,
                    surName = @surName,
                    userName = @userName,
                    firstName = @firstName,
                    dob = @dob,
                    pob = @pob,
                    docImg = ISNULL(@docImg, docImg),
                    docType = @docType,
                    docNumber = @docNumber,
                    docIssueDate = @docIssueDate,
                    address = @address,
                    country = @country,
                    domain = @domain,
                    status = @status
                WHERE userId = @userId
            `);

        /* =========================
           2️⃣ UPSERT statusKYCdetails
        ========================== */
        await new sql.Request(transaction)
            .input("uid", sql.VarChar, userId)
            .input("status", sql.Int, status)
            .input("remark", sql.VarChar, currentStatus.remark)
            .input("reason", sql.VarChar, currentStatus.reason)
            .query(`
                IF EXISTS (SELECT 1 FROM statusKYCdetails WHERE uid = @uid)
                    UPDATE statusKYCdetails
                    SET 
                        status = @status,
                        remark = @remark,
                        reason = @reason,
                        dateTime = GETDATE()
                    WHERE uid = @uid
                ELSE
                    INSERT INTO statusKYCdetails (
                        uid,
                        status,
                        remark,
                        reason,
                        dateTime
                    )
                    VALUES (
                        @uid,
                        @status,
                        @remark,
                        @reason,
                        GETDATE()
                    )
            `);

        // 🔹 Commit
        await transaction.commit();

        return res.json({
            status: "Success",
            message: `KYC Details Uploaded Successfully...`
        });

    } catch (err) {
        if (transaction) await transaction.rollback();

        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.post("/api/updateKYC", upload.single("docImg"), async (req, res) => {
    try {
        const {
            userId,
            phoneNumber,
            email,
            surName,
            userName,
            firstName,
            dob,
            pob,
            docType,
            docNumber,
            docIssueDate,
            address,
            country,
            domain
        } = req.body;

        if (!userId || !docType || !docNumber) {
            return res.json({
                status: "Error",
                message: "Required fields missing"
            });
        }

        const docImgPath = req.file
            ? `assets\\images\\kycStorage\\${req.file.filename}`
            : null;

        const pool = await sql.connect(config);

        /* ---------------- INSERT INTO updatKYC ---------------- */
        await pool.request()
            .input("userId", sql.VarChar, userId)
            .input("phoneNumber", sql.VarChar, phoneNumber || null)
            .input("email", sql.VarChar, email || null)
            .input("surName", sql.VarChar, surName || null)
            .input("userName", sql.VarChar, userName || null)
            .input("firstName", sql.VarChar, firstName || null)
            .input("dob", sql.DateTime, dob && dob !== "" ? dob : null)
            .input("pob", sql.VarChar, pob || null)
            .input("docImg", sql.VarChar, docImgPath)
            .input("docType", sql.Int, docType)
            .input("docNumber", sql.VarChar, docNumber)
            .input("docIssueDate", sql.DateTime, docIssueDate && docIssueDate !== "" ? docIssueDate : null)
            .input("address", sql.VarChar, address || null)
            .input("country", sql.VarChar, country || null)
            .input("domain", sql.VarChar, domain || null)
            .query(`
                INSERT INTO updatKYC
                (
                    userId,
                    phoneNumber,
                    email,
                    surName,
                    userName,
                    firstName,
                    dob,
                    pob,
                    docImg,
                    docType,
                    docNumber,
                    docIssueDate,
                    address,
                    country,
                    domain,
                    status
                )
                VALUES
                (
                    @userId,
                    @phoneNumber,
                    @email,
                    @surName,
                    @userName,
                    @firstName,
                    @dob,
                    @pob,
                    @docImg,
                    @docType,
                    @docNumber,
                    @docIssueDate,
                    @address,
                    @country,
                    @domain,
                    0
                )
            `);

        /* ---------------- INSERT INTO statusKYCdetails ---------------- */
        await pool.request()
            .input("uid", sql.Int, userId)
            .input("remark", sql.VarChar, "Pending")
            .input("reason", sql.VarChar, "KYC Under Review.")
            .input("status", sql.Int, 0)
            .query(`
                INSERT INTO statusKYCdetails
                (
                    dateTime,
                    uid,
                    remark,
                    reason,
                    status
                )
                VALUES
                (
                    GETDATE(),
                    @uid,
                    @remark,
                    @reason,
                    @status
                )
            `);

        return res.json({
            status: "Success",
            message: "KYC Details Uploaded Successfully..."
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.get("/api/getKYCdetailsAll", async (req, res) => {
    try {
        const status = parseInt(req.query.status);

        if (status !== 0 && status !== 1 && status !== 2) {
            return res.json({
                status: "Error",
                message: "status must be 0, 1 or 2"
            });
        }

        const pool = await sql.connect(config);

        const result = await pool.request()
            .input("status", sql.Int, status)
            .query(`
               SELECT *
FROM updatKYC
WHERE status = @status;
            `);

        return res.json({
            status: "Success",
            count: result.recordset.length,
            data: result.recordset
        });

    } catch (err) {
        return res.json({
            status: "Error",
            message: err.message
        });
    }
});
app.post("/api/updateKYCstatus", async (req, res) => {
    try {
        const { userId, status, reason } = req.body;

        if (!userId || status === undefined || reason === undefined) {
            return res.json({
                status: "Error",
                message: "userId, status and reason are required"
            });
        }

        const pool = await sql.connect(config);


        const result1 = await pool.request()
            .input("userId", sql.VarChar, userId)
            .input("status", sql.Int, status)
            .query(`
        UPDATE updatKYC
        SET status = @status
        WHERE userId = @userId
      `);


        const result2 = await pool.request()
            .input("userId", sql.VarChar, userId)
            .input("status", sql.Int, status)
            .input("reason", sql.NVarChar, reason)
            .query(`
        UPDATE statusKYCdetails
        SET 
          status = @status,
          reason = @reason,
          remark = CASE 
            WHEN @status = 0 THEN 'Pending'
            WHEN @status = 1 THEN 'Approved'
            WHEN @status = 2 THEN 'Rejected'
          END
        WHERE uid = @userId
      `);

        if (result1.rowsAffected[0] === 0 || result2.rowsAffected[0] === 0) {
            return res.json({
                status: "Error",
                message: "User not found"
            });
        }

        res.json({
            status: "Success",
            message: "KYC status & remark updated successfully"
        });

    } catch (err) {
        console.error(err);
        res.json({
            status: "Error",
            message: err.message
        });
    }
});





sql.connect(config)
    .then(pool => {
        console.log("✅ SQL Server Connected Successfully!");
    })
    .catch(err => {
        console.error("❌ Database Connection Failed:", err);
    });

app.listen(PORT, () => {
    console.log(`✅ Server running on http://localhost:${PORT}`);
});
