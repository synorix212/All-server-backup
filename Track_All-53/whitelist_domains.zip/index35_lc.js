var express = require('express')();
var https = require('https');
var axios = require('axios');
var fs = require('fs');
var _ = require('lodash');
var cors = require('cors')

var ssl_domain = require("./ssl/ssl_domain");
var whitelist_domain = require("./whitelist_domains/domains");

const { json } = require('express');

const redis = require('redis');
const redisPort = 6379;
const client = redis.createClient(redisPort);
let app = https.createServer(ssl_domain.options, express);

app.addContext('api1.streamingtv.fun', ssl_domain.options1);
app.addContext('api2.streamingtv.fun', ssl_domain.options2);
app.addContext('api3.streamingtv.fun', ssl_domain.options3);
app.addContext('access.vrnl.net', ssl_domain.options4);
app.addContext('access.streamtv247.fun', ssl_domain.options5);
app.addContext('api3.streamtv247.fun', ssl_domain.options6);
app.addContext('api.bfoddsapi.in', ssl_domain.options7);
app.addContext('access.vrnlapi.live', ssl_domain.options8);
app.addContext('api3.vrnlapi.live', ssl_domain.options9);
app.addContext('api2.vrnlapi.live', ssl_domain.options10);
app.addContext('api2.vrnlapi.xyz', ssl_domain.options11);


express.use(cors());
express.get('/', function (req, res) {
    res.send('VRNL.NET');
});

let hostNames = [
    "lc247.live",
    "lc247.bet",
    "abetbuzz365.bet",
    "bdbaji365.live",
    "jmdexchange.in",
    "1wicket.vip",
    "citybett.com",
    "betguru.live",
    "betguru.win",
    "bazi9.live",
    "playbdt.live",
    "agun365.win",
    "kingxchange.com",
    
    "9wicketbdt.com",
    "betx123.live",
    "vellkiex123.com",
    "sat-sport.live",
];

function getCallerIP(request) {
    var ip = request.headers['x-forwarded-for'] ||
        request.connection.remoteAddress ||
        request.socket.remoteAddress ||
        request.connection.socket.remoteAddress;
    ip = ip.split(',')[0];
    ip = ip.split(':').slice(-1); //in case the ip returned in a format: "::ffff:146.xxx.xxx.xxx"
    return ip;
}

function getDomainName(hostName) {
    if (!hostName) {
        return;
    }
    let formatedHost = "";
    let splithostName = hostName.split('.');
    if (splithostName.length > 2) {
        formatedHost = hostName.substring(hostName.lastIndexOf(".", hostName.lastIndexOf(".") - 1) + 1);
    } else {
        formatedHost = hostName.split('//')[1]
    }
    return formatedHost;
}

let TimerInteval;
let TimerInteval2;

let matchesTv = [];

function startInteval() {
    if (TimerInteval) {
        clearInterval(TimerInteval);
    }
    if (TimerInteval2) {
        clearInterval(TimerInteval2);
    }


    getstreaminfo();
    TimerInteval = setInterval(getstreaminfo, 20000);
    TimerInteval2 = setInterval(() => {
        matchesTv.forEach((match, index) => {
            storeLiveTv(match);
        });
    }, 1000);


}
startInteval();


function getstreaminfo() {
    var config = {
        method: 'get',
        // url: 'https://ss247.life/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/streaminfo.php',
        url: 'https://streamingtv.fun:3447/api/streaminfo',
    };
    axios(config)
        .then(function (response) {
            if (response.data.data) {
                matchesTv = response.data.data.getMatches;
                response.data.data.getMatches.forEach((match, index) => {
                    storeLiveTv(match);
                });
            }

        })
        .catch(function (error) {
            // console.log(error);
        });
}

function storeLiveTv(match) {
    // let tvData = {
    //     "streamingUrl": "https://ss247.life/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/SNstreamapi.php?chid=" + match.Channel + "&ip="
    // };
    let tvData = {
        "Channel": match.Channel,
        // "streamingUrl": "https://live-ngenix-live-das-ss247-ipv4-d6-hs-usdhp60.com/" + match.Channel + "/index.m3u8" // runnning
        // "streamingUrl": "https://inf52mediasrv-ss247.live/" + match.Channel + "/index.m3u8" // old  runnning
        "streamingUrl": "https://live-ngenix-live-das-ss247-ipv4-d6-hs-usdhp60.com/" + match.Channel + "/index.m3u8" //new running
        // "streamingUrl": "https://mediasrv789-ss247-23-prod-sa-ulivestreaming.com/" + match.Channel + "/index.m3u8" // backup url
        // "streamingUrl": "https://live-ngenix-live-das-ss247-ipv4-d6-hs-usdhp60.com/" + match.Channel + "/tracks-v1a1/mono.m3u8"
        // https://mediasrv789-ss247-23-prod-sa-ulivestreaming.com/1029/tracks-v1a1/mono.m3u8
    };
    if (match.MatchID < 0) {
        let gameId = -(match.MatchID);
        match.MatchID = '17' + gameId;
    }
    content = JSON.stringify(tvData);
    client.set('tvstream_' + match.MatchID, content);
}


express.get('/api/get_streamurl/:eventId', function (req, res) {
    var clientIp = getCallerIP(req);

    client.get('tvstream_' + req.params.eventId, (err, data) => {

        if (data) {
            data = JSON.parse(data);
            // let streamingUrl = data.streamingUrl + clientIp[0];

            res.send({
                "link": data.streamingUrl,
                "Channel": data.Channel,
                "User": "",
                "Ip": clientIp[0],
                "status": "200"
            });
        } else {
            res.send({
                "link": "",
                "Channel": "",
                "User": "",
                "Ip": "",
                "status": "404"
            });

        }
    })
});


express.get('/api/get_streamurl2/:eventId', function (req, res) {
    var clientIp = getCallerIP(req);

    client.get('tvstream_' + req.params.eventId, (err, data) => {

        if (data) {
            data = JSON.parse(data);
            let streamingUrl = data.streamingUrl + clientIp[0];
            var config = {
                method: 'get',
                maxBodyLength: Infinity,
                url: streamingUrl,
                headers: {}
            };

            axios(config)
                .then(function (response) {
                    // console.log(JSON.stringify(response.data));
                    res.send(response.data);

                })
                .catch(function (error) {
                    console.log(error);
                });
        } else {
            res.send({
                "link": "",
                "Channel": "",
                "User": "",
                "Ip": "",
                "status": "404"
            });

        }
    })
});


express.get('/api/get_live_tv_url/:eventId', function (req, res) {
    var clientIp = getCallerIP(req);
    // console.log(clientIp[0])
    let scoreTvData = {
        "scoreUrl": "",
        "streamingUrl": ""
    };
    client.get('tvstream_' + req.params.eventId, (err, data) => {
        // console.log(data)
        if (data) {
            data = JSON.parse(data);
            // scoreTvData.streamingUrl = data.streamingUrl + clientIp[0];
            scoreTvData.streamingUrl = "https://ninewiickets.com/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653_staging/?eventId=" + req.params.eventId;
            // scoreTvData.streamingUrl = "https://lc247.live/api/ba8dc11afad30795e5ab25f06bfa50d0b0919653/?eventId=" + req.params.eventId;

        } else {
            scoreTvData.streamingUrl = null;
        }
        res.send(scoreTvData);

    })


});


app.listen(3475, function () {
    console.log('listening on *:3475');
});

