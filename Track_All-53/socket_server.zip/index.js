var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var _ = require('lodash');
var fs = require('fs');

var cors = require('cors');
const { json } = require('express');

// var requestIp = require('request-ip');

const redis = require('redis');
const redisPort = 6379;
const client = redis.createClient(redisPort);

app.use(cors())

app.get('/', function (req, res) {
  res.send('Hello world');
});

setInterval(() => {
  fs.readdir('../../store_sky_sportbook/', (err, files) => {
    files.forEach(file => {
      // console.log(file);
      fs.unlinkSync('../../store_sky_sportbook/' + file);
    });
  });

  client.flushdb(function (err, succeeded) {
    console.log(succeeded); // will be true if successfull
  });

}, 300 * 1000);



let https = require('http');


let hostNames = [
  "http://localhost:3030",

];


function getCallerIP(request) {
  var ip = request.headers['x-forwarded-for'] ||
    request.connection.remoteAddress ||
    request.socket.remoteAddress ||
    request.connection.socket.remoteAddress;
  ip = ip.split(',')[0];
  ip = ip.split(':').slice(-1); //in case the ip returned in a format: "::ffff:146.xxx.xxx.xxx"
  return ip;
}



let userconnected = 0;
io.on('connection', function (socket) {
  console.log('a user connected');
  socket.broadcast.emit('Hello Vrnl');
  userconnected++;
  console.log(userconnected);




  let hostname = socket.handshake.headers.origin;
  // if (hostNames.indexOf(hostname) > -1) {
  socket.on('subscribeScore', params => {
    socket.join(params);
  });
  // }

  socket.on('unsubscribeScore', function (params) {
    socket.leave(params);
  })

  socket.on('betfair_score_333333', function (data) {

    _.forEach(data, (item) => {

      if (item.eventTypeId != 4) {
        var content = JSON.stringify(item);
        client.set('store_scores' + item.eventId, content);

        fs.writeFile('../../store_scores/' + item.eventId + '.json', content, (err) => {
          // console.log(err)
          if (err) {
            throw err;
          }
          // console.log('File saved!');
        });
      } else {
        var content = JSON.stringify(item);
        client.set('store_scores' + item.eventId + '_4', content);

        fs.writeFile('../../store_scores/' + item.eventId + '_4.json', content, (err) => {
          // console.log(err)
          if (err) {
            throw err;
          }
          // console.log('File saved!');
        });
      }

    })

    var scoreContent = JSON.stringify(data);

    client.set('store_all_scores', scoreContent);

    // _.forEach(data, (item) => {
    //   io.to(item.eventId).emit('InplayScoreData', item);
    // })

    // io.emit('send_betfair_score', data);
  });

  socket.on('DiamondScoreData_333333', function (data) {

    if (!data.eventId) {
      return;
    }
    // console.log(data)

    // io.emit('sendDiamondScoreData', data);

    // if (data.eventId == "2109251107") {
    //   data.eventId = "30940270";
    // }
    if (data.eventId == "2111220946") {
      data.eventId = "31085545";
    }
    data.eventId = data.eventId.replace('/', '');

    var content = JSON.stringify(data);
    client.set('store_scores' + data.eventId, content);

    fs.writeFile('../../store_scores/' + data.eventId + '.json', content, (err) => {
      // console.log(err)
      if (err) {
        throw err;
      }
      // console.log('File saved!');
    });
    // io.to(data.eventId).emit('InplayScoreData', data);
  });

  socket.on('diamondHighlightsData_333333', function (data) {
    data.data.forEach(element => {

      if (element.vir == 2) {
        element.vir = 1;
      }
      if (element.gameId == "2111220946") {
        element.gameId = "31085545";
        element.marketId = "1.191369540";
      }
      if (element.gameId == "" || element.name == "South Western Districts v Lions") {
        element.gameId = "30942960";
        element.marketId = "1.188145376";
      }
      if (element.gameId == "" || element.name == "Northern Cape v Western Province") {
        element.gameId = "30942961";
        element.marketId = "1.188145380";
      }
    });
    var content = JSON.stringify(data);
    fs.writeFile('../../store_highlights/' + data.eventTypeId + '.json', content, (err) => {
      // console.log(err)
      if (err) {
        throw err;
      }
      // console.log('File saved!');
    });
    // io.emit('sendDiamondHighlightsData', data);
  });

  socket.on('diamondMarketData_333333', function (data) {

    if (!data.gameId) {
      return;
    }

    // if (data.gameId == "32103563") {
    //   console.log(data.updatetime);
    // }

    // if (data.eventId == "2109251107") {
    //   data.eventId = "30940270";
    // }

    // if (data.gameId == '32623913') { // adding toss market in diamond fancy
    if (data.data.t4 && data.data.t3) {
      data.data.t4 = data.data.t4.filter((f1) => {
        if (f1.nat) {
          return (f1.sid == '2501' || f1.sid == '2503' || f1.sid == '2516' || f1.sid == '2520') && f1.nat.replace(/\s{2,}/g, ' ').trim().toLowerCase().includes('will win the toss');
        }
      });
      // console.log(data.data.t4[0]);
      if (data.data.t4[0]) {
        let tossData = {
          "mid": data.data.t4[0].mid,
          "sid": data.data.t4[0].sid,
          "nat": data.data.t4[0].nat,
          "b1": "1.00",
          "bs1": "90.00",
          "l1": "1.00",
          "ls1": "110.00",
          "b2": "0.00",
          "bs2": "0.00",
          "l2": "0.00",
          "ls2": "0.00",
          "b3": "0.00",
          "bs3": "0.00",
          "l3": "0.00",
          "ls3": "0.00",
          "gtype": "Fancy",
          "utime": "0",
          "gvalid": data.data.t4[0].gvalid,
          "gus": data.data.t4[0].gstatus,
          "remark": "",
          "min": "100.00",
          "max": "50000.00",
          "srno": "0",
          "s1": "0",
          "s2": "0",
          "ballsess": "1"
        }
        data.data.t3.push(tossData);
      }

    }
    // }

    if (data.data.t2) {
      data.data.t2 = data.data.t2.filter((book) => {
        return book.bm1[0].mname.indexOf('Bookmaker') > -1;
      });
    }

    if (data.gameId == "1802162242") {// if eventName is null
      data['name'] = "Pakistan Super League";
      if (data.data.t2) {
        data.data.t2.forEach(element => {
          element.bm1.forEach(runner => {
            runner.mname = "Bookmaker";
          });
        });
      }
    }

    if (data.gameId == "1808131147") { // if book maker b1 data different then replace b2
      if (data.data.t2) {
        data.data.t2[0].bm1 = data.data.t2[0].bm2;

      }
    }

    if (data.gameId == "32672932") {//  if 2 length in t2 array and 1st array bookmaker available
      if (data.data.t2) {
        let t2 = data.data.t2[0];
        data.data.t2 = [];
        data.data.t2.push(t2);
      }
    }
    if (data.gameId == "32851884") {// if 2 length in t2 array and 2nd array bookmaker available
      if (data.data.t2) {
        let t2 = data.data.t2[1];
        data.data.t2 = [];
        data.data.t2.push(t2);
      }
    }

    if (data.data.t3) {
      if (data.data.t3[0]) {
        data.data.t3.forEach((f1) => {
          if (f1.nat) {
            f1.nat = f1.nat.replace("\t", "");
            f1.nat = f1.nat.replace("'", "");
            f1.nat = f1.nat.replace(/\s+/g, ' ').trim();
            // f1.nat = f1.nat.replace(/\xa0/g, ' ');
            // f1.nat = f1.nat.replace(/\s/g,' ');
            // console.log(f1.nat)
          }
        });
        data.data.t3 = data.data.t3.filter((f1) => {
          if (f1.nat) {
            return !f1.nat.replace(/\s{2,}/g, ' ').trim().toLowerCase().includes('ball no boundaries');
          }
        });
        data.data.t3 = data.data.t3.filter((f1) => {
          if (f1.nat) {
            return !f1.nat.replace(/\s{2,}/g, ' ').trim().toLowerCase().includes('ball no boundareis');
          }
        });
        data.data.t3 = data.data.t3.filter((f1) => {
          if (f1.nat) {
            return !f1.nat.replace(/\s{2,}/g, ' ').trim().toLowerCase().includes('ball no boundries');
          }
        });
        data.data.t3 = data.data.t3.filter((f1) => {
          if (f1.nat) {
            return !f1.nat.replace(/\s{2,}/g, ' ').trim().toLowerCase().includes('balll run');
          }
        });
        data.data.t3 = data.data.t3.filter((f1) => {
          if (f1.nat) {
            return !f1.nat.replace(/\s{2,}/g, ' ').trim().toLowerCase().includes('demo ');
          }
        });
      }
    }

    if (data.gameId == '32747361') { //if mname is diff
      if (data.data.t2) {
        data.data.t2.forEach(element => {
          element.bm1.forEach(runner => {
            runner.mname = "Bookmaker";
          });
        });
      }

    }

    if (data.gameId == '32451294') { //if market id diffrent in diamond
      if (data.data.t2) {
        data.data.t2.forEach(element => {
          element.bm1.forEach(runner => {
            runner.mid = "1.215695580";
          });
        });
      }
      if (data.data.t3) {
        data.data.t3.forEach(element => {
          element.mid = "1.215695580";
        });
      }
    }

    if (data.gameId == '32723243') { //if bm1 null and bm2 availble 
      if (data.data.t2) {
        data.data.t2.forEach(element => {
          if (element.bm1.length == 0 && element.bm2.length > 0) {
            element.bm1 = element.bm2;
          }
        });
      }
    }

    if (data.gameId == "1802162242" || data.gameId == "42357775") { //if bf match and diamond manual match same change here bf id only
      var content = JSON.stringify(data);

      client.set('store_markets' + data.gameId, content);

      fs.writeFile('../../store_markets/' + data.gameId + '.json', content, (err) => {
        // console.log(err)
        if (err) {
          throw err;
        }
        // console.log('File saved!');
      });
      if (data.gameId == "1802162242") {//diamond eventId 1st match
        data.gameId = "28102621"; //change to betfair eventId 
        data.marketId = "1.224699772"; //change to betfair marketId 
      }
      if (data.gameId == "42357775") {//diamond eventId 2nd match
        data.gameId = "42372675"; //change to betfair eventId 
        data.marketId = "1.314529500"; //change to betfair marketId 
      }


      if (data.data.t2) {
        data.data.t2.forEach(element => {
          element.bm1.forEach(element2 => {
            element2.mid = data.marketId;
          })
        });
      }

      if (data.data.t3) {
        data.data.t3.forEach(element => {
          element.mid = data.marketId;
        });
      }
    }
    if (data.gameId == "" || data.name == "South Western Districts v Lions") {
      data.gameId = "30942960";
      data.marketId = "1.188145376";
    }



    var content = JSON.stringify(data);
    // var content=data;
    if (data.fn) {
      client.set('store_markets' + data.gameId + '_' + data.fn, content);

      fs.writeFile('../../store_markets/' + data.gameId + '_' + data.fn + '.json', content, (err) => {
        // console.log(err)
        if (err) {
          throw err;
        }
        // console.log('File saved!');
      });
    } else {

      client.set('store_markets' + data.gameId, content);


      fs.writeFile('../../store_markets/' + data.gameId + '.json', content, (err) => {
        // console.log(err)
        if (err) {
          throw err;
        }
        // console.log('File saved!');
      });
    }

  });

  socket.on('diamondCasinoData_333333', function (data) {




    // var content = data;
    data = JSON.parse(data);

    if (!data.success) {
      return
    }

    if (data.api == "rate" && data.gtype != "teen") {
      if (data.data.t2 && data.data.t1) {
        data.data.t2.forEach((element, index) => {
          element['mid'] = data.data.t1[0].mid;
        })
      }
    }
    var content = JSON.stringify(data);



    let folderName = "store_diamond_teenpatti_rates";

    if (data.api == "rate") {
      folderName = "store_diamond_teenpatti_rates";


      fs.writeFileSync('../../' + folderName + '/' + data.gtype + '.json', content, (err) => {
        // console.log(err)
        if (err) {
          throw err;
        }
        // console.log('File saved!');
      });
    } else if (data.api == "lresult") {
      folderName = "store_diamond_teenpatti_last_result";
      fs.writeFileSync('../../' + folderName + '/' + data.gtype + '.json', content, (err) => {
        // console.log(err)
        if (err) {
          throw err;
        }
        // console.log('File saved!');
      });
    } else if (data.api == "rresult") {
      folderName = "store_diamond_teenpatti_popup_result";
      if (data.data[0]) {
        fs.writeFileSync('../../' + folderName + '/' + data.data[0].gtype + '_' + data.data[0].mid + '.json', content, (err) => {
          // console.log(err)
          if (err) {
            throw err;
          }
          // console.log('File saved!');
        });
      } else {
        fs.writeFileSync('../../' + folderName + '/' + data.data.t1[0].gtype + '_' + data.data.t1[0].mid + '.json', content, (err) => {
          // console.log(err)
          if (err) {
            throw err;
          }
          // console.log('File saved!');
        });
      }


    }


    // io.emit('sendDiamondCasinoData', data);

  });

  socket.on('skyEventsData_333333', function (data) {
    var content = JSON.stringify(data);

    fs.writeFile('../../store_sky_highlight/' + data.eventType + '.json', content, (err) => {
      // console.log(err)
      if (err) {
        throw err;
      }
      // console.log('File saved!');
    });
    // io.emit('sendSkyEventsData', data);
  });

  socket.on('skyMarketData_333333', function (data) {

    var content = JSON.stringify(data);

    fs.writeFile('../../store_sky_markets/' + data.eventId + '.json', content, (err) => {
      // console.log(err)
      if (err) {
        throw err;
      }
      // console.log('File saved!');
    });
    // io.emit('sendSkyMarketData', data);
  });

  socket.on('skyBookData_333333', function (data) {

    if (data) {
      if (data.bookMakerEvent) {
        if (data.bookMakerEvent?.eventType == 1 && data.bookMakerEvent?.eventId < 0) {

          data.eventId = -(data.eventId);
          data.eventId = '17' + data.eventId;
          data.bookMakerEvent.highlightMarketId = '1.' + data.eventId;

          data.bookMakerEvent.eventId = data.eventId;
          data.bookMakerMarket.eventId = data.eventId;
          data.bookMakerSelection.eventId = data.eventId;
        }
      }
    }

    var content = JSON.stringify(data);

    client.set('store_sky_book' + data.eventId, content);

    fs.writeFile('../../store_sky_book/' + data.eventId + '.json', content, (err) => {
      // console.log(err)
      if (err) {
        throw err;
      }
      // console.log('File saved!');
    });
    // io.emit('sendSkyBookData', data);
  });

  socket.on('skyFancyData_333333', function (data) {

    var content = JSON.stringify(data);

    client.set('store_sky_fancy' + data.eventId, content);

    fs.writeFile('../../store_sky_fancy/' + data.eventId + '.json', content, (err) => {
      // console.log(err)
      if (err) {
        throw err;
      }
      // console.log('File saved!');
    });
    // io.emit('sendSkyFancyData', data);
  });

  let sportbookMapping = { // sportbook mapping sky to diamond
    "-10597232": {
      skyEventId: '-10597232',
      diamondEventId: 1803081512,
      diamondMarketId: 1.180308151313
    },
    "-10594818": {
      skyEventId: '-10594818',
      diamondEventId: 1803050515,
      diamondMarketId: 1.180305051919
    },
    "-10587200": {
      skyEventId: '-10587200',
      diamondEventId: 1802202240,
      diamondMarketId: 1.180220224040
    },

  }

  socket.on('skySportSBookData_333333', function (data) {

    if (data.score) {
      data.score = null;
    }

    // if (data.eventType == 4) {
    //   data.sportsBookMarket=[];
    // }

    if (data.sportsBookMarket) {
      data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
        return market.apiSiteStatus != "DEACTIVED";
      });

      data.sportsBookMarket.forEach(element => {
        element.apiSiteSpecifier = "";
        element.bookMode = "";
        element.closeSite = null;

      });
    }
    if (data.sportsBookMarket) {
      if (data.eventType == 1) {
        data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
          return !market.marketName.toLowerCase().includes('handicap');
        });
        data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
          return !market.marketName.toLowerCase().includes('which team wins');
        });
        data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
          return !market.marketName.toLowerCase().includes('double chance');
        });
        data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
          return !market.marketName.toLowerCase().includes('halftime/fulltime');
        });
        data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
          return !market.marketName.toLowerCase().includes('anytime goalscorer');
        });
        // data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
        //   return !market.marketName.toLowerCase().includes('anytime goalscorer');
        // });
        // if (data.isElectronic != 1) {
        //   data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
        //     return !market.marketName.toLowerCase().includes('1x2') && market.marketName.length > 3;
        //   });
        // }

        data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
          return !market.marketName.toLowerCase().includes('winner');
        });
      }
      if ((data.eventType == 4 && data.isElectronic != 1 && data.eventId > -1) || (data.eventType == 4 && data.eventId > -1)) {
        // if (data.eventId != "-10396580") {
        // data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
        //   return !market.marketName.toLowerCase().includes('winner');
        // });
      }
      data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
        return !market.marketName.toLowerCase().includes('run range');
      });
      data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
        return !market.marketName.toLowerCase().includes('dismissal method (extended)');
      });
      data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
        return !market.marketName.toLowerCase().includes(' dismissal method');
      });
      data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
        return !market.marketName.toLowerCase().includes('to hit a boundary');
      });
      data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
        return !market.marketName.toLowerCase().includes('total player performance');
      });
      data.sportsBookMarket = data.sportsBookMarket.filter((market) => {
        return !market.marketName.toLowerCase().includes('boundary four & a six');
      });

      // }
    }
    if (data.sportsBookMarket) {

      let spData = sportbookMapping[data.eventId];
      if (spData) {
        data.eventId = spData.diamondEventId;
        data.highlightMarketId = spData.diamondMarketId;

        data.sportsBookMarket.forEach(market => {
          market.betfairEventId = data.eventId;
          if (market.sportsBookSelection) {
            market.sportsBookSelection.forEach(selection => {
              selection.betfairEventId = data.eventId;
            });
          }
        });
      }

      // if (data.eventId == "-10594955") {
      //   data.eventId = 1803051601;
      //   data.highlightMarketId = 1.180305160202;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }
      // if (data.eventId == "-10594818") {//kabaddi
      //   data.eventId = 1803050515;
      //   data.highlightMarketId = 1.180305051919;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }
      // if (data.eventId == "-10594535") {
      //   data.eventId = 1803041557;
      //   data.highlightMarketId = 1.180304155959;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }
      // if (data.eventId == "-10582742") {//test
      //   data.eventId = 1802132200;
      //   data.highlightMarketId = 1.180213220101;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }

      // if (data.eventId == "-10596637") {
      //   data.eventId = 1803072053;
      //   data.highlightMarketId = 1.180307205454;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }

      // if (data.eventId == "-10597110") {
      //   data.eventId = 1803081504;
      //   data.highlightMarketId = 1.180308150606;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }
      // if (data.eventId == "-10596957") {
      //   data.eventId = 1803081231;
      //   data.highlightMarketId = 1.180308123333;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }
      // if (data.eventId == "-10492457") {
      //   data.eventId = 1808250109;
      //   data.highlightMarketId = 1.180825011111;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }
      // if (data.eventId == "-104134645") {
      //   data.eventId = 18081612341;
      //   data.highlightMarketId = 1.1804291811313;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }
      // if (data.eventId == "-104129341") {
      //   data.eventId = 17104219341;
      //   data.highlightMarketId = 1.17104219341;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }
      // if (data.eventId == "-104417231") {
      //   data.eventId = 18052022154;
      //   data.highlightMarketId = 1.1805202125656;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }
      // if (data.eventId == "-101453191") {
      //   data.eventId = 18060511723;
      //   data.highlightMarketId = 1.1806015172424;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }
      // if (data.eventId == "-104531192") {
      //   data.eventId = 18060511726;
      //   data.highlightMarketId = 1.1806105172727;

      //   data.sportsBookMarket.forEach(market => {
      //     market.betfairEventId = data.eventId;
      //     if (market.sportsBookSelection) {
      //       market.sportsBookSelection.forEach(selection => {
      //         selection.betfairEventId = data.eventId;
      //       });
      //     }
      //   });
      // }
    }
    //for SRL matches dont do this here and manual matches
    if ((data.isElectronic == 1 && data.sportsBookMarket) || (data.eventId < 0 && data.sportsBookMarket)) {
      data.eventId = -(data.eventId);
      data.eventId = '17' + data.eventId;
      data.highlightMarketId = '1.' + data.eventId;

      data.sportsBookMarket.forEach(market => {
        market.betfairEventId = data.eventId;
        if (market.sportsBookSelection) {
          market.sportsBookSelection.forEach(selection => {
            selection.betfairEventId = data.eventId;
          });
        }
      });
    }

    var content = JSON.stringify(data);

    // client.set('store_sky_sportbook' + data.eventId, content, 'EX', 10, callback);

    client.set('store_sky_sportbook' + data.eventId, content);


    // fs.writeFile('../../store_sky_sportbook/' + data.eventId + '.json', content, (err) => {
    //   // console.log(err)
    //   if (err) {
    //     throw err;
    //   }
    //   // console.log('File saved!');
    // });
    // io.emit('sendSkySportSBookData', data);
  });

  socket.on('eventResultsData_333333', function (data) {

    var content = JSON.stringify(data);

    fs.writeFile('../../store_sky_event_result/' + data.sport + '_' + data.type + '.json', content, (err) => {
      // console.log(err)
      if (err) {
        throw err;
      }
      // console.log('File saved!');
    });
    // io.emit('sendEventResultsData', data);
  });
  socket.on('disconnect', function () {
    console.log('user disconnected');
    userconnected--;
    console.log(userconnected);
  });
});


http.listen(3030, function () {
  console.log('listening on *:3030');
});
