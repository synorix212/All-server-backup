var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var _ = require('lodash');
var fs = require('fs');

var cors = require('cors');
const { json } = require('express');

// var requestIp = require('request-ip');

// const redis = require('redis');
// const redisPort = 6379;
// const client = redis.createClient(redisPort);

app.use(cors());

app.use(json({ limit: '50mb' }));

app.get('/', function (req, res) {
    res.send('VRNL.NET');
});


let BfDataStore = {};
app.post('/bfdata', json({ type: '*/*' }), function (req, res) {

    // console.log(req.body)
    if (!req.body) {
        return;
    }

    req.body.forEach(market => {
        var content = JSON.stringify(market);
        BfDataStore[market.MarketId] = market;
        fs.writeFile('../../store_ssexch_markets/' + market.MarketId + '.json', content, (err) => {
            // console.log(err)
            if (err) {
                throw err;
            }
            // console.log('File saved!');
        });
    });


    res.send('saved');
});


function doSomethingAsync(marketId) {
    return new Promise((resolve) => {

        if (BfDataStore[marketId]) {
            resolve(BfDataStore[marketId]);
        } else {
            resolve([]);
        }

        // const data = fs.readFile('../../store_ssexch_markets/' + marketId + '.json', 'utf8', (err, data) => {
        //     if (err) {
        //         resolve([]);
        //         return null;
        //     }
        //     if (data) {
        //         try {
        //             data = JSON.parse(data);
        //         } catch (err) {
        //             console.error(err)
        //         }
        //         resolve(data);
        //     }
        //     else {
        //         resolve([]);
        //     }
        // })
    });
}

app.get('/api/markets/:marketIds', function (req, res) {

    let splitMarketIds = req.params.marketIds.split(',');

    const promises = [];

    for (let i = 0; i < splitMarketIds.length; i++) {
        let market = doSomethingAsync(splitMarketIds[i]);
        promises.push(market);
    }

    Promise.all(promises)
        .then((results) => {
            results = results.filter((result) => {
                // console.log(result.length)
                return result.length != 0;
            })
            res.send(results);
        })
        .catch((e) => {
            // Handle errors here
            res.send(e);
        });

});

http.listen(3031, function () {
    console.log('listening on *:3031');
});